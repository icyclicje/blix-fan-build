"""Build the browser version of Blix from your own copy of the iOS package.

    python tools/build.py "path/to/Blix 1.03.ipa"
    python tools/build.py --scripts      (re-bundle engine + mods only)

What it does:
  1. extracts the .ipa (a zip) into tools/.work
  2. unpacks resource.car (Corona's archive of compiled Lua 5.1 scripts)
  3. decompiles each script with unluac (Java; downloaded on first run)
  4. repairs a decompiler artifact (fix_multret.py) and applies web patches
  5. converts Apple-"crushed" PNGs (CgBI) back to standard PNGs
  6. writes game-data.js (scripts + assets) and engine/engine-lua.js

Requires Python 3 with Pillow and numpy, and Java 8+.
The output contains the game's original code and art: keep it for personal use.
"""
import base64, io, json, os, pathlib, shutil, struct, subprocess, sys, urllib.request, zipfile, zlib

import numpy as np
from PIL import Image

ROOT = pathlib.Path(__file__).resolve().parent.parent
TOOLS = ROOT / 'tools'
WORK = TOOLS / '.work'
UNLUAC = TOOLS / 'unluac.jar'
UNLUAC_URL = 'https://sourceforge.net/projects/unluac/files/latest/download'

sys.path.insert(0, str(TOOLS))
import fix_multret  # noqa: E402


def log(msg):
    print(msg, flush=True)


# --------------------------------------------------------------------------
# resource.car
# --------------------------------------------------------------------------

def unpack_car(path):
    d = path.read_bytes()
    if d[:4] != b'rac\x01':
        raise SystemExit('resource.car: unexpected header')
    _rev, _data_off, count = struct.unpack_from('<III', d, 4)
    pos = 16
    out = {}
    for _ in range(count):
        _typ, off, ln = struct.unpack_from('<III', d, pos)
        pos += 12
        name = d[pos:pos + ln].decode()
        pos += (ln + 4) & ~3
        _tag, _nxt, size = struct.unpack_from('<III', d, off)
        out[name] = d[off + 12: off + 12 + size]
    return out


def ensure_unluac():
    if UNLUAC.exists():
        return
    log('downloading unluac ...')
    with urllib.request.urlopen(UNLUAC_URL) as r:
        UNLUAC.write_bytes(r.read())


def decompile(bytecode_dir, out_dir):
    out_dir.mkdir(parents=True, exist_ok=True)
    for f in sorted(bytecode_dir.glob('*.lu')):
        res = subprocess.run(['java', '-jar', str(UNLUAC), str(f)], capture_output=True)
        if res.returncode != 0:
            raise SystemExit(f'unluac failed on {f.name}: {res.stderr.decode(errors="replace")}')
        (out_dir / (f.stem + '.lua')).write_bytes(res.stdout)


# --------------------------------------------------------------------------
# web patches to the decompiled scripts
# --------------------------------------------------------------------------

SCREEN_OLD_START = '  else\n    L4_2 = _MODEL\n    L5_2 = L4_2\n    L4_2 = L4_2.find\n    L6_2 = "iPhone"'
SCREEN_OLD_END = '  ::lbl_141::\n'
SCREEN_NEW = '''  else
    -- (web build) unluac emitted a goto into a nested block here; same logic, restructured
    if _MODEL:find("iPhone") or _MODEL:find("iPod") then
      if _iVersion < 5 then
        _diagonalInches = 3.5
      else
        _diagonalInches = 4
      end
    elseif _MODEL:find("iPad") then
      _diagonalInches = 9.7
    else
      _diagonalInches = 4
    end
  end
'''


def patch_scripts(lua_dir):
    p = lua_dir / '_screen.lua'
    src = p.read_text(encoding='utf-8')
    a = src.find(SCREEN_OLD_START)
    b = src.find(SCREEN_OLD_END, a)
    if a < 0 or b < 0:
        raise SystemExit('_screen.lua: patch anchor not found')
    p.write_text(src[:a] + SCREEN_NEW + src[b + len(SCREEN_OLD_END):], encoding='utf-8')

    # Third-party SDK wrappers are replaced by stubs in engine/lua/corona_init.lua.
    # _kiip_utils does not even parse (decompiler goto), so drop it.
    (lua_dir / '_kiip_utils.lua').unlink(missing_ok=True)

    report = []
    total = 0
    for f in sorted(lua_dir.glob('*.lua')):
        new, n = fix_multret.fix(f.read_text(encoding='utf-8'), f.name, report)
        if n:
            f.write_text(new, encoding='utf-8')
            total += n
    log(f'  repaired {total} truncated multi-value calls')


# --------------------------------------------------------------------------
# Apple CgBI ("crushed") PNG -> standard PNG
# --------------------------------------------------------------------------

def _paeth(a, b, c):
    p = a.astype(np.int16) + b - c
    pa, pb, pc = np.abs(p - a), np.abs(p - b), np.abs(p - c)
    return np.where((pa <= pb) & (pa <= pc), a, np.where(pb <= pc, b, c))


def decode_png(data):
    """Decode a PNG that may be CgBI-crushed. Returns a PIL image."""
    if data[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('not a PNG')
    pos, idat, cgbi = 8, b'', False
    w = h = depth = ctype = interlace = None
    while pos < len(data):
        ln = struct.unpack('>I', data[pos:pos + 4])[0]
        typ = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if typ == b'CgBI':
            cgbi = True
        elif typ == b'IHDR':
            w, h, depth, ctype, _c, _f, interlace = struct.unpack('>IIBBBBB', body)
        elif typ == b'IDAT':
            idat += body
        elif typ == b'IEND':
            break
    if not cgbi:
        return Image.open(io.BytesIO(data))
    if depth != 8 or ctype not in (2, 6) or interlace:
        raise ValueError(f'unsupported CgBI PNG (depth={depth}, color={ctype}, interlace={interlace})')
    bpp = 4 if ctype == 6 else 3
    raw = zlib.decompress(idat, -15)
    stride = w * bpp
    rows = np.frombuffer(raw, dtype=np.uint8).reshape(h, stride + 1)
    out = np.zeros((h, stride), dtype=np.uint8)
    prev = np.zeros(stride, dtype=np.uint8)
    for y in range(h):
        ft = rows[y, 0]
        line = rows[y, 1:].copy()
        if ft == 0:
            pass
        elif ft == 2:
            line = (line + prev).astype(np.uint8)
        elif ft in (1, 3, 4):
            # these depend on the reconstructed left neighbour: do it pixel-column by pixel-column
            cur = np.zeros(stride, dtype=np.uint8)
            for x in range(0, stride, bpp):
                left = cur[x - bpp:x] if x >= bpp else np.zeros(bpp, dtype=np.uint8)
                up = prev[x:x + bpp]
                if ft == 1:
                    val = line[x:x + bpp].astype(np.uint16) + left
                elif ft == 3:
                    val = line[x:x + bpp].astype(np.uint16) + ((left.astype(np.uint16) + up) >> 1)
                else:
                    ul = prev[x - bpp:x] if x >= bpp else np.zeros(bpp, dtype=np.uint8)
                    val = line[x:x + bpp].astype(np.uint16) + _paeth(left, up, ul)
                cur[x:x + bpp] = (val & 255).astype(np.uint8)
            line = cur
        else:
            raise ValueError(f'bad PNG filter {ft}')
        out[y] = line
        prev = line
    px = out.reshape(h, w, bpp).astype(np.float64)
    # BGR(A) -> RGB(A)
    px = px[:, :, [2, 1, 0, 3]] if bpp == 4 else px[:, :, [2, 1, 0]]
    if bpp == 4:
        a = px[:, :, 3:4]
        # undo premultiplied alpha
        with np.errstate(divide='ignore', invalid='ignore'):
            rgb = np.where(a > 0, np.clip(np.round(px[:, :, :3] * 255.0 / a), 0, 255), 0)
        px = np.concatenate([rgb, a], axis=2)
        return Image.fromarray(px.astype(np.uint8), 'RGBA')
    return Image.fromarray(px.astype(np.uint8), 'RGB')


def png_bytes(path):
    img = decode_png(path.read_bytes())
    buf = io.BytesIO()
    img.save(buf, 'PNG', optimize=True)
    return buf.getvalue()


# --------------------------------------------------------------------------
# fonts
# --------------------------------------------------------------------------

def strip_tables(data, drop):
    """Rebuild an sfnt without the given tables (browsers reject some malformed optional ones)."""
    num = struct.unpack('>H', data[4:6])[0]
    recs = []
    for i in range(num):
        tag, cs, off, ln = struct.unpack('>4sIII', data[12 + 16 * i:28 + 16 * i])
        if tag.decode('latin1') not in drop:
            recs.append((tag, cs, data[off:off + ln]))
    if len(recs) == num:
        return data
    n = len(recs)
    es = n.bit_length() - 1
    sr = (1 << es) * 16
    out = bytearray(data[:4] + struct.pack('>HHHH', n, sr, es, n * 16 - sr))
    offset = 12 + 16 * n
    body = bytearray()
    for tag, cs, blob in recs:
        out += struct.pack('>4sIII', tag, cs, offset + len(body), len(blob))
        body += blob + bytes(1) * (-len(blob) % 4)
    return bytes(out + body)


def font_family(data):
    num = struct.unpack('>H', data[4:6])[0]
    for i in range(num):
        tag, _cs, off, _ln = struct.unpack('>4sIII', data[12 + 16 * i:28 + 16 * i])
        if tag != b'name':
            continue
        _fmt, count, so = struct.unpack('>HHH', data[off:off + 6])
        for j in range(count):
            pid, _eid, _lid, nid, ln, o = struct.unpack('>HHHHHH', data[off + 6 + 12 * j:off + 18 + 12 * j])
            if nid == 1:
                s = data[off + so + o:off + so + o + ln]
                return s.decode('utf-16-be') if pid in (0, 3) else s.decode('latin1')
    return None


# --------------------------------------------------------------------------
# bundling
# --------------------------------------------------------------------------

def clear_dir(d):
    """Empty a directory without removing it (it may be open in a shell or editor)."""
    d.mkdir(parents=True, exist_ok=True)
    for child in d.iterdir():
        if child.is_dir():
            shutil.rmtree(child)
        else:
            child.unlink()


def js_bundle(var, obj):
    return f'window.{var} = ' + json.dumps(obj, separators=(',', ':'), ensure_ascii=True) + ';\n'


def bundle_engine():
    lua = {p.stem: p.read_text(encoding='utf-8') for p in sorted((ROOT / 'engine' / 'lua').glob('*.lua'))}
    (ROOT / 'engine' / 'engine-lua.js').write_text(
        '/* Engine Lua modules (corona_init + Solar2D timer/transition/easing/composer/json, MIT). Generated by tools/build.py */\n'
        + js_bundle('ENGINE_LUA', lua), encoding='utf-8')
    log(f'  engine/engine-lua.js: {len(lua)} modules')


def bundle_mods():
    mods_dir = ROOT / 'mods'
    lua = {p.stem: p.read_text(encoding='utf-8') for p in sorted(mods_dir.glob('*.lua'))}
    (mods_dir / 'mods-lua.js').write_text(
        '/* Blix! 1.0 additions (mods/*.lua). Generated by tools/build.py */' + chr(10)
        + js_bundle('MODS_LUA', lua), encoding='utf-8')
    log(f'  mods/mods-lua.js: {len(lua)} modules')


def bundle_game(app, lua_dir):
    files = {}
    res_dir = ROOT / 'game' / 'res'
    clear_dir(res_dir)
    for sub in ('images', 'sounds'):
        for f in sorted((app / sub).glob('*')):
            if not f.is_file():
                continue
            rel = f'{sub}/{f.name}'
            if f.suffix.lower() == '.png':
                data, mime, kind = png_bytes(f), 'image/png', 'image'
            elif f.suffix.lower() in ('.jpg', '.jpeg'):
                data, mime, kind = f.read_bytes(), 'image/jpeg', 'image'
            elif f.suffix.lower() in ('.mp3', '.wav', '.caf', '.ogg', '.m4a'):
                data, mime, kind = f.read_bytes(), None, 'audio'
            else:
                continue
            out = res_dir / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(data)
            entry = {'type': kind, 'b64': base64.b64encode(data).decode('ascii')}
            if mime:
                entry['mime'] = mime
            files[rel] = entry
    for f in sorted(app.glob('_font_*')):
        data = strip_tables(f.read_bytes(), {'hdmx'})
        files[f.name] = {'type': 'font', 'family': font_family(data), 'b64': base64.b64encode(data).decode('ascii')}
    for name in ('bbs.txt',):
        if (app / name).exists():
            files[name] = {'type': 'text', 'data': (app / name).read_text(encoding='utf-8')}
    # launch image + icon for the start screen
    for name, key in (('Default-568h@2x.png', 'launch.png'), ('Icon-152.png', 'icon.png')):
        if (app / name).exists():
            data = png_bytes(app / name)
            (res_dir / key).write_bytes(data)
    lua = {p.stem: p.read_text(encoding='utf-8') for p in sorted(lua_dir.glob('*.lua'))}
    (ROOT / 'game-data.js').write_text(
        '/* Blix game data extracted from the original .ipa by tools/build.py. Personal use only. */\n'
        + js_bundle('GAME_DATA', {'lua': lua, 'files': files}), encoding='utf-8')
    log(f'  game-data.js: {len(lua)} scripts, {len(files)} assets')


def main():
    if len(sys.argv) >= 2 and sys.argv[1] == '--scripts':
        # re-bundle the engine and mod scripts only (no .ipa needed)
        bundle_engine()
        bundle_mods()
        return
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    ipa = pathlib.Path(sys.argv[1])
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)
    log('extracting ' + ipa.name)
    with zipfile.ZipFile(ipa) as z:
        z.extractall(WORK / 'ipa')
    apps = list((WORK / 'ipa' / 'Payload').glob('*.app'))
    if not apps:
        raise SystemExit('no Payload/*.app in the .ipa')
    app = apps[0]
    log('unpacking resource.car')
    bc_dir = WORK / 'bytecode'
    bc_dir.mkdir()
    for name, blob in unpack_car(app / 'resource.car').items():
        (bc_dir / name).write_bytes(blob)
    ensure_unluac()
    log('decompiling scripts')
    lua_dir = ROOT / 'game' / 'lua'
    clear_dir(lua_dir)
    decompile(bc_dir, lua_dir)
    log('patching scripts')
    patch_scripts(lua_dir)
    log('bundling')
    bundle_engine()
    bundle_mods()
    bundle_game(app, lua_dir)
    shutil.rmtree(WORK, ignore_errors=True)
    log('done - open index.html')


if __name__ == '__main__':
    main()
