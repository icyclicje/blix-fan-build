"""Repair a decompiler artifact in unluac output.

Lua 5.1 bytecode passes "all results" of a call (or of ...) straight into the
next call / return. Without debug info, unluac renders that as an assignment
to every register up to the end of the stack frame, e.g.

    local L0_4, L1_4, L2_4, L3_4
    L2_4, L3_4 = L2_4()          -- really: all results
    L0_4(L1_4, L2_4, L3_4)       -- really: L0_4(L1_4, L2_4())

which silently truncates the values when the frame is small. This rewrites
such pairs back to the nested form so every result is passed through.
"""
import re, sys, pathlib

DECL = re.compile(r'^\s*local ((?:L\d+_\d+)(?:, L\d+_\d+)*)\s*$')
MULTI = re.compile(r'^(\s*)((?:L\d+_\d+)(?:, L\d+_\d+)+) = (.+)$')
REG = re.compile(r'L(\d+)_(\d+)$')

def regs(s):
    return [r.strip() for r in s.split(',')]

def fix(src, name, report):
    lines = src.split('\n')
    maxreg = {}          # level -> highest register index of the current function
    out = []
    i = 0
    changed = 0
    while i < len(lines):
        line = lines[i]
        m = DECL.match(line)
        if m:
            rs = regs(m.group(1))
            lv = REG.match(rs[-1]).group(2)
            maxreg[lv] = int(REG.match(rs[-1]).group(1))
        m = MULTI.match(line)
        if m:
            lhs = regs(m.group(2))
            rhs = m.group(3)
            parsed = [REG.match(r) for r in lhs]
            lv = parsed[0].group(2)
            idx = [int(p.group(1)) for p in parsed]
            consecutive = all(p.group(2) == lv for p in parsed) and idx == list(range(idx[0], idx[0] + len(idx)))
            is_multret_rhs = rhs.strip() == '...' or rhs.rstrip().endswith(')')
            if consecutive and is_multret_rhs and maxreg.get(lv) == idx[-1] and i + 1 < len(lines):
                nxt = lines[i + 1]
                tail = ', '.join(lhs)
                done = False
                # trailing arguments of a call:  f(a, b, Lx, Ly)
                for pre in ('(' , ', '):
                    pat = pre + tail + ')'
                    if nxt.rstrip().endswith(pat) and nxt.count(tail) == 1:
                        new = nxt.rstrip()[: -len(pat)] + pre + rhs.strip() + ')'
                        report.append(f'{name}:{i+1}: {line.strip()} | {nxt.strip()}  =>  {new.strip()}')
                        out.append(new)
                        i += 2
                        changed += 1
                        done = True
                        break
                if not done and re.match(r'^\s*return ' + re.escape(tail) + r'\s*$', nxt):
                    new = re.sub(re.escape(tail), rhs.strip(), nxt, count=1)
                    report.append(f'{name}:{i+1}: {line.strip()} | {nxt.strip()}  =>  {new.strip()}')
                    out.append(new)
                    i += 2
                    changed += 1
                    done = True
                if done:
                    continue
                report.append(f'{name}:{i+1}: UNHANDLED {line.strip()} | {nxt.strip()}')
        out.append(line)
        i += 1
    return '\n'.join(out), changed

if __name__ == '__main__':
    report = []
    total = 0
    for p in sys.argv[1:]:
        path = pathlib.Path(p)
        src = path.read_text(encoding='utf-8')
        new, n = fix(src, path.name, report)
        if n:
            path.write_text(new, encoding='utf-8')
            total += n
    print('\n'.join(report))
    print(f'rewrote {total} truncated multi-value calls')
