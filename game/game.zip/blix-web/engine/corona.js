/*
 * corona.js
 * A small browser runtime that implements the part of the Corona SDK
 * (Graphics 2.0, 2014) API that Blix uses. The game's own Lua scripts run
 * unchanged on Fengari (a Lua VM written in JavaScript); this file supplies
 * display objects, rendering (Canvas 2D), touch input, audio, storage and
 * the system/native/network libraries.
 */
(function () {
'use strict';

const F = window.fengari;
const { lua, lauxlib, lualib } = F;
const to_luastring = F.to_luastring;
const to_jsstring = F.to_jsstring;
const REG = lua.LUA_REGISTRYINDEX;
const T_NIL = lua.LUA_TNIL, T_BOOL = lua.LUA_TBOOLEAN, T_LUD = lua.LUA_TLIGHTUSERDATA,
      T_NUM = lua.LUA_TNUMBER, T_STR = lua.LUA_TSTRING, T_TABLE = lua.LUA_TTABLE,
      T_FUNC = lua.LUA_TFUNCTION;

// Virtual device: a 1920x1080 landscape screen.
const DEVICE_W = 1920, DEVICE_H = 1080;
const FRAME_MS = 1000 / 60;

let L = null;
let canvas, ctx, measureCtx;
let view = { x: 0, y: 0, w: DEVICE_W, h: DEVICE_H, k: 1 };
const metrics = {};        // content metrics (contentWidth, screenOriginX, ...)
let stage = null;
let DOCLASS = 0;           // registry ref of the Lua DisplayObject class
const assets = { images: new Map(), sounds: new Map(), fonts: new Map(), texts: new Map(), lua: new Map() };

/* ------------------------------------------------------------------ */
/* Lua helpers                                                         */
/* ------------------------------------------------------------------ */

const lstrCache = new Map();
function lstr(s) {
	let u = lstrCache.get(s);
	if (u === undefined) {
		u = to_luastring(s);
		if (s.length <= 48) lstrCache.set(s, u);
	}
	return u;
}
function pushstr(s) { lua.lua_pushstring(L, lstr(s)); }
const keyCache = new WeakMap();
function keyAt(i) {
	const u = lua.lua_tostring(L, i);
	let s = keyCache.get(u);
	if (s === undefined) { s = to_jsstring(u); keyCache.set(u, s); }
	return s;
}
function typeAt(i) { return lua.lua_type(L, i); }
function numAt(i, d) { return lua.lua_type(L, i) === T_NUM ? lua.lua_tonumber(L, i) : d; }
function strAt(i, d) {
	const t = lua.lua_type(L, i);
	if (t === T_STR) return lua.lua_tojsstring(L, i);
	if (t === T_NUM) return String(fmtNum(lua.lua_tonumber(L, i)));
	return d;
}
function boolAt(i) { return lua.lua_toboolean(L, i); }
function argc() {
	let n = lua.lua_gettop(L);
	while (n > 0 && lua.lua_type(L, n) === T_NIL) n--;
	return n;
}
function fmtNum(n) {
	if (Number.isInteger(n)) return String(n);
	return String(Number(n.toPrecision(14)));
}
function pushnum(n) { lua.lua_pushnumber(L, n); }
function field(idx, name) { lua.lua_getfield(L, idx, lstr(name)); return lua.lua_type(L, -1); }
function fieldNum(idx, name, d) { field(idx, name); const v = numAt(-1, d); lua.lua_pop(L, 1); return v; }
function fieldStr(idx, name, d) { field(idx, name); const v = strAt(-1, d); lua.lua_pop(L, 1); return v; }
function fieldBool(idx, name, d) {
	const t = field(idx, name);
	const v = t === T_NIL ? d : lua.lua_toboolean(L, -1);
	lua.lua_pop(L, 1);
	return v;
}
function setfield(name, pushfn) { pushfn(); lua.lua_setfield(L, -2, lstr(name)); }

// Push a JS value as a Lua value (tables become fresh Lua tables).
function pushValue(v) {
	if (v === null || v === undefined) lua.lua_pushnil(L);
	else if (typeof v === 'number') lua.lua_pushnumber(L, v);
	else if (typeof v === 'string') pushstr(v);
	else if (typeof v === 'boolean') lua.lua_pushboolean(L, v);
	else if (v instanceof DObj) pushObj(v);
	else if (v && v.__luaref) lua.lua_rawgeti(L, REG, v.__luaref);
	else if (typeof v === 'function') lua.lua_pushcfunction(L, v);
	else if (Array.isArray(v)) {
		lua.lua_createtable(L, v.length, 0);
		v.forEach((x, i) => { pushValue(x); lua.lua_rawseti(L, -2, i + 1); });
	} else if (typeof v === 'object') {
		lua.lua_createtable(L, 0, 4);
		for (const k in v) {
			if (v[k] === undefined || v[k] === null) continue;
			pushValue(v[k]);
			lua.lua_setfield(L, -2, lstr(k));
		}
	} else lua.lua_pushnil(L);
}

function traceback(Ls) {
	const msg = lua.lua_tojsstring(Ls, 1);
	lauxlib.luaL_traceback(Ls, Ls, to_luastring(msg == null ? String(lua.lua_touserdata(Ls, 1)) : msg), 1);
	return 1;
}

// Call the function sitting below `nargs` arguments on the stack.
function pcall(nargs, nres) {
	const base = lua.lua_gettop(L) - nargs;
	lua.lua_pushcfunction(L, traceback);
	lua.lua_insert(L, base);
	const st = lua.lua_pcall(L, nargs, nres, base);
	lua.lua_remove(L, base);
	if (st !== lua.LUA_OK) {
		const msg = lua.lua_tojsstring(L, -1);
		lua.lua_pop(L, 1);
		reportError(msg);
		return false;
	}
	return true;
}

function reportError(msg) {
	console.error('Lua runtime error:\n' + msg);
	if (window.CoronaWeb && window.CoronaWeb.onError) window.CoronaWeb.onError(msg);
}

function ref() { return lauxlib.luaL_ref(L, REG); }
function unref(r) { if (r) lauxlib.luaL_unref(L, REG, r); }

// Call a registry-referenced listener (function or table with method `name`).
function callListener(listenerRef, name, event) {
	if (!listenerRef) return;
	lua.lua_rawgeti(L, REG, listenerRef);
	if (lua.lua_type(L, -1) === T_FUNC) {
		pushValue(event);
		pcall(1, 0);
	} else if (lua.lua_type(L, -1) === T_TABLE) {
		lua.lua_getfield(L, -1, lstr(name));
		if (lua.lua_type(L, -1) === T_FUNC) {
			lua.lua_insert(L, -2);
			pushValue(event);
			pcall(2, 0);
		} else lua.lua_pop(L, 2);
	} else lua.lua_pop(L, 1);
}

/* ------------------------------------------------------------------ */
/* Display objects                                                     */
/* ------------------------------------------------------------------ */

const objMap = new WeakMap();
const defaults = { anchorX: 0.5, anchorY: 0.5, isAnchorClamped: true,
	fillColor: [1, 1, 1, 1], strokeColor: [1, 1, 1, 1], lineColor: [1, 1, 1, 1], textColor: [1, 1, 1, 1] };

class DObj {
	constructor(kind) {
		this.kind = kind;
		this.x = 0; this.y = 0;
		this.rotation = 0; this.xScale = 1; this.yScale = 1;
		this.alpha = 1; this.isVisible = true; this.isHitTestable = false;
		this.anchorX = defaults.anchorX; this.anchorY = defaults.anchorY;
		this.parent = null; this.removed = false; this.ref = 0;
		this.listens = Object.create(null);
		this.w = 0; this.h = 0;
	}
}

function objAt(i) {
	const p = lua.lua_topointer(L, i);
	return p ? objMap.get(p) : undefined;
}
function pushObj(o) {
	if (!o || o.removed || !o.ref) lua.lua_pushnil(L);
	else lua.lua_rawgeti(L, REG, o.ref);
}

const KINDS = {};
function bind(o) {
	lua.lua_createtable(L, 0, 0);
	lua.lua_rawgeti(L, REG, KINDS[o.kind].mt);
	lua.lua_setmetatable(L, -2);
	objMap.set(lua.lua_topointer(L, -1), o);
	lua.lua_pushvalue(L, -1);
	o.ref = ref();
	return o;
}

function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

function insertChild(group, child, index) {
	if (!group || !group.children || child === group) return;
	for (let p = group; p; p = p.parent) if (p === child) return;
	if (child.parent) {
		const arr = child.parent.children;
		const i = arr.indexOf(child);
		if (i >= 0) arr.splice(i, 1);
	}
	const arr = group.children;
	if (index === undefined || index > arr.length) arr.push(child);
	else arr.splice(Math.max(0, index - 1), 0, child);
	child.parent = group;
}

function removeObj(o) {
	if (o.removed || o === stage) return;
	if (o.children) {
		const kids = o.children.slice();
		for (const c of kids) removeObj(c);
	}
	if (o.parent) {
		const arr = o.parent.children;
		const i = arr.indexOf(o);
		if (i >= 0) arr.splice(i, 1);
	}
	o.parent = null;
	o.removed = true;
	for (const k in focus) if (focus[k] === o) delete focus[k];
	unref(o.ref);
	o.ref = 0;
	if (o.kind === 'image') o.tintCache = null;
}

/* ---- geometry ---- */

function localMatrix(o) {
	let ox = 0, oy = 0;
	if (o.children) {
		if (o.anchorChildren) {
			const b = groupBounds(o);
			if (b) { ox = -(b[0] + o.anchorX * (b[2] - b[0])); oy = -(b[1] + o.anchorY * (b[3] - b[1])); }
		}
	} else if (o.kind !== 'line') {
		ox = (0.5 - o.anchorX) * o.w;
		oy = (0.5 - o.anchorY) * o.h;
	}
	let a = o.xScale, b = 0, c = 0, d = o.yScale;
	if (o.rotation !== 0) {
		const r = o.rotation * Math.PI / 180, cs = Math.cos(r), sn = Math.sin(r);
		a = cs * o.xScale; b = sn * o.xScale; c = -sn * o.yScale; d = cs * o.yScale;
	}
	return [a, b, c, d, o.x + a * ox + c * oy, o.y + b * ox + d * oy];
}
function mul(m, n) {
	return [
		m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1],
		m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3],
		m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]];
}
function invert(m) {
	const det = m[0] * m[3] - m[1] * m[2];
	if (Math.abs(det) < 1e-12) return null;
	const id = 1 / det;
	return [m[3] * id, -m[1] * id, -m[2] * id, m[0] * id,
		(m[2] * m[5] - m[3] * m[4]) * id, (m[1] * m[4] - m[0] * m[5]) * id];
}
function apply(m, x, y) { return [m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]]; }
function worldMatrix(o) {
	let m = localMatrix(o);
	for (let p = o.parent; p; p = p.parent) m = mul(localMatrix(p), m);
	return m;
}
function xformBounds(m, b) {
	const p1 = apply(m, b[0], b[1]), p2 = apply(m, b[2], b[1]), p3 = apply(m, b[0], b[3]), p4 = apply(m, b[2], b[3]);
	return [Math.min(p1[0], p2[0], p3[0], p4[0]), Math.min(p1[1], p2[1], p3[1], p4[1]),
		Math.max(p1[0], p2[0], p3[0], p4[0]), Math.max(p1[1], p2[1], p3[1], p4[1])];
}
function union(a, b) {
	if (!a) return b;
	if (!b) return a;
	return [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.max(a[2], b[2]), Math.max(a[3], b[3])];
}
// Bounds of an object's own geometry, before its own transform.
function selfBounds(o) {
	if (o.children) return groupBounds(o);
	if (o.kind === 'line') {
		const p = o.pts;
		let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
		for (let i = 0; i < p.length; i += 2) {
			x0 = Math.min(x0, p[i]); x1 = Math.max(x1, p[i]);
			y0 = Math.min(y0, p[i + 1]); y1 = Math.max(y1, p[i + 1]);
		}
		return [x0, y0, x1, y1];
	}
	return [-o.w / 2, -o.h / 2, o.w / 2, o.h / 2];
}
function groupBounds(g) {
	let b = null;
	for (const c of g.children) {
		const cb = selfBounds(c);
		if (cb) b = union(b, xformBounds(localMatrix(c), cb));
	}
	return b;
}
function contentBounds(o) {
	const b = selfBounds(o);
	if (!b) { const p = apply(worldMatrix(o), 0, 0); return [p[0], p[1], p[0], p[1]]; }
	return xformBounds(worldMatrix(o), b);
}

/* ---- colors ---- */

function readColor(first) {
	// setFillColor( gray ), ( gray, a ), ( r, g, b ), ( r, g, b, a ); trailing nils ignored
	let n = 0;
	const v = [];
	for (let i = first; i < first + 4; i++) {
		if (lua.lua_type(L, i) !== T_NUM) break;
		v.push(lua.lua_tonumber(L, i));
		n++;
	}
	if (n === 0) {
		if (lua.lua_type(L, first) === T_TABLE) {   // gradient / paint table: use its first color
			field(first, 'color1');
			if (lua.lua_type(L, -1) === T_TABLE) {
				const c = [];
				for (let i = 1; i <= 4; i++) { lua.lua_rawgeti(L, -1, i); c.push(numAt(-1, 1)); lua.lua_pop(L, 1); }
				lua.lua_pop(L, 1);
				return c.map(clamp01);
			}
			lua.lua_pop(L, 1);
		}
		return null;
	}
	if (n === 1) return [clamp01(v[0]), clamp01(v[0]), clamp01(v[0]), 1];
	if (n === 2) return [clamp01(v[0]), clamp01(v[0]), clamp01(v[0]), clamp01(v[1])];
	if (n === 3) return [clamp01(v[0]), clamp01(v[1]), clamp01(v[2]), 1];
	return [clamp01(v[0]), clamp01(v[1]), clamp01(v[2]), clamp01(v[3])];
}
function css(c, a) {
	return 'rgba(' + Math.round(c[0] * 255) + ',' + Math.round(c[1] * 255) + ',' + Math.round(c[2] * 255) + ',' + (c[3] * a) + ')';
}

/* ---- text layout ---- */

const SYSTEM_FONT_CSS = '"Helvetica Neue", Helvetica, Arial, sans-serif';
const fontInfo = new Map();      // font name -> { css, asc, desc, gap }
const measureCache = new Map();

function resolveFont(name) {
	const key = name || '';
	let fi = fontInfo.get(key);
	if (fi) return fi;
	const reg = name && assets.fonts.get(name);
	if (reg) fi = { css: '"' + name + '"', asc: reg.asc, desc: reg.desc, gap: reg.gap };
	else {
		measureCtx.font = '100px ' + SYSTEM_FONT_CSS;
		const m = measureCtx.measureText('Hg');
		const asc = (m.fontBoundingBoxAscent || 95) / 100, desc = (m.fontBoundingBoxDescent || 25) / 100;
		fi = { css: SYSTEM_FONT_CSS, asc, desc, gap: 0 };
	}
	fontInfo.set(key, fi);
	return fi;
}
function measure(fi, s) {
	const key = fi.css + '\u0000' + s;
	let w = measureCache.get(key);
	if (w === undefined) {
		measureCtx.font = '100px ' + fi.css;
		w = measureCtx.measureText(s).width / 100;
		if (measureCache.size > 20000) measureCache.clear();
		measureCache.set(key, w);
	}
	return w;
}
function layoutText(o) {
	const fi = resolveFont(o.font);
	const size = o.size;
	o.fi = fi;
	o.lineH = (fi.asc + fi.desc + fi.gap) * size;
	o.ascent = fi.asc * size;
	const paragraphs = String(o.text).split('\n');
	const lines = [];
	if (o.boxW > 0) {
		for (const para of paragraphs) {
			const words = para.split(' ');
			let cur = '';
			for (const word of words) {
				const trial = cur === '' ? word : cur + ' ' + word;
				if (measure(fi, trial) * size <= o.boxW || cur === '') {
					if (cur === '' && measure(fi, word) * size > o.boxW) {
						// break an over-long word by characters
						let part = '';
						for (const ch of word) {
							if (part !== '' && measure(fi, part + ch) * size > o.boxW) { lines.push(part); part = ''; }
							part += ch;
						}
						cur = part;
					} else cur = trial;
				} else {
					lines.push(cur);
					cur = word;
				}
			}
			lines.push(cur);
		}
	} else lines.push(...paragraphs);
	o.lines = lines;
	o.lineW = lines.map(s => measure(fi, s) * size);
	o.w = o.boxW > 0 ? o.boxW : Math.max(0, ...o.lineW);
	o.h = o.boxH > 0 ? o.boxH : lines.length * o.lineH;
}

/* ---- property and method tables ---- */

function numSetter(prop, fix) {
	return (o, i) => { if (lua.lua_type(L, i) === T_NUM) o[prop] = fix ? fix(lua.lua_tonumber(L, i)) : lua.lua_tonumber(L, i); };
}
function numGetter(prop) { return o => { pushnum(o[prop]); return 1; }; }
const anchorFix = v => defaults.isAnchorClamped ? clamp01(v) : v;

const baseGet = {
	x: numGetter('x'), y: numGetter('y'), rotation: numGetter('rotation'),
	xScale: numGetter('xScale'), yScale: numGetter('yScale'), alpha: numGetter('alpha'),
	anchorX: numGetter('anchorX'), anchorY: numGetter('anchorY'),
	isVisible: o => { lua.lua_pushboolean(L, o.isVisible); return 1; },
	isHitTestable: o => { lua.lua_pushboolean(L, o.isHitTestable); return 1; },
	width: o => { const b = selfBounds(o); pushnum(b ? b[2] - b[0] : 0); return 1; },
	height: o => { const b = selfBounds(o); pushnum(b ? b[3] - b[1] : 0); return 1; },
	contentWidth: o => { const b = contentBounds(o); pushnum(b[2] - b[0]); return 1; },
	contentHeight: o => { const b = contentBounds(o); pushnum(b[3] - b[1]); return 1; },
	contentBounds: o => {
		const b = contentBounds(o);
		pushValue({ xMin: b[0], yMin: b[1], xMax: b[2], yMax: b[3] });
		return 1;
	},
	parent: o => { pushObj(o.parent); return 1; },
	_proxy: o => { pushstr('userdata: ' + (o.uid || (o.uid = ++uidCounter))); return 1; },
	maskX: o => { pushnum(0); return 1; }, maskY: o => { pushnum(0); return 1; },
	isAnchorClamped: o => { lua.lua_pushboolean(L, defaults.isAnchorClamped); return 1; },
};
let uidCounter = 0;
const baseSet = {
	x: numSetter('x'), y: numSetter('y'), rotation: numSetter('rotation'),
	xScale: numSetter('xScale'), yScale: numSetter('yScale'), alpha: numSetter('alpha', clamp01),
	anchorX: numSetter('anchorX', anchorFix), anchorY: numSetter('anchorY', anchorFix),
	isVisible: (o, i) => { o.isVisible = lua.lua_toboolean(L, i); },
	isHitTestable: (o, i) => { o.isHitTestable = lua.lua_toboolean(L, i); },
	maskX: () => {}, maskY: () => {}, isAnchorClamped: () => {},
};

function method(fn) {
	return function () {
		const o = objAt(1);
		if (!o || o.removed) return 0;
		return fn(o) || 0;
	};
}
const noopFn = function () { return 0; };

const baseMethods = {
	removeSelf: method(o => { removeObj(o); }),
	toFront: method(o => {
		const p = o.parent; if (!p) return;
		const arr = p.children, i = arr.indexOf(o);
		if (i >= 0) { arr.splice(i, 1); arr.push(o); }
	}),
	toBack: method(o => {
		const p = o.parent; if (!p) return;
		const arr = p.children, i = arr.indexOf(o);
		if (i >= 0) { arr.splice(i, 1); arr.unshift(o); }
	}),
	translate: method(o => { o.x += numAt(2, 0); o.y += numAt(3, 0); }),
	scale: method(o => { o.xScale *= numAt(2, 1); o.yScale *= numAt(3, 1); }),
	rotate: method(o => { o.rotation += numAt(2, 0); }),
	localToContent: method(o => {
		const p = apply(worldMatrix(o), numAt(2, 0), numAt(3, 0));
		pushnum(p[0]); pushnum(p[1]);
		return 2;
	}),
	contentToLocal: method(o => {
		const inv = invert(worldMatrix(o));
		const p = inv ? apply(inv, numAt(2, 0), numAt(3, 0)) : [0, 0];
		pushnum(p[0]); pushnum(p[1]);
		return 2;
	}),
	_setHasListener: function () {
		const o = objAt(1);
		if (o) o.listens[strAt(2, '')] = boolAt(3);
		return 0;
	},
	setReferencePoint: noopFn, setMask: noopFn,
};

function fillMethods(prop) {
	return {
		setFillColor: method(o => { const c = readColor(2); if (c) { o[prop] = c; o.tintCache = null; } }),
	};
}
const strokeMethods = {
	setStrokeColor: method(o => { const c = readColor(2); if (c) o.stroke = c; }),
};

function defineKind(name, spec) {
	const k = {
		get: Object.assign({}, baseGet, spec.get || {}),
		set: Object.assign({}, baseSet, spec.set || {}),
		methods: Object.assign({}, baseMethods, spec.methods || {}),
	};
	KINDS[name] = k;
}

const groupSpec = {
	get: {
		numChildren: o => { pushnum(o.children.length); return 1; },
		anchorChildren: o => { lua.lua_pushboolean(L, !!o.anchorChildren); return 1; },
	},
	set: {
		anchorChildren: (o, i) => { o.anchorChildren = lua.lua_toboolean(L, i); },
	},
	methods: {
		insert: method(o => {
			let index, childIdx = 2;
			if (lua.lua_type(L, 2) === T_NUM) { index = Math.trunc(lua.lua_tonumber(L, 2)); childIdx = 3; }
			const c = objAt(childIdx);
			if (!c || c.removed) return;
			insertChild(o, c, index);
			if (lua.lua_toboolean(L, childIdx + 1)) { c.x = 0; c.y = 0; c.rotation = 0; c.xScale = 1; c.yScale = 1; }
		}),
		remove: method(o => {
			let c;
			if (lua.lua_type(L, 2) === T_NUM) c = o.children[Math.trunc(lua.lua_tonumber(L, 2)) - 1];
			else c = objAt(2);
			if (c && c.parent === o) removeObj(c);
		}),
	},
};
const shapeStroke = {
	strokeWidth: numSetter('strokeWidth'),
};
const sizeSetters = {
	width: numSetter('w', v => Math.max(0, v)),
	height: numSetter('h', v => Math.max(0, v)),
};

function initKinds() {
	defineKind('group', groupSpec);
	defineKind('stage', {
		get: groupSpec.get, set: groupSpec.set,
		methods: Object.assign({}, groupSpec.methods, {
			setFocus: function () {
				const st = objAt(1);
				const target = objAt(2);
				const hasId = lua.lua_type(L, 3) !== T_NIL;
				const id = hasId ? touchIdOf(3) : null;
				if (!target) {
					if (hasId) delete focus[id]; else for (const k in focus) delete focus[k];
				} else if (multitouch) {
					if (hasId) focus[id] = target;
					else for (const k in focus) if (focus[k] === target) delete focus[k];
				} else {
					focus['*'] = target;
				}
				return 0;
			},
		}),
	});
	const shape = {
		get: { strokeWidth: numGetter('strokeWidth') },
		set: Object.assign({}, shapeStroke, sizeSetters),
		methods: Object.assign({}, fillMethods('fill'), strokeMethods),
	};
	defineKind('rect', shape);
	defineKind('roundedrect', shape);
	defineKind('circle', shape);
	defineKind('line', {
		get: { strokeWidth: numGetter('strokeWidth') },
		set: shapeStroke,
		methods: Object.assign({}, strokeMethods, {
			setColor: strokeMethods.setStrokeColor,
			append: method(o => {
				const n = argc();
				for (let i = 2; i + 1 <= n; i += 2) o.pts.push(numAt(i, 0) - o.x0, numAt(i + 1, 0) - o.y0);
			}),
		}),
	});
	defineKind('image', {
		set: sizeSetters,
		methods: fillMethods('fill'),
	});
	const textSpec = {
		get: {
			text: o => { pushstr(o.text); return 1; },
			size: numGetter('size'),
		},
		set: {
			text: (o, i) => { const s = strAt(i, ''); if (s !== o.text) { o.text = s; layoutText(o); } },
			size: (o, i) => { if (lua.lua_type(L, i) === T_NUM) { o.size = lua.lua_tonumber(L, i); layoutText(o); } },
		},
		methods: Object.assign({}, fillMethods('fill'), {
			setTextColor: method(o => { const c = readColor(2); if (c) o.fill = c; }),
			setSize: method(o => { o.size = numAt(2, o.size); layoutText(o); }),
			setEmbossColor: method(o => {
				if (lua.lua_type(L, 2) !== T_TABLE) return;
				for (const which of ['highlight', 'shadow']) {
					if (field(2, which) === T_TABLE) {
						const c = [fieldNum(-1, 'r', 1), fieldNum(-1, 'g', 1), fieldNum(-1, 'b', 1), fieldNum(-1, 'a', 1)];
						o[which] = c.map(clamp01);
					}
					lua.lua_pop(L, 1);
				}
			}),
		}),
	};
	defineKind('text', textSpec);
	defineKind('embossedtext', textSpec);

	for (const name in KINDS) {
		const kind = KINDS[name];
		lua.lua_createtable(L, 0, 2);
		lua.lua_pushcfunction(L, makeIndex(kind));
		lua.lua_setfield(L, -2, lstr('__index'));
		lua.lua_pushcfunction(L, makeNewIndex(kind));
		lua.lua_setfield(L, -2, lstr('__newindex'));
		kind.mt = ref();
	}
}

function makeIndex(kind) {
	return function () {
		const o = objAt(1);
		const kt = lua.lua_type(L, 2);
		if (o && kt === T_NUM) {
			const i = lua.lua_tonumber(L, 2);
			if (o.children && !o.removed && Number.isInteger(i)) { pushObj(o.children[i - 1]); return 1; }
			lua.lua_pushnil(L);
			return 1;
		}
		if (o && kt === T_STR) {
			const k = keyAt(2);
			const g = kind.get[k];
			if (g !== undefined) {
				if (o.removed) { lua.lua_pushnil(L); return 1; }
				return g(o);
			}
			const m = kind.methods[k];
			if (m !== undefined) {
				if (o.removed && k === 'removeSelf') lua.lua_pushnil(L);
				else lua.lua_pushcfunction(L, o.removed ? noopFn : m);
				return 1;
			}
		}
		lua.lua_rawgeti(L, REG, DOCLASS);
		lua.lua_pushvalue(L, 2);
		lua.lua_gettable(L, -2);
		return 1;
	};
}
function makeNewIndex(kind) {
	return function () {
		const o = objAt(1);
		if (o && !o.removed && lua.lua_type(L, 2) === T_STR) {
			const k = keyAt(2);
			const s = kind.set[k];
			if (s !== undefined) { s(o, 3); return 0; }
			if (kind.get[k] !== undefined) return 0;   // read-only engine property
		}
		lua.lua_rawset(L, 1);
		return 0;
	};
}

/* ---- constructors ---- */

// Optional leading parent group argument; returns [parent, firstArgIndex].
function parentArg() {
	if (lua.lua_type(L, 1) === T_TABLE) {
		const p = objAt(1);
		if (p && p.children) return [p, 2];
	}
	return [null, 1];
}
function finish(o, parent) {
	insertChild(parent && !parent.removed ? parent : stage, o);
	bind(o);
	return 1;
}

function newGroup() {
	const o = new DObj('group');
	o.children = [];
	o.anchorChildren = false;
	return finish(o, null);
}
function newRect() {
	const [parent, i] = parentArg();
	const o = new DObj('rect');
	o.x = numAt(i, 0); o.y = numAt(i + 1, 0); o.w = numAt(i + 2, 0); o.h = numAt(i + 3, 0);
	o.fill = defaults.fillColor.slice(); o.stroke = defaults.strokeColor.slice(); o.strokeWidth = 0;
	return finish(o, parent);
}
function newRoundedRect() {
	const [parent, i] = parentArg();
	const o = new DObj('roundedrect');
	o.x = numAt(i, 0); o.y = numAt(i + 1, 0); o.w = numAt(i + 2, 0); o.h = numAt(i + 3, 0);
	o.radius = numAt(i + 4, 0);
	o.fill = defaults.fillColor.slice(); o.stroke = defaults.strokeColor.slice(); o.strokeWidth = 0;
	return finish(o, parent);
}
function newCircle() {
	const [parent, i] = parentArg();
	const o = new DObj('circle');
	o.x = numAt(i, 0); o.y = numAt(i + 1, 0);
	const r = numAt(i + 2, 0);
	o.w = o.h = 2 * r;
	o.fill = defaults.fillColor.slice(); o.stroke = defaults.strokeColor.slice(); o.strokeWidth = 0;
	return finish(o, parent);
}
function newLine() {
	const [parent, i] = parentArg();
	const o = new DObj('line');
	const n = argc();
	const x0 = numAt(i, 0), y0 = numAt(i + 1, 0);
	o.x = o.x0 = x0; o.y = o.y0 = y0;
	o.pts = [0, 0];
	for (let j = i + 2; j + 1 <= n; j += 2) o.pts.push(numAt(j, 0) - x0, numAt(j + 1, 0) - y0);
	o.stroke = defaults.lineColor.slice();
	o.strokeWidth = 1;
	return finish(o, parent);
}

function isBaseDir(i) {
	return lua.lua_type(L, i) === T_LUD || (lua.lua_type(L, i) === T_STR && DIRS[lua.lua_tojsstring(L, i)] !== undefined);
}
function imageFor(filename) {
	return assets.images.get(String(filename).replace(/^\.?\//, ''));
}
function newImageRect() {
	let [parent, i] = parentArg();
	const filename = strAt(i, null);
	i++;
	if (isBaseDir(i)) i++;
	const img = filename && imageFor(filename);
	if (!img) { console.warn('WARNING: Failed to find image (' + filename + ')'); lua.lua_pushnil(L); return 1; }
	const o = new DObj('image');
	o.img = img;
	o.w = numAt(i, img.width); o.h = numAt(i + 1, img.height);
	o.fill = [1, 1, 1, 1];
	return finish(o, parent);
}
function newImage() {
	let [parent, i] = parentArg();
	const filename = strAt(i, null);
	i++;
	if (isBaseDir(i)) i++;
	const img = filename && imageFor(filename);
	if (!img) { console.warn('WARNING: Failed to find image (' + filename + ')'); lua.lua_pushnil(L); return 1; }
	const o = new DObj('image');
	o.img = img;
	o.w = img.width; o.h = img.height;
	o.x = numAt(i, 0); o.y = numAt(i + 1, 0);
	o.fill = [1, 1, 1, 1];
	return finish(o, parent);
}
function makeText(kind) {
	return function () {
		const o = new DObj(kind);
		let parent = null;
		o.boxW = 0; o.boxH = 0; o.align = 'left';
		o.fill = defaults.textColor.slice();
		const p = objAt(1);
		if (lua.lua_type(L, 1) === T_TABLE && !p) {
			// options table
			const t = 1;
			if (field(t, 'parent') === T_TABLE) { const pp = objAt(-1); if (pp && pp.children) parent = pp; }
			lua.lua_pop(L, 1);
			o.text = fieldStr(t, 'text', '');
			o.x = fieldNum(t, 'x', 0); o.y = fieldNum(t, 'y', 0);
			o.boxW = fieldNum(t, 'width', 0); o.boxH = fieldNum(t, 'height', 0);
			o.font = fieldStr(t, 'font', null);
			o.size = fieldNum(t, 'fontSize', 14);
			o.align = fieldStr(t, 'align', 'left');
		} else {
			let i = 1;
			if (p && p.children) { parent = p; i = 2; }
			o.text = strAt(i, '');
			o.x = numAt(i + 1, 0); o.y = numAt(i + 2, 0);
			i += 3;
			if (lua.lua_type(L, i) === T_NUM) { o.boxW = numAt(i, 0); o.boxH = numAt(i + 1, 0); i += 2; }
			o.font = lua.lua_type(L, i) === T_STR ? lua.lua_tojsstring(L, i) : null;
			o.size = numAt(i + 1, 14);
		}
		if (kind === 'embossedtext') {
			o.highlight = [1, 1, 1, 0.5];
			o.shadow = [0, 0, 0, 0.5];
		}
		layoutText(o);
		return finish(o, parent);
	};
}
function newEmitter() {
	const o = new DObj('group');
	o.children = [];
	return finish(o, null);
}

/* ------------------------------------------------------------------ */
/* Rendering                                                           */
/* ------------------------------------------------------------------ */

function strokeOffset(sw) {
	// Corona splits strokes into an inner part floor(w/2) and an outer remainder.
	return (sw - 2 * Math.floor(sw / 2)) / 2;
}

function tinted(o) {
	const f = o.fill;
	if (f[0] === 1 && f[1] === 1 && f[2] === 1) return o.img;
	if (o.tintCache) return o.tintCache;
	const img = o.img;
	const c = document.createElement('canvas');
	c.width = img.width; c.height = img.height;
	const x = c.getContext('2d');
	x.drawImage(img, 0, 0);
	x.globalCompositeOperation = 'multiply';
	x.fillStyle = 'rgb(' + Math.round(f[0] * 255) + ',' + Math.round(f[1] * 255) + ',' + Math.round(f[2] * 255) + ')';
	x.fillRect(0, 0, c.width, c.height);
	x.globalCompositeOperation = 'destination-in';
	x.drawImage(img, 0, 0);
	o.tintCache = c;
	return c;
}

function drawNode(o, pm, pa) {
	if (!o.isVisible) return;
	const a = pa * o.alpha;
	if (a <= 0) return;
	const m = mul(pm, localMatrix(o));
	const kind = o.kind;
	if (o.children) {
		const kids = o.children;
		for (let i = 0; i < kids.length; i++) drawNode(kids[i], m, a);
		return;
	}
	ctx.setTransform(m[0], m[1], m[2], m[3], m[4], m[5]);
	if (kind === 'rect' || kind === 'roundedrect' || kind === 'circle') {
		const w = o.w, h = o.h;
		const sw = o.strokeWidth;
		if (o.fill[3] > 0) {
			ctx.fillStyle = css(o.fill, a);
			ctx.beginPath();
			if (kind === 'rect') ctx.rect(-w / 2, -h / 2, w, h);
			else if (kind === 'circle') ctx.arc(0, 0, w / 2, 0, Math.PI * 2);
			else roundRect(-w / 2, -h / 2, w, h, Math.min(o.radius, w / 2, h / 2));
			ctx.fill();
		}
		if (sw > 0 && o.stroke[3] > 0) {
			const off = strokeOffset(sw);
			ctx.strokeStyle = css(o.stroke, a);
			ctx.lineWidth = sw;
			ctx.lineJoin = 'miter';
			ctx.beginPath();
			if (kind === 'rect') ctx.rect(-w / 2 - off, -h / 2 - off, w + 2 * off, h + 2 * off);
			else if (kind === 'circle') ctx.arc(0, 0, w / 2 + off, 0, Math.PI * 2);
			else roundRect(-w / 2 - off, -h / 2 - off, w + 2 * off, h + 2 * off, Math.min(o.radius, w / 2, h / 2) + off);
			ctx.stroke();
		}
	} else if (kind === 'line') {
		if (o.strokeWidth <= 0 || o.stroke[3] <= 0) return;
		const p = o.pts;
		ctx.strokeStyle = css(o.stroke, a);
		ctx.lineWidth = o.strokeWidth;
		ctx.lineCap = 'butt';
		ctx.lineJoin = 'miter';
		ctx.beginPath();
		ctx.moveTo(p[0], p[1]);
		for (let i = 2; i < p.length; i += 2) ctx.lineTo(p[i], p[i + 1]);
		ctx.stroke();
	} else if (kind === 'image') {
		ctx.globalAlpha = a * o.fill[3];
		ctx.drawImage(tinted(o), -o.w / 2, -o.h / 2, o.w, o.h);
		ctx.globalAlpha = 1;
	} else if (kind === 'text' || kind === 'embossedtext') {
		drawText(o, m, a);
	}
}

function roundRect(x, y, w, h, r) {
	r = Math.max(0, r);
	ctx.moveTo(x + r, y);
	ctx.arcTo(x + w, y, x + w, y + h, r);
	ctx.arcTo(x + w, y + h, x, y + h, r);
	ctx.arcTo(x, y + h, x, y, r);
	ctx.arcTo(x, y, x + w, y, r);
	ctx.closePath();
}

function drawText(o, m, a) {
	if (!o.lines || o.text === '') return;
	// Render glyphs at device resolution: strip the uniform scale from the matrix.
	const s = Math.sqrt(Math.abs(m[0] * m[3] - m[1] * m[2]));
	if (s < 1e-6) return;
	ctx.setTransform(m[0] / s, m[1] / s, m[2] / s, m[3] / s, m[4], m[5]);
	ctx.font = (o.size * s) + 'px ' + o.fi.css;
	ctx.textBaseline = 'alphabetic';
	ctx.textAlign = 'left';
	const left = -o.w / 2, top = -o.h / 2;
	const passes = [];
	if (o.kind === 'embossedtext') {
		if (o.highlight && o.highlight[3] > 0) passes.push([o.highlight, 1, 1]);
		if (o.shadow && o.shadow[3] > 0) passes.push([o.shadow, -1, -1]);
	}
	passes.push([o.fill, 0, 0]);
	for (const [color, dx, dy] of passes) {
		if (color[3] <= 0) continue;
		ctx.fillStyle = css(color, a);
		for (let i = 0; i < o.lines.length; i++) {
			let lx = left;
			if (o.boxW > 0) {
				if (o.align === 'center') lx = left + (o.w - o.lineW[i]) / 2;
				else if (o.align === 'right') lx = left + o.w - o.lineW[i];
			}
			const ly = top + o.ascent + i * o.lineH;
			ctx.fillText(o.lines[i], (lx + dx) * s, (ly + dy) * s);
		}
	}
}

function render() {
	ctx.setTransform(1, 0, 0, 1, 0, 0);
	ctx.fillStyle = '#000';
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	ctx.save();
	ctx.beginPath();
	ctx.rect(view.x, view.y, view.w, view.h);
	ctx.clip();
	const k = view.k;
	const base = [k, 0, 0, k, view.x - metrics.screenOriginX * k, view.y - metrics.screenOriginY * k];
	drawNode(stage, base, 1);
	ctx.restore();
}

function layoutCanvas() {
	const dpr = window.devicePixelRatio || 1;
	const cw = Math.round(window.innerWidth * dpr), ch = Math.round(window.innerHeight * dpr);
	if (canvas.width !== cw || canvas.height !== ch) { canvas.width = cw; canvas.height = ch; }
	canvas.style.width = window.innerWidth + 'px';
	canvas.style.height = window.innerHeight + 'px';
	// fit the 16:9 virtual device into the window
	const s = Math.min(cw / DEVICE_W, ch / DEVICE_H);
	const vw = DEVICE_W * s, vh = DEVICE_H * s;
	view.x = Math.round((cw - vw) / 2); view.y = Math.round((ch - vh) / 2);
	view.w = Math.round(vw); view.h = Math.round(vh);
	view.k = view.w / metrics.actualContentWidth;
	ctx.imageSmoothingEnabled = true;
	ctx.imageSmoothingQuality = 'high';
	dirty = true;
}

/* ------------------------------------------------------------------ */
/* Touch input                                                         */
/* ------------------------------------------------------------------ */

const focus = Object.create(null);
let multitouch = false;
const pointers = new Map();     // pointerId -> touch record
let nextTouchId = 1;

function touchIdOf(i) {
	// touch ids are passed to Lua as numbers
	return lua.lua_type(L, i) === T_NUM ? lua.lua_tonumber(L, i) : String(lua.lua_topointer(L, i));
}

function toContent(e) {
	const r = canvas.getBoundingClientRect();
	const sx = canvas.width / r.width, sy = canvas.height / r.height;
	const px = (e.clientX - r.left) * sx, py = (e.clientY - r.top) * sy;
	return [(px - view.x) / view.k + metrics.screenOriginX, (py - view.y) / view.k + metrics.screenOriginY];
}

function visibleForHit(o) {
	return (o.isVisible && o.alpha > 0) || o.isHitTestable;
}
// Objects under (x, y) with a listener for `name`, front-most first.
function hitList(x, y, name) {
	const out = [];
	const walk = (o, pm) => {
		if (o.removed || !visibleForHit(o)) return false;
		const m = mul(pm, localMatrix(o));
		if (o.children) {
			let any = false;
			for (let i = o.children.length - 1; i >= 0; i--) if (walk(o.children[i], m)) any = true;
			if (any && o.listens[name] && o !== stage) out.push(o);
			return any;
		}
		const b = selfBounds(o);
		const cb = xformBounds(m, b);
		if (x >= cb[0] && x <= cb[2] && y >= cb[1] && y <= cb[3]) {
			if (o.listens[name]) out.push(o);
			return true;
		}
		return false;
	};
	walk(stage, [1, 0, 0, 1, 0, 0]);
	return out;
}

function dispatchToObject(o, ev) {
	if (o.removed || !o.ref) return false;
	pushObj(o);
	lua.lua_getfield(L, -1, lstr('dispatchEvent'));
	lua.lua_insert(L, -2);
	ev.target = o;
	pushValue(ev);
	if (!pcall(2, 1)) return false;
	const handled = lua.lua_toboolean(L, -1);
	lua.lua_pop(L, 1);
	return handled;
}
function dispatchRuntime(ev) {
	lua.lua_getglobal(L, lstr('Runtime'));
	lua.lua_getfield(L, -1, lstr('dispatchEvent'));
	lua.lua_insert(L, -2);
	pushValue(ev);
	if (!pcall(2, 1)) return false;
	const r = lua.lua_toboolean(L, -1);
	lua.lua_pop(L, 1);
	return r;
}

function deliverTouch(t, phase) {
	const ev = { name: 'touch', phase, x: t.x, y: t.y, xStart: t.xs, yStart: t.ys, id: t.id, time: getTimer(),
		isShiftDown: !!t.shift, isCtrlDown: !!t.ctrl };   // modifier keys (web addition, for mouse users)
	const f = focus[t.id] || focus['*'];
	if (window.CoronaWeb._traceTouch) console.log('touch ' + phase + ' id=' + t.id + ' focus=' + (f ? f.kind + '#' + f.ref : '-') + ' hits=' + hitList(t.x, t.y, 'touch').map(o => o.kind + '#' + o.ref).join(','));
	if (f && !f.removed) {
		dispatchToObject(f, ev);
	} else {
		let handled = false;
		for (const o of hitList(t.x, t.y, 'touch')) {
			if (dispatchToObject(o, Object.assign({}, ev))) { handled = true; break; }
		}
		if (!handled) { delete ev.target; dispatchRuntime(ev); }
	}
	if (phase === 'ended' || phase === 'cancelled') {
		delete focus[t.id];
		if (focus['*'] && (!multitouch || pointers.size <= 1)) delete focus['*'];
	}
	dirty = true;
}

function onPointerDown(e) {
	if (!running || modalOpen) return;
	if (e.pointerType === 'mouse' && e.button !== 0) return;
	if (actx && actx.state === 'suspended') actx.resume();
	if (!multitouch && pointers.size > 0) return;
	e.preventDefault();
	try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
	const [x, y] = toContent(e);
	const t = { id: nextTouchId++, x, y, xs: x, ys: y, shift: e.shiftKey, ctrl: e.ctrlKey || e.metaKey };
	pointers.set(e.pointerId, t);
	deliverTouch(t, 'began');
}
function onPointerMove(e) {
	const t = pointers.get(e.pointerId);
	if (!t) return;
	e.preventDefault();
	const [x, y] = toContent(e);
	if (x === t.x && y === t.y) return;
	t.x = x; t.y = y;
	t.shift = e.shiftKey; t.ctrl = e.ctrlKey || e.metaKey;
	deliverTouch(t, 'moved');
}
function onPointerUp(e, cancelled) {
	const t = pointers.get(e.pointerId);
	if (!t) return;
	e.preventDefault();
	const [x, y] = toContent(e);
	t.x = x; t.y = y;
	pointers.delete(e.pointerId);
	deliverTouch(t, cancelled ? 'cancelled' : 'ended');
}

/* ------------------------------------------------------------------ */
/* Audio                                                               */
/* ------------------------------------------------------------------ */

let actx = null, masterGain = null;
const NUM_CHANNELS = 32;
const channels = [];
const soundHandles = new WeakMap();   // Lua handle table -> sound record

function initAudio() {
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return;
	actx = new AC();
	masterGain = actx.createGain();
	masterGain.connect(actx.destination);
	for (let c = 1; c <= NUM_CHANNELS; c++) {
		const g = actx.createGain();
		g.connect(masterGain);
		channels[c] = { gain: g, volume: 1, source: null, handleRef: 0, onComplete: 0, loopsLeft: 0, buffer: null, paused: false };
	}
}

function soundAt(i) {
	const p = lua.lua_topointer(L, i);
	return p ? soundHandles.get(p) : undefined;
}
function newSoundHandle(path) {
	const key = String(path).replace(/^\.?\//, '');
	const buf = assets.sounds.get(key);
	if (!buf) { console.warn('WARNING: Failed to load sound ' + path); lua.lua_pushnil(L); return 1; }
	lua.lua_createtable(L, 0, 0);
	soundHandles.set(lua.lua_topointer(L, -1), { path: key, buffer: buf });
	return 1;
}
function channelOpt(i) {
	if (lua.lua_type(L, i) === T_TABLE) return Math.trunc(fieldNum(i, 'channel', 0));
	return 0;
}
function stopChannel(c, completed) {
	const ch = channels[c];
	if (!ch || !ch.source) return;
	const src = ch.source;
	ch.source = null;
	src.onended = null;
	try { src.stop(); } catch (_) {}
	finishChannel(c, ch, completed);
}
function finishChannel(c, ch, completed) {
	const cb = ch.onComplete, h = ch.handleRef;
	ch.onComplete = 0; ch.handleRef = 0;
	if (cb) {
		lua.lua_rawgeti(L, REG, h);
		const handleRef = h;
		const ev = { name: 'audio', channel: c, completed: !!completed, phase: completed ? 'stopped' : 'stopped' };
		lua.lua_pop(L, 1);
		ev.handle = { __luaref: handleRef };
		callListener(cb, 'audio', ev);
		unref(cb);
	}
	unref(h);
}
function startSource(c, ch, buffer, loops) {
	const src = actx.createBufferSource();
	src.buffer = buffer;
	src.connect(ch.gain);
	if (loops === -1) src.loop = true;
	ch.source = src;
	ch.loopsLeft = loops;
	src.onended = () => {
		if (ch.source !== src) return;
		ch.source = null;
		if (ch.loopsLeft > 0) { startSource(c, ch, buffer, ch.loopsLeft - 1); return; }
		finishChannel(c, ch, true);
	};
	src.start();
}
const audioLib = {
	loadSound: () => newSoundHandle(strAt(1, '')),
	loadStream: () => newSoundHandle(strAt(1, '')),
	play: () => {
		const snd = soundAt(1);
		if (!snd || !actx) { pushnum(0); return 1; }
		let c = channelOpt(2);
		if (c < 1 || c > NUM_CHANNELS) {
			c = 0;
			for (let i = 1; i <= NUM_CHANNELS; i++) if (!channels[i].source && !channels[i].reserved) { c = i; break; }
			if (!c) { pushnum(0); return 1; }
		}
		stopChannel(c, false);
		const ch = channels[c];
		let loops = 0, onComplete = 0;
		if (lua.lua_type(L, 2) === T_TABLE) {
			loops = Math.trunc(fieldNum(2, 'loops', 0));
			if (field(2, 'onComplete') !== T_NIL) onComplete = ref(); else lua.lua_pop(L, 1);
		}
		lua.lua_pushvalue(L, 1);
		ch.handleRef = ref();
		ch.onComplete = onComplete;
		ch.gain.gain.cancelScheduledValues(actx.currentTime);
		ch.gain.gain.setValueAtTime(ch.volume, actx.currentTime);
		startSource(c, ch, snd.buffer, loops);
		pushnum(c);
		return 1;
	},
	stop: () => {
		const c = lua.lua_type(L, 1) === T_NUM ? Math.trunc(lua.lua_tonumber(L, 1)) : channelOpt(1);
		if (c > 0) stopChannel(c, false);
		else for (let i = 1; i <= NUM_CHANNELS; i++) stopChannel(i, false);
		return 0;
	},
	setVolume: () => {
		const v = clamp01(numAt(1, 1));
		const c = channelOpt(2);
		if (!actx) return 0;
		if (c > 0) {
			const ch = channels[c];
			if (ch) { ch.volume = v; ch.gain.gain.cancelScheduledValues(actx.currentTime); ch.gain.gain.setValueAtTime(v, actx.currentTime); }
		} else masterGain.gain.setValueAtTime(v, actx.currentTime);
		lua.lua_pushboolean(L, true);
		return 1;
	},
	getVolume: () => {
		const c = channelOpt(1);
		pushnum(c > 0 && channels[c] ? channels[c].volume : (masterGain ? masterGain.gain.value : 1));
		return 1;
	},
	fade: () => {
		if (!actx || lua.lua_type(L, 1) !== T_TABLE) return 0;
		const c = Math.trunc(fieldNum(1, 'channel', 0)), t = fieldNum(1, 'time', 1000) / 1000, v = clamp01(fieldNum(1, 'volume', 0));
		const list = c > 0 ? [c] : Array.from({ length: NUM_CHANNELS }, (_, k) => k + 1);
		for (const i of list) {
			const ch = channels[i];
			ch.gain.gain.cancelScheduledValues(actx.currentTime);
			ch.gain.gain.setValueAtTime(ch.gain.gain.value, actx.currentTime);
			ch.gain.gain.linearRampToValueAtTime(v, actx.currentTime + t);
			ch.volume = v;
		}
		return 0;
	},
	fadeOut: () => {
		if (!actx) return 0;
		let c = 0, t = 1000;
		if (lua.lua_type(L, 1) === T_TABLE) { c = Math.trunc(fieldNum(1, 'channel', 0)); t = fieldNum(1, 'time', 1000); }
		const list = c > 0 ? [c] : Array.from({ length: NUM_CHANNELS }, (_, k) => k + 1);
		for (const i of list) {
			const ch = channels[i];
			if (!ch.source) continue;
			ch.gain.gain.cancelScheduledValues(actx.currentTime);
			ch.gain.gain.setValueAtTime(ch.gain.gain.value, actx.currentTime);
			ch.gain.gain.linearRampToValueAtTime(0, actx.currentTime + t / 1000);
			const src = ch.source;
			setTimeout(() => { if (ch.source === src) stopChannel(i, false); }, t);
		}
		return 0;
	},
	rewind: () => 0, seek: () => 0, pause: () => 0, resume: () => 0, dispose: () => 0,
	reserveChannels: () => {
		const n = Math.trunc(numAt(1, 0));
		for (let i = 1; i <= NUM_CHANNELS; i++) channels[i] && (channels[i].reserved = i <= n);
		pushnum(n); return 1;
	},
	isChannelPlaying: () => { const c = Math.trunc(numAt(1, 0)); lua.lua_pushboolean(L, !!(channels[c] && channels[c].source)); return 1; },
	isChannelActive: () => { const c = Math.trunc(numAt(1, 0)); lua.lua_pushboolean(L, !!(channels[c] && channels[c].source)); return 1; },
	isChannelPaused: () => { lua.lua_pushboolean(L, false); return 1; },
	findFreeChannel: () => {
		for (let i = 1; i <= NUM_CHANNELS; i++) if (!channels[i].source && !channels[i].reserved) { pushnum(i); return 1; }
		pushnum(0); return 1;
	},
	getDuration: () => { const s = soundAt(1); pushnum(s ? s.buffer.duration * 1000 : 0); return 1; },
};
function playEventSound(snd) {
	if (!actx || !snd) return;
	const src = actx.createBufferSource();
	src.buffer = snd.buffer;
	src.connect(masterGain);
	src.start();
}
const mediaLib = {
	newEventSound: () => newSoundHandle(strAt(1, '')),
	playEventSound: () => {
		let snd = soundAt(1);
		if (!snd && lua.lua_type(L, 1) === T_STR) snd = { buffer: assets.sounds.get(strAt(1, '')) };
		if (snd && snd.buffer) playEventSound(snd);
		return 0;
	},
	playSound: () => 0, stopSound: () => 0, pauseSound: () => 0, setSoundVolume: () => 0,
	getSoundVolume: () => { pushnum(1); return 1; },
};

/* ------------------------------------------------------------------ */
/* Files                                                               */
/* ------------------------------------------------------------------ */

const DIRS = { ResourceDirectory: 'res', DocumentsDirectory: 'doc', TemporaryDirectory: 'tmp',
	CachesDirectory: 'cache', ApplicationSupportDirectory: 'doc', SystemResourceDirectory: 'res' };
const STORAGE_PREFIX = 'blix-web:';
const memFiles = new Map();

function storageGet(k) { try { return window.localStorage.getItem(STORAGE_PREFIX + k); } catch (_) { return memFiles.has(k) ? memFiles.get(k) : null; } }
function storageSet(k, v) { try { window.localStorage.setItem(STORAGE_PREFIX + k, v); } catch (_) { memFiles.set(k, v); } }
function storageDel(k) { try { window.localStorage.removeItem(STORAGE_PREFIX + k); } catch (_) {} memFiles.delete(k); }

function splitPath(p) {
	const m = /^([a-z]+):\/(.*)$/.exec(p);
	return m ? [m[1], m[2]] : [null, p];
}
function fsRead(p) {
	const [dir, name] = splitPath(p);
	if (dir === 'res') {
		if (assets.texts.has(name)) return assets.texts.get(name);
		if (assets.lua.has(name.replace(/\.lua$/, ''))) return assets.lua.get(name.replace(/\.lua$/, ''));
		return null;
	}
	if (dir === 'tmp') return memFiles.has(p) ? memFiles.get(p) : null;
	if (dir) return storageGet(p);
	return null;
}
function fsWrite(p, data) {
	const [dir] = splitPath(p);
	if (dir === 'tmp') memFiles.set(p, data);
	else if (dir && dir !== 'res') storageSet(p, data);
}
function resExists(name) {
	return assets.texts.has(name) || assets.images.has(name) || assets.sounds.has(name) || assets.fonts.has(name);
}

/* ------------------------------------------------------------------ */
/* MD5 (for the game's save-file checksums)                            */
/* ------------------------------------------------------------------ */

function md5(bytes) {
	const K = new Int32Array(64), S = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21];
	for (let i = 0; i < 64; i++) K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) | 0;
	const len = bytes.length, nblk = ((len + 8) >> 6) + 1;
	const w = new Int32Array(nblk * 16);
	for (let i = 0; i < len; i++) w[i >> 2] |= bytes[i] << ((i % 4) * 8);
	w[len >> 2] |= 0x80 << ((len % 4) * 8);
	w[nblk * 16 - 2] = len * 8;
	let a0 = 0x67452301, b0 = 0xefcdab89 | 0, c0 = 0x98badcfe | 0, d0 = 0x10325476;
	for (let blk = 0; blk < nblk; blk++) {
		let a = a0, b = b0, c = c0, d = d0;
		for (let i = 0; i < 64; i++) {
			let f, g;
			if (i < 16) { f = (b & c) | (~b & d); g = i; }
			else if (i < 32) { f = (d & b) | (~d & c); g = (5 * i + 1) % 16; }
			else if (i < 48) { f = b ^ c ^ d; g = (3 * i + 5) % 16; }
			else { f = c ^ (b | ~d); g = (7 * i) % 16; }
			const tmp = d; d = c; c = b;
			const x = (a + f + K[i] + w[blk * 16 + g]) | 0;
			const s = S[(i >> 4) * 4 + (i % 4)];
			b = (b + ((x << s) | (x >>> (32 - s)))) | 0;
			a = tmp;
		}
		a0 = (a0 + a) | 0; b0 = (b0 + b) | 0; c0 = (c0 + c) | 0; d0 = (d0 + d) | 0;
	}
	const out = new Uint8Array(16);
	[a0, b0, c0, d0].forEach((v, i) => { for (let j = 0; j < 4; j++) out[i * 4 + j] = (v >>> (8 * j)) & 255; });
	return out;
}

/* ------------------------------------------------------------------ */
/* system / native / network                                           */
/* ------------------------------------------------------------------ */

let t0 = 0, pausedAt = 0, pausedTotal = 0;
function getTimer() {
	const now = pausedAt || performance.now();
	return now - t0 - pausedTotal;
}

function deviceId() {
	let id = storageGet('deviceID');
	if (!id) {
		id = Array.from(crypto.getRandomValues(new Uint8Array(20)), b => b.toString(16).padStart(2, '0')).join('');
		storageSet('deviceID', id);
	}
	return id;
}

const INFO = {
	environment: 'device', platformName: 'iPhone OS', platform: 'ios', platformVersion: '7.1.2',
	model: 'iPhone', name: 'iPhone', architectureInfo: 'iPhone6,1', build: '2014.2264',
	appVersionString: '1.03', targetAppStore: 'apple', maxTextureSize: 4096, textureMemoryUsed: 0,
	iosAdvertisingIdentifier: '', iosAdvertisingTrackingEnabled: false, manufacturer: 'Apple',
};

const systemLib = {
	getTimer: () => { pushnum(getTimer()); return 1; },
	getInfo: () => {
		const k = strAt(1, '');
		if (k === 'deviceID' || k === 'iosIdentifierForVendor') { pushstr(deviceId()); return 1; }
		pushValue(INFO[k]);
		return 1;
	},
	getPreference: () => {
		const cat = strAt(1, ''), k = strAt(2, '');
		if (cat === 'locale' || cat === 'ui') {
			const v = { country: 'US', language: 'en', identifier: 'en_US', languageCode: 'en' }[k];
			pushValue(v);
			return 1;
		}
		if (cat === 'app') { const v = storageGet('pref/' + k); pushValue(v === null ? null : JSON.parse(v)); return 1; }
		lua.lua_pushnil(L);
		return 1;
	},
	setPreferences: () => {
		if (strAt(1, '') === 'app' && lua.lua_type(L, 2) === T_TABLE) {
			lua.lua_pushnil(L);
			while (lua.lua_next(L, 2)) {
				if (lua.lua_type(L, -2) === T_STR) {
					const k = lua.lua_tojsstring(L, -2);
					const t = lua.lua_type(L, -1);
					const v = t === T_NUM ? lua.lua_tonumber(L, -1) : t === T_BOOL ? lua.lua_toboolean(L, -1) : t === T_STR ? lua.lua_tojsstring(L, -1) : null;
					storageSet('pref/' + k, JSON.stringify(v));
				}
				lua.lua_pop(L, 1);
			}
		}
		lua.lua_pushboolean(L, true);
		return 1;
	},
	pathForFile: () => {
		const name = strAt(1, null);
		let dir = 'res';
		if (lua.lua_type(L, 2) === T_STR) dir = DIRS[lua.lua_tojsstring(L, 2)] || 'res';
		if (name === null) { pushstr(dir + ':/'); return 1; }
		const clean = name.replace(/^\.?\//, '');
		if (dir === 'res' && !resExists(clean)) { lua.lua_pushnil(L); return 1; }
		pushstr(dir + ':/' + clean);
		return 1;
	},
	openURL: () => {
		const url = strAt(1, '');
		if (/^https?:/i.test(url)) window.open(url, '_blank', 'noopener');
		lua.lua_pushboolean(L, true);
		return 1;
	},
	canOpenURL: () => { lua.lua_pushboolean(L, /^https?:/i.test(strAt(1, ''))); return 1; },
	activate: () => { if (strAt(1, '') === 'multitouch') multitouch = true; return 0; },
	deactivate: () => { if (strAt(1, '') === 'multitouch') multitouch = false; return 0; },
	hasEventSource: () => { lua.lua_pushboolean(L, false); return 1; },
	beginListener: noopFn, endListener: noopFn,
	setIdleTimer: noopFn, vibrate: noopFn, setTapDelay: noopFn, setLocationAccuracy: noopFn,
	setAccelerometerInterval: noopFn, setGyroscopeInterval: noopFn,
	scheduleNotification: () => { lua.lua_pushnil(L); return 1; }, cancelNotification: noopFn,
	getInputDevices: () => { lua.lua_createtable(L, 0, 0); return 1; },
};

/* ------------------------------------------------------------------ */
/* Text input (native.newTextField / newTextBox), files, fullscreen    */
/* ------------------------------------------------------------------ */

const textInputs = new Map();
let textInputCounter = 0;

function contentToPage(x, y) {
	const r = canvas.getBoundingClientRect();
	const s = r.width / canvas.width;
	return [r.left + (view.x + (x - metrics.screenOriginX) * view.k) * s,
		r.top + (view.y + (y - metrics.screenOriginY) * view.k) * s, view.k * s];
}
function layoutTextInput(t) {
	const [left, top, s] = contentToPage(t.x - t.w / 2, t.y - t.h / 2);
	const st = t.el.style;
	st.left = left + 'px';
	st.top = top + 'px';
	st.width = (t.w * s) + 'px';
	st.height = (t.h * s) + 'px';
	st.fontSize = (t.size * s) + 'px';
	st.display = t.visible ? '' : 'none';
}
function layoutTextInputs() { for (const t of textInputs.values()) layoutTextInput(t); }
function textInputEvent(t, phase) {
	if (!t.listener) return;
	callListener(t.listener, 'userInput', { name: 'userInput', phase, text: t.el.value });
	dirty = true;
}
const textInputLib = {
	tiCreate: () => {
		const multiline = boolAt(1);
		const el = document.createElement(multiline ? 'textarea' : 'input');
		el.className = 'cw-input';
		el.spellcheck = false;
		el.autocomplete = 'off';
		const t = { el, x: numAt(2, 0), y: numAt(3, 0), w: numAt(4, 100), h: numAt(5, 20), size: 12, visible: true, listener: 0 };
		const id = ++textInputCounter;
		textInputs.set(id, t);
		el.addEventListener('focus', () => textInputEvent(t, 'began'));
		el.addEventListener('input', () => textInputEvent(t, 'editing'));
		el.addEventListener('blur', () => textInputEvent(t, 'ended'));
		el.addEventListener('keydown', e => {
			if (e.key === 'Escape') return;   // leaves the field; onKey passes it on to the game
			e.stopPropagation();
			if (e.key === 'Enter' && !multiline) { textInputEvent(t, 'submitted'); el.blur(); }
		});
		document.body.append(el);
		layoutTextInput(t);
		pushnum(id);
		return 1;
	},
	tiSet: () => {
		const t = textInputs.get(numAt(1, 0));
		if (!t) return 0;
		const k = strAt(2, '');
		if (k === 'text') t.el.value = strAt(3, '');
		else if (k === 'placeholder') t.el.placeholder = strAt(3, '');
		else if (k === 'font') {
			const name = strAt(3, null);
			t.el.style.fontFamily = name && assets.fonts.get(name) ? '"' + name + '"' : SYSTEM_FONT_CSS;
		} else if (k === 'color') {
			t.el.style.color = 'rgba(' + Math.round(numAt(3, 0) * 255) + ',' + Math.round(numAt(4, 0) * 255) + ',' + Math.round(numAt(5, 0) * 255) + ',' + numAt(6, 1) + ')';
		} else if (k === 'align') t.el.style.textAlign = strAt(3, 'left');
		else if (k === 'editable') t.el.readOnly = !boolAt(3);
		else if (k === 'maxLength') t.el.maxLength = numAt(3, 524288);
		else if (k === 'visible') { t.visible = boolAt(3); layoutTextInput(t); }
		else if (k === 'x' || k === 'y' || k === 'w' || k === 'h' || k === 'size') { t[k] = numAt(3, t[k]); layoutTextInput(t); }
		return 0;
	},
	tiGet: () => {
		const t = textInputs.get(numAt(1, 0));
		pushstr(t ? t.el.value : '');
		return 1;
	},
	tiListener: () => {
		const t = textInputs.get(numAt(1, 0));
		if (!t) return 0;
		unref(t.listener);
		t.listener = 0;
		if (lua.lua_type(L, 2) === T_FUNC || lua.lua_type(L, 2) === T_TABLE) { lua.lua_pushvalue(L, 2); t.listener = ref(); }
		return 0;
	},
	tiFocus: () => {
		const t = textInputs.get(numAt(1, 0));
		if (t) t.el.focus();
		else if (document.activeElement && document.activeElement.classList.contains('cw-input')) document.activeElement.blur();
		return 0;
	},
	tiRemove: () => {
		const id = numAt(1, 0), t = textInputs.get(id);
		if (t) { unref(t.listener); t.el.remove(); textInputs.delete(id); }
		return 0;
	},
	// download a text file (level export)
	saveFile: () => {
		const name = strAt(1, 'file.txt'), text = strAt(2, '');
		const blob = new Blob([text], { type: 'application/octet-stream' });
		const a = document.createElement('a');
		a.href = URL.createObjectURL(blob);
		a.download = name;
		document.body.append(a);
		a.click();
		a.remove();
		setTimeout(() => URL.revokeObjectURL(a.href), 5000);
		lua.lua_pushboolean(L, true);
		return 1;
	},
	// show the browser's open-file dialog; listener receives { filename, text } or { isError = true }
	openFile: () => {
		let listener = 0;
		if (lua.lua_type(L, 1) === T_FUNC) { lua.lua_pushvalue(L, 1); listener = ref(); }
		const accept = strAt(2, '');
		const input = document.createElement('input');
		input.type = 'file';
		if (accept) input.accept = accept;
		let done = false;
		const finish = ev => {
			if (done) return;
			done = true;
			callListener(listener, 'file', ev);
			unref(listener);
			dirty = true;
		};
		input.addEventListener('change', () => {
			const f = input.files && input.files[0];
			if (!f) { finish({ name: 'file', isError: true, cancelled: true }); return; }
			f.text().then(text => finish({ name: 'file', filename: f.name, text }), () => finish({ name: 'file', isError: true }));
		});
		input.addEventListener('cancel', () => finish({ name: 'file', isError: true, cancelled: true }));
		input.click();
		return 0;
	},
	setFullscreen: () => {
		const on = boolAt(1);
		if (on && !document.fullscreenElement && document.documentElement.requestFullscreen) {
			document.documentElement.requestFullscreen({ navigationUI: 'hide' }).catch(() => {});
		} else if (!on && document.fullscreenElement) document.exitFullscreen().catch(() => {});
		return 0;
	},
	isFullscreen: () => { lua.lua_pushboolean(L, !!document.fullscreenElement); return 1; },
	resumeAudio: () => { if (actx && actx.state !== 'running') actx.resume(); return 0; },
	runMain: () => { runMain(); return 0; },
};

// Corona "key" events (desktop builds): Runtime:addEventListener( "key", ... )
const KEY_NAMES = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right',
	Backspace: 'deleteBack', Delete: 'deleteForward', Enter: 'enter', Escape: 'escape', ' ': 'space',
	Tab: 'tab', Shift: 'leftShift', Control: 'leftCtrl', Alt: 'leftAlt', Meta: 'leftCommand',
	PageUp: 'pageUp', PageDown: 'pageDown', Home: 'home', End: 'end' };
function onKey(e, phase) {
	if (!running || modalOpen) return;
	const t = e.target;
	if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) {
		// typing stays in the field; Escape leaves it and reaches the game
		if (e.key !== 'Escape') return;
		t.blur();
	}
	const name = KEY_NAMES[e.key] || (e.key && e.key.length === 1 ? e.key.toLowerCase() : null);
	if (!name) return;
	const handled = dispatchRuntime({ name: 'key', phase, keyName: name, isShiftDown: e.shiftKey,
		isCtrlDown: e.ctrlKey, isAltDown: e.altKey, isCommandDown: e.metaKey });
	if (handled) e.preventDefault();
	dirty = true;
}

function onFileDrop(e) {
	e.preventDefault();
	const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
	if (!f || !running) return;
	f.text().then(text => { dispatchRuntime({ name: 'fileDropped', filename: f.name, text }); dirty = true; });
}

let modalOpen = false;
function showAlert() {
	const title = strAt(1, ''), message = strAt(2, '');
	const buttons = [];
	if (lua.lua_type(L, 3) === T_TABLE) {
		for (let i = 1; ; i++) {
			lua.lua_rawgeti(L, 3, i);
			if (lua.lua_type(L, -1) === T_NIL) { lua.lua_pop(L, 1); break; }
			buttons.push(strAt(-1, ''));
			lua.lua_pop(L, 1);
		}
	}
	if (!buttons.length) buttons.push('OK');
	let listenerRef = 0;
	if (lua.lua_type(L, 4) === T_FUNC || lua.lua_type(L, 4) === T_TABLE) { lua.lua_pushvalue(L, 4); listenerRef = ref(); }
	lua.lua_createtable(L, 0, 0);
	lua.lua_pushvalue(L, -1);
	const handleRef = ref();
	const el = document.createElement('div');
	el.className = 'cw-alert';
	const box = document.createElement('div');
	box.className = 'cw-alert-box';
	const h = document.createElement('div'); h.className = 'cw-alert-title'; h.textContent = title;
	const p = document.createElement('div'); p.className = 'cw-alert-msg'; p.textContent = message;
	const row = document.createElement('div'); row.className = 'cw-alert-buttons' + (buttons.length > 2 ? ' stacked' : '');
	box.append(h, p, row);
	el.append(box);
	const close = (action, index) => {
		el.remove();
		modalOpen = document.querySelector('.cw-alert') !== null;
		alerts.delete(handleRef);
		const ev = { name: 'completion', action, index };
		callListener(listenerRef, 'completion', ev);
		unref(listenerRef);
		unref(handleRef);
		dirty = true;
	};
	buttons.forEach((label, i) => {
		const b = document.createElement('button');
		b.textContent = label;
		b.onclick = ev => { ev.stopPropagation(); close('clicked', i + 1); };
		row.append(b);
	});
	alerts.set(handleRef, close);
	document.body.append(el);
	modalOpen = true;
	return 1;
}
const alerts = new Map();
const nativeLib = {
	showAlert,
	cancelAlert: () => {
		const p = lua.lua_topointer(L, 1);
		for (const [r, close] of alerts) {
			lua.lua_rawgeti(L, REG, r);
			const same = lua.lua_topointer(L, -1) === p;
			lua.lua_pop(L, 1);
			if (same) { close('cancelled', 0); break; }
		}
		return 0;
	},
	showPopup: () => { lua.lua_pushboolean(L, false); return 1; },
	canShowPopup: () => { lua.lua_pushboolean(L, false); return 1; },
	requestExit: noopFn, setActivityIndicator: noopFn, setKeyboardFocus: noopFn, setProperty: noopFn,
	getProperty: () => { lua.lua_pushnil(L); return 1; },
	newFont: () => { lua.lua_pushvalue(L, 1); return 1; },
	getFontNames: () => { pushValue(Array.from(assets.fonts.keys())); return 1; },
	showWebPopup: noopFn, cancelWebPopup: noopFn,
};

let requestCounter = 0;
function networkFail() {
	// The game's servers are long gone: every request fails like an offline device.
	let listener = 0;
	for (let i = 1; i <= 4; i++) {
		const t = lua.lua_type(L, i);
		if (t === T_FUNC || (t === T_TABLE && !listener && i > 2)) { lua.lua_pushvalue(L, i); listener = ref(); break; }
	}
	const url = strAt(1, '');
	const id = ++requestCounter;
	if (listener) {
		setTimeout(() => {
			callListener(listener, 'networkRequest', { name: 'networkRequest', isError: true, status: -1, response: '', url, phase: 'ended', requestId: id });
			unref(listener);
			dirty = true;
		}, 60);
	}
	pushnum(id);
	return 1;
}
const networkLib = {
	request: networkFail, download: networkFail, upload: networkFail,
	cancel: noopFn,
	setStatusListener: () => { lua.lua_pushboolean(L, false); return 1; },
	getConnectionStatus: () => { pushValue({ isConnected: false, isMobile: false }); return 1; },
	canDetectNetworkStatusChanges: false,
};

/* ------------------------------------------------------------------ */
/* Library registration                                                */
/* ------------------------------------------------------------------ */

function registerLib(name, fns, extra) {
	lua.lua_createtable(L, 0, 0);
	for (const k in fns) {
		if (typeof fns[k] === 'function') { lua.lua_pushcfunction(L, fns[k]); lua.lua_setfield(L, -2, lstr(k)); }
		else { pushValue(fns[k]); lua.lua_setfield(L, -2, lstr(k)); }
	}
	if (extra) for (const k in extra) { pushValue(extra[k]); lua.lua_setfield(L, -2, lstr(k)); }
	lua.lua_setglobal(L, lstr(name));
}

function setGlobalField(lib, name, value) {
	lua.lua_getglobal(L, lstr(lib));
	pushValue(value);
	lua.lua_setfield(L, -2, lstr(name));
	lua.lua_pop(L, 1);
}

function installDisplay() {
	const displayLib = {
		newGroup, newContainer: newGroup, newRect, newRoundedRect, newCircle, newLine,
		newImage, newImageRect, newText: makeText('text'), newEmbossedText: makeText('embossedtext'),
		newEmitter,
		getCurrentStage: () => { pushObj(stage); return 1; },
		setStatusBar: noopFn,
		setDefault: () => {
			const k = strAt(1, '');
			if (k === 'anchorX' || k === 'anchorY') defaults[k] = numAt(2, 0.5);
			else if (k === 'isAnchorClamped') defaults.isAnchorClamped = boolAt(2);
			else if (k === 'fillColor' || k === 'strokeColor' || k === 'lineColor' || k === 'textColor') {
				const c = readColor(2); if (c) defaults[k] = c;
			}
			return 0;
		},
		getDefault: () => {
			const k = strAt(1, '');
			if (k === 'graphicsCompatibility') pushnum(2);
			else if (k in defaults && typeof defaults[k] !== 'object') pushValue(defaults[k]);
			else lua.lua_pushnil(L);
			return 1;
		},
		save: noopFn, capture: () => { lua.lua_pushnil(L); return 1; }, captureScreen: () => { lua.lua_pushnil(L); return 1; },
		captureBounds: () => { lua.lua_pushnil(L); return 1; }, colorSample: noopFn,
		_initProfiling: noopFn,
	};
	const consts = {
		HiddenStatusBar: 'HiddenStatusBar', DefaultStatusBar: 'DefaultStatusBar',
		DarkStatusBar: 'DarkStatusBar', TranslucentStatusBar: 'TranslucentStatusBar',
		statusBarHeight: 0, topStatusBarContentHeight: 0, imageSuffix: null,
	};
	registerLib('display', displayLib, consts);
}

function setMetrics(content) {
	// config.lua describes a portrait 320x480 content area; the app runs in landscape.
	let cw = content.width || DEVICE_H, ch = content.height || DEVICE_W;
	if (cw < ch) { const t = cw; cw = ch; ch = t; }
	const scaleMode = content.scale || 'letterBox';
	let sx = DEVICE_W / cw, sy = DEVICE_H / ch, s;
	if (scaleMode === 'zoomEven') s = Math.max(sx, sy);
	else s = Math.min(sx, sy);
	const actualW = DEVICE_W / s, actualH = DEVICE_H / s;
	Object.assign(metrics, {
		contentWidth: cw, contentHeight: ch,
		contentCenterX: cw / 2, contentCenterY: ch / 2,
		actualContentWidth: actualW, actualContentHeight: actualH,
		viewableContentWidth: Math.min(cw, actualW), viewableContentHeight: Math.min(ch, actualH),
		screenOriginX: (cw - actualW) / 2, screenOriginY: (ch - actualH) / 2,
		contentScaleX: 1 / s, contentScaleY: 1 / s,
		pixelWidth: DEVICE_H, pixelHeight: DEVICE_W,
		fps: content.fps || 60,
		safeScreenOriginX: (cw - actualW) / 2, safeScreenOriginY: (ch - actualH) / 2,
		safeActualContentWidth: actualW, safeActualContentHeight: actualH,
	});
	lua.lua_getglobal(L, lstr('display'));
	for (const k in metrics) { pushnum(metrics[k]); lua.lua_setfield(L, -2, lstr(k)); }
	lua.lua_pop(L, 1);
}

function readContentConfig() {
	const out = {};
	lua.lua_getglobal(L, lstr('application'));
	if (lua.lua_type(L, -1) === T_TABLE && field(-1, 'content') === T_TABLE) {
		out.width = fieldNum(-1, 'width', 0);
		out.height = fieldNum(-1, 'height', 0);
		out.scale = fieldStr(-1, 'scale', 'letterBox');
		out.fps = fieldNum(-1, 'fps', 30);
		lua.lua_pop(L, 1);
	} else if (lua.lua_type(L, -1) === T_TABLE) lua.lua_pop(L, 1);
	lua.lua_pop(L, 1);
	return out;
}

// Module loader: Lua sources come from the bundles, not the network.
function installSearcher() {
	lua.lua_getglobal(L, lstr('package'));
	lua.lua_getfield(L, -1, lstr('searchers'));
	const searcher = function () {
		const name = lua.lua_tojsstring(L, 1);
		const src = assets.lua.get(name) || assets.lua.get(name.replace(/\./g, '/'));
		if (src === undefined) { pushstr('\n\tno bundled module \'' + name + '\''); return 1; }
		const st = lauxlib.luaL_loadbuffer(L, typeof src === 'string' ? to_luastring(src) : src, null, to_luastring('@' + name + '.lua'));
		if (st !== lua.LUA_OK) return lua.lua_error(L);
		pushstr(name);
		return 2;
	};
	// keep package.preload, then the bundle; drop Fengari's file/XHR searchers
	const n = lua.lua_rawlen(L, -1);
	for (let i = n; i >= 2; i--) { lua.lua_pushnil(L); lua.lua_rawseti(L, -2, i); }
	lua.lua_pushcfunction(L, searcher);
	lua.lua_rawseti(L, -2, 2);
	lua.lua_pop(L, 2);
}

function runChunk(name) {
	const src = assets.lua.get(name);
	if (src === undefined) throw new Error('missing script ' + name);
	const st = lauxlib.luaL_loadbuffer(L, to_luastring(src), null, to_luastring('@' + name + '.lua'));
	if (st !== lua.LUA_OK) { reportError(lua.lua_tojsstring(L, -1)); lua.lua_pop(L, 1); return false; }
	return pcall(0, 0);
}

function boot() {
	L = lauxlib.luaL_newstate();
	lualib.luaL_openlibs(L);
	measureCtx = document.createElement('canvas').getContext('2d');
	initKinds();
	installDisplay();
	registerLib('system', systemLib, Object.assign({ orientation: 'landscapeRight' },
		Object.fromEntries(Object.keys(DIRS).map(k => [k, k]))));
	registerLib('native', nativeLib, { systemFont: 'HelveticaNeue', systemFontBold: 'HelveticaNeue-Bold', systemFontSize: 17 });
	registerLib('audio', audioLib, { totalChannels: NUM_CHANNELS, freeChannels: NUM_CHANNELS, unreservedFreeChannels: NUM_CHANNELS });
	registerLib('media', mediaLib);
	registerLib('network', networkLib);
	registerLib('_corona', Object.assign({
		log: () => { console.log(strAt(1, '')); return 0; },
		setDisplayObjectClass: () => { lua.lua_pushvalue(L, 1); DOCLASS = ref(); return 0; },
		fsRead: () => { const d = fsRead(strAt(1, '')); if (d === null || d === undefined) lua.lua_pushnil(L); else pushstr(d); return 1; },
		fsWrite: () => { fsWrite(strAt(1, ''), strAt(2, '')); return 0; },
		fsWritable: () => { const [dir] = splitPath(strAt(1, '')); lua.lua_pushboolean(L, !!dir && dir !== 'res'); return 1; },
		fsRemove: () => {
			const p = strAt(1, ''), [dir] = splitPath(p);
			const existed = fsRead(p) !== null;
			if (dir === 'tmp') memFiles.delete(p); else if (dir && dir !== 'res') storageDel(p);
			lua.lua_pushboolean(L, existed && dir !== 'res');
			return 1;
		},
		digest: () => {
			const algo = strAt(1, 'md5');
			const bytes = lua.lua_tostring(L, 2) || new Uint8Array(0);
			if (algo !== 'md5') console.warn('crypto.digest: only md5 is implemented, got ' + algo);
			const out = md5(bytes);
			if (boolAt(3)) lua.lua_pushstring(L, out);
			else pushstr(Array.from(out, b => b.toString(16).padStart(2, '0')).join(''));
			return 1;
		},
	}, textInputLib));
	// os.time returns a float (Lua 5.1 numbers) so arithmetic never wraps 32-bit integers
	lua.lua_getglobal(L, lstr('os'));
	lua.lua_getfield(L, -1, lstr('time'));
	const osTimeRef = ref();
	lua.lua_pushcfunction(L, function () {
		const n = lua.lua_gettop(L);
		lua.lua_rawgeti(L, REG, osTimeRef);
		if (n >= 1) lua.lua_pushvalue(L, 1);
		lua.lua_call(L, n >= 1 ? 1 : 0, 1);
		const v = lua.lua_tonumber(L, -1);
		lua.lua_pop(L, 1);
		pushnum(v);
		return 1;
	});
	lua.lua_setfield(L, -2, lstr('time'));
	lua.lua_pop(L, 1);

	// the stage
	stage = new DObj('stage');
	stage.children = [];
	bind(stage);
	lua.lua_pop(L, 1);

	installSearcher();

	// Corona runs config.lua first (in the same Lua state), then main.lua.
	if (!runChunk('corona_init')) throw new Error('engine init failed');
	setMetrics({ width: 320, height: 480, scale: 'letterBox', fps: 60 });
	if (assets.lua.has('config')) runChunk('config');
	setMetrics(readContentConfig());
	layoutCanvas();
	t0 = performance.now();
	running = true;
	if (assets.lua.has('mod_init')) runChunk('mod_init');   // mods decide when main.lua starts
	else runMain();
	dirty = true;
	requestAnimationFrame(loop);
}

let mainStarted = false;
function runMain() {
	if (mainStarted) return;
	mainStarted = true;
	runChunk('main');
	dispatchRuntime({ name: 'system', type: 'applicationStart' });
}

/* ------------------------------------------------------------------ */
/* Main loop                                                           */
/* ------------------------------------------------------------------ */

let running = false, dirty = true, frame = 0, lastTime = 0, acc = 0;
function tick() {
	frame++;
	dispatchRuntime({ name: 'enterFrame', time: getTimer(), frame });
	dirty = true;
}
function loop(now) {
	if (!lastTime) lastTime = now;
	acc += now - lastTime;
	lastTime = now;
	if (acc > 250) acc = FRAME_MS;
	let steps = 0;
	// small tolerance keeps 60 Hz displays at exactly one update per refresh
	while (acc >= FRAME_MS - 2 && steps < 4) { tick(); acc -= FRAME_MS; steps++; }
	if (acc < -FRAME_MS) acc = 0;
	if (dirty) { render(); dirty = false; }
	requestAnimationFrame(loop);
}

function onVisibility() {
	if (!running) return;
	if (document.hidden) {
		if (!pausedAt) { pausedAt = performance.now(); dispatchRuntime({ name: 'system', type: 'applicationSuspend' }); }
	} else if (pausedAt) {
		pausedTotal += performance.now() - pausedAt;
		pausedAt = 0;
		lastTime = 0; acc = 0;
		dispatchRuntime({ name: 'system', type: 'applicationResume' });
		if (actx && actx.state === 'suspended') actx.resume();
	}
}

/* ------------------------------------------------------------------ */
/* Asset loading                                                       */
/* ------------------------------------------------------------------ */

function b64ToBytes(b64) {
	const bin = atob(b64);
	const out = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
	return out;
}

// Vertical metrics from the font's hhea/head tables (what iOS uses for line height).
function fontMetrics(bytes) {
	const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
	const num = dv.getUint16(4);
	let head = -1, hhea = -1;
	for (let i = 0; i < num; i++) {
		const rec = 12 + i * 16;
		const tag = String.fromCharCode(dv.getUint8(rec), dv.getUint8(rec + 1), dv.getUint8(rec + 2), dv.getUint8(rec + 3));
		if (tag === 'head') head = dv.getUint32(rec + 8);
		if (tag === 'hhea') hhea = dv.getUint32(rec + 8);
	}
	const upm = head >= 0 ? dv.getUint16(head + 18) : 1000;
	if (hhea < 0) return { asc: 0.8, desc: 0.2, gap: 0 };
	return { asc: dv.getInt16(hhea + 4) / upm, desc: -dv.getInt16(hhea + 6) / upm, gap: dv.getInt16(hhea + 8) / upm };
}

async function loadAssets(data, progress) {
	for (const [name, src] of Object.entries(data.lua || {})) assets.lua.set(name, src);
	const files = Object.entries(data.files || {});
	let done = 0;
	const step = () => progress && progress(++done / files.length);
	const decodeCtx = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 1, 44100);
	await Promise.all(files.map(async ([path, f]) => {
		try {
			if (f.type === 'text') assets.texts.set(path, f.data);
			else if (f.type === 'image') {
				const img = new Image();
				img.src = 'data:' + f.mime + ';base64,' + f.b64;
				await img.decode();
				assets.images.set(path, img);
			} else if (f.type === 'audio') {
				const bytes = b64ToBytes(f.b64);
				const buf = await decodeCtx.decodeAudioData(bytes.buffer);
				assets.sounds.set(path, buf);
			} else if (f.type === 'font') {
				const bytes = b64ToBytes(f.b64);
				const face = new FontFace(f.family, bytes.buffer);
				await face.load();
				document.fonts.add(face);
				assets.fonts.set(f.family, Object.assign({ file: path }, fontMetrics(bytes)));
				assets.texts.set(path, '');   // resource exists
			}
		} catch (err) {
			console.warn('asset failed: ' + path, err);
		}
		step();
	}));
}

/* ------------------------------------------------------------------ */
/* Public entry point                                                  */
/* ------------------------------------------------------------------ */

window.CoronaWeb = {
	onError: null,
	async load(progress) {
		const merged = { lua: Object.assign({}, window.ENGINE_LUA || {}, (window.GAME_DATA || {}).lua || {}, window.MODS_LUA || {}), files: (window.GAME_DATA || {}).files || {} };
		await loadAssets(merged, progress);
	},
	start(canvasEl) {
		canvas = canvasEl;
		ctx = canvas.getContext('2d', { alpha: false });
		initAudio();
		if (actx && actx.state === 'suspended') actx.resume();
		// re-decode sounds on the live context is unnecessary: AudioBuffers are context-independent
		canvas.addEventListener('pointerdown', onPointerDown);
		canvas.addEventListener('pointermove', onPointerMove);
		canvas.addEventListener('pointerup', e => onPointerUp(e, false));
		canvas.addEventListener('pointercancel', e => onPointerUp(e, true));
		canvas.addEventListener('contextmenu', e => e.preventDefault());
		window.addEventListener('resize', () => { if (running) { layoutCanvas(); layoutTextInputs(); } });
		document.addEventListener('fullscreenchange', () => setTimeout(() => { if (running) { layoutCanvas(); layoutTextInputs(); } }, 50));
		window.addEventListener('keydown', e => onKey(e, 'down'));
		window.addEventListener('keyup', e => onKey(e, 'up'));
		window.addEventListener('dragover', e => e.preventDefault());
		window.addEventListener('drop', onFileDrop);
		document.addEventListener('visibilitychange', onVisibility);
		boot();
	},
	resumeAudio() { if (actx && actx.state !== 'running') actx.resume(); },
	// testing hooks
	_debug: { get stage() { return stage; }, get metrics() { return metrics; }, contentBounds, hitList, deliverTouchAt(phase, x, y, id) {
		const t = { id: id || 999, x, y, xs: x, ys: y };
		deliverTouch(t, phase);
	}, tick, render, getTimer,
	// evaluate a Lua expression or chunk in the running game; returns tostring() of the first result
	lua(code) {
		let st = lauxlib.luaL_loadstring(L, to_luastring('return ' + code));
		if (st !== lua.LUA_OK) { lua.lua_pop(L, 1); st = lauxlib.luaL_loadstring(L, to_luastring(code)); }
		if (st !== lua.LUA_OK) { const m = lua.lua_tojsstring(L, -1); lua.lua_pop(L, 1); return 'syntax: ' + m; }
		const top = lua.lua_gettop(L) - 1;
		if (!pcall(0, 1)) return 'error';
		lauxlib.luaL_tolstring(L, -1);
		const s = lua.lua_tojsstring(L, -1);
		lua.lua_settop(L, top);
		return s;
	} },
};

})();
