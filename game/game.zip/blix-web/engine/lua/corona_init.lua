------------------------------------------------------------------------------
-- corona_init.lua
-- Lua side of the web runtime: Lua 5.1 compatibility on top of Fengari (5.3),
-- the Corona event system, and stand-ins for platform services.
--
-- The EventDispatcher / Runtime / DisplayObject section is adapted from
-- Solar2D's platform/resources/init.lua (MIT licensed, Corona Labs).
------------------------------------------------------------------------------

local _native = _corona   -- helpers registered by corona.js
_corona = nil

------------------------------------------------------------------------------
-- Lua 5.1 compatibility
------------------------------------------------------------------------------

unpack = unpack or table.unpack
loadstring = loadstring or load
table.getn = table.getn or function( t ) return #t end
table.setn = table.setn or function() end
table.maxn = table.maxn or function( t )
	local n = 0
	for k in pairs( t ) do
		if type( k ) == "number" and k > n then n = k end
	end
	return n
end
string.gfind = string.gfind or string.gmatch
math.pow = math.pow or function( x, y ) return x ^ y end
math.mod = math.mod or math.fmod
math.log10 = math.log10 or function( x ) return math.log( x, 10 ) end
math.atan2 = math.atan2 or function( y, x ) return math.atan( y, x ) end
math.cosh = math.cosh or function( x ) return ( math.exp( x ) + math.exp( -x ) ) / 2 end
math.sinh = math.sinh or function( x ) return ( math.exp( x ) - math.exp( -x ) ) / 2 end
math.tanh = math.tanh or function( x ) return math.sinh( x ) / math.cosh( x ) end
math.ldexp = math.ldexp or function( m, e ) return m * 2.0 ^ e end
math.frexp = math.frexp or function( x )
	if x == 0 then return 0, 0 end
	local e = math.floor( math.log( math.abs( x ), 2 ) ) + 1
	return x / 2.0 ^ e, e
end

-- 5.1 truncated non-integral numeric arguments where 5.3 raises errors.
local function toint( n )
	if type( n ) == "string" then n = tonumber( n ) end
	if type( n ) ~= "number" then return n end
	if n >= 0 then return math.floor( n ) else return math.ceil( n ) end
end

local _random = math.random
math.random = function( m, n )
	if m == nil then return _random() end
	if n == nil then return _random( toint( m ) ) end
	return _random( toint( m ), toint( n ) )
end

local _sub, _rep, _char, _byte = string.sub, string.rep, string.char, string.byte
string.sub = function( s, i, j ) return _sub( s, toint( i or 1 ), toint( j or -1 ) ) end
string.rep = function( s, n, sep ) return _rep( s, toint( n ), sep ) end
string.byte = function( s, i, j ) return _byte( s, toint( i or 1 ), toint( j or i or 1 ) ) end
string.char = function( ... )
	local t = { ... }
	for i = 1, select( "#", ... ) do t[i] = toint( t[i] ) end
	return _char( table.unpack( t, 1, select( "#", ... ) ) )
end

local _format = string.format
string.format = function( fmt, ... )
	local args = { ... }
	local n = select( "#", ... )
	local i = 0
	for spec in tostring( fmt ):gmatch( "%%[-+ #0]*%d*%.?%d*([%a%%])" ) do
		if spec ~= "%" then
			i = i + 1
			if ( spec == "d" or spec == "i" or spec == "x" or spec == "X" or spec == "o" or spec == "c" or spec == "u" )
				and type( args[i] ) == "number" then
				args[i] = toint( args[i] )
			end
		end
	end
	return _format( fmt, table.unpack( args, 1, n ) )
end

-- table.insert / table.remove with Lua 5.1 semantics (no position bounds errors)
table.insert = function( t, ... )
	local n = select( "#", ... )
	if n == 1 then
		t[#t + 1] = ( ... )
		return
	end
	local pos, value = ...
	pos = toint( pos )
	local e = #t + 1
	if pos > e then e = pos end
	for i = e, pos + 1, -1 do t[i] = t[i - 1] end
	t[pos] = value
end
table.remove = function( t, pos )
	local e = #t
	if pos == nil then pos = e else pos = toint( pos ) end
	if e == 0 then return nil end
	if pos < 1 or pos > e then return nil end
	local value = t[pos]
	for i = pos, e - 1 do t[i] = t[i + 1] end
	t[e] = nil
	return value
end

local _collectgarbage = collectgarbage
collectgarbage = function( opt, arg )
	if opt == "count" then return 0, 0 end
	return 0
end

print = function( ... )
	local n = select( "#", ... )
	local parts = {}
	for i = 1, n do parts[i] = tostring( ( select( i, ... ) ) ) end
	_native.log( table.concat( parts, "\t" ) )
end

------------------------------------------------------------------------------
-- io / os on top of the virtual file system in corona.js
------------------------------------------------------------------------------

io = io or {}
local File = {}
File.__index = File

function File:read( fmt, ... )
	if self.closed then return nil end
	fmt = fmt or "*l"
	local data, pos = self.data, self.pos
	if type( fmt ) == "number" then
		if pos > #data then return nil end
		local s = _sub( data, pos, pos + fmt - 1 )
		self.pos = pos + #s
		return s
	end
	fmt = _sub( fmt, 1, 2 )
	if fmt == "*a" or fmt == "a" then
		self.pos = #data + 1
		return _sub( data, pos )
	elseif fmt == "*l" or fmt == "l" or fmt == "*L" or fmt == "L" then
		if pos > #data then return nil end
		local s, e = data:find( "\n", pos, true )
		local line
		if s then
			line = _sub( data, pos, ( fmt == "*L" or fmt == "L" ) and s or s - 1 )
			self.pos = s + 1
		else
			line = _sub( data, pos )
			self.pos = #data + 1
		end
		return line
	elseif fmt == "*n" or fmt == "n" then
		local s, e = data:find( "^%s*[-+]?%d*%.?%d+[eE]?[-+]?%d*", pos )
		if not s then return nil end
		self.pos = e + 1
		return tonumber( _sub( data, s, e ) )
	end
	return nil
end

function File:lines()
	return function() return self:read( "*l" ) end
end

function File:write( ... )
	if self.closed or not self.writable then return nil end
	local parts = { self.data }
	for i = 1, select( "#", ... ) do parts[#parts + 1] = tostring( ( select( i, ... ) ) ) end
	self.data = table.concat( parts )
	self.dirty = true
	return self
end

function File:flush()
	if self.dirty then
		_native.fsWrite( self.path, self.data )
		self.dirty = false
	end
	return self
end

function File:seek( whence, offset )
	whence = whence or "cur"
	offset = offset or 0
	if whence == "set" then self.pos = offset + 1
	elseif whence == "end" then self.pos = #self.data + offset + 1
	else self.pos = self.pos + offset end
	return self.pos - 1
end

function File:setvbuf() return true end

function File:close()
	if self.closed then return nil end
	self:flush()
	self.closed = true
	return true
end

io.open = function( path, mode )
	if type( path ) ~= "string" then return nil, "invalid path" end
	mode = mode or "r"
	local m = _sub( mode, 1, 1 )
	local existing = _native.fsRead( path )
	if m == "r" then
		if existing == nil then return nil, path .. ": No such file or directory", 2 end
		return setmetatable( { path = path, data = existing, pos = 1, writable = _sub( mode, 2, 2 ) == "+" }, File )
	elseif m == "w" then
		if not _native.fsWritable( path ) then return nil, path .. ": Permission denied", 13 end
		local f = setmetatable( { path = path, data = "", pos = 1, writable = true, dirty = true }, File )
		f:flush()
		return f
	elseif m == "a" then
		if not _native.fsWritable( path ) then return nil, path .. ": Permission denied", 13 end
		local f = setmetatable( { path = path, data = existing or "", pos = 1, writable = true }, File )
		f.pos = #f.data + 1
		return f
	end
	return nil, "invalid mode"
end
io.close = function( f ) if f then return f:close() end end
io.lines = function( path )
	local f = assert( io.open( path, "r" ) )
	return function()
		local l = f:read( "*l" )
		if not l then f:close() end
		return l
	end
end
io.write = function( ... )
	local parts = {}
	for i = 1, select( "#", ... ) do parts[i] = tostring( ( select( i, ... ) ) ) end
	_native.log( table.concat( parts ) )
end
local stdio = { setvbuf = function() return true end, write = function( self, ... ) io.write( ... ) return self end,
	flush = function( self ) return self end, close = function() end }
io.stdout = setmetatable( {}, { __index = stdio } )
io.stderr = setmetatable( {}, { __index = stdio } )
io.output = function() return io.stdout end

os.remove = function( path )
	if _native.fsRemove( path ) then return true end
	return nil, tostring( path ) .. ": No such file or directory"
end
os.rename = function( from, to )
	local data = _native.fsRead( from )
	if data == nil then return nil, tostring( from ) .. ": No such file or directory" end
	_native.fsWrite( to, data )
	_native.fsRemove( from )
	return true
end
os.exit = function() end
os.execute = function() return false end
os.getenv = function() return nil end
os.clock = os.clock or function() return system.getTimer() / 1000 end

------------------------------------------------------------------------------
-- Event dispatch (adapted from Solar2D init.lua, MIT)
------------------------------------------------------------------------------

local Object = {}
function Object:new( o )
	o = o or {}
	setmetatable( o, self )
	self.__index = self
	return o
end

function Object:newClass( o )
	o = self:new( o )
	o._super = self
	return o
end

local EventDispatcher = Object:newClass()

EventDispatcher._indexForType = { ["table"] = "_tableListeners", ["function"] = "_functionListeners" }

function EventDispatcher:getOrCreateTable( eventName, listenerType )
	local index = EventDispatcher._indexForType[ listenerType ]
	local t = nil
	if index then
		local listeners = rawget( self, index ) or self[index]
		if nil == listeners then
			listeners = {}
			self[index] = listeners
		end
		t = listeners[eventName]
		if nil == t then
			t = {}
			listeners[eventName] = t
		end
	end
	return t
end

function EventDispatcher:addEventListener( eventName, listener )
	if not listener and self[eventName] then listener = self end
	local listenerType = type( listener )
	local t = self:getOrCreateTable( eventName, listenerType )
	if t then
		table.insert( t, listener )
	end
	return ( t ~= nil )
end

function EventDispatcher:didRemoveListener( eventName )
end

function EventDispatcher:removeEventListener( eventName, listener )
	if not listener and self[eventName] then listener = self end
	local wasRemoved = false
	local k = EventDispatcher._indexForType[ type( listener ) ]
	local listenerTable = k and self[k]
	if listenerTable then
		local listenerArray = listenerTable[eventName]
		if listenerArray then
			for index = 1, #listenerArray do
				if rawequal( listener, listenerArray[index] ) then
					table.remove( listenerArray, index )
					wasRemoved = true
					if #listenerArray == 0 then
						listenerTable[eventName] = nil
					end
					self:didRemoveListener( eventName )
					break
				end
			end
		end
	end
	return wasRemoved or nil
end

function EventDispatcher:hasEventListener( eventName, listener )
	if not listener and self[eventName] then listener = self end
	local k = EventDispatcher._indexForType[ type( listener ) ]
	local listenerTable = k and self[k]
	if listenerTable then
		local listenerArray = listenerTable[eventName]
		if listenerArray then
			for index = 1, #listenerArray do
				if rawequal( listener, listenerArray[index] ) then
					return true
				end
			end
		end
	end
	return false
end

local function cloneArray( array )
	local clone = {}
	for k, v in ipairs( array ) do
		clone[k] = v
	end
	return clone
end

function EventDispatcher:dispatchEvent( event )
	local result = false
	local eventName = event.name

	local functionDict = self._functionListeners
	local functionArray = ( functionDict and functionDict[eventName] ) or nil
	if ( functionArray ~= nil ) and ( #functionArray > 0 ) then
		local functionArrayClone = cloneArray( functionArray )
		for index = 1, #functionArrayClone do
			local func = functionArrayClone[index]
			if self:hasEventListener( eventName, func ) then
				local handled = func( event )
				result = handled or result
			end
		end
	end

	local tableDict = self._tableListeners
	local tableArray = ( tableDict and tableDict[eventName] ) or nil
	if ( tableArray ~= nil ) and ( #tableArray > 0 ) then
		local tableArrayClone = cloneArray( tableArray )
		for index = 1, #tableArrayClone do
			local obj = tableArrayClone[index]
			if self:hasEventListener( eventName, obj ) then
				local method = obj[eventName]
				if ( type( method ) == "function" ) then
					local handled = method( obj, event )
					result = handled or result
				end
			end
		end
	end

	return result
end

function EventDispatcher:respondsToEvent( eventName )
	local t = self._functionListeners
	local result = t and t[eventName]
	if not result then
		t = self._tableListeners
		result = t and t[eventName]
	end
	return result
end

system.newEventDispatcher = function()
	return EventDispatcher:new()
end

local ExtendedEventDispatcher = EventDispatcher:newClass()

Runtime = ExtendedEventDispatcher:newClass()

function Runtime:addEventListener( eventName, listener )
	local super = self._super
	return super.addEventListener( self, eventName, listener ) or nil
end

function Runtime:removeEventListener( eventName, listener )
	local super = self._super
	return super.removeEventListener( self, eventName, listener )
end

function Runtime:hasEventSource( eventName )
	return true
end

function Runtime:setCheckGlobals( onOff )
end

local function verifyListener( listener, name )
	local listenerType = type( listener )
	if "function" == listenerType then
		return listener
	elseif "table" == listenerType then
		local method = listener[name]
		if type( method ) == "function" then
			return listener
		end
	end
	return nil
end

local function callListener( listener, name, ... )
	local listenerType = type( listener )
	if listenerType == "function" then
		return listener( ... )
	elseif listenerType == "table" then
		return listener[name]( listener, ... )
	end
end

Runtime.verifyListener = verifyListener
Runtime.callListener = callListener

local PublicObject = {}
function PublicObject:new( o )
	o = o or {}
	setmetatable( o, self )
	self.__index = self
	return o
end
Runtime.Object = PublicObject

local _frame_id, _frame_start_time = 0, 0
Runtime:addEventListener( "enterFrame", function( event )
	_frame_id, _frame_start_time = event.frame, event.time
end )
function Runtime.getFrameID() return _frame_id + 1 end
function Runtime.getFrameStartTime() return _frame_start_time end

-- Display objects are Lua tables whose metatable (installed by corona.js)
-- resolves engine properties natively and falls back to this class.
local DisplayObject = ExtendedEventDispatcher:new()

function DisplayObject:addEventListener( eventName, listener )
	local noListeners = not self:respondsToEvent( eventName )
	local wasAdded = ExtendedEventDispatcher.addEventListener( self, eventName, listener )
	if noListeners then
		self:_setHasListener( eventName, true )
	end
	return wasAdded or nil
end

function DisplayObject:removeEventListener( eventName, listener )
	local wasRemoved = ExtendedEventDispatcher.removeEventListener( self, eventName, listener )
	if not self:respondsToEvent( eventName ) then
		self:_setHasListener( eventName, false )
	end
	return wasRemoved or nil
end

_native.setDisplayObjectClass( DisplayObject )

display.remove = function( object )
	if object then
		local method = object.removeSelf
		if "function" == type( method ) then
			method( object )
		end
	end
end

display.newRetinaText = function( ... ) return display.newText( ... ) end

table.indexOf = function( t, object )
	if "table" == type( t ) then
		for i = 1, #t do
			if object == t[i] then return i end
		end
	end
	return nil
end

table.copy = function( t, ... )
	local copyShallow = function( src, dst, dstStart )
		local result = dst or {}
		local resultStart = 0
		if dst and dstStart then resultStart = dstStart end
		local resultLen = 0
		if "table" == type( src ) then
			resultLen = #src
			for i = 1, resultLen do
				local value = src[i]
				if nil ~= value then
					result[i + resultStart] = value
				else
					resultLen = i - 1
					break
				end
			end
		end
		return result, resultLen
	end
	local result, resultStart = copyShallow( t )
	local srcs = { ... }
	for i = 1, #srcs do
		local _, len = copyShallow( srcs[i], result, resultStart )
		resultStart = resultStart + len
	end
	return result
end

math.round = function( num ) return math.floor( num + .5 ) end

function string.starts( s, prefix ) return _sub( s, 1, #prefix ) == prefix end
function string.ends( s, suffix ) return suffix == "" or _sub( s, -#suffix ) == suffix end

------------------------------------------------------------------------------
-- Platform services that do not exist on the web
------------------------------------------------------------------------------

local function noop() end
local function stub( t )
	return setmetatable( t or {}, { __index = function() return noop end } )
end

native.newWebView = function( x, y, w, h )
	local r = display.newRect( x or 0, y or 0, w or 1, h or 1 )
	r.isVisible = false
	r.request = noop; r.stop = noop; r.back = noop; r.forward = noop; r.reload = noop
	return r
end
native.newVideo = native.newWebView
native.newMapView = native.newWebView

-- native.newTextField / native.newTextBox: an HTML input floating over the canvas
local TextInput = {}
local textInputProps = { x = true, y = true, width = "w", height = "h" }
local function newTextInput( multiline, x, y, w, h )
	local id = _native.tiCreate( multiline, x or 0, y or 0, w or 100, h or 20 )
	local state = { id = id, x = x or 0, y = y or 0, width = w or 100, height = h or 20, isVisible = true,
		isEditable = true, size = 12, placeholder = "", align = "left" }
	local obj = { _state = state }
	return setmetatable( obj, {
		__index = function( t, k )
			if k == "text" then return _native.tiGet( id ) end
			if state[k] ~= nil then return state[k] end
			return TextInput[k]
		end,
		__newindex = function( t, k, v )
			if k == "text" then _native.tiSet( id, "text", tostring( v or "" ) )
			elseif textInputProps[k] then
				state[k] = v
				_native.tiSet( id, textInputProps[k] == true and k or textInputProps[k], v )
			elseif k == "isVisible" then state[k] = v and true or false; _native.tiSet( id, "visible", state[k] )
			elseif k == "isEditable" then state[k] = v and true or false; _native.tiSet( id, "editable", state[k] )
			elseif k == "size" then state[k] = v; _native.tiSet( id, "size", v )
			elseif k == "font" then state[k] = v; _native.tiSet( id, "font", type( v ) == "table" and v.name or v )
			elseif k == "placeholder" then state[k] = v; _native.tiSet( id, "placeholder", tostring( v or "" ) )
			elseif k == "align" then state[k] = v; _native.tiSet( id, "align", v )
			elseif k == "maxLength" then state[k] = v; _native.tiSet( id, "maxLength", v )
			else rawset( t, k, v ) end
		end,
	} )
end
function TextInput:setTextColor( r, g, b, a )
	if g == nil then g, b = r, r end
	_native.tiSet( self._state.id, "color", r or 0, g or 0, b or 0, a or 1 )
end
function TextInput:addEventListener( name, listener )
	if name == "userInput" then
		self._state.listener = listener
		_native.tiListener( self._state.id, function( event )
			event.target = self
			if type( listener ) == "function" then return listener( event ) end
			if type( listener ) == "table" and listener.userInput then return listener:userInput( event ) end
		end )
	end
end
function TextInput:removeEventListener( name )
	if name == "userInput" then _native.tiListener( self._state.id, nil ) end
end
function TextInput:removeSelf()
	if self._state.removed then return end
	self._state.removed = true
	_native.tiRemove( self._state.id )
end
function TextInput:setSelection() end
function TextInput:resizeFontToFitHeight() end
function TextInput:resizeHeightToFitFont() end
native.newTextField = function( x, y, w, h ) return newTextInput( false, x, y, w, h ) end
native.newTextBox = function( x, y, w, h ) return newTextInput( true, x, y, w, h ) end
native.setKeyboardFocus = function( obj )
	if obj and obj._state then _native.tiFocus( obj._state.id ) else _native.tiFocus( 0 ) end
end
native.newFont = function( name, size ) return name end

-- files (web build): export / import of level files, fullscreen, deferred main.lua
native.saveTextFile = function( filename, text ) return _native.saveFile( filename, text ) end
native.openTextFile = function( listener, accept ) return _native.openFile( listener, accept ) end
native.setFullscreen = function( on ) _native.setFullscreen( on and true or false ) end
native.isFullscreen = function() return _native.isFullscreen() end
native.resumeAudio = function() _native.resumeAudio() end
native.runMain = function() _native.runMain() end

local preload = package.preload
preload["analytics"] = function() return stub{ init = noop, logEvent = noop } end
preload["ads"] = function() return stub{ init = noop, show = noop, hide = noop } end
preload["gameNetwork"] = function() return stub{ init = noop, request = noop, show = noop } end
preload["facebook"] = function() return stub{ login = noop, logout = noop, request = noop, showDialog = noop } end
preload["store"] = function() return stub{ init = noop, purchase = noop, restore = noop, canMakePurchases = false, isActive = false } end
preload["physics"] = function() return stub{} end
preload["licensing"] = function() return stub{ init = noop, verify = noop } end
preload["crypto"] = function()
	return {
		md4 = "md4", md5 = "md5", sha1 = "sha1", sha224 = "sha224", sha256 = "sha256", sha384 = "sha384", sha512 = "sha512",
		digest = function( algorithm, data, raw ) return _native.digest( algorithm, tostring( data ), raw and true or false ) end,
		hmac = function( algorithm, data, key, raw ) return _native.digest( algorithm, tostring( key ) .. tostring( data ), raw and true or false ) end,
	}
end

-- Third-party SDK wrappers in the game (ads, Facebook, Game Center, Kiip,
-- GameThrive, rating prompts). Same interface, no network services behind them.
preload["_ads"] = function()
	return {
		initAdProviders = noop,
		possiblyShowStartupAd = function() return false end,
		possiblyShowInterstitial = function() return false end,
		possiblyShowExitAd = function() return false end,
	}
end
preload["_applovin"] = function() return stub{} end
preload["_kiip_utils"] = function() return { init = noop, savedData = { numMomentsSaved = 0 }, saveMoment = noop } end
preload["_gamethrive_utils"] = function() return { doCommonTags = noop, playerPurchase = noop, init = noop } end
preload["_offers"] = function() return { init = noop, showAd = function() return false end } end
preload["_fb_utils"] = function() return stub{ generateFbParams = function() return "" end } end
preload["_fb_friends"] = function() return stub{ possiblyFetchAndSaveFriends = noop } end
preload["_gamenetwork_utils"] = function()
	return {
		initGC = noop, sendAchievementProgress = noop, sendHighScore = noop,
		showAchievements = noop, showLeaderboards = noop,
	}
end
preload["_rating"] = function() return { checkforRatingPopup = noop } end

-- Any other native plugin resolves to an inert table.
table.insert( package.searchers, function( name )
	if _sub( name, 1, 7 ) == "plugin." or _sub( name, 1, 15 ) == "CoronaProvider." then
		return function() return stub{} end
	end
	return "\n\tno web stub for '" .. name .. "'"
end )

------------------------------------------------------------------------------
-- Corona framework libraries (Solar2D sources, MIT)
------------------------------------------------------------------------------

timer = require "timer"
easing = require "easing"
transition = require "transition"
