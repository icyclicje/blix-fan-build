local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_bsi.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = saver
L2_1 = L2_1.Load
L3_1 = "bsi.txt"
L2_1 = L2_1(L3_1)
if not L2_1 then
  L2_1 = {}
end
L0_1.savedData = L2_1
L2_1 = L0_1.savedData
L2_1 = L2_1.firstTimeUse
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L3_1 = os
  L3_1 = L3_1.time
  L3_1 = L3_1()
  L2_1.firstTimeUse = L3_1
end
L2_1 = L0_1.savedData
L2_1 = L2_1.sessionNumber
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.sessionNumber = 0
end
L2_1 = L0_1.savedData
L2_1 = L2_1.versionWhenInstalled
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L3_1 = APP_VERSION
  L2_1.versionWhenInstalled = L3_1
end
L2_1 = os
L2_1 = L2_1.time
L2_1 = L2_1()
L3_1 = L0_1.savedData
L3_1 = L3_1.timeOfLastUse
if not L3_1 then
  L3_1 = 0
end
L2_1 = L2_1 - L3_1
L0_1.timeSinceLastUse = L2_1
L2_1 = L0_1.savedData
L2_1 = L2_1.versionLastRun
if not L2_1 then
  L2_1 = 0
end
L0_1.versionLastRun = L2_1
L2_1 = os
L2_1 = L2_1.time
L2_1 = L2_1()
L0_1.timeOfThisSessionStartup = L2_1
L2_1 = L0_1.savedData
L3_1 = L0_1.savedData
L3_1 = L3_1.sessionNumber
L3_1 = L3_1 + 1
L2_1.sessionNumber = L3_1
L2_1 = L0_1.savedData
L3_1 = os
L3_1 = L3_1.time
L3_1 = L3_1()
L2_1.timeOfLastUse = L3_1
L2_1 = L0_1.savedData
L3_1 = APP_VERSION
L2_1.versionLastRun = L3_1
L2_1 = saver
L2_1 = L2_1.Save
L3_1 = L0_1.savedData
L4_1 = "bsi.txt"
L2_1(L3_1, L4_1)

function L2_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2 = L0_2.versionWhenInstalled
  return L0_2
end

L0_1.getVersionWhenInstalled = L2_1

function L2_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2 = L0_2.firstTimeUse
  return L0_2
end

L0_1.getFirstTimeUse = L2_1

function L2_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.timeSinceLastUse
  return L0_2
end

L0_1.getTimeSinceLastUse = L2_1

function L2_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2 = L0_2.sessionNumber
  return L0_2
end

L0_1.getSessionNumber = L2_1

function L2_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.versionLastRun
  return L0_2
end

L0_1.getVersionLastRun = L2_1

function L2_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.timeOfThisSessionStartup
  return L0_2
end

L0_1.getTimeOfThisSessionStartup = L2_1
if L1_1 then
  L2_1 = print
  L3_1 = "getVersionWhenInstalled="
  L4_1 = L0_1.getVersionWhenInstalled
  L4_1 = L4_1()
  L3_1 = L3_1 .. L4_1
  L2_1(L3_1)
  L2_1 = print
  L3_1 = "getFirstTimeUse="
  L4_1 = L0_1.getFirstTimeUse
  L4_1 = L4_1()
  L3_1 = L3_1 .. L4_1
  L2_1(L3_1)
  L2_1 = print
  L3_1 = "getTimeSinceLastUse="
  L4_1 = L0_1.getTimeSinceLastUse
  L4_1 = L4_1()
  L3_1 = L3_1 .. L4_1
  L2_1(L3_1)
  L2_1 = print
  L3_1 = "getSessionNumber="
  L4_1 = L0_1.getSessionNumber
  L4_1 = L4_1()
  L3_1 = L3_1 .. L4_1
  L2_1(L3_1)
  L2_1 = print
  L3_1 = "getVersionLastRun="
  L4_1 = L0_1.getVersionLastRun
  L4_1 = L4_1()
  L3_1 = L3_1 .. L4_1
  L2_1(L3_1)
end
return L0_1
