local L0_1, L1_1
L0_1 = table

function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = 0
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2 = L2_2(L3_2)
  for L5_2, L6_2 in L2_2, L3_2, L4_2 do
    L1_2 = L1_2 + 1
  end
  return L1_2
end

L0_1.getSize = L1_1
L0_1 = table

function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = {}
  
  function L2_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = type
    L2_3 = A0_3
    L1_3 = L1_3(L2_3)
    if L1_3 ~= "table" then
      return A0_3
    else
      L1_3 = L1_2
      L1_3 = L1_3[A0_3]
      if L1_3 then
        L1_3 = L1_2
        L1_3 = L1_3[A0_3]
        return L1_3
      end
    end
    L1_3 = {}
    L2_3 = L1_2
    L2_3[A0_3] = L1_3
    L2_3 = pairs
    L3_3 = A0_3
    L2_3, L3_3, L4_3 = L2_3(L3_3)
    for L5_3, L6_3 in L2_3, L3_3, L4_3 do
      L7_3 = L2_2
      L8_3 = L5_3
      L7_3 = L7_3(L8_3)
      L8_3 = L2_2
      L9_3 = L6_3
      L8_3 = L8_3(L9_3)
      L1_3[L7_3] = L8_3
    end
    L2_3 = setmetatable
    L3_3 = L1_3
    L4_3 = getmetatable
    L5_3 = A0_3
    return L2_3(L3_3, L4_3(L5_3))
  end
  
  L3_2 = L2_2
  L4_2 = A0_2
  return L3_2(L4_2)
end

L0_1.deepCopy = L1_1
L0_1 = table

function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2 = L2_2(L3_2)
  for L5_2, L6_2 in L2_2, L3_2, L4_2 do
    if L6_2 == A1_2 then
      L7_2 = true
      return L7_2
    end
  end
  L2_2 = false
  return L2_2
end

L0_1.contains = L1_1
