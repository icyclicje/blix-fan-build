local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1
L0_1 = {}
L1_1 = require
L2_1 = "json"
L1_1 = L1_1(L2_1)
L2_1 = {}
L0_1.t = L2_1
L2_1 = L0_1.t
L2_1.useSSL = false
L2_1 = L0_1.t
L2_1.allowEasterEgg = true
L2_1 = L0_1.t
L2_1.flurry_key_ios = ""
L2_1 = L0_1.t
L2_1.flurry_key_android = ""
L2_1 = L0_1.t
L2_1.flurry_key_nook = ""
L2_1 = L0_1.t
L2_1.flurry_key_kindle = ""
L2_1 = L0_1.t
L2_1.gc_ios_leaderboard_id = ""
L2_1 = L0_1.t
L2_1.gc_android_leaderboard_id = ""
L2_1 = L0_1.t
L2_1.kiip_turned_on = false
L2_1 = L0_1.t
L2_1.kiip_gremlin_license_key = ""
L2_1 = L0_1.t
L2_1.kiip_app_key_android = ""
L2_1 = L0_1.t
L2_1.kiip_app_secret_android = ""
L2_1 = L0_1.t
L2_1.kiip_app_key_ios = ""
L2_1 = L0_1.t
L2_1.kiip_app_secret_ios = ""
L2_1 = L0_1.t
L2_1.ask_for_rating_freq_mod = 12
L2_1 = L0_1.t
L2_1.allow_rating_optout = true
L2_1 = L0_1.t
L2_1.enableAppTrailersS2S = false
L2_1 = L0_1.t
L2_1.appTrailersAppId = ""
L2_1 = L0_1.t
L2_1.appTrailersSSK = ""
L2_1 = L0_1.t
L2_1.ads_startup_chance = 0
L2_1 = L0_1.t
L2_1.ads_interstitial_chance = 0
L2_1 = L0_1.t
L2_1.ads_exit_chance = 0
L2_1 = L0_1.t
L2_1.ads_min_seconds_between_interstitials = 180
L2_1 = L0_1.t
L2_1.ads_min_seconds_into_session_before_interstitial = 90
L2_1 = L0_1.t
L2_1.applovin_startup_share = 0
L2_1 = L0_1.t
L2_1.applovin_interstitial_share = 0
L2_1 = L0_1.t
L2_1.applovin_exit_share = 0
L2_1 = L0_1.t
L2_1.applovin_use_easier_to_close_native_display = true
L2_1 = L0_1.t
L2_1.vungle_startup_share = 0
L2_1 = L0_1.t
L2_1.vungle_interstitial_share = 0
L2_1 = L0_1.t
L2_1.vungle_exit_share = 0
L2_1 = L0_1.t
L2_1.vungle_enable_sound = false
L2_1 = L0_1.t
L2_1.vungle_appid_android = ""
L2_1 = L0_1.t
L2_1.vungle_appid_ios = ""
L2_1 = L0_1.t
L2_1.playhaven_startup_share = 0
L2_1 = L0_1.t
L2_1.playhaven_interstitial_share = 0
L2_1 = L0_1.t
L2_1.playhaven_exit_share = 0
L2_1 = L0_1.t
L2_1.playhaven_token_android = ""
L2_1 = L0_1.t
L2_1.playhaven_secret_android = ""
L2_1 = L0_1.t
L2_1.playhaven_token_ios = ""
L2_1 = L0_1.t
L2_1.playhaven_secret_ios = ""
L2_1 = L0_1.t
L2_1.adbuddiz_startup_share = 0
L2_1 = L0_1.t
L2_1.adbuddiz_interstitial_share = 0
L2_1 = L0_1.t
L2_1.adbuddiz_exit_share = 0
L2_1 = L0_1.t
L2_1.adbuddiz_apppublisherkey_android = ""
L2_1 = L0_1.t
L2_1.adbuddiz_apppublisherkey_ios = ""
L2_1 = L0_1.t
L2_1.offers_startup_share = 0
L2_1 = L0_1.t
L2_1.offers_interstitial_share = 0
L2_1 = L0_1.t
L2_1.offers_exit_share = 0
L2_1 = L0_1.t
L3_1 = {}
L2_1.offers = L3_1
L2_1 = saver
L2_1 = L2_1.Load
L3_1 = "settings.txt"
L2_1 = L2_1(L3_1)
if not L2_1 then
  L2_1 = {}
end
L0_1.savedData = L2_1
L2_1 = L0_1.savedData
L2_1 = L2_1.numServerCalls
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.numServerCalls = 0
end
L2_1 = L0_1.savedData
L2_1 = L2_1.numServerResponses
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.numServerResponses = 0
end
L2_1 = L0_1.savedData
L2_1 = L2_1.lastTimeOfGoodResponse
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.lastTimeOfGoodResponse = 0
end
L2_1 = L0_1.savedData
L2_1 = L2_1.lastTimeShowedDialog
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.lastTimeShowedDialog = 0
end
L2_1 = L0_1.savedData
L2_1 = L2_1.noDialogStreak
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.noDialogStreak = 0
end
L2_1 = L0_1.savedData
L2_1 = L2_1.t
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L3_1 = {}
  L2_1.t = L3_1
end
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "_settings.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = nil
L4_1 = nil
L5_1 = false
L6_1 = nil
L7_1 = nil
L8_1 = nil

function L9_1()
  local L0_2, L1_2
  L0_2 = L7_1
  if not L0_2 then
    L0_2 = 9999999
  end
  return L0_2
end

L0_1.getInternetLatency = L9_1

function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = pairs
  L1_2 = L0_1
  L1_2 = L1_2.t
  L0_2, L1_2, L2_2 = L0_2(L1_2)
  for L3_2, L4_2 in L0_2, L1_2, L2_2 do
    L5_2 = L0_1
    L5_2 = L5_2.savedData
    L5_2 = L5_2.t
    L5_2 = L5_2[L3_2]
    if L5_2 ~= nil then
      L5_2 = L0_1
      L5_2 = L5_2.t
      L5_2 = L5_2[L3_2]
      L6_2 = L0_1
      L6_2 = L6_2.savedData
      L6_2 = L6_2.t
      L6_2 = L6_2[L3_2]
      if L5_2 ~= L6_2 then
        L5_2 = _SIMULATOR
        if L5_2 then
          L5_2 = print
          L6_2 = "Saved overrode default "
          L7_2 = L3_2
          L8_2 = " from "
          L9_2 = tostring
          L10_2 = L0_1
          L10_2 = L10_2.t
          L10_2 = L10_2[L3_2]
          L9_2 = L9_2(L10_2)
          L10_2 = " to "
          L11_2 = tostring
          L12_2 = L0_1
          L12_2 = L12_2.savedData
          L12_2 = L12_2.t
          L12_2 = L12_2[L3_2]
          L11_2 = L11_2(L12_2)
          L6_2 = L6_2 .. L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2
          L5_2(L6_2)
        end
      end
      L5_2 = L0_1
      L5_2 = L5_2.t
      L6_2 = L0_1
      L6_2 = L6_2.savedData
      L6_2 = L6_2.t
      L6_2 = L6_2[L3_2]
      L5_2[L3_2] = L6_2
    end
    L5_2 = L2_1
    if L5_2 then
      L5_2 = print
      L6_2 = "overrideDefaultsWithSaved"
      L7_2 = L3_2
      L8_2 = L0_1
      L8_2 = L8_2.t
      L8_2 = L8_2[L3_2]
      L5_2(L6_2, L7_2, L8_2)
    end
  end
end

L10_1 = L9_1
L10_1()

function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = L3_1
  if L0_2 == nil then
    L0_2 = print
    L1_2 = "t_fromServer was nil"
    L0_2(L1_2)
  end
  L0_2 = pairs
  L1_2 = L0_1
  L1_2 = L1_2.t
  L0_2, L1_2, L2_2 = L0_2(L1_2)
  for L3_2, L4_2 in L0_2, L1_2, L2_2 do
    L5_2 = L3_1
    L5_2 = L5_2[L3_2]
    if L5_2 ~= nil then
      L5_2 = L0_1
      L5_2 = L5_2.t
      L5_2 = L5_2[L3_2]
      L6_2 = L3_1
      L6_2 = L6_2[L3_2]
      if L5_2 ~= L6_2 then
        L5_2 = _SIMULATOR
        if L5_2 then
          L5_2 = print
          L6_2 = "Server overrode saved "
          L7_2 = L3_2
          L8_2 = " from "
          L9_2 = tostring
          L10_2 = L0_1
          L10_2 = L10_2.t
          L10_2 = L10_2[L3_2]
          L9_2 = L9_2(L10_2)
          L10_2 = " to "
          L11_2 = tostring
          L12_2 = L3_1
          L12_2 = L12_2[L3_2]
          L11_2 = L11_2(L12_2)
          L6_2 = L6_2 .. L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2
          L5_2(L6_2)
        end
      end
      L5_2 = L0_1
      L5_2 = L5_2.t
      L6_2 = L3_1
      L6_2 = L6_2[L3_2]
      L5_2[L3_2] = L6_2
      L5_2 = L0_1
      L5_2 = L5_2.savedData
      L5_2 = L5_2.t
      L6_2 = L3_1
      L6_2 = L6_2[L3_2]
      L5_2[L3_2] = L6_2
    end
    L5_2 = L2_1
    if L5_2 then
      L5_2 = print
      L6_2 = "overrideSavedWithServerValues"
      L7_2 = L3_2
      L8_2 = L0_1
      L8_2 = L8_2.t
      L8_2 = L8_2[L3_2]
      L5_2(L6_2, L7_2, L8_2)
    end
  end
end

function L11_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = A0_2.index
  if L1_2 == 1 then
    L2_2 = L3_1
    L2_2 = L2_2.positiveURL
    if L2_2 then
      L2_2 = system
      L2_2 = L2_2.openURL
      L3_2 = L3_1
      L3_2 = L3_2.positiveURL
      L2_2(L3_2)
    end
  elseif L1_2 == 2 then
    L2_2 = L3_1
    L2_2 = L2_2.negativeURL
    if L2_2 then
      L2_2 = system
      L2_2 = L2_2.openURL
      L3_2 = L3_1
      L3_2 = L3_2.negativeURL
      L2_2(L3_2)
    end
  end
end

function L12_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = native
  L0_2 = L0_2.showAlert
  L1_2 = L3_1
  L1_2 = L1_2.title
  L2_2 = L3_1
  L2_2 = L2_2.description
  L3_2 = {}
  L4_2 = L3_1
  L4_2 = L4_2.positiveButton
  L5_2 = L3_1
  L5_2 = L5_2.negativeButton
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L4_2 = L11_1
  L0_2(L1_2, L2_2, L3_2, L4_2)
end

function L13_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = L2_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "reportDoneAndSave() serverStatus="
    L3_2 = tostring
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
  L1_2 = L8_1
  if L1_2 then
    L1_2 = timer
    L1_2 = L1_2.cancel
    L2_2 = L8_1
    L1_2(L2_2)
    L1_2 = nil
    L8_1 = L1_2
  end
  L1_2 = L7_1
  if L1_2 and not A0_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "_settings: got timeout after success"
    L1_2(L2_2)
    return
  end
  L1_2 = L7_1
  if L1_2 and A0_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "_settings: got multiple server responses"
    L1_2(L2_2)
    return
  end
  L1_2 = toast
  L1_2 = L1_2.hide
  L1_2()
  if A0_2 then
    L1_2 = system
    L1_2 = L1_2.getTimer
    L1_2 = L1_2()
    L2_2 = L6_1
    L1_2 = L1_2 - L2_2
    L7_1 = L1_2
    L1_2 = L2_1
    if L1_2 then
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "reportDoneAndSave() howLongCallTookInMs="
      L3_2 = L7_1
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
    end
    L1_2 = false
    L2_2 = nil
    L3_2 = _SIMULATOR
    if L3_2 then
      L3_2 = L0_1
      L3_2 = L3_2.t
      L2_2 = L3_2.flurry_key_ios
    end
    L3_2 = platform
    L3_2 = L3_2.ios
    if L3_2 then
      L3_2 = L0_1
      L3_2 = L3_2.t
      L2_2 = L3_2.flurry_key_ios
    end
    L3_2 = platform
    L3_2 = L3_2.android
    if L3_2 then
      L3_2 = L0_1
      L3_2 = L3_2.t
      L2_2 = L3_2.flurry_key_android
    end
    L3_2 = _KINDLE
    if L3_2 then
      L3_2 = L0_1
      L3_2 = L3_2.t
      L2_2 = L3_2.flurry_key_kindle
    end
    L3_2 = _NOOK
    if L3_2 then
      L3_2 = L0_1
      L3_2 = L3_2.t
      L2_2 = L3_2.flurry_key_nook
    end
    if L2_2 then
      L4_2 = L2_2
      L3_2 = L2_2.len
      L3_2 = L3_2(L4_2)
      if 0 < L3_2 then
        L3_2 = analytics
        L3_2 = L3_2.init
        L4_2 = L2_2
        L3_2(L4_2)
        L3_2 = analytics
        L3_2 = L3_2.logEvent
        L4_2 = "Startup"
        L3_2(L4_2)
    end
    else
      L3_2 = L2_1
      if not L3_2 then
        L3_2 = _SIMULATOR
        if not L3_2 then
          goto lbl_124
        end
      end
      L3_2 = log
      L3_2 = L3_2.show
      L4_2 = "Warning: flurry_application_key is "
      L5_2 = L2_2 or L5_2
      if not L2_2 then
        L5_2 = "nil"
      end
      L4_2 = L4_2 .. L5_2
      L3_2(L4_2)
    end
    ::lbl_124::
    L3_2 = L3_1
    if L3_2 then
      L3_2 = L3_1
      L3_2 = L3_2.dialog
      if L3_2 then
        L3_2 = L12_1
        L3_2()
        L1_2 = true
        L3_2 = L0_1
        L3_2 = L3_2.savedData
        L4_2 = os
        L4_2 = L4_2.time
        L4_2 = L4_2()
        L3_2.lastTimeShowedDialog = L4_2
    end
    else
      L3_2 = L0_1
      L3_2 = L3_2.savedData
      L4_2 = L0_1
      L4_2 = L4_2.savedData
      L4_2 = L4_2.noDialogStreak
      L4_2 = L4_2 + 1
      L3_2.noDialogStreak = L4_2
    end
    L3_2 = saver
    L3_2 = L3_2.Save
    L4_2 = L0_1
    L4_2 = L4_2.savedData
    L5_2 = "settings.txt"
    L3_2(L4_2, L5_2)
    L3_2 = ads
    L3_2 = L3_2.initAdProviders
    L3_2()
    if not L1_2 then
      L3_2 = ads
      L3_2 = L3_2.possiblyShowStartupAd
      L3_2()
    end
    L3_2 = L0_1
    L3_2 = L3_2.t
    L3_2 = L3_2.enableAppTrailersS2S
    if L3_2 then
      L3_2 = L0_1
      L3_2 = L3_2.t
      L3_2 = L3_2.appTrailersAppId
      if L3_2 then
        L3_2 = L0_1
        L3_2 = L3_2.t
        L3_2 = L3_2.appTrailersSSK
        if L3_2 then
          L3_2 = "http://d1.appredeem.com/redeem.php?mac_addr="
          L4_2 = _UUID
          L5_2 = "&appid="
          L6_2 = L0_1
          L6_2 = L6_2.t
          L6_2 = L6_2.appTrailersAppId
          L7_2 = "&ssk="
          L8_2 = L0_1
          L8_2 = L8_2.t
          L8_2 = L8_2.appTrailersSSK
          L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2 .. L7_2 .. L8_2
          L4_2 = platform
          L4_2 = L4_2.android
          if L4_2 then
            L4_2 = "http://d1.appredeem.com/redeem_android.php?uuid="
            L5_2 = _UUID
            L6_2 = "&appid="
            L7_2 = L0_1
            L7_2 = L7_2.t
            L7_2 = L7_2.appTrailersAppId
            L8_2 = "&ssk="
            L9_2 = L0_1
            L9_2 = L9_2.t
            L9_2 = L9_2.appTrailersSSK
            L3_2 = L4_2 .. L5_2 .. L6_2 .. L7_2 .. L8_2 .. L9_2
          end
          L4_2 = {}
          L4_2["Accept-Language"] = "en-US"
          L5_2 = {}
          L5_2.headers = L4_2
          L6_2 = network
          L6_2 = L6_2.request
          L7_2 = L3_2
          L8_2 = "GET"
          
          function L9_2(A0_3)
            local L1_3, L2_3
            L1_3 = L2_1
            if L1_3 then
              L1_3 = print
              L2_3 = A0_3.status
              L1_3(L2_3)
            end
          end
          
          L10_2 = L5_2
          L6_2(L7_2, L8_2, L9_2, L10_2)
        end
      end
    end
    L3_2 = kiip_utils
    L3_2 = L3_2.init
    L3_2()
  end
  L1_2 = L4_1
  if L1_2 then
    L1_2 = L5_1
    if not L1_2 then
      L1_2 = L4_1
      L1_2()
      L1_2 = nil
      L4_1 = L1_2
    end
  end
  L1_2 = true
  L5_1 = L1_2
end

function L14_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = A0_2.isError
  if L1_2 then
    L1_2 = print
    L2_2 = "settings networkListener: Network error"
    L1_2(L2_2)
    L1_2 = L13_1
    L2_2 = nil
    L1_2(L2_2)
  else
    L1_2 = L2_1
    if L1_2 then
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "networkListener"
      L1_2(L2_2)
    end
    L1_2 = L1_1
    L1_2 = L1_2.decode
    L2_2 = A0_2.response
    L1_2 = L1_2(L2_2)
    L3_1 = L1_2
    L1_2 = L2_1
    if L1_2 then
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "event.status: "
      L3_2 = A0_2.status
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "event.response:len(): "
      L3_2 = A0_2.response
      L4_2 = L3_2
      L3_2 = L3_2.len
      L3_2 = L3_2(L4_2)
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
      L1_2 = L3_1
      if L1_2 then
        L1_2 = log
        L1_2 = L1_2.show
        L2_2 = "t_fromServer is good"
        L1_2(L2_2)
      else
        L1_2 = log
        L1_2 = L1_2.show
        L2_2 = "t_fromServer is nil"
        L1_2(L2_2)
      end
      L1_2 = print
      L2_2 = "t_fromServer:"
      L1_2(L2_2)
      L1_2 = print
      L2_2 = inspect
      L3_2 = L3_1
      L1_2(L2_2(L3_2))
      L1_2 = A0_2.status
      if L1_2 ~= 200 then
        L1_2 = print
        L2_2 = A0_2.response
        L1_2(L2_2)
      end
    end
    L1_2 = L3_1
    if L1_2 then
      L1_2 = L10_1
      L1_2()
      L1_2 = L0_1
      L1_2 = L1_2.savedData
      L2_2 = L0_1
      L2_2 = L2_2.savedData
      L2_2 = L2_2.numServerResponses
      L2_2 = L2_2 + 1
      L1_2.numServerResponses = L2_2
      L1_2 = L0_1
      L1_2 = L1_2.savedData
      L2_2 = os
      L2_2 = L2_2.time
      L2_2 = L2_2()
      L1_2.lastTimeOfGoodResponse = L2_2
    end
    L1_2 = L13_1
    L2_2 = A0_2.status
    L1_2(L2_2)
  end
end

function L15_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = _SIMULATOR
  if L2_2 then
    L2_2 = platform
    L2_2 = L2_2.android
    if L2_2 then
      L2_2 = log
      L2_2 = L2_2.show
      L3_2 = "hacked to pretend to be Android"
      L2_2(L3_2)
    end
  end
  L2_2 = _SIMULATOR
  if L2_2 then
    L2_2 = platform
    L2_2 = L2_2.ios
    if L2_2 then
      L2_2 = log
      L2_2 = L2_2.show
      L3_2 = "hacked to pretend to be iOS"
      L2_2(L3_2)
    end
  end
  L2_2 = L2_1
  if L2_2 then
    L2_2 = log
    L2_2 = L2_2.show
    L3_2 = "settings.callServer()"
    L2_2(L3_2)
  end
  L2_2 = A1_2.initMsg
  if not L2_2 then
    L2_2 = "Initializing..."
  end
  L3_2 = toast
  L3_2 = L3_2.show
  L4_2 = L2_2
  L5_2 = A1_2
  L3_2(L4_2, L5_2)
  L3_2 = system
  L3_2 = L3_2.getTimer
  L3_2 = L3_2()
  L6_1 = L3_2
  L3_2 = L0_1
  L3_2 = L3_2.savedData
  L4_2 = L0_1
  L4_2 = L4_2.savedData
  L4_2 = L4_2.numServerCalls
  L4_2 = L4_2 + 1
  L3_2.numServerCalls = L4_2
  L4_1 = A0_2
  L3_2 = {}
  L3_2["Accept-Language"] = "en-US"
  L4_2 = {}
  L4_2.headers = L3_2
  L5_2 = utils
  L5_2 = L5_2.getURL
  L6_2 = "GET"
  L5_2 = L5_2(L6_2)
  L6_2 = "?Command=Games_GetSettings2&game="
  L7_2 = APP_ID
  L8_2 = "&"
  L9_2 = utils
  L9_2 = L9_2.getParametersForServer
  L9_2 = L9_2()
  L10_2 = ltv
  L10_2 = L10_2.generateParamsString
  L10_2 = L10_2()
  L5_2 = L5_2 .. L6_2 .. L7_2 .. L8_2 .. L9_2 .. L10_2
  L6_2 = L2_1
  if L6_2 then
    L6_2 = print
    L7_2 = L5_2
    L6_2(L7_2)
  end
  L6_2 = network
  L6_2 = L6_2.request
  L7_2 = L5_2
  L8_2 = "GET"
  L9_2 = L14_1
  L10_2 = L4_2
  L6_2(L7_2, L8_2, L9_2, L10_2)
  L6_2 = timer
  L6_2 = L6_2.performWithDelay
  L7_2 = 3500
  
  function L8_2()
    local L0_3, L1_3
    L0_3 = L13_1
    L1_3 = nil
    L0_3(L1_3)
  end
  
  L6_2 = L6_2(L7_2, L8_2)
  L8_1 = L6_2
end

L0_1.callServer = L15_1
return L0_1
