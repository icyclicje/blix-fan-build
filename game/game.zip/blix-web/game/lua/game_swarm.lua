local L0_1, L1_1, L2_1, L3_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "game_swarm.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = math
L2_1 = L2_1.random
L0_1.name = "Swarm"
L0_1.displayName = "Swarm"
L0_1.instructions = "How many squiggles can you have alive on the screen at once without letting them touch each other?"
L0_1.scoring = true
L0_1.leveling = false
L0_1.lives = 1
L0_1.oneStrokeAtOnce = false
L0_1.oneStrokePerColorAtOnce = false
L0_1.multitouch = true

function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = gamenetwork_utils
  L1_2 = L1_2.sendHighScore
  L2_2 = globals
  L2_2 = L2_2.LEADERBOARD_ID_SWARM
  L3_2 = _score
  L1_2(L2_2, L3_2)
end

L0_1.onEndGame = L3_1

function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L4_2 = A2_2
  L3_2 = A2_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = _loseLife
  L3_2()
end

L0_1.onStrokesCollide = L3_1

function L3_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = stroke
  L2_2 = L2_2.numInPlay
  L3_2 = _score
  if L2_2 > L3_2 then
    L2_2 = _setScore
    L3_2 = stroke
    L3_2 = L3_2.numInPlay
    L2_2(L3_2)
  end
end

L0_1.onStrokeFinished = L3_1

function L3_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = stroke
  L2_2 = L2_2.numInPlay
  L3_2 = _score
  if L2_2 > L3_2 then
    L2_2 = _setScore
    L3_2 = stroke
    L3_2 = L3_2.numInPlay
    L2_2(L3_2)
  end
end

L0_1.strokeLeftScreen = L3_1
return L0_1
