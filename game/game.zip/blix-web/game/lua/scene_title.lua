local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1, L22_1, L23_1, L24_1, L25_1, L26_1
L0_1 = require
L1_1 = "composer"
L0_1 = L0_1(L1_1)
L1_1 = L0_1.newScene
L1_1 = L1_1()
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "scene_title.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = nil
L4_1 = nil
L5_1 = nil
L6_1 = nil
L7_1 = nil
L8_1 = nil
L9_1 = nil
L10_1 = nil
L11_1 = nil
L12_1 = nil
L13_1 = nil
L14_1 = nil

function L15_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  if A0_2 then
    L1_2 = sounds
    L1_2 = L1_2.toggleSoundSetting
    L1_2()
  end
  L1_2 = "images/sound_on_white_120.png"
  L2_2 = sounds
  L2_2 = L2_2.savedData
  L2_2 = L2_2.soundOn
  if not L2_2 then
    L1_2 = "images/sound_off_white_120.png"
  end
  L2_2 = L12_1
  L3_2 = L2_2
  L2_2 = L2_2.setParam
  L4_2 = "file"
  L5_2 = L1_2
  L2_2(L3_2, L4_2, L5_2)
end

function L16_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = L0_1
  L0_2 = L0_2.gotoScene
  L1_2 = "scene_game"
  L2_2 = {}
  L3_2 = {}
  L4_2 = game_main
  L3_2.game = L4_2
  L3_2.skip_instructions = false
  L2_2.params = L3_2
  L0_2(L1_2, L2_2)
end

function L17_1()
  local L0_2, L1_2, L2_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Mini Games button"
  L0_2(L1_2)
  L0_2 = L0_1
  L0_2 = L0_2.showOverlay
  L1_2 = "scene_minigames_menu"
  L2_2 = {}
  L2_2.isModal = true
  L0_2(L1_2, L2_2)
end

function L18_1()
  local L0_2, L1_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "GameCenter button"
  L0_2(L1_2)
  L0_2 = gamenetwork_utils
  L0_2 = L0_2.showAchievements
  L1_2 = true
  L0_2(L1_2)
end

function L19_1()
  local L0_2, L1_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Leaderboard button"
  L0_2(L1_2)
  L0_2 = gamenetwork_utils
  L0_2 = L0_2.showLeaderboards
  L1_2 = true
  L0_2(L1_2)
end

function L20_1()
  local L0_2, L1_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Achievements button"
  L0_2(L1_2)
  L0_2 = gamenetwork_utils
  L0_2 = L0_2.showAchievements
  L1_2 = true
  L0_2(L1_2)
end

function L21_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = "Title Screen"
  L1_2 = "My best score is "
  L2_2 = progress
  L2_2 = L2_2.getHighScore
  L3_2 = game_main
  L3_2 = L3_2.name
  L2_2 = L2_2(L3_2)
  L3_2 = "! "
  L1_2 = L1_2 .. L2_2 .. L3_2
  L2_2 = platform
  L2_2 = L2_2.android
  if L2_2 then
    L2_2 = sharing
    L2_2 = L2_2.shareViaGoogle
    L3_2 = L0_2
    L4_2 = L1_2
    L2_2(L3_2, L4_2)
  else
    L2_2 = L0_1
    L2_2 = L2_2.showOverlay
    L3_2 = "_scene_share"
    L4_2 = {}
    L4_2.isModal = true
    L5_2 = {}
    L5_2.dimAlpha = 0.1
    L6_2 = gray
    L5_2.borderColor = L6_2
    L6_2 = white
    L5_2.bgColor = L6_2
    L5_2.framelessButtons = true
    L5_2.fontSize = 24
    L6_2 = gray
    L5_2.backButtonColor = L6_2
    L5_2.shareMsgPrefix = L1_2
    L5_2.source = L0_2
    L4_2.params = L5_2
    L2_2(L3_2, L4_2)
  end
end

function L22_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = L0_1
  L0_2 = L0_2.gotoScene
  L1_2 = "scene_game"
  L2_2 = {}
  L3_2 = {}
  L4_2 = game_tester
  L3_2.game = L4_2
  L3_2.skip_instructions = false
  L2_2.params = L3_2
  L0_2(L1_2, L2_2)
end

function L23_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_title:create()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = display
  L3_2 = L3_2.newRect
  L4_2 = L2_2
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = screenWidth
  L8_2 = screenHeight
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L3_1 = L3_2
  L3_2 = L3_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = white
  L3_2(L4_2, L5_2())
  L3_2 = display
  L3_2 = L3_2.newImageRect
  L4_2 = L2_2
  L5_2 = "images/graph_paper_1230x919.jpg"
  L6_2 = screenWidth
  L7_2 = screenWidth
  L7_2 = L7_2 * 919
  L7_2 = L7_2 / 1230
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2)
  L4_1 = L3_2
  L3_2 = L4_1
  L3_2.alpha = 0.1
  L3_2 = L4_1
  L4_2 = L4_1
  L5_2 = _W2
  L6_2 = _H2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = display
  L3_2 = L3_2.newText
  L4_2 = L2_2
  L5_2 = APP_NAME
  L6_2 = 0
  L7_2 = 0
  L8_2 = _ttf_font
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2 = L8_2[L9_2]
  L9_2 = 72
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L5_1 = L3_2
  L3_2 = L5_1
  L4_2 = L5_1
  L5_2 = _W2
  L6_2 = _H2
  L6_2 = L6_2 - 90
  L7_2 = _ttf_font_offset
  L8_2 = globals
  L8_2 = L8_2.defaultFont
  L7_2 = L7_2[L8_2]
  L7_2 = L7_2 * 72
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = L5_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = black
  L3_2(L4_2, L5_2())
  L3_2 = 0
  L4_2 = platform
  L4_2 = L4_2.android
  if L4_2 then
    L3_2 = 200
  end
  L4_2 = utils
  L4_2 = L4_2.typeOutTextObject
  L5_2 = L5_1
  L6_2 = L3_2
  L7_2 = 200
  L8_2 = false
  L9_2 = nil
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
  L4_2 = 0
  L5_2 = timer
  L5_2 = L5_2.performWithDelay
  L6_2 = 200
  
  function L7_2()
    local L0_3, L1_3, L2_3
    L0_3 = L4_2
    L0_3 = L0_3 + 1
    L4_2 = L0_3
    L0_3 = sounds
    L0_3 = L0_3.play
    L1_3 = sounds
    L1_3 = L1_3.hits
    L2_3 = L4_2
    L1_3 = L1_3[L2_3]
    L0_3(L1_3)
  end
  
  L8_2 = 4
  L5_2(L6_2, L7_2, L8_2)
  L5_2 = buttons
  L5_2 = L5_2.newPlainText
  L6_2 = "Start"
  L7_2 = L16_1
  L8_2 = {}
  L8_2.group = L2_2
  L9_2 = red
  L8_2.textColor = L9_2
  L8_2.frameless = true
  L8_2.fontSize = 40
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2.fontNum = L9_2
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L6_1 = L5_2
  L5_2 = L6_1
  L6_2 = L6_1
  L7_2 = _W2
  L8_2 = _H2
  L6_2.y = L8_2
  L5_2.x = L7_2
  L5_2 = buttons
  L5_2 = L5_2.newPlainText
  L6_2 = "Mini Games"
  L7_2 = L17_1
  L8_2 = {}
  L8_2.group = L2_2
  L9_2 = purple
  L8_2.textColor = L9_2
  L8_2.frameless = true
  L8_2.fontSize = 30
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2.fontNum = L9_2
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L7_1 = L5_2
  L5_2 = L7_1
  L6_2 = L7_1
  L7_2 = _W2
  L8_2 = _H2
  L8_2 = L8_2 + 50
  L6_2.y = L8_2
  L5_2.x = L7_2
  L5_2 = _H2
  L5_2 = L5_2 + 100
  L6_2 = platform
  L6_2 = L6_2.ios
  if L6_2 then
    L6_2 = buttons
    L6_2 = L6_2.newGraphical
    L7_2 = "images/gamecenter_gray_128.png"
    L8_2 = L18_1
    L9_2 = {}
    L9_2.group = L2_2
    L9_2.fixedWidth = 32
    L9_2.fixedHeight = 32
    L6_2 = L6_2(L7_2, L8_2, L9_2)
    L8_1 = L6_2
    L6_2 = buttons
    L6_2 = L6_2.newGraphical
    L7_2 = "images/share_gray_128.png"
    L8_2 = L21_1
    L9_2 = {}
    L9_2.group = L2_2
    L9_2.fixedWidth = 32
    L9_2.fixedHeight = 32
    L6_2 = L6_2(L7_2, L8_2, L9_2)
    L11_1 = L6_2
    L6_2 = L8_1
    L7_2 = L8_1
    L8_2 = _W2
    L8_2 = L8_2 - 20
    L7_2.y = L5_2
    L6_2.x = L8_2
    L6_2 = L11_1
    L7_2 = L11_1
    L8_2 = _W2
    L8_2 = L8_2 + 20
    L7_2.y = L5_2
    L6_2.x = L8_2
  else
    L6_2 = buttons
    L6_2 = L6_2.newGraphical
    L7_2 = "images/gpgs_leaderboard_gray_128.png"
    L8_2 = L19_1
    L9_2 = {}
    L9_2.group = L2_2
    L9_2.fixedWidth = 32
    L9_2.fixedHeight = 32
    L6_2 = L6_2(L7_2, L8_2, L9_2)
    L9_1 = L6_2
    L6_2 = buttons
    L6_2 = L6_2.newGraphical
    L7_2 = "images/gpgs_achievements_gray_128.png"
    L8_2 = L20_1
    L9_2 = {}
    L9_2.group = L2_2
    L9_2.fixedWidth = 32
    L9_2.fixedHeight = 32
    L6_2 = L6_2(L7_2, L8_2, L9_2)
    L10_1 = L6_2
    L6_2 = buttons
    L6_2 = L6_2.newGraphical
    L7_2 = "images/share_gray_128.png"
    L8_2 = L21_1
    L9_2 = {}
    L9_2.group = L2_2
    L9_2.fixedWidth = 32
    L9_2.fixedHeight = 32
    L6_2 = L6_2(L7_2, L8_2, L9_2)
    L11_1 = L6_2
    L6_2 = L9_1
    L7_2 = L9_1
    L8_2 = _W2
    L8_2 = L8_2 - 40
    L7_2.y = L5_2
    L6_2.x = L8_2
    L6_2 = L10_1
    L7_2 = L10_1
    L8_2 = _W2
    L7_2.y = L5_2
    L6_2.x = L8_2
    L6_2 = L11_1
    L7_2 = L11_1
    L8_2 = _W2
    L8_2 = L8_2 + 40
    L7_2.y = L5_2
    L6_2.x = L8_2
  end
  L6_2 = buttons
  L6_2 = L6_2.newGraphical
  L7_2 = "images/sound_on_white_120.png"
  
  function L8_2()
    local L0_3, L1_3
    L0_3 = L15_1
    L1_3 = true
    L0_3(L1_3)
  end
  
  L9_2 = {}
  L9_2.group = L2_2
  L9_2.fixedWidth = 24
  L9_2.fixedHeight = 24
  L10_2 = verylightgray
  L9_2.fillColor = L10_2
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  L12_1 = L6_2
  L6_2 = L12_1
  L7_2 = L12_1
  L8_2 = screenLeft
  L8_2 = L8_2 + 24
  L9_2 = screenBottom
  L9_2 = L9_2 - 24
  L7_2.y = L9_2
  L6_2.x = L8_2
  L6_2 = buttons
  L6_2 = L6_2.newPlainText
  L7_2 = "Test All BBs"
  L8_2 = L22_1
  L9_2 = {}
  L9_2.group = L2_2
  L10_2 = gray
  L9_2.textColor = L10_2
  L9_2.frameless = true
  L9_2.fontSize = 16
  L10_2 = globals
  L10_2 = L10_2.defaultFont
  L9_2.fontNum = L10_2
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  L13_1 = L6_2
  L6_2 = L13_1
  L7_2 = L13_1
  L8_2 = _W2
  L9_2 = screenBottom
  L9_2 = L9_2 - 20
  L7_2.y = L9_2
  L6_2.x = L8_2
  L6_2 = display
  L6_2 = L6_2.newText
  L7_2 = L2_2
  L8_2 = "v"
  L9_2 = string
  L9_2 = L9_2.format
  L10_2 = "%.2f"
  L11_2 = APP_VERSION
  L11_2 = L11_2 / 100
  L9_2 = L9_2(L10_2, L11_2)
  L8_2 = L8_2 .. L9_2
  L9_2 = 0
  L10_2 = 0
  L11_2 = _ttf_font
  L11_2 = L11_2[0]
  L12_2 = 9
  L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L14_1 = L6_2
  L6_2 = L14_1
  L7_2 = L6_2
  L6_2 = L6_2.setFillColor
  L8_2 = black
  L6_2(L7_2, L8_2())
  L6_2 = L14_1
  L6_2.alpha = 0.1
  L6_2 = L14_1
  L7_2 = L14_1
  L8_2 = 1
  L7_2.anchorY = 1
  L6_2.anchorX = L8_2
  L6_2 = L14_1
  L7_2 = L14_1
  L8_2 = screenRight
  L8_2 = L8_2 - 1
  L9_2 = screenBottom
  L9_2 = L9_2 - 1
  L10_2 = _ttf_font_offset
  L10_2 = L10_2[0]
  L9_2 = L9_2 + L10_2
  L7_2.y = L9_2
  L6_2.x = L8_2
end

L1_1.create = L23_1

function L23_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_title:show() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
      L3_2 = L15_1
      L4_2 = false
      L3_2(L4_2)
      L3_2 = L13_1
      L4_2 = _EASTER_EGG_MODE
      L3_2.isVisible = L4_2
      L3_2 = ads
      L3_2 = L3_2.possiblyShowInterstitial
      L3_2 = L3_2()
      if not L3_2 then
        L4_2 = rating
        L4_2 = L4_2.checkforRatingPopup
        L4_2()
      end
      L4_2 = sounds
      L4_2 = L4_2.playBgMusic
      L5_2 = sounds
      L5_2 = L5_2.getRandomBgMusic
      L5_2 = L5_2()
      L6_2 = 0.03
      L4_2(L5_2, L6_2)
      L4_2 = kiip_utils
      L4_2 = L4_2.savedData
      L4_2 = L4_2.numMomentsSaved
      if L4_2 == 0 then
        L4_2 = settings
        L4_2 = L4_2.t
        L4_2 = L4_2.kiip_turned_on
        if L4_2 then
          L4_2 = L0_1
          L4_2 = L4_2.showOverlay
          L5_2 = "_scene_popup"
          L6_2 = {}
          L6_2.isModal = true
          L7_2 = {}
          L7_2.dimAlpha = 0.85
          L7_2.title = "Earn Rewards"
          L8_2 = "NEW: "
          L9_2 = APP_NAME
          L10_2 = " has teamed up with Kiip to give out free rewards for getting great scores. Look out for them!"
          L8_2 = L8_2 .. L9_2 .. L10_2
          L7_2.text = L8_2
          L8_2 = yellow
          L7_2.titleColor = L8_2
          L8_2 = yellow
          L7_2.textColor = L8_2
          L8_2 = white
          L7_2.okTextColor = L8_2
          L8_2 = white
          L7_2.bgStrokeColor = L8_2
          L6_2.params = L7_2
          L4_2(L5_2, L6_2)
        end
      end
    end
  end
end

L1_1.show = L23_1

function L23_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_title:hide() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
    L3_2 = utils
    L3_2 = L3_2.cancelAllTimersAndTransitions
    L3_2()
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
    end
  end
end

L1_1.hide = L23_1

function L23_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_title:destroy()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
end

L1_1.destroy = L23_1
L24_1 = L1_1
L23_1 = L1_1.addEventListener
L25_1 = "create"
L26_1 = L1_1
L23_1(L24_1, L25_1, L26_1)
L24_1 = L1_1
L23_1 = L1_1.addEventListener
L25_1 = "show"
L26_1 = L1_1
L23_1(L24_1, L25_1, L26_1)
L24_1 = L1_1
L23_1 = L1_1.addEventListener
L25_1 = "hide"
L26_1 = L1_1
L23_1(L24_1, L25_1, L26_1)
L24_1 = L1_1
L23_1 = L1_1.addEventListener
L25_1 = "destroy"
L26_1 = L1_1
L23_1(L24_1, L25_1, L26_1)
return L1_1
