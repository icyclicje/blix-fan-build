local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1
L0_1 = {}
L1_1 = require
L2_1 = "composer"
L1_1 = L1_1(L2_1)
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "game_tutorial.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = math
L3_1 = L3_1.random
L4_1 = math
L4_1 = L4_1.ceil
L5_1 = math
L5_1 = L5_1.floor
L0_1.name = "Tutorial"
L0_1.displayName = "Tutorial"
L0_1.scoring = false
L0_1.leveling = false
L0_1.lives = 0
L0_1.oneStrokeAtOnce = false
L0_1.oneStrokePerColorAtOnce = true
L0_1.multitouch = false
L6_1 = nil
L7_1 = nil
L8_1 = nil
L9_1 = nil
L10_1 = nil

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = building_block
  L2_2 = L2_2.numInPlay
  if L2_2 == 0 then
    L2_2 = timer
    L2_2 = L2_2.performWithDelay
    L3_2 = 1000
    
    function L4_2()
      local L0_3, L1_3
      L0_3 = _levelUp
      L1_3 = 1000
      L0_3(L1_3)
    end
    
    L2_2(L3_2, L4_2)
  end
end

L0_1.onBuildingBlockSuccess = L11_1

function L11_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
  L3_2 = _loseLife
  L3_2()
end

L0_1.onWrongTargetHit = L11_1

function L11_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
  L3_2 = _loseLife
  L3_2()
end

L0_1.onObstacleHit = L11_1

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = 1
  L3_2 = A1_2.targetsHit
  L3_2 = #L3_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = A1_2.targetsHit
    L6_2 = L6_2[L5_2]
    L7_2 = L6_2
    L6_2 = L6_2.reappear
    L6_2(L7_2)
  end
end

L0_1.onStrokeLost = L11_1

function L11_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = buttons
  L1_2 = L1_2.newPlainText
  L2_2 = "skip >"
  L3_2 = _levelUp
  L4_2 = {}
  L5_2 = _group
  L4_2.group = L5_2
  L5_2 = gray
  L4_2.textColor = L5_2
  L4_2.frameless = true
  L4_2.textAnchorX = 1
  L4_2.fontSize = 14
  L5_2 = globals
  L5_2 = L5_2.defaultFont
  L4_2.fontNum = L5_2
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L6_1 = L1_2
  L1_2 = L6_1
  L2_2 = L6_1
  L3_2 = screenRight
  L3_2 = L3_2 - 30
  L4_2 = screenBottom
  L4_2 = L4_2 - 15
  L2_2.y = L4_2
  L1_2.x = L3_2
  L1_2 = display
  L1_2 = L1_2.newText
  L2_2 = _group
  L3_2 = ""
  L4_2 = 0
  L5_2 = 0
  L6_2 = _ttf_font
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2 = L6_2[L7_2]
  L7_2 = 15
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  L7_1 = L1_2
  L1_2 = L7_1
  L2_2 = L7_1
  L3_2 = _canvasW2
  L4_2 = screenTop
  L5_2 = _HEADER_HEIGHT
  L5_2 = L5_2 / 2
  L4_2 = L4_2 + L5_2
  L5_2 = _ttf_font_offset
  L6_2 = globals
  L6_2 = L6_2.defaultFont
  L5_2 = L5_2[L6_2]
  L5_2 = L5_2 * 15
  L4_2 = L4_2 + L5_2
  L2_2.y = L4_2
  L1_2.x = L3_2
  L1_2 = L7_1
  L2_2 = L1_2
  L1_2 = L1_2.setFillColor
  L3_2 = darkgray
  L1_2(L2_2, L3_2())
  L1_2 = display
  L1_2 = L1_2.newImageRect
  L2_2 = _group
  L3_2 = "images/hand_path_512x256.png"
  L4_2 = 64
  L5_2 = 32
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2)
  L8_1 = L1_2
  L1_2 = L8_1
  L2_2 = L8_1
  L3_2 = 0.5
  L2_2.anchorY = 0.5
  L1_2.anchorX = L3_2
  L1_2 = L8_1
  L1_2.alpha = 0.33
  L1_2 = L8_1
  L1_2.isVisible = false
  L1_2 = display
  L1_2 = L1_2.newImageRect
  L2_2 = _group
  L3_2 = "images/hand_path2_512x256.png"
  L4_2 = 128
  L5_2 = 51.2
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2)
  L9_1 = L1_2
  L1_2 = L9_1
  L2_2 = L9_1
  L3_2 = 0.5
  L2_2.anchorY = 0.5
  L1_2.anchorX = L3_2
  L1_2 = L9_1
  L1_2.alpha = 0.33
  L1_2 = L9_1
  L1_2.isVisible = false
  L1_2 = display
  L1_2 = L1_2.newImageRect
  L2_2 = _group
  L3_2 = "images/hand_pointer_bw_194x246.png"
  L4_2 = 24.5
  L5_2 = 30.75
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2)
  L10_1 = L1_2
  L1_2 = L10_1
  L2_2 = L10_1
  L3_2 = 0.5
  L2_2.anchorY = 1
  L1_2.anchorX = L3_2
  L1_2 = L10_1
  L1_2.isVisible = false
end

L0_1.onSetupGame = L11_1

function L11_1(A0_2)
  local L1_2, L2_2
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L6_1
  L1_2(L2_2)
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L7_1
  L1_2(L2_2)
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L8_1
  L1_2(L2_2)
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L9_1
  L1_2(L2_2)
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L10_1
  L1_2(L2_2)
end

L0_1.onCleanUp = L11_1

function L11_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = timerStash
  L0_2 = L0_2["path and hand"]
  if L0_2 then
    L0_2 = timer
    L0_2 = L0_2.cancel
    L1_2 = timerStash
    L1_2 = L1_2["path and hand"]
    L0_2(L1_2)
    L0_2 = timerStash
    L0_2["path and hand"] = nil
  end
  L0_2 = L7_1
  L0_2 = L0_2.typeout1
  if L0_2 then
    L0_2 = timer
    L0_2 = L0_2.cancel
    L1_2 = L7_1
    L1_2 = L1_2.typeout1
    L0_2(L1_2)
    L0_2 = L7_1
    L0_2.typeout1 = nil
  end
  L0_2 = L7_1
  L0_2 = L0_2.typeout2
  if L0_2 then
    L0_2 = timer
    L0_2 = L0_2.cancel
    L1_2 = L7_1
    L1_2 = L1_2.typeout2
    L0_2(L1_2)
    L0_2 = L7_1
    L0_2.typeout2 = nil
  end
  L0_2 = L7_1
  L1_2 = L7_1
  L2_2 = _canvasW2
  L3_2 = screenTop
  L4_2 = _HEADER_HEIGHT
  L4_2 = L4_2 / 2
  L3_2 = L3_2 + L4_2
  L4_2 = _ttf_font_offset
  L5_2 = globals
  L5_2 = L5_2.defaultFont
  L4_2 = L4_2[L5_2]
  L4_2 = L4_2 * 15
  L3_2 = L3_2 + L4_2
  L1_2.y = L3_2
  L0_2.x = L2_2
  L0_2 = L8_1
  L0_2.isVisible = false
  L0_2 = L9_1
  L0_2.isVisible = false
  L0_2 = L10_1
  L0_2.isVisible = false
end

function L12_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = L11_1
  L1_2()
  L1_2 = L0_1
  L1_2.replaySpeedMultiplier = 1
  L1_2 = _level
  if L1_2 == 1 then
    L1_2 = analytics
    L1_2 = L1_2.logEvent
    L2_2 = "Tutorial Started"
    L1_2(L2_2)
    L1_2 = building_block
    L1_2 = L1_2.new
    L2_2 = _group
    L3_2 = {}
    L3_2.delay = 1500
    L3_2.name = "two dots"
    L4_2 = building_block
    L4_2 = L4_2.MODIFIER_NORMAL
    L3_2.modifier = L4_2
    L4_2 = red
    L3_2.color = L4_2
    L1_2 = L1_2(L2_2, L3_2)
    L3_2 = L1_2
    L2_2 = L1_2.changeScaleFactor
    L4_2 = 2.25
    L2_2(L3_2, L4_2)
    L2_2 = _canvasW34
    L3_2 = _canvasH2
    L1_2.y = L3_2
    L1_2.x = L2_2
    L2_2 = L7_1
    L2_2.text = "Draw a squiggle as shown."
    L2_2 = utils
    L2_2 = L2_2.typeOutTextObject
    L3_2 = L7_1
    L4_2 = 2000
    L5_2 = 50
    L6_2 = false
    L7_2 = nil
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
    
    function L2_2()
      local L0_3, L1_3, L2_3, L3_3
      L0_3 = _level
      if L0_3 ~= 1 then
        return
      end
      L0_3 = L8_1
      L0_3.isVisible = true
      L0_3 = L10_1
      L0_3.isVisible = true
      L0_3 = transition
      L0_3 = L0_3.from
      L1_3 = L8_1
      L2_3 = {}
      L2_3.time = 500
      L2_3.alpha = 0
      L0_3(L1_3, L2_3)
      L0_3 = transition
      L0_3 = L0_3.from
      L1_3 = L10_1
      L2_3 = {}
      L2_3.time = 500
      L2_3.alpha = 0
      L0_3(L1_3, L2_3)
      L0_3 = L8_1
      L1_3 = L8_1
      L2_3 = L1_2
      L2_3 = L2_3.x
      L2_3 = L2_3 - 200
      L3_3 = _canvasH2
      L1_3.y = L3_3
      L0_3.x = L2_3
      L0_3 = L10_1
      L1_3 = L10_1
      L2_3 = L8_1
      L2_3 = L2_3.x
      L3_3 = L8_1
      L3_3 = L3_3.y
      L3_3 = L3_3 + 25
      L1_3.y = L3_3
      L0_3.x = L2_3
      L0_3 = L10_1
      L0_3.rotation = -45
      L0_3 = transition
      L0_3 = L0_3.to
      L1_3 = L10_1
      L2_3 = {}
      L2_3.delay = 500
      L2_3.time = 1000
      L2_3.rotation = 50
      L0_3(L1_3, L2_3)
    end
    
    L3_2 = timerStash
    L4_2 = timer
    L4_2 = L4_2.performWithDelay
    L5_2 = 3500
    L6_2 = L2_2
    L7_2 = -1
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    L3_2["path and hand"] = L4_2
  else
    L1_2 = _level
    if L1_2 == 2 then
      L1_2 = building_block
      L1_2 = L1_2.new
      L2_2 = _group
      L3_2 = {}
      L3_2.delay = 1500
      L3_2.name = "three dots"
      L4_2 = building_block
      L4_2 = L4_2.MODIFIER_NORMAL
      L3_2.modifier = L4_2
      L4_2 = orange
      L3_2.color = L4_2
      L1_2 = L1_2(L2_2, L3_2)
      L3_2 = L1_2
      L2_2 = L1_2.changeScaleFactor
      L4_2 = 2
      L2_2(L3_2, L4_2)
      L2_2 = _canvasW34
      L3_2 = _canvasH4
      L1_2.y = L3_2
      L1_2.x = L2_2
      L2_2 = building_block
      L2_2 = L2_2.new
      L3_2 = _group
      L4_2 = {}
      L4_2.delay = 2000
      L4_2.name = "three dots"
      L5_2 = building_block
      L5_2 = L5_2.MODIFIER_NORMAL
      L4_2.modifier = L5_2
      L5_2 = blue
      L4_2.color = L5_2
      L2_2 = L2_2(L3_2, L4_2)
      L4_2 = L2_2
      L3_2 = L2_2.changeScaleFactor
      L5_2 = 2
      L3_2(L4_2, L5_2)
      L3_2 = _canvasW34
      L4_2 = _canvasH34
      L2_2.y = L4_2
      L2_2.x = L3_2
      L3_2 = L7_1
      L3_2.text = "Now change colors and draw orange and blue squiggles."
      L3_2 = utils
      L3_2 = L3_2.typeOutTextObject
      L4_2 = L7_1
      L5_2 = 800
      L6_2 = 50
      L7_2 = false
      L8_2 = nil
      L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
    else
      L1_2 = _level
      if L1_2 == 3 then
        L1_2 = building_block
        L1_2 = L1_2.new
        L2_2 = _group
        L3_2 = {}
        L3_2.delay = 1500
        L3_2.name = "simple hop"
        L4_2 = building_block
        L4_2 = L4_2.MODIFIER_NORMAL
        L3_2.modifier = L4_2
        L4_2 = green
        L3_2.color = L4_2
        L1_2 = L1_2(L2_2, L3_2)
        L3_2 = L1_2
        L2_2 = L1_2.changeScaleFactor
        L4_2 = 2
        L2_2(L3_2, L4_2)
        L2_2 = _canvasW34
        L3_2 = _canvasH2
        L1_2.y = L3_2
        L1_2.x = L2_2
        L2_2 = L7_1
        L2_2.text = "Draw a green squiggle that avoids the black dot."
        L2_2 = utils
        L2_2 = L2_2.typeOutTextObject
        L3_2 = L7_1
        L4_2 = 800
        L5_2 = 50
        L6_2 = false
        L7_2 = nil
        L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
        
        function L2_2()
          local L0_3, L1_3, L2_3, L3_3
          L0_3 = _level
          if L0_3 ~= 3 then
            return
          end
          L0_3 = L9_1
          L0_3.isVisible = true
          L0_3 = L10_1
          L0_3.isVisible = true
          L0_3 = transition
          L0_3 = L0_3.from
          L1_3 = L9_1
          L2_3 = {}
          L2_3.time = 500
          L2_3.alpha = 0
          L0_3(L1_3, L2_3)
          L0_3 = transition
          L0_3 = L0_3.from
          L1_3 = L10_1
          L2_3 = {}
          L2_3.time = 500
          L2_3.alpha = 0
          L0_3(L1_3, L2_3)
          L0_3 = L9_1
          L1_3 = L9_1
          L2_3 = L1_2
          L2_3 = L2_3.x
          L2_3 = L2_3 - 213
          L3_3 = L1_2
          L3_3 = L3_3.y
          L3_3 = L3_3 - 10
          L1_3.y = L3_3
          L0_3.x = L2_3
          L0_3 = L10_1
          L1_3 = L10_1
          L2_3 = L9_1
          L2_3 = L2_3.x
          L3_3 = L9_1
          L3_3 = L3_3.y
          L3_3 = L3_3 + 25
          L1_3.y = L3_3
          L0_3.x = L2_3
          L0_3 = L10_1
          L0_3.rotation = -80
          L0_3 = transition
          L0_3 = L0_3.to
          L1_3 = L10_1
          L2_3 = {}
          L2_3.delay = 500
          L2_3.time = 1000
          L2_3.rotation = 90
          L0_3(L1_3, L2_3)
        end
        
        L3_2 = timerStash
        L4_2 = timer
        L4_2 = L4_2.performWithDelay
        L5_2 = 3500
        L6_2 = L2_2
        L7_2 = -1
        L4_2 = L4_2(L5_2, L6_2, L7_2)
        L3_2["path and hand"] = L4_2
      else
        L1_2 = _level
        if L1_2 == 4 then
          L1_2 = building_block
          L1_2 = L1_2.new
          L2_2 = _group
          L3_2 = {}
          L3_2.delay = 2000
          L3_2.name = "triangle jail"
          L4_2 = building_block
          L4_2 = L4_2.MODIFIER_SLOWSPIN
          L3_2.modifier = L4_2
          L3_2.rotationTime = 10000
          L4_2 = purple
          L3_2.color = L4_2
          L1_2 = L1_2(L2_2, L3_2)
          L3_2 = L1_2
          L2_2 = L1_2.changeScaleFactor
          L4_2 = 2
          L2_2(L3_2, L4_2)
          L2_2 = _canvasW2
          L3_2 = _canvasH2
          L1_2.y = L3_2
          L1_2.x = L2_2
          L2_2 = L7_1
          L2_2.text = "Sometimes drawing straight is safest. Draw in any direction."
          L2_2 = utils
          L2_2 = L2_2.typeOutTextObject
          L3_2 = L7_1
          L4_2 = 800
          L5_2 = 50
          L6_2 = false
          L7_2 = nil
          L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
        else
          L1_2 = _level
          if L1_2 == 5 then
            L1_2 = building_block
            L1_2 = L1_2.new
            L2_2 = _group
            L3_2 = {}
            L3_2.delay = 1500
            L3_2.name = "grid three dots"
            L4_2 = building_block
            L4_2 = L4_2.MODIFIER_ROTATED
            L3_2.modifier = L4_2
            L4_2 = blue
            L3_2.color = L4_2
            L3_2.startRotation = 90
            L1_2 = L1_2(L2_2, L3_2)
            L3_2 = L1_2
            L2_2 = L1_2.changeScaleFactor
            L4_2 = 1.25
            L2_2(L3_2, L4_2)
            L2_2 = _canvasW4
            L3_2 = _canvasH4
            L1_2.y = L3_2
            L1_2.x = L2_2
            L2_2 = building_block
            L2_2 = L2_2.new
            L3_2 = _group
            L4_2 = {}
            L4_2.delay = 2000
            L4_2.name = "two dots"
            L5_2 = building_block
            L5_2 = L5_2.MODIFIER_NORMAL
            L4_2.modifier = L5_2
            L5_2 = green
            L4_2.color = L5_2
            L2_2 = L2_2(L3_2, L4_2)
            L4_2 = L2_2
            L3_2 = L2_2.changeScaleFactor
            L5_2 = 1.25
            L3_2(L4_2, L5_2)
            L3_2 = _canvasW34
            L4_2 = _canvasH4
            L2_2.y = L4_2
            L2_2.x = L3_2
            L3_2 = building_block
            L3_2 = L3_2.new
            L4_2 = _group
            L5_2 = {}
            L5_2.delay = 2500
            L5_2.name = "two dots"
            L6_2 = building_block
            L6_2 = L6_2.MODIFIER_ROTATED
            L5_2.modifier = L6_2
            L6_2 = red
            L5_2.color = L6_2
            L5_2.startRotation = 90
            L3_2 = L3_2(L4_2, L5_2)
            L5_2 = L3_2
            L4_2 = L3_2.changeScaleFactor
            L6_2 = 1.25
            L4_2(L5_2, L6_2)
            L4_2 = _canvasW2
            L5_2 = _canvasH34
            L3_2.y = L5_2
            L3_2.x = L4_2
            L4_2 = nil
            
            function L5_2()
              local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
              L0_3 = L7_1
              L0_3.text = "Dots are grouped into clusters. Here are three clusters."
              L0_3 = utils
              L0_3 = L0_3.typeOutTextObject
              L1_3 = L7_1
              L2_3 = 800
              L3_3 = 50
              L4_3 = false
              
              function L5_3()
                local L0_4, L1_4, L2_4
                L0_4 = timer
                L0_4 = L0_4.performWithDelay
                L1_4 = 700
                L2_4 = L4_2
                L0_4(L1_4, L2_4)
              end
              
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
            end
            
            function L4_2()
              local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
              L0_3 = _level
              if L0_3 ~= 5 then
                return
              end
              L0_3 = L7_1
              L0_3.text = "Clearing all dots in a cluster gets rid of the cluster."
              L0_3 = utils
              L0_3 = L0_3.typeOutTextObject
              L1_3 = L7_1
              L2_3 = 1
              L3_3 = 50
              L4_3 = false
              L5_3 = nil
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
            end
            
            L6_2 = L5_2
            L6_2()
          else
            L1_2 = _level
            if L1_2 == 6 then
              L1_2 = L0_1
              L1_2.replaySpeedMultiplier = 0.33
              L1_2 = building_block
              L1_2 = L1_2.new
              L2_2 = _group
              L3_2 = {}
              L3_2.delay = 1500
              L3_2.name = "three dots"
              L4_2 = building_block
              L4_2 = L4_2.MODIFIER_MULTICOLOR
              L3_2.modifier = L4_2
              L3_2.color = nil
              L1_2 = L1_2(L2_2, L3_2)
              L3_2 = L1_2
              L2_2 = L1_2.changeScaleFactor
              L4_2 = 1.5
              L2_2(L3_2, L4_2)
              L2_2 = _canvasW2
              L3_2 = _canvasH2
              L1_2.y = L3_2
              L1_2.x = L2_2
              L2_2 = nil
              L3_2 = nil
              
              function L4_2()
                local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
                L0_3 = L7_1
                L0_3.text = "Clusters can be multicolored. Clear the dots below using"
                L0_3 = utils
                L0_3 = L0_3.typeOutTextObject
                L1_3 = L7_1
                L2_3 = 800
                L3_3 = 50
                L4_3 = false
                
                function L5_3()
                  local L0_4, L1_4, L2_4
                  L0_4 = timer
                  L0_4 = L0_4.performWithDelay
                  L1_4 = 250
                  L2_4 = L2_2
                  L0_4(L1_4, L2_4)
                end
                
                L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
              end
              
              function L2_2()
                local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
                L0_3 = _level
                if L0_3 ~= 6 then
                  return
                end
                L0_3 = L7_1
                L0_3.text = "different colored squiggles. Notice that if you are"
                L0_3 = utils
                L0_3 = L0_3.typeOutTextObject
                L1_3 = L7_1
                L2_3 = 1
                L3_3 = 50
                L4_3 = false
                
                function L5_3()
                  local L0_4, L1_4, L2_4
                  L0_4 = timer
                  L0_4 = L0_4.performWithDelay
                  L1_4 = 250
                  L2_4 = L3_2
                  L0_4(L1_4, L2_4)
                end
                
                L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
              end
              
              function L3_2()
                local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
                L0_3 = _level
                if L0_3 ~= 6 then
                  return
                end
                L0_3 = L7_1
                L0_3.text = "too slow, dots will reappear once squiggles are lost."
                L0_3 = utils
                L0_3 = L0_3.typeOutTextObject
                L1_3 = L7_1
                L2_3 = 1
                L3_3 = 50
                L4_3 = false
                L5_3 = nil
                L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
              end
              
              L5_2 = L4_2
              L5_2()
            else
              L1_2 = L7_1
              L1_2.isVisible = false
              L1_2 = analytics
              L1_2 = L1_2.logEvent
              L2_2 = "Tutorial Finished"
              L1_2(L2_2)
              L1_2 = gamenetwork_utils
              L1_2 = L1_2.sendAchievementProgress
              L2_2 = globals
              L2_2 = L2_2.ACH_ID_TUTORIAL
              L3_2 = 100
              L1_2(L2_2, L3_2)
              
              function L1_2()
                local L0_3, L1_3
                L0_3 = L1_1
                L0_3 = L0_3.gotoScene
                L1_3 = "scene_title"
                L0_3(L1_3)
              end
              
              L2_2 = L1_1
              L2_2 = L2_2.showOverlay
              L3_2 = "_scene_popup"
              L4_2 = {}
              L4_2.isModal = true
              L5_2 = {}
              L5_2.title = "Congratulations!"
              L5_2.bgStrokeWidth = 2
              L6_2 = black
              L5_2.bgStrokeColor = L6_2
              L6_2 = white
              L5_2.bgColor = L6_2
              L5_2.bgAlpha = 1
              L5_2.dimAlpha = 0.1
              L5_2.lineSpacingAdjust = 6
              L6_2 = gray
              L5_2.titleColor = L6_2
              L5_2.textWidth = 250
              L5_2.fontSize = 20
              L5_2.text = "You finished the tutorial. Now you're ready to play!"
              L6_2 = darkgray
              L5_2.textColor = L6_2
              L5_2.okText = "Ok!"
              L6_2 = red
              L5_2.okTextColor = L6_2
              L5_2.okCallBackFn = L1_2
              L4_2.params = L5_2
              L2_2(L3_2, L4_2)
            end
          end
        end
      end
    end
  end
end

L0_1.onLevelUp = L12_1

function L12_1(A0_2)
  local L1_2
end

L0_1.onEndGame = L12_1
return L0_1
