local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1
L0_1 = {}
L1_1 = require
L2_1 = "json"
L1_1 = L1_1(L2_1)
L2_1 = require
L3_1 = "composer"
L2_1 = L2_1(L3_1)
L3_1 = false
if L3_1 then
  L4_1 = log
  L4_1 = L4_1.show
  L5_1 = "_offers.lua DEBUGGING"
  L4_1(L5_1)
end
L0_1.TYPE_NATIVE_IMAGE = 1
L0_1.TYPE_NATIVE_DIALOG = 2
L0_1.TYPE_WEB = 3
L4_1 = {}
L5_1 = {}
L6_1 = nil

function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = string
  L1_2 = L1_2.find
  L2_2 = A0_2.imageURL
  L3_2 = "/[^/]*$"
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = A0_2.imageURL
  L3_2 = L2_2
  L2_2 = L2_2.sub
  L4_2 = L1_2 + 1
  return L2_2(L3_2, L4_2)
end

function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = A0_2.url
  if L1_2 ~= nil then
    L1_2 = A0_2.url
    L2_2 = L1_2
    L1_2 = L1_2.len
    L1_2 = L1_2(L2_2)
    if not (L1_2 < 1) then
      goto lbl_10
    end
  end
  do return end
  ::lbl_10::
  L1_2 = A0_2.url
  if L1_2 then
    L1_2 = A0_2.url
    L2_2 = L1_2
    L1_2 = L1_2.len
    L1_2 = L1_2(L2_2)
    if L1_2 == 0 then
      A0_2.url = nil
    end
  end
  L1_2 = A0_2.buttonText
  if L1_2 then
    L1_2 = A0_2.buttonText
    L2_2 = L1_2
    L1_2 = L1_2.len
    L1_2 = L1_2(L2_2)
    if L1_2 == 0 then
      A0_2.buttonText = nil
    end
  end
  L1_2 = A0_2.text
  if L1_2 then
    L1_2 = A0_2.text
    L2_2 = L1_2
    L1_2 = L1_2.len
    L1_2 = L1_2(L2_2)
    if L1_2 == 0 then
      A0_2.text = nil
    end
  end
  L1_2 = A0_2.imageURL
  if L1_2 then
    L1_2 = A0_2.imageURL
    L2_2 = L1_2
    L1_2 = L1_2.len
    L1_2 = L1_2(L2_2)
    if L1_2 == 0 then
      A0_2.imageURL = nil
    end
  end
  L1_2 = A0_2.url
  if L1_2 then
    L1_2 = A0_2.url
    L2_2 = L1_2
    L1_2 = L1_2.len
    L1_2 = L1_2(L2_2)
    if 0 < L1_2 then
      L1_2 = A0_2.imageURL
      if L1_2 then
        L1_2 = A0_2.imageURL
        L2_2 = L1_2
        L1_2 = L1_2.len
        L1_2 = L1_2(L2_2)
        if 0 < L1_2 then
          L1_2 = L0_1
          L1_2 = L1_2.TYPE_NATIVE_IMAGE
          A0_2.type = L1_2
          A0_2.imageFetched = false
      end
    end
  end
  else
    L1_2 = A0_2.url
    if L1_2 then
      L1_2 = A0_2.url
      L2_2 = L1_2
      L1_2 = L1_2.len
      L1_2 = L1_2(L2_2)
      if 0 < L1_2 then
        L1_2 = A0_2.text
        if L1_2 then
          L1_2 = A0_2.text
          L2_2 = L1_2
          L1_2 = L1_2.len
          L1_2 = L1_2(L2_2)
          if 0 < L1_2 then
            L1_2 = A0_2.buttonText
            if L1_2 then
              L1_2 = A0_2.buttonText
              L2_2 = L1_2
              L1_2 = L1_2.len
              L1_2 = L1_2(L2_2)
              if 0 < L1_2 then
                L1_2 = L0_1
                L1_2 = L1_2.TYPE_NATIVE_DIALOG
                A0_2.type = L1_2
            end
          end
        end
      end
    end
    else
      L1_2 = A0_2.url
      if L1_2 then
        L1_2 = A0_2.url
        L2_2 = L1_2
        L1_2 = L1_2.len
        L1_2 = L1_2(L2_2)
        if 0 < L1_2 then
          L1_2 = L0_1
          L1_2 = L1_2.TYPE_WEB
          A0_2.type = L1_2
      end
      else
        L1_2 = print
        L2_2 = "ERROR: could not deduce offer type for "
        L3_2 = A0_2.name
        L2_2 = L2_2 .. L3_2
        L1_2(L2_2)
        return
      end
    end
  end
  L1_2 = L3_1
  if L1_2 then
    L1_2 = print
    L2_2 = A0_2.name
    L3_2 = " is type "
    L4_2 = A0_2.type
    L2_2 = L2_2 .. L3_2 .. L4_2
    L1_2(L2_2)
  end
  L1_2 = L4_1
  L2_2 = A0_2.name
  L1_2[L2_2] = A0_2
end

function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = L3_1
  if L0_2 then
    L0_2 = log
    L0_2 = L0_2.show
    L1_2 = "init()"
    L2_2 = {}
    L3_2 = yellow
    L2_2.textColor = L3_2
    L0_2(L1_2, L2_2)
  end
  L0_2 = L3_1
  if L0_2 then
    L0_2 = print
    L1_2 = "OFFERS"
    L0_2(L1_2)
    L0_2 = print
    L1_2 = inspect
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.offers
    L0_2(L1_2(L2_2))
  end
  L0_2 = ipairs
  L1_2 = settings
  L1_2 = L1_2.t
  L1_2 = L1_2.offers
  L0_2, L1_2, L2_2 = L0_2(L1_2)
  for L3_2, L4_2 in L0_2, L1_2, L2_2 do
    L5_2 = L8_1
    L6_2 = L4_2
    L5_2(L6_2)
  end
  L0_2 = pairs
  L1_2 = L4_1
  L0_2, L1_2, L2_2 = L0_2(L1_2)
  for L3_2, L4_2 in L0_2, L1_2, L2_2 do
    L5_2 = L4_2.imageURL
    if L5_2 then
      L5_2 = L4_2.imageURL
      L6_2 = L5_2
      L5_2 = L5_2.len
      L5_2 = L5_2(L6_2)
      if 0 < L5_2 then
        L5_2 = display
        L5_2 = L5_2.newImage
        L6_2 = L7_1
        L7_2 = L4_2
        L6_2 = L6_2(L7_2)
        L7_2 = system
        L7_2 = L7_2.DocumentsDirectory
        L8_2 = 1
        L9_2 = 1
        L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2)
        if L5_2 == nil then
          function L6_2(A0_3)
            local L1_3, L2_3, L3_3, L4_3
            
            L1_3 = A0_3.isError
            if L1_3 then
              L1_3 = print
              L2_3 = "Network error - download failed for "
              L3_3 = L4_2
              L3_3 = L3_3.name
              L2_3 = L2_3 .. L3_3
              L1_3(L2_3)
            else
              L1_3 = L4_2
              L1_3.imageFetched = true
              L1_3 = L3_1
              if L1_3 then
                L1_3 = print
                L2_3 = "Offer "
                L3_3 = L4_2
                L3_3 = L3_3.name
                L4_3 = " image fetched successfully."
                L2_3 = L2_3 .. L3_3 .. L4_3
                L1_3(L2_3)
              end
            end
          end
          
          L7_2 = network
          L7_2 = L7_2.download
          L8_2 = L4_2.imageURL
          L9_2 = "GET"
          L10_2 = L6_2
          L11_2 = L7_1
          L12_2 = L4_2
          L11_2 = L11_2(L12_2)
          L12_2 = system
          L12_2 = L12_2.DocumentsDirectory
          L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
          L7_2 = L3_1
          if L7_2 then
            L7_2 = print
            L8_2 = "Offer "
            L9_2 = L4_2.name
            L10_2 = " image being fetched..."
            L8_2 = L8_2 .. L9_2 .. L10_2
            L7_2(L8_2)
          end
        else
          L6_2 = L3_1
          if L6_2 then
            L6_2 = print
            L7_2 = "Offer "
            L8_2 = L4_2.name
            L9_2 = " image already existed."
            L7_2 = L7_2 .. L8_2 .. L9_2
            L6_2(L7_2)
          end
          L4_2.imageFetched = true
          L7_2 = L5_2
          L6_2 = L5_2.removeSelf
          L6_2(L7_2)
          L5_2 = nil
        end
      end
    end
    L5_2 = pairs
    L6_2 = L4_1
    L5_2, L6_2, L7_2 = L5_2(L6_2)
    for L8_2, L9_2 in L5_2, L6_2, L7_2 do
      L10_2 = 1
      L11_2 = L9_2.priority
      L12_2 = 1
      for L13_2 = L10_2, L11_2, L12_2 do
        L14_2 = L5_1
        L15_2 = L5_1
        L15_2 = #L15_2
        L15_2 = L15_2 + 1
        L16_2 = L9_2.name
        L14_2[L15_2] = L16_2
      end
    end
    L5_2 = L3_1
    if L5_2 then
      L5_2 = print
      L6_2 = inspect
      L7_2 = L5_1
      L5_2(L6_2(L7_2))
    end
  end
end

L0_1.init = L9_1

function L9_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = A0_2.index
  if L1_2 == 1 then
    L2_2 = L6_1
    L2_2 = L2_2.url
    if L2_2 then
      L2_2 = L6_1
      L2_2 = L2_2.url
      L3_2 = L2_2
      L2_2 = L2_2.len
      L2_2 = L2_2(L3_2)
      if 0 < L2_2 then
        L2_2 = ltv
        L2_2 = L2_2.recordAdClick
        L2_2()
        L2_2 = system
        L2_2 = L2_2.openURL
        L3_2 = L6_1
        L3_2 = L3_2.url
        L2_2(L3_2)
      end
    end
  elseif L1_2 == 2 then
  end
end

function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = native
  L0_2 = L0_2.showAlert
  L1_2 = L6_1
  L1_2 = L1_2.text
  L2_2 = ""
  L3_2 = {}
  L4_2 = L6_1
  L4_2 = L4_2.buttonText
  L5_2 = "Cancel"
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L4_2 = L9_1
  L0_2(L1_2, L2_2, L3_2, L4_2)
end

function L11_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = L5_1
  L0_2 = #L0_2
  if L0_2 == 0 then
    L0_2 = false
    return L0_2
  end
  L0_2 = L4_1
  L1_2 = L5_1
  L2_2 = math
  L2_2 = L2_2.random
  L3_2 = L5_1
  L3_2 = #L3_2
  L2_2 = L2_2(L3_2)
  L1_2 = L1_2[L2_2]
  L0_2 = L0_2[L1_2]
  L6_1 = L0_2
  L0_2 = L6_1
  L0_2 = L0_2.type
  L1_2 = L0_1
  L1_2 = L1_2.TYPE_NATIVE_IMAGE
  if L0_2 == L1_2 then
    L0_2 = L6_1
    L0_2 = L0_2.imageFetched
    if not L0_2 then
      L0_2 = print
      L1_2 = "Image for "
      L2_2 = L6_1
      L2_2 = L2_2.name
      L3_2 = " wasn't ready so offer not shown"
      L1_2 = L1_2 .. L2_2 .. L3_2
      L0_2(L1_2)
      L0_2 = false
      return L0_2
    end
  end
  L0_2 = L3_1
  if L0_2 then
    L0_2 = print
    L1_2 = "showing offer "
    L2_2 = L6_1
    L2_2 = L2_2.name
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
  end
  
  function L0_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L0_3 = L6_1
    L0_3 = L0_3.type
    L1_3 = L0_1
    L1_3 = L1_3.TYPE_NATIVE_DIALOG
    if L0_3 == L1_3 then
      L0_3 = L10_1
      L0_3()
    end
    L0_3 = L6_1
    L0_3 = L0_3.type
    L1_3 = L0_1
    L1_3 = L1_3.TYPE_NATIVE_IMAGE
    if L0_3 == L1_3 then
      function L0_3()
        local L0_4, L1_4
        
        L0_4 = ltv
        L0_4 = L0_4.recordAdClick
        L0_4()
        L0_4 = system
        L0_4 = L0_4.openURL
        L1_4 = L6_1
        L1_4 = L1_4.url
        L0_4(L1_4)
      end
      
      L1_3 = L2_1
      L1_3 = L1_3.showOverlay
      L2_3 = "_scene_popup"
      L3_3 = {}
      L3_3.isModal = true
      L4_3 = {}
      L4_3.dimAlpha = 0.5
      L5_3 = L6_1
      L5_3 = L5_3.buttonText
      L4_3.title = L5_3
      L5_3 = L6_1
      L5_3 = L5_3.text
      L4_3.text = L5_3
      L5_3 = screenWidth
      L5_3 = L5_3 - 50
      L4_3.textWidth = L5_3
      L5_3 = L7_1
      L6_3 = L6_1
      L5_3 = L5_3(L6_3)
      L4_3.image = L5_3
      L5_3 = system
      L5_3 = L5_3.DocumentsDirectory
      L4_3.directory = L5_3
      L5_3 = green
      L4_3.titleColor = L5_3
      L5_3 = lightGray
      L4_3.textColor = L5_3
      L5_3 = white
      L4_3.okTextColor = L5_3
      L5_3 = gray
      L4_3.bgStrokeColor = L5_3
      L4_3.bgCornerRadius = 0
      L4_3.bgMargin = 10
      L4_3.okCallBackFn = L0_3
      L4_3.imageCallBackFn = L0_3
      L4_3.cancelText = "Cancel"
      L5_3 = gray
      L4_3.cancelTextColor = L5_3
      L3_3.params = L4_3
      L1_3(L2_3, L3_3)
    end
    L0_3 = L6_1
    L0_3 = L0_3.type
    L1_3 = L0_1
    L1_3 = L1_3.TYPE_WEB
    if L0_3 == L1_3 then
      L0_3 = L2_1
      L0_3 = L0_3.showOverlay
      L1_3 = "_scene_popup"
      L2_3 = {}
      L2_3.isModal = true
      L3_3 = {}
      L3_3.dimAlpha = 0.5
      L4_3 = L6_1
      L4_3 = L4_3.url
      L3_3.url = L4_3
      L3_3.okText = "Close"
      L4_3 = gray
      L3_3.okTextColor = L4_3
      L4_3 = gray
      L3_3.bgStrokeColor = L4_3
      L3_3.bgCornerRadius = 0
      L3_3.bgMargin = 10
      L2_3.params = L3_3
      L0_3(L1_3, L2_3)
    end
  end
  
  L1_2 = timer
  L1_2 = L1_2.performWithDelay
  L2_2 = 1
  L3_2 = L0_2
  L1_2(L2_2, L3_2)
  L1_2 = true
  return L1_2
end

L0_1.showAd = L11_1
return L0_1
