local L0_1, L1_1
L0_1 = {}

function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2()
  L6_2 = L2_2 / A1_2
  L7_2 = L3_2 / A1_2
  L8_2 = L4_2 / A1_2
  L9_2 = L5_2
  return L6_2, L7_2, L8_2, L9_2
end

L0_1.getDarker = L1_1

function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2()
  L6_2 = L2_2 * A1_2
  L7_2 = L3_2 * A1_2
  L8_2 = L4_2 * A1_2
  L9_2 = L5_2
  return L6_2, L7_2, L8_2, L9_2
end

L0_1.getLigher = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0
  L1_2 = 0
  L2_2 = 0
  L3_2 = 0
  return L0_2, L1_2, L2_2, L3_2
end

none = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 0.3764705882352941
  L2_2 = 0.3764705882352941
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

red = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.5019607843137255
  L1_2 = 1
  L2_2 = 0.5019607843137255
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

green = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.39215686274509803
  L1_2 = 0.5019607843137255
  L2_2 = 1
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

blue = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 1
  L2_2 = 0
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

yellow = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.7843137254901961
  L1_2 = 0.5568627450980392
  L2_2 = 1
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

purple = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.5019607843137255
  L1_2 = 1
  L2_2 = 1
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

teal = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.6274509803921569
  L1_2 = 0.9215686274509803
  L2_2 = 0.8823529411764706
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

cyan = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 0.6549019607843137
  L2_2 = 0
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

orange = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.9411764705882353
  L1_2 = 0.6078431372549019
  L2_2 = 0
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

darkorange = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 1
  L2_2 = 1
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

white = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.9254901960784314
  L1_2 = 0.9411764705882353
  L2_2 = 0.9450980392156862
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

offwhite = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.7843137254901961
  L1_2 = 0.7843137254901961
  L2_2 = 0.7843137254901961
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

lightgray = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.9137254901960784
  L1_2 = 0.9137254901960784
  L2_2 = 0.9137254901960784
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

verylightgray = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.5019607843137255
  L1_2 = 0.5019607843137255
  L2_2 = 0.5019607843137255
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

gray = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.2823529411764706
  L1_2 = 0.2823529411764706
  L2_2 = 0.2823529411764706
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

kindadarkgray = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.25098039215686274
  L1_2 = 0.25098039215686274
  L2_2 = 0.25098039215686274
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

darkgray = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.12549019607843137
  L1_2 = 0.12549019607843137
  L2_2 = 0.12549019607843137
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

verydarkgray = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0
  L1_2 = 0
  L2_2 = 0
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

black = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 0.7843137254901961
  L2_2 = 0.7843137254901961
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

pink = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.12941176470588237
  L1_2 = 0.38823529411764707
  L2_2 = 0.12941176470588237
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

darkgreen = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 1
  L2_2 = 0.7686274509803922
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

lightyellow = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.3058823529411765
  L1_2 = 0.6470588235294118
  L2_2 = 0.3058823529411765
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

mediumgreen = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0
  L1_2 = 0
  L2_2 = 0.19607843137254902
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

verydarkblue = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 0
  L2_2 = 0
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

darkred = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0
  L1_2 = 0
  L2_2 = 1
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

pureblue = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.3176470588235294
  L1_2 = 0.5490196078431373
  L2_2 = 0.9921568627450981
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

pleasantblue = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.8862745098039215
  L1_2 = 0.8784313725490196
  L2_2 = 0.8
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

paleyellow = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 0.9725490196078431
  L2_2 = 0.9215686274509803
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

faintyellow = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.4549019607843137
  L1_2 = 0.27450980392156865
  L2_2 = 0.08235294117647059
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

brown = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 0.5882352941176471
  L2_2 = 0.5882352941176471
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

lightred = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.8274509803921568
  L1_2 = 0.8
  L2_2 = 0.6862745098039216
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

tan = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 0.3254901960784314
  L2_2 = 0
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

button_orange = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.6823529411764706
  L1_2 = 0.12549019607843137
  L2_2 = 0.35294117647058826
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

agnes_score_purple = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.8745098039215686
  L1_2 = 0.8313725490196079
  L2_2 = 0.6627450980392157
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

agnes_score_gold_emboss = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.1607843137254902
  L1_2 = 0.1607843137254902
  L2_2 = 0.1607843137254902
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

hundred_balls_verydarkgray = L1_1

function L1_1()
  local L0_2, L1_2
  L0_2 = verydarkgray
  return L0_2()
end

staytheline_bgcolor = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.2
  L1_2 = 0.2
  L2_2 = 0.2
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

staytheline_darkgray = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.3176470588235294
  L1_2 = 0.5490196078431373
  L2_2 = 0.9921568627450981
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

staytheline_color = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.7254901960784313
  L1_2 = 0.7254901960784313
  L2_2 = 0.2627450980392157
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_yellow = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 1
  L2_2 = 0.5882352941176471
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_yellow_light = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.12549019607843137
  L1_2 = 0.12549019607843137
  L2_2 = 0.06274509803921569
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

superdarkyellow = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.0392156862745098
  L1_2 = 0.7254901960784313
  L2_2 = 0.2627450980392157
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_green = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0
  L1_2 = 1
  L2_2 = 0.5882352941176471
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_green_light = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.06274509803921569
  L1_2 = 0.12549019607843137
  L2_2 = 0.06274509803921569
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

superdarkgreen = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.0392156862745098
  L1_2 = 0.2627450980392157
  L2_2 = 0.7254901960784313
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_blue = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0
  L1_2 = 0.5882352941176471
  L2_2 = 1
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_blue_light = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.06274509803921569
  L1_2 = 0.06274509803921569
  L2_2 = 0.12549019607843137
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

superdarkblue = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.6666666666666666
  L1_2 = 0.12549019607843137
  L2_2 = 0.7254901960784313
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_purple = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.9019607843137255
  L1_2 = 0.39215686274509803
  L2_2 = 1
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_purple_light = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.12549019607843137
  L1_2 = 0.06274509803921569
  L2_2 = 0.12549019607843137
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

superdarkpurple = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.7254901960784313
  L1_2 = 0.2627450980392157
  L2_2 = 0.2627450980392157
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_red = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 1
  L1_2 = 0.5882352941176471
  L2_2 = 0.5882352941176471
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

particle_red_light = L1_1

function L1_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = 0.12549019607843137
  L1_2 = 0.06274509803921569
  L2_2 = 0.06274509803921569
  L3_2 = 1
  return L0_2, L1_2, L2_2, L3_2
end

superdarkred = L1_1
return L0_1
