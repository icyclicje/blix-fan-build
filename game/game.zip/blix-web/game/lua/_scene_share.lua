local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1, L22_1, L23_1, L24_1, L25_1, L26_1
L0_1 = require
L1_1 = "composer"
L0_1 = L0_1(L1_1)
L1_1 = L0_1.newScene
L1_1 = L1_1()
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "_scene_share.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = nil
L4_1 = nil
L5_1 = nil
L6_1 = nil
L7_1 = nil
L8_1 = nil
L9_1 = nil
L10_1 = nil
L11_1 = nil
L12_1 = nil
L13_1 = nil
L14_1 = nil
L15_1 = 0

function L16_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.hideOverlay
  L1_2 = true
  L0_2(L1_2)
  L0_2 = L13_1
  if L0_2 then
    L0_2 = L13_1
    L0_2()
  end
end

function L17_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Share via Email"
  L0_2(L1_2)
  L0_2 = native
  L0_2 = L0_2.showPopup
  L1_2 = "mail"
  L2_2 = {}
  L3_2 = sharing
  L3_2 = L3_2.title
  L2_2.subject = L3_2
  L3_2 = sharing
  L3_2 = L3_2.url
  L4_2 = [[


]]
  L5_2 = L14_1
  L6_2 = sharing
  L6_2 = L6_2.message
  L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
  L2_2.body = L3_2
  L0_2(L1_2, L2_2)
  L0_2 = _SIMULATOR
  if L0_2 then
    L0_2 = print
    L1_2 = sharing
    L1_2 = L1_2.title
    L2_2 = sharing
    L2_2 = L2_2.url
    L3_2 = [[


]]
    L4_2 = L14_1
    L5_2 = sharing
    L5_2 = L5_2.message
    L2_2 = L2_2 .. L3_2 .. L4_2 .. L5_2
    L0_2(L1_2, L2_2)
  end
end

function L18_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Share via Text"
  L0_2(L1_2)
  L0_2 = native
  L0_2 = L0_2.showPopup
  L1_2 = "sms"
  L2_2 = {}
  L3_2 = L14_1
  L4_2 = sharing
  L4_2 = L4_2.message
  L5_2 = " "
  L6_2 = sharing
  L6_2 = L6_2.url
  L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
  L2_2.body = L3_2
  L0_2(L1_2, L2_2)
  L0_2 = _SIMULATOR
  if L0_2 then
    L0_2 = print
    L1_2 = L14_1
    L2_2 = sharing
    L2_2 = L2_2.message
    L3_2 = " "
    L4_2 = sharing
    L4_2 = L4_2.url
    L1_2 = L1_2 .. L2_2 .. L3_2 .. L4_2
    L0_2(L1_2)
  end
end

function L19_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Share via FB"
  L0_2(L1_2)
  L0_2 = native
  L0_2 = L0_2.showPopup
  L1_2 = "social"
  L2_2 = {}
  L2_2.service = "facebook"
  L3_2 = L14_1
  L4_2 = sharing
  L4_2 = L4_2.message
  L3_2 = L3_2 .. L4_2
  L2_2.message = L3_2
  L3_2 = sharing
  L3_2 = L3_2.url
  L2_2.url = L3_2
  L3_2 = sharing
  L3_2 = L3_2.image
  L2_2.image = L3_2
  L0_2(L1_2, L2_2)
  L0_2 = _SIMULATOR
  if L0_2 then
    L0_2 = print
    L1_2 = L14_1
    L2_2 = sharing
    L2_2 = L2_2.message
    L1_2 = L1_2 .. L2_2
    L2_2 = sharing
    L2_2 = L2_2.url
    L3_2 = sharing
    L3_2 = L3_2.image
    L0_2(L1_2, L2_2, L3_2)
  end
end

function L20_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Share via Twitter"
  L0_2(L1_2)
  L0_2 = native
  L0_2 = L0_2.showPopup
  L1_2 = "social"
  L2_2 = {}
  L2_2.service = "twitter"
  L3_2 = L14_1
  L4_2 = sharing
  L4_2 = L4_2.message
  L5_2 = " "
  L6_2 = sharing
  L6_2 = L6_2.url
  L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
  L2_2.message = L3_2
  L3_2 = sharing
  L3_2 = L3_2.url
  L2_2.url = L3_2
  L3_2 = sharing
  L3_2 = L3_2.image
  L2_2.image = L3_2
  L0_2(L1_2, L2_2)
  L0_2 = _SIMULATOR
  if L0_2 then
    L0_2 = print
    L1_2 = L14_1
    L2_2 = sharing
    L2_2 = L2_2.message
    L1_2 = L1_2 .. L2_2
    L2_2 = sharing
    L2_2 = L2_2.url
    L3_2 = sharing
    L3_2 = L3_2.image
    L0_2(L1_2, L2_2, L3_2)
  end
end

function L21_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Share via Sina Weibo"
  L0_2(L1_2)
  L0_2 = native
  L0_2 = L0_2.showPopup
  L1_2 = "social"
  L2_2 = {}
  L2_2.service = "sinaWeibo"
  L3_2 = L14_1
  L4_2 = sharing
  L4_2 = L4_2.message
  L3_2 = L3_2 .. L4_2
  L2_2.message = L3_2
  L3_2 = sharing
  L3_2 = L3_2.url
  L2_2.url = L3_2
  L3_2 = sharing
  L3_2 = L3_2.image
  L2_2.image = L3_2
  L0_2(L1_2, L2_2)
  L0_2 = _SIMULATOR
  if L0_2 then
    L0_2 = print
    L1_2 = L14_1
    L2_2 = sharing
    L2_2 = L2_2.message
    L1_2 = L1_2 .. L2_2
    L2_2 = sharing
    L2_2 = L2_2.url
    L3_2 = sharing
    L3_2 = L3_2.image
    L0_2(L1_2, L2_2, L3_2)
  end
end

function L22_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Share via Android"
  L0_2(L1_2)
  L0_2 = native
  L0_2 = L0_2.showPopup
  L1_2 = "social"
  L2_2 = {}
  L3_2 = L14_1
  L4_2 = sharing
  L4_2 = L4_2.message
  L3_2 = L3_2 .. L4_2
  L2_2.message = L3_2
  L3_2 = sharing
  L3_2 = L3_2.url
  L2_2.url = L3_2
  L3_2 = sharing
  L3_2 = L3_2.image
  L2_2.image = L3_2
  L0_2(L1_2, L2_2)
  L0_2 = _SIMULATOR
  if L0_2 then
    L0_2 = print
    L1_2 = L14_1
    L2_2 = sharing
    L2_2 = L2_2.message
    L1_2 = L1_2 .. L2_2
    L2_2 = sharing
    L2_2 = L2_2.url
    L3_2 = sharing
    L3_2 = L3_2.image
    L0_2(L1_2, L2_2, L3_2)
  end
end

function L23_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_share:create()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = display
  L3_2 = L3_2.newRect
  L4_2 = L2_2
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = screenWidth
  L8_2 = screenHeight
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L3_1 = L3_2
  L3_2 = L3_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = black
  L3_2(L4_2, L5_2())
  L3_2 = L3_1
  
  function L4_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = A1_3.phase
    if L2_3 == "began" then
      L2_3 = 0
      L15_1 = L2_3
    else
      L2_3 = A1_3.phase
      if L2_3 == "moved" then
        L2_3 = A1_3.x
        L3_3 = _W34
        if L2_3 > L3_3 then
          L2_3 = A1_3.y
          L3_3 = _H4
          if L2_3 < L3_3 then
            L2_3 = L15_1
            L2_3 = L2_3 + 1
            L15_1 = L2_3
            L2_3 = L15_1
            if 200 < L2_3 then
              L2_3 = settings
              L2_3 = L2_3.t
              L2_3 = L2_3.allowEasterEgg
              if L2_3 then
                L2_3 = _EASTER_EGG_MODE
                if not L2_3 then
                  L2_3 = analytics
                  L2_3 = L2_3.logEvent
                  L3_3 = "Easter Egg Mode On"
                  L2_3(L3_3)
                  L2_3 = true
                  _EASTER_EGG_MODE = L2_3
                  L2_3 = toast
                  L2_3 = L2_3.show
                  L3_3 = "Easter Egg Mode On"
                  L4_3 = {}
                  L4_3.time = 1000
                  L2_3(L3_3, L4_3)
                end
              end
            end
          end
        end
      else
        L2_3 = A1_3.phase
        if L2_3 == "ended" then
        end
      end
    end
    L2_3 = true
    return L2_3
  end
  
  L3_2.touch = L4_2
  L3_2 = L3_1
  L4_2 = L3_2
  L3_2 = L3_2.addEventListener
  L5_2 = "touch"
  L6_2 = L3_1
  L3_2(L4_2, L5_2, L6_2)
end

L1_1.create = L23_1

function L23_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_share:show() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
      L3_2 = A1_2.params
      L3_2 = L3_2.fnBackCallback
      L13_1 = L3_2
      L3_2 = A1_2.params
      L3_2 = L3_2.shareMsgPrefix
      if not L3_2 then
        L3_2 = ""
      end
      L14_1 = L3_2
      L3_2 = A1_2.params
      L3_2 = L3_2.source
      L4_2 = A1_2.params
      L4_2 = L4_2.fontNum
      if not L4_2 then
        L4_2 = globals
        L4_2 = L4_2.defaultFont
      end
      L5_2 = A1_2.params
      L5_2 = L5_2.fontSize
      if not L5_2 then
        L5_2 = 24
      end
      L6_2 = A1_2.params
      L6_2 = L6_2.title
      L7_2 = A1_2.params
      L7_2 = L7_2.titleColor
      if not L7_2 then
        L7_2 = white
      end
      L8_2 = A1_2.params
      L8_2 = L8_2.bgColor
      if not L8_2 then
        L8_2 = black
      end
      L9_2 = A1_2.params
      L9_2 = L9_2.borderColor
      if not L9_2 then
        L9_2 = white
      end
      L10_2 = A1_2.params
      L10_2 = L10_2.borderWidth
      if not L10_2 then
        L10_2 = 2
      end
      L11_2 = A1_2.params
      L11_2 = L11_2.dimAlpha
      if not L11_2 then
        L11_2 = 0.85
      end
      L12_2 = A1_2.params
      L12_2 = L12_2.backButtonColor
      if not L12_2 then
        L12_2 = white
      end
      L13_2 = A1_2.params
      L13_2 = L13_2.framelessButtons
      if not L13_2 then
        L13_2 = false
      end
      L14_2 = analytics
      L14_2 = L14_2.logEvent
      L15_2 = "Share Screen from "
      L16_2 = L3_2
      L15_2 = L15_2 .. L16_2
      L14_2(L15_2)
      L14_2 = display
      L14_2 = L14_2.newGroup
      L14_2 = L14_2()
      L14_2.anchorChildren = true
      L16_2 = L2_2
      L15_2 = L2_2.insert
      L17_2 = L14_2
      L15_2(L16_2, L17_2)
      L15_2 = 35
      if L13_2 then
        L15_2 = 15
      end
      L16_2 = 0
      if L6_2 then
        L17_2 = utils
        L17_2 = L17_2.newTextWithWrap
        L18_2 = L14_2
        L19_2 = L6_2
        L20_2 = 250
        L21_2 = L4_2
        L22_2 = 22
        L23_2 = 24
        L24_2 = L7_2
        L25_2 = false
        L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
        L5_1 = L17_2
        L17_2 = L5_1
        L18_2 = L5_1
        L19_2 = _W2
        L18_2.y = L16_2
        L17_2.x = L19_2
        L17_2 = L5_1
        L17_2 = L17_2.height
        L17_2 = L17_2 / 2
        L17_2 = L16_2 + L17_2
        L16_2 = L17_2 + L15_2
      end
      L17_2 = _SIMULATOR
      if not L17_2 then
        L17_2 = platform
        L17_2 = L17_2.ios
        if not L17_2 then
          goto lbl_287
        end
      end
      L17_2 = native
      L17_2 = L17_2.canShowPopup
      L18_2 = "mail"
      L17_2 = L17_2(L18_2)
      if not L17_2 then
        L17_2 = _SIMULATOR
        if not L17_2 then
          goto lbl_161
        end
      end
      L17_2 = buttons
      L17_2 = L17_2.newPlainText
      L18_2 = "Email"
      L19_2 = L17_1
      L20_2 = {}
      L20_2.group = L14_2
      L20_2.frameless = L13_2
      L21_2 = red
      L20_2.textColor = L21_2
      L21_2 = red
      L20_2.strokeColor = L21_2
      L21_2 = verydarkgray
      L20_2.bgColor = L21_2
      L20_2.fontSize = L5_2
      L20_2.fontNum = L4_2
      L17_2 = L17_2(L18_2, L19_2, L20_2)
      L6_1 = L17_2
      L17_2 = L6_1
      L18_2 = L6_1
      L19_2 = _W2
      L18_2.y = L16_2
      L17_2.x = L19_2
      L17_2 = L6_1
      L17_2 = L17_2.height
      L17_2 = L17_2 / 2
      L17_2 = L16_2 + L17_2
      L16_2 = L17_2 + L15_2
      ::lbl_161::
      L17_2 = native
      L17_2 = L17_2.canShowPopup
      L18_2 = "sms"
      L17_2 = L17_2(L18_2)
      if not L17_2 then
        L17_2 = _SIMULATOR
        if not L17_2 then
          goto lbl_197
        end
      end
      L17_2 = buttons
      L17_2 = L17_2.newPlainText
      L18_2 = "Text"
      L19_2 = L18_1
      L20_2 = {}
      L20_2.group = L14_2
      L20_2.frameless = L13_2
      L21_2 = orange
      L20_2.textColor = L21_2
      L21_2 = orange
      L20_2.strokeColor = L21_2
      L21_2 = verydarkgray
      L20_2.bgColor = L21_2
      L20_2.fontSize = L5_2
      L20_2.fontNum = L4_2
      L17_2 = L17_2(L18_2, L19_2, L20_2)
      L7_1 = L17_2
      L17_2 = L7_1
      L18_2 = L7_1
      L19_2 = _W2
      L18_2.y = L16_2
      L17_2.x = L19_2
      L17_2 = L7_1
      L17_2 = L17_2.height
      L17_2 = L17_2 / 2
      L17_2 = L16_2 + L17_2
      L16_2 = L17_2 + L15_2
      ::lbl_197::
      L17_2 = buttons
      L17_2 = L17_2.newPlainText
      L18_2 = "Facebook"
      L19_2 = L19_1
      L20_2 = {}
      L20_2.group = L14_2
      L20_2.frameless = L13_2
      L21_2 = blue
      L20_2.textColor = L21_2
      L21_2 = blue
      L20_2.strokeColor = L21_2
      L21_2 = verydarkgray
      L20_2.bgColor = L21_2
      L20_2.fontSize = L5_2
      L20_2.fontNum = L4_2
      L17_2 = L17_2(L18_2, L19_2, L20_2)
      L8_1 = L17_2
      L17_2 = L8_1
      L18_2 = L8_1
      L19_2 = _W2
      L18_2.y = L16_2
      L17_2.x = L19_2
      L17_2 = L8_1
      L17_2 = L17_2.height
      L17_2 = L17_2 / 2
      L17_2 = L16_2 + L17_2
      L16_2 = L17_2 + L15_2
      L17_2 = buttons
      L17_2 = L17_2.newPlainText
      L18_2 = "Twitter"
      L19_2 = L20_1
      L20_2 = {}
      L20_2.group = L14_2
      L20_2.frameless = L13_2
      L21_2 = cyan
      L20_2.textColor = L21_2
      L21_2 = cyan
      L20_2.strokeColor = L21_2
      L21_2 = verydarkgray
      L20_2.bgColor = L21_2
      L20_2.fontSize = L5_2
      L20_2.fontNum = L4_2
      L17_2 = L17_2(L18_2, L19_2, L20_2)
      L9_1 = L17_2
      L17_2 = L9_1
      L18_2 = L9_1
      L19_2 = _W2
      L18_2.y = L16_2
      L17_2.x = L19_2
      L17_2 = L9_1
      L17_2 = L17_2.height
      L17_2 = L17_2 / 2
      L17_2 = L16_2 + L17_2
      L16_2 = L17_2 + L15_2
      L17_2 = _COUNTRY
      if L17_2 ~= "CN" then
        L17_2 = _COUNTRY
        if L17_2 ~= "HK" then
          L17_2 = COUNTRY
          if L17_2 ~= "TW" then
            goto lbl_287
          end
        end
      end
      L17_2 = buttons
      L17_2 = L17_2.newPlainText
      L18_2 = "Sina Weibo"
      L19_2 = L21_1
      L20_2 = {}
      L20_2.group = L14_2
      L20_2.frameless = L13_2
      L21_2 = purple
      L20_2.textColor = L21_2
      L21_2 = purple
      L20_2.strokeColor = L21_2
      L21_2 = verydarkgray
      L20_2.bgColor = L21_2
      L20_2.fontSize = L5_2
      L20_2.fontNum = L4_2
      L17_2 = L17_2(L18_2, L19_2, L20_2)
      L10_1 = L17_2
      L17_2 = L10_1
      L18_2 = L10_1
      L19_2 = _W2
      L18_2.y = L16_2
      L17_2.x = L19_2
      L17_2 = L10_1
      L17_2 = L17_2.height
      L17_2 = L17_2 / 2
      L17_2 = L16_2 + L17_2
      L16_2 = L17_2 + L15_2
      ::lbl_287::
      L17_2 = platform
      L17_2 = L17_2.android
      if L17_2 then
        L17_2 = buttons
        L17_2 = L17_2.newPlainText
        L18_2 = "Share Now"
        L19_2 = L22_1
        L20_2 = {}
        L20_2.group = L14_2
        L20_2.frameless = L13_2
        L21_2 = green
        L20_2.textColor = L21_2
        L21_2 = green
        L20_2.strokeColor = L21_2
        L21_2 = verydarkgray
        L20_2.bgColor = L21_2
        L20_2.fontSize = L5_2
        L20_2.fontNum = L4_2
        L17_2 = L17_2(L18_2, L19_2, L20_2)
        L11_1 = L17_2
        L17_2 = L11_1
        L18_2 = L11_1
        L19_2 = _W2
        L18_2.y = L16_2
        L17_2.x = L19_2
        L17_2 = L11_1
        L17_2 = L17_2.height
        L17_2 = L17_2 / 2
        L17_2 = L16_2 + L17_2
        L16_2 = L17_2 + L15_2
      end
      L17_2 = buttons
      L17_2 = L17_2.newPlainText
      L18_2 = "Back"
      L19_2 = L16_1
      L20_2 = {}
      L20_2.group = L14_2
      L20_2.textColor = L12_2
      L20_2.frameless = true
      L20_2.alphaWhenEnabled = 0.6
      L20_2.fontSize = 16
      L20_2.fontNum = L4_2
      L17_2 = L17_2(L18_2, L19_2, L20_2)
      L12_1 = L17_2
      L17_2 = L12_1
      L18_2 = L12_1
      L19_2 = _W2
      L18_2.y = L16_2
      L17_2.x = L19_2
      L17_2 = L12_1
      L17_2 = L17_2.height
      L17_2 = L17_2 / 2
      L17_2 = L16_2 + L17_2
      L16_2 = L17_2 + L15_2
      L17_2 = 0.5
      L14_2.anchorY = 0.5
      L14_2.anchorX = L17_2
      L17_2 = _W2
      L18_2 = _H2
      L14_2.y = L18_2
      L14_2.x = L17_2
      L17_2 = 0
      L18_2 = L8_1
      if L18_2 then
        L18_2 = L8_1
        L18_2 = L18_2.width
        L17_2 = L18_2 + 30
      end
      L18_2 = L10_1
      if L18_2 then
        L18_2 = L10_1
        L18_2 = L18_2.width
        L17_2 = L18_2 + 30
      end
      L18_2 = L11_1
      if L18_2 then
        L18_2 = L11_1
        L18_2 = L18_2.width
        L17_2 = L18_2 + 30
      end
      L18_2 = L5_1
      if L18_2 then
        L18_2 = L5_1
        L18_2 = L18_2.width
        L17_2 = L18_2 + 30
      end
      if L17_2 < 150 then
        L17_2 = 150
      end
      L18_2 = L14_2.height
      L18_2 = L18_2 + L15_2
      L19_2 = display
      L19_2 = L19_2.newRoundedRect
      L20_2 = L2_2
      L21_2 = _W2
      L22_2 = _H2
      L23_2 = L17_2
      L24_2 = L18_2
      L25_2 = 20
      L19_2 = L19_2(L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
      L4_1 = L19_2
      L19_2 = L4_1
      L19_2.alpha = 1
      L19_2 = L4_1
      L20_2 = L19_2
      L19_2 = L19_2.setFillColor
      L21_2 = L8_2
      L19_2(L20_2, L21_2())
      L19_2 = L4_1
      L19_2.strokeWidth = L10_2
      L19_2 = L4_1
      L20_2 = L19_2
      L19_2 = L19_2.setStrokeColor
      L21_2 = L9_2
      L19_2(L20_2, L21_2())
      L19_2 = L4_1
      L20_2 = L19_2
      L19_2 = L19_2.toBack
      L19_2(L20_2)
      L19_2 = L3_1
      L19_2.alpha = L11_2
      L19_2 = L3_1
      L20_2 = L19_2
      L19_2 = L19_2.toBack
      L19_2(L20_2)
    end
  end
end

L1_1.show = L23_1

function L23_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_share:hide() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
    L3_2 = utils
    L3_2 = L3_2.cancelAllTimersAndTransitions
    L3_2()
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
    end
  end
end

L1_1.hide = L23_1

function L23_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_share:destroy()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
end

L1_1.destroy = L23_1
L24_1 = L1_1
L23_1 = L1_1.addEventListener
L25_1 = "create"
L26_1 = L1_1
L23_1(L24_1, L25_1, L26_1)
L24_1 = L1_1
L23_1 = L1_1.addEventListener
L25_1 = "show"
L26_1 = L1_1
L23_1(L24_1, L25_1, L26_1)
L24_1 = L1_1
L23_1 = L1_1.addEventListener
L25_1 = "hide"
L26_1 = L1_1
L23_1(L24_1, L25_1, L26_1)
L24_1 = L1_1
L23_1 = L1_1.addEventListener
L25_1 = "destroy"
L26_1 = L1_1
L23_1(L24_1, L25_1, L26_1)
return L1_1
