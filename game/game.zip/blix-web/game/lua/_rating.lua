local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_rating.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = saver
L2_1 = L2_1.Load
L3_1 = "rating.txt"
L2_1 = L2_1(L3_1)
if not L2_1 then
  L2_1 = {}
end
L0_1.savedData = L2_1
L2_1 = L0_1.savedData
L2_1 = L2_1.numberOfChecks
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.numberOfChecks = 0
end
L2_1 = L0_1.savedData
L2_1 = L2_1.optedOut
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.optedOut = false
end
L2_1 = L0_1.savedData
L2_1 = L2_1.saidDontLike
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.saidDontLike = false
end
L2_1 = L0_1.savedData
L2_1 = L2_1.alreadyRated
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L2_1.alreadyRated = false
end
L2_1 = saver
L2_1 = L2_1.Save
L3_1 = L0_1.savedData
L4_1 = "rating.txt"
L2_1(L3_1, L4_1)

function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2.alreadyRated = true
  L0_2 = saver
  L0_2 = L0_2.Save
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L2_2 = "rating.txt"
  L0_2(L1_2, L2_2)
  L0_2 = system
  L0_2 = L0_2.openURL
  L1_2 = "http://bonfiremedia.com/"
  L2_2 = APP_ID
  L3_2 = "_rate_this.jsp?"
  L4_2 = utils
  L4_2 = L4_2.getParametersForServer
  L4_2 = L4_2()
  L1_2 = L1_2 .. L2_2 .. L3_2 .. L4_2
  L0_2(L1_2)
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Rating - rated"
  L0_2(L1_2)
end

function L3_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2 = L0_2.optedOut
  if not L0_2 then
    L0_2 = L0_1
    L0_2 = L0_2.savedData
    L0_2 = L0_2.saidDontLike
    if not L0_2 then
      L0_2 = L0_1
      L0_2 = L0_2.savedData
      L0_2 = L0_2.alreadyRated
      if not L0_2 then
        goto lbl_18
      end
    end
  end
  L0_2 = false
  do return L0_2 end
  ::lbl_18::
  L0_2 = true
  return L0_2
end

function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = A0_2.index
  if L1_2 == 2 then
    L2_2 = analytics
    L2_2 = L2_2.logEvent
    L3_2 = "Rating - rate later"
    L2_2(L3_2)
  elseif L1_2 == 1 then
    L2_2 = L2_1
    L2_2()
  elseif L1_2 == 3 then
    L2_2 = L0_1
    L2_2 = L2_2.savedData
    L2_2.optedOut = true
    L2_2 = saver
    L2_2 = L2_2.Save
    L3_2 = L0_1
    L3_2 = L3_2.savedData
    L4_2 = "rating.txt"
    L2_2(L3_2, L4_2)
    L2_2 = analytics
    L2_2 = L2_2.logEvent
    L3_2 = "Rating - opted out"
    L2_2(L3_2)
  end
end

function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = settings
  L0_2 = L0_2.t
  L0_2 = L0_2.allow_rating_optout
  if L0_2 then
    L0_2 = native
    L0_2 = L0_2.showAlert
    L1_2 = "Rate "
    L2_2 = APP_NAME
    L3_2 = " now."
    L1_2 = L1_2 .. L2_2 .. L3_2
    L2_2 = "Thanks for your support!"
    L3_2 = {}
    L4_2 = "Rate Now"
    L5_2 = "Later"
    L6_2 = "Don't ask again"
    L3_2[1] = L4_2
    L3_2[2] = L5_2
    L3_2[3] = L6_2
    L4_2 = L4_1
    L0_2(L1_2, L2_2, L3_2, L4_2)
  else
    L0_2 = native
    L0_2 = L0_2.showAlert
    L1_2 = "Rate "
    L2_2 = APP_NAME
    L3_2 = " now."
    L1_2 = L1_2 .. L2_2 .. L3_2
    L2_2 = "Thanks for your support!"
    L3_2 = {}
    L4_2 = "Rate Now"
    L5_2 = "Later"
    L3_2[1] = L4_2
    L3_2[2] = L5_2
    L4_2 = L4_1
    L0_2(L1_2, L2_2, L3_2, L4_2)
  end
end

function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = A0_2.index
  if L1_2 == 2 then
    L2_2 = {}
    L3_2 = {}
    L4_2 = SUPPORT_EMAIL
    L3_2[1] = L4_2
    L2_2.to = L3_2
    L3_2 = APP_NAME
    L4_2 = " Feedback"
    L3_2 = L3_2 .. L4_2
    L2_2.subject = L3_2
    L2_2.body = "<Enter Suggestions>"
    L3_2 = native
    L3_2 = L3_2.showPopup
    L4_2 = "mail"
    L5_2 = L2_2
    L3_2(L4_2, L5_2)
    L3_2 = L0_1
    L3_2 = L3_2.savedData
    L3_2.saidDontLike = true
    L3_2 = saver
    L3_2 = L3_2.Save
    L4_2 = L0_1
    L4_2 = L4_2.savedData
    L5_2 = "rating.txt"
    L3_2(L4_2, L5_2)
    L3_2 = analytics
    L3_2 = L3_2.logEvent
    L4_2 = "Rating - email bc dislike"
    L3_2(L4_2)
  elseif L1_2 == 1 then
    L2_2 = timer
    L2_2 = L2_2.performWithDelay
    L3_2 = 33
    L4_2 = L5_1
    L2_2(L3_2, L4_2)
  end
end

function L7_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = L3_1
  L0_2 = L0_2()
  if not L0_2 then
    return
  end
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2 = L1_2.numberOfChecks
  L1_2 = L1_2 + 1
  L0_2.numberOfChecks = L1_2
  L0_2 = saver
  L0_2 = L0_2.Save
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L2_2 = "rating.txt"
  L0_2(L1_2, L2_2)
  L0_2 = L1_1
  if L0_2 then
    L0_2 = log
    L0_2 = L0_2.show
    L1_2 = "rating.savedData.numberOfChecks:"
    L2_2 = L0_1
    L2_2 = L2_2.savedData
    L2_2 = L2_2.numberOfChecks
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
  end
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2 = L0_2.numberOfChecks
  L1_2 = settings
  L1_2 = L1_2.t
  L1_2 = L1_2.ask_for_rating_freq_mod
  L0_2 = L0_2 % L1_2
  if L0_2 == 0 then
    L0_2 = native
    L0_2 = L0_2.showAlert
    L1_2 = "Are you enjoying "
    L2_2 = APP_NAME
    L3_2 = "?"
    L1_2 = L1_2 .. L2_2 .. L3_2
    L2_2 = ""
    L3_2 = {}
    L4_2 = "Yes!"
    L5_2 = "No, tell us why"
    L3_2[1] = L4_2
    L3_2[2] = L5_2
    L4_2 = L6_1
    L0_2(L1_2, L2_2, L3_2, L4_2)
    L0_2 = true
    return L0_2
  end
  L0_2 = false
  return L0_2
end

L0_1.checkforRatingPopup = L7_1
return L0_1
