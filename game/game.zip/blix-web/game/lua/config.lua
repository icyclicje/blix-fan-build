local L0_1

function L0_1(...)
  local L0_2, L1_2
  L0_2 = application
  if L0_2 then
    L0_2 = type
    L1_2 = application
    L0_2 = L0_2(L1_2)
    if L0_2 == "table" then
      goto lbl_11
    end
  end
  L0_2 = {}
  application = L0_2
  ::lbl_11::
  L0_2 = application
  L1_2 = {}
  L1_2.appName = "Blix"
  L1_2.appVersion = "1.03"
  L1_2.appPackageId = "com.bonfiremedia.blix"
  L1_2.appId = "92621538d3a01cbd052.37681666"
  L1_2.userId = "92621"
  L1_2.subscription = "pro"
  L1_2.mode = "distribution"
  L0_2.metadata = L1_2
end

L0_1()

function L0_1(...)
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  
  function L0_2(A0_3, A1_3)
    local L2_3
    
    function L2_3(A0_4)
      local L1_4, L2_4, L3_4
      L1_4 = A0_4.action
      if "clicked" == L1_4 then
        L1_4 = A0_4.index
        if 1 == L1_4 then
        else
          L2_4 = system
          L2_4 = L2_4.openURL
          L3_4 = A0_3
          L2_4(L3_4)
        end
      end
      L1_4 = A1_3
      if L1_4 then
        L1_4 = os
        L1_4 = L1_4.exit
        L2_4 = -1
        L1_4(L2_4)
      end
    end
    
    return L2_3
  end
  
  function L1_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L1_3 = A0_3.feature
    if not L1_3 then
      L1_3 = ""
    end
    L2_3 = A0_3.type
    if not L2_3 then
      L2_3 = ""
    end
    L3_3 = A0_3.tier
    if not L3_3 then
      L3_3 = "Pro (or higher)"
    end
    L4_3 = "Corona SDK Error"
    L5_3 = "The premium %s feature (%s) is restricted to %s subscribers. You must upgrade your subscription to run this project."
    L6_3 = string
    L6_3 = L6_3.format
    L7_3 = L5_3
    L8_3 = L2_3
    L9_3 = L1_3
    L10_3 = L3_3
    L6_3 = L6_3(L7_3, L8_3, L9_3, L10_3)
    L7_3 = {}
    L8_3 = "Quit"
    L9_3 = "Upgrade"
    L7_3[1] = L8_3
    L7_3[2] = L9_3
    L8_3 = "http://www.coronalabs.com/upgrade/?utm_source=corona-sdk&utm_medium=corona-sdk&utm_campaign=feature-error&api="
    L9_3 = L1_3
    L8_3 = L8_3 .. L9_3
    L9_3 = L0_2
    L10_3 = L8_3
    L11_3 = true
    L9_3 = L9_3(L10_3, L11_3)
    L10_3 = native
    L10_3 = L10_3.showAlert
    L11_3 = L4_3
    L12_3 = L6_3
    L13_3 = L7_3
    L14_3 = L9_3
    L10_3(L11_3, L12_3, L13_3, L14_3)
  end
  
  function L2_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L1_3 = A0_3.feature
    if not L1_3 then
      L1_3 = ""
    end
    L2_3 = A0_3.type
    if not L2_3 then
      L2_3 = ""
    end
    L3_3 = A0_3.tier
    if not L3_3 then
      L3_3 = "Pro (or higher)"
    end
    L4_3 = "Corona SDK Warning"
    L5_3 = "Your project uses premium %s feature (%s) available to %s subscribers. You can view these in the simulator as a demo, but you must upgrade to see them on a device."
    L6_3 = string
    L6_3 = L6_3.format
    L7_3 = L5_3
    L8_3 = L2_3
    L9_3 = L1_3
    L10_3 = L3_3
    L6_3 = L6_3(L7_3, L8_3, L9_3, L10_3)
    L7_3 = {}
    L8_3 = "Continue with Demo"
    L9_3 = "Upgrade"
    L7_3[1] = L8_3
    L7_3[2] = L9_3
    L8_3 = "http://www.coronalabs.com/upgrade/?utm_source=corona-sdk&utm_medium=corona-sdk&utm_campaign=feature-warning&api="
    L9_3 = L1_3
    L8_3 = L8_3 .. L9_3
    L9_3 = L0_2
    L10_3 = L8_3
    L9_3 = L9_3(L10_3)
    L10_3 = native
    L10_3 = L10_3.showAlert
    L11_3 = L4_3
    L12_3 = L6_3
    L13_3 = L7_3
    L14_3 = L9_3
    L10_3(L11_3, L12_3, L13_3, L14_3)
  end
  
  L3_2 = L1_2
  L4_2 = system
  L4_2 = L4_2.getInfo
  L5_2 = "environment"
  L4_2 = L4_2(L5_2)
  if "simulator" == L4_2 then
    L3_2 = L2_2
  end
  
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L0_3 = true
    L1_3 = true
    L2_3 = true
    L3_3 = true
    L4_3 = application
    if L4_3 then
      L4_3 = application
      L4_3 = L4_3.metadata
      if L4_3 then
        L4_3 = application
        L4_3 = L4_3.metadata
        L4_3 = L4_3.subscription
        if L4_3 and "trial" ~= L4_3 then
          L0_3 = false
        end
        if L4_3 and "basic" ~= L4_3 then
          L1_3 = false
        end
        if L4_3 and "pro" ~= L4_3 then
          L2_3 = false
        end
        L5_3 = application
        L5_3 = L5_3.metadata
        L5_3 = L5_3.mode
        if L5_3 and "distribution" ~= L5_3 then
          L3_3 = false
        end
      end
    end
    L4_3 = initializeMetadata
    if L4_3 then
      L4_3 = nil
      L5_3 = application
      if L5_3 then
        L5_3 = application
        L4_3 = L5_3.metadata
      else
        L5_3 = {}
        L4_3 = L5_3
      end
      L5_3 = L4_3.permissions
      if not L5_3 then
        L6_3 = {}
        L5_3 = L6_3
        L4_3.permissions = L5_3
      end
      L6_3 = not L0_3 and L6_3
      L5_3.advancedGraphics = L6_3
      L6_3 = not L0_3 and not L1_3 and L6_3
      L5_3.customFragment = L6_3
      L6_3 = not L0_3 and not L1_3 and L6_3
      L5_3.customVertex = L6_3
      L6_3 = initializeMetadata
      L7_3 = L4_3
      L6_3(L7_3)
      L6_3 = nil
      initializeMetadata = L6_3
      L6_3 = Runtime
      L7_3 = L6_3
      L6_3 = L6_3.addEventListener
      L8_3 = "featureRestriction"
      L9_3 = L3_2
      L6_3(L7_3, L8_3, L9_3)
    end
    L4_3 = require
    L5_3 = {}
    L5_3.store = true
    L5_3.analytics = true
    
    function L6_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4
      L1_4 = "Corona SDK Warning"
      L2_4 = "You will not be able to publish this app to the store because it uses a restricted library (%s). Please upgrade to unlock it."
      L3_4 = string
      L3_4 = L3_4.format
      L4_4 = L2_4
      L5_4 = A0_4
      L3_4 = L3_4(L4_4, L5_4)
      L4_4 = {}
      L5_4 = "OK"
      L6_4 = "Upgrade"
      L4_4[1] = L5_4
      L4_4[2] = L6_4
      
      function L5_4(A0_5)
        local L1_5, L2_5, L3_5, L4_5
        L1_5 = A0_5.action
        if "clicked" == L1_5 then
          L1_5 = A0_5.index
          if 1 == L1_5 then
          else
            L2_5 = system
            L2_5 = L2_5.openURL
            L3_5 = "http://www.coronalabs.com/upgrade/?utm_source=corona-sdk&utm_medium=corona-sdk&utm_campaign=trial-warning&mod="
            L4_5 = A0_4
            L3_5 = L3_5 .. L4_5
            L2_5(L3_5)
          end
        end
      end
      
      L6_4 = native
      L6_4 = L6_4.showAlert
      L7_4 = L1_4
      L8_4 = L3_4
      L9_4 = L4_4
      L10_4 = L5_4
      L6_4(L7_4, L8_4, L9_4, L10_4)
    end
    
    function L7_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4
      L1_4 = "Corona SDK Error"
      L2_4 = "You cannot put this app on the store because it uses a restricted library (%s). Please upgrade to unlock it."
      L3_4 = string
      L3_4 = L3_4.format
      L4_4 = L2_4
      L5_4 = A0_4
      L3_4 = L3_4(L4_4, L5_4)
      L4_4 = {}
      L5_4 = "Quit"
      L6_4 = "Upgrade"
      L4_4[1] = L5_4
      L4_4[2] = L6_4
      
      function L5_4(A0_5)
        local L1_5, L2_5, L3_5, L4_5
        L1_5 = A0_5.action
        if "clicked" == L1_5 then
          L1_5 = A0_5.index
          if 1 == L1_5 then
          else
            L2_5 = system
            L2_5 = L2_5.openURL
            L3_5 = "http://www.coronalabs.com/upgrade/?utm_source=corona-sdk&utm_medium=corona-sdk&utm_campaign=trial-error&mod="
            L4_5 = A0_4
            L3_5 = L3_5 .. L4_5
            L2_5(L3_5)
          end
        end
        L1_5 = os
        L1_5 = L1_5.exit
        L2_5 = -1
        L1_5(L2_5)
      end
      
      L6_4 = native
      L6_4 = L6_4.showAlert
      L7_4 = L1_4
      L8_4 = L3_4
      L9_4 = L4_4
      L10_4 = L5_4
      L6_4(L7_4, L8_4, L9_4, L10_4)
    end
    
    function L8_3(A0_4)
      local L1_4, L2_4, L3_4
      L1_4 = true
      L2_4 = L0_3
      if L2_4 then
        L2_4 = L5_3
        L2_4 = L2_4[A0_4]
        if L2_4 then
          L2_4 = L3_3
          if L2_4 then
            L1_4 = false
          else
            L2_4 = L6_3
            L3_4 = A0_4
            L2_4(L3_4)
          end
        end
      end
      return L1_4
    end
    
    function L9_3(...)
      local L1_4, L2_4, L3_4
      L1_4 = L8_3
      L1_4 = L1_4(...)
      if L1_4 then
        L1_4 = L4_3
        return L1_4(...)
      end
      L1_4 = (...)
      L2_4 = L7_3
      L3_4 = L1_4
      L2_4(L3_4)
      L2_4 = nil
      return L2_4
    end
    
    if L0_3 then
      L10_3 = _G
      L10_3.require = L9_3
    end
  end
  
  L5_2 = L4_2
  L5_2()
  L4_2 = nil
end

L0_1()

function L0_1(...)
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = false
  _KINDLE = L0_2
  L0_2 = false
  _NOOK = L0_2
  L0_2 = system
  L0_2 = L0_2.getInfo
  L1_2 = "model"
  L0_2 = L0_2(L1_2)
  _MODEL = L0_2
  L0_2 = system
  L0_2 = L0_2.getInfo
  L1_2 = "architectureInfo"
  L0_2 = L0_2(L1_2)
  _ARCH = L0_2
  L0_2 = system
  L0_2 = L0_2.getPreference
  L1_2 = "locale"
  L2_2 = "country"
  L0_2 = L0_2(L1_2, L2_2)
  if not L0_2 then
    L0_2 = "none"
  end
  _COUNTRY = L0_2
  L0_2 = system
  L0_2 = L0_2.getPreference
  L1_2 = "locale"
  L2_2 = "language"
  L0_2 = L0_2(L1_2, L2_2)
  if not L0_2 then
    L0_2 = "none"
  end
  _LANGUAGE = L0_2
  L0_2 = system
  L0_2 = L0_2.getInfo
  L1_2 = "environment"
  L0_2 = L0_2(L1_2)
  L0_2 = L0_2 == "simulator"
  _SIMULATOR = L0_2
  L0_2 = system
  L0_2 = L0_2.getInfo
  L1_2 = "deviceID"
  L0_2 = L0_2(L1_2)
  if not L0_2 then
    L0_2 = ""
  end
  _UUID = L0_2
  L0_2 = system
  L0_2 = L0_2.getInfo
  L1_2 = "iosAdvertisingIdentifier"
  L0_2 = L0_2(L1_2)
  if not L0_2 then
    L0_2 = ""
  end
  _IFA = L0_2
  L0_2 = system
  L0_2 = L0_2.getInfo
  L1_2 = "iosAdvertisingTrackingEnabled"
  L0_2 = L0_2(L1_2)
  _IFATE = L0_2
  L0_2 = _IFATE
  if L0_2 == nil then
    L0_2 = ""
    _IFATE = L0_2
  end
  L0_2 = system
  L0_2 = L0_2.getInfo
  L1_2 = "iosIdentifierForVendor"
  L0_2 = L0_2(L1_2)
  if not L0_2 then
    L0_2 = ""
  end
  _IFV = L0_2
  L0_2 = false
  _DEV_TAKE_PIC_MODE = L0_2
  L0_2 = false
  _LEVEL_CREATION_MODE = L0_2
  L0_2 = false
  _REDDIT_HACK_MODE = L0_2
  L0_2 = false
  _EASTER_EGG_MODE = L0_2
  L0_2 = {}
  platform = L0_2
  L0_2 = string
  L0_2 = L0_2.lower
  L1_2 = system
  L1_2 = L1_2.getInfo
  L2_2 = "platformName"
  L0_2 = L0_2(L1_2(L2_2))
  if L0_2 == "android" then
    L1_2 = platform
    L1_2.android = true
  elseif L0_2 == "iphone os" then
    L1_2 = platform
    L1_2.ios = true
  elseif L0_2 == "win" then
    L1_2 = platform
    L1_2.win = true
  elseif L0_2 == "mac os x" then
    L1_2 = platform
    L1_2.mac = true
  end
  L1_2 = platform
  L1_2.name = L0_2
  L1_2 = platform
  L2_2 = system
  L2_2 = L2_2.getInfo
  L3_2 = "platformVersion"
  L2_2 = L2_2(L3_2)
  L1_2.version = L2_2
  L1_2 = false
  _isIpad = L1_2
  L1_2 = false
  _isIphone = L1_2
  L1_2 = false
  _isGear = L1_2
  L1_2 = _MODEL
  if L1_2 == "iPad" then
    L1_2 = true
    _isIpad = L1_2
  end
  L1_2 = _MODEL
  if L1_2 == "iPhone" then
    L1_2 = true
    _isIphone = L1_2
  end
  L1_2 = _MODEL
  if L1_2 == "SM-V700" then
    L1_2 = true
    _isGear = L1_2
  end
  L1_2 = 0
  _iVersion = L1_2
  L1_2 = false
  _isSlow = L1_2
  L1_2 = false
  _isFast = L1_2
  L1_2 = platform
  L1_2 = L1_2.android
  if L1_2 then
    L1_2 = true
    _isSlow = L1_2
  end
  L1_2 = string
  L1_2 = L1_2.find
  L2_2 = _ARCH
  L3_2 = "iPad"
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L1_2 = _ARCH
    L2_2 = L1_2
    L1_2 = L1_2.sub
    L3_2 = 5
    L4_2 = 5
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    L1_2 = L1_2 + 0
    _iVersion = L1_2
    L1_2 = _iVersion
    if 2 <= L1_2 then
      L1_2 = true
      _isFast = L1_2
    end
  else
    L1_2 = string
    L1_2 = L1_2.find
    L2_2 = _ARCH
    L3_2 = "iPhone"
    L1_2 = L1_2(L2_2, L3_2)
    if L1_2 then
      L1_2 = _ARCH
      L2_2 = L1_2
      L1_2 = L1_2.sub
      L3_2 = 7
      L4_2 = 7
      L1_2 = L1_2(L2_2, L3_2, L4_2)
      L1_2 = L1_2 + 0
      _iVersion = L1_2
      L1_2 = _iVersion
      if 4 <= L1_2 then
        L1_2 = true
        _isFast = L1_2
      end
      L1_2 = _iVersion
      if L1_2 <= 1 then
        L1_2 = true
        _isSlow = L1_2
      end
    else
      L1_2 = string
      L1_2 = L1_2.find
      L2_2 = _ARCH
      L3_2 = "iPod"
      L1_2 = L1_2(L2_2, L3_2)
      if L1_2 then
        L1_2 = _ARCH
        L2_2 = L1_2
        L1_2 = L1_2.sub
        L3_2 = 5
        L4_2 = 5
        L1_2 = L1_2(L2_2, L3_2, L4_2)
        L1_2 = L1_2 + 0
        _iVersion = L1_2
        L1_2 = _iVersion
        if 5 <= L1_2 then
          L1_2 = true
          _isFast = L1_2
        end
        L1_2 = _iVersion
        if L1_2 <= 3 then
          L1_2 = true
          _isSlow = L1_2
        end
      else
        L1_2 = string
        L1_2 = L1_2.find
        L2_2 = _ARCH
        L3_2 = "i386"
        L1_2 = L1_2(L2_2, L3_2)
        if L1_2 then
          L1_2 = true
          _isFast = L1_2
        end
      end
    end
  end
  L1_2 = 60
  _FPS = L1_2
  L1_2 = {}
  L2_2 = {}
  L3_2 = {}
  L3_2.projectNumber = "907374466034"
  L2_2.google = L3_2
  L3_2 = {}
  L4_2 = {}
  L5_2 = "badge"
  L6_2 = "sound"
  L7_2 = "alert"
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  L4_2[3] = L7_2
  L3_2.types = L4_2
  L2_2.iphone = L3_2
  L1_2.notification = L2_2
  L2_2 = {}
  L2_2.width = 320
  L2_2.height = 480
  L2_2.scale = "letterBox"
  L3_2 = _FPS
  L2_2.fps = L3_2
  L2_2.antialias = true
  L3_2 = {}
  L2_2.imageSuffix = L3_2
  L1_2.content = L2_2
  application = L1_2
end

L0_1()

function L0_1(...)
  local L0_2, L1_2
  L0_2 = application
  if L0_2 then
    L0_2 = type
    L1_2 = application
    L0_2 = L0_2(L1_2)
    if L0_2 == "table" then
      goto lbl_11
    end
  end
  L0_2 = {}
  application = L0_2
  ::lbl_11::
  L0_2 = application
  L1_2 = {}
  L1_2.appName = "Blix"
  L1_2.appVersion = "1.03"
  L1_2.appPackageId = "com.bonfiremedia.blix"
  L1_2.appId = "92621538d3a01cbd052.37681666"
  L1_2.userId = "92621"
  L1_2.subscription = "pro"
  L1_2.mode = "distribution"
  L0_2.metadata = L1_2
end

L0_1()
