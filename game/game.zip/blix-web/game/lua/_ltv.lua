local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
L1_1 = require
L2_1 = "json"
L1_1 = L1_1(L2_1)
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "_ltv.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = saver
L3_1 = L3_1.Load
L4_1 = "ltv.txt"
L3_1 = L3_1(L4_1)
if not L3_1 then
  L3_1 = {}
end
L0_1.data = L3_1
L3_1 = L0_1.data
L3_1 = L3_1.numSessions
if L3_1 == nil then
  L3_1 = L0_1.data
  L3_1.numSessions = 0
end
L3_1 = L0_1.data
L3_1 = L3_1.numPurchases
if L3_1 == nil then
  L3_1 = L0_1.data
  L3_1.numPurchases = 0
end
L3_1 = L0_1.data
L3_1 = L3_1.purchaseAmount
if L3_1 == nil then
  L3_1 = L0_1.data
  L3_1.purchaseAmount = 0
end
L3_1 = L0_1.data
L3_1 = L3_1.numAdsViewed
if L3_1 == nil then
  L3_1 = L0_1.data
  L3_1.numAdsViewed = 0
end
L3_1 = L0_1.data
L3_1 = L3_1.numAdsClicked
if L3_1 == nil then
  L3_1 = L0_1.data
  L3_1.numAdsClicked = 0
end
L3_1 = L0_1.data
L3_1 = L3_1.gamesPlayed
if L3_1 == nil then
  L3_1 = L0_1.data
  L3_1.gamesPlayed = 0
end
L3_1 = L0_1.data
L3_1 = L3_1.custom1
if L3_1 == nil then
  L3_1 = L0_1.data
  L3_1.custom1 = nil
end

function L3_1()
  local L0_2, L1_2, L2_2
  L0_2 = _LEVEL_CREATION_MODE
  if L0_2 then
    return
  end
  L0_2 = L2_1
  if L0_2 then
    L0_2 = print
    L1_2 = "ltv.startup()"
    L0_2(L1_2)
  end
  L0_2 = L0_1
  L0_2 = L0_2.data
  L1_2 = L0_1
  L1_2 = L1_2.data
  L1_2 = L1_2.numSessions
  L1_2 = L1_2 + 1
  L0_2.numSessions = L1_2
  L0_2 = saver
  L0_2 = L0_2.Save
  L1_2 = L0_1
  L1_2 = L1_2.data
  L2_2 = "ltv.txt"
  L0_2(L1_2, L2_2)
  L0_2 = timer
  L0_2 = L0_2.performWithDelay
  L1_2 = 2000
  
  function L2_2()
    local L0_3, L1_3
    L0_3 = L0_1
    L0_3 = L0_3.uploadLastestDataToServer
    L0_3()
  end
  
  L0_2(L1_2, L2_2)
end

L0_1.startup = L3_1

function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = _LEVEL_CREATION_MODE
  if L1_2 then
    return
  end
  L1_2 = L2_1
  if L1_2 then
    L1_2 = print
    L2_2 = "ltv.recordPurchase()"
    L1_2(L2_2)
  end
  L1_2 = L0_1
  L1_2 = L1_2.data
  L2_2 = L0_1
  L2_2 = L2_2.data
  L2_2 = L2_2.numPurchases
  L2_2 = L2_2 + 1
  L1_2.numPurchases = L2_2
  L1_2 = L0_1
  L1_2 = L1_2.data
  L2_2 = L0_1
  L2_2 = L2_2.data
  L2_2 = L2_2.purchaseAmount
  L2_2 = L2_2 + A0_2
  L1_2.purchaseAmount = L2_2
  L1_2 = gamethrive_utils
  L1_2 = L1_2.playerPurchase
  L2_2 = L0_1
  L2_2 = L2_2.data
  L2_2 = L2_2.purchaseAmount
  L1_2(L2_2)
  L1_2 = saver
  L1_2 = L1_2.Save
  L2_2 = L0_1
  L2_2 = L2_2.data
  L3_2 = "ltv.txt"
  L1_2(L2_2, L3_2)
  L1_2 = L0_1
  L1_2 = L1_2.uploadLastestDataToServer
  L1_2()
end

L0_1.recordPurchase = L3_1

function L3_1()
  local L0_2, L1_2, L2_2
  L0_2 = _LEVEL_CREATION_MODE
  if L0_2 then
    return
  end
  L0_2 = L2_1
  if L0_2 then
    L0_2 = print
    L1_2 = "ltv.recordAdView()"
    L0_2(L1_2)
  end
  L0_2 = L0_1
  L0_2 = L0_2.data
  L1_2 = L0_1
  L1_2 = L1_2.data
  L1_2 = L1_2.numAdsViewed
  L1_2 = L1_2 + 1
  L0_2.numAdsViewed = L1_2
  L0_2 = saver
  L0_2 = L0_2.Save
  L1_2 = L0_1
  L1_2 = L1_2.data
  L2_2 = "ltv.txt"
  L0_2(L1_2, L2_2)
  L0_2 = L0_1
  L0_2 = L0_2.uploadLastestDataToServer
  L0_2()
end

L0_1.recordAdView = L3_1

function L3_1()
  local L0_2, L1_2, L2_2
  L0_2 = _LEVEL_CREATION_MODE
  if L0_2 then
    return
  end
  L0_2 = L2_1
  if L0_2 then
    L0_2 = print
    L1_2 = "ltv.startup()"
    L0_2(L1_2)
  end
  L0_2 = L0_1
  L0_2 = L0_2.data
  L1_2 = L0_1
  L1_2 = L1_2.data
  L1_2 = L1_2.numAdsClicked
  L1_2 = L1_2 + 1
  L0_2.numAdsClicked = L1_2
  L0_2 = saver
  L0_2 = L0_2.Save
  L1_2 = L0_1
  L1_2 = L1_2.data
  L2_2 = "ltv.txt"
  L0_2(L1_2, L2_2)
  L0_2 = L0_1
  L0_2 = L0_2.uploadLastestDataToServer
  L0_2()
end

L0_1.recordAdClick = L3_1

function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = _LEVEL_CREATION_MODE
  if L1_2 then
    return
  end
  L1_2 = L2_1
  if L1_2 then
    L1_2 = print
    L2_2 = "ltv.recordGamePlayed()"
    L1_2(L2_2)
  end
  L1_2 = L0_1
  L1_2 = L1_2.data
  L2_2 = L0_1
  L2_2 = L2_2.data
  L2_2 = L2_2.gamesPlayed
  L2_2 = L2_2 + 1
  L1_2.gamesPlayed = L2_2
  L1_2 = saver
  L1_2 = L1_2.Save
  L2_2 = L0_1
  L2_2 = L2_2.data
  L3_2 = "ltv.txt"
  L1_2(L2_2, L3_2)
  if A0_2 then
    L1_2 = L0_1
    L1_2 = L1_2.uploadLastestDataToServer
    L1_2()
  end
end

L0_1.recordGamePlayed = L3_1

function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = _LEVEL_CREATION_MODE
  if L1_2 then
    return
  end
  L1_2 = L2_1
  if L1_2 then
    L1_2 = print
    L2_2 = "ltv.setNumGamesPlayed()"
    L1_2(L2_2)
  end
  L1_2 = L0_1
  L1_2 = L1_2.data
  L1_2.gamesPlayed = A0_2
  L1_2 = saver
  L1_2 = L1_2.Save
  L2_2 = L0_1
  L2_2 = L2_2.data
  L3_2 = "ltv.txt"
  L1_2(L2_2, L3_2)
end

L0_1.setNumGamesPlayed = L3_1

function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = _LEVEL_CREATION_MODE
  if L1_2 then
    return
  end
  L1_2 = L2_1
  if L1_2 then
    L1_2 = print
    L2_2 = "ltv.setCustom()"
    L1_2(L2_2)
  end
  L1_2 = L0_1
  L1_2 = L1_2.data
  L1_2.custom1 = A0_2
  L1_2 = saver
  L1_2 = L1_2.Save
  L2_2 = L0_1
  L2_2 = L2_2.data
  L3_2 = "ltv.txt"
  L1_2(L2_2, L3_2)
end

L0_1.setCustom = L3_1

function L3_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = _LEVEL_CREATION_MODE
  if L1_2 then
    return
  end
  L1_2 = L2_1
  if L1_2 then
    L1_2 = print
    L2_2 = "ltv.addToCustom()"
    L1_2(L2_2)
  end
  L1_2 = L0_1
  L1_2 = L1_2.data
  L1_2 = L1_2.custom1
  if L1_2 == nil then
    L1_2 = L0_1
    L1_2 = L1_2.data
    L1_2.custom1 = 0
  end
  L1_2 = L0_1
  L1_2 = L1_2.data
  L2_2 = L0_1
  L2_2 = L2_2.data
  L2_2 = L2_2.custom1
  L2_2 = L2_2 + A0_2
  L1_2.custom1 = L2_2
  L1_2 = saver
  L1_2 = L1_2.Save
  L2_2 = L0_1
  L2_2 = L2_2.data
  L3_2 = "ltv.txt"
  L1_2(L2_2, L3_2)
end

L0_1.addToCustom = L3_1

function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L2_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "ltv listener() "
    L3_2 = A0_2.status
    L2_2 = L2_2 .. L3_2
    L3_2 = {}
    L4_2 = yellow
    L3_2.textColor = L4_2
    L4_2 = 1
    L1_2(L2_2, L3_2, L4_2)
  end
  L1_2 = A0_2.isError
  if L1_2 then
    L1_2 = print
    L2_2 = "ltv listener(): Network error"
    L1_2(L2_2)
  else
    L1_2 = L2_1
    if L1_2 then
      L1_2 = print
      L2_2 = "STATUS CODE: "
      L3_2 = A0_2.status
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
    end
    L1_2 = L2_1
    if L1_2 then
      L1_2 = print
      L2_2 = "RESPONSE: "
      L3_2 = A0_2.response
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
    end
  end
end

function L4_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = ""
  L1_2 = L0_2
  L2_2 = "&numSessions="
  L3_2 = L0_1
  L3_2 = L3_2.data
  L3_2 = L3_2.numSessions
  L0_2 = L1_2 .. L2_2 .. L3_2
  L1_2 = L0_2
  L2_2 = "&numPurchases="
  L3_2 = L0_1
  L3_2 = L3_2.data
  L3_2 = L3_2.numPurchases
  L0_2 = L1_2 .. L2_2 .. L3_2
  L1_2 = L0_2
  L2_2 = "&purchaseAmount="
  L3_2 = L0_1
  L3_2 = L3_2.data
  L3_2 = L3_2.purchaseAmount
  L0_2 = L1_2 .. L2_2 .. L3_2
  L1_2 = L0_2
  L2_2 = "&numAdsViewed="
  L3_2 = L0_1
  L3_2 = L3_2.data
  L3_2 = L3_2.numAdsViewed
  L0_2 = L1_2 .. L2_2 .. L3_2
  L1_2 = L0_2
  L2_2 = "&numAdsClicked="
  L3_2 = L0_1
  L3_2 = L3_2.data
  L3_2 = L3_2.numAdsClicked
  L0_2 = L1_2 .. L2_2 .. L3_2
  L1_2 = L0_2
  L2_2 = "&gamesPlayed="
  L3_2 = L0_1
  L3_2 = L3_2.data
  L3_2 = L3_2.gamesPlayed
  L0_2 = L1_2 .. L2_2 .. L3_2
  L1_2 = L0_1
  L1_2 = L1_2.data
  L1_2 = L1_2.custom1
  if L1_2 then
    L1_2 = L0_2
    L2_2 = "&custom1="
    L3_2 = L0_1
    L3_2 = L3_2.data
    L3_2 = L3_2.custom1
    L0_2 = L1_2 .. L2_2 .. L3_2
  end
  return L0_2
end

L0_1.generateParamsString = L4_1

function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = _LEVEL_CREATION_MODE
  if L0_2 then
    return
  end
  L0_2 = settings
  L0_2 = L0_2.getInternetLatency
  L0_2 = L0_2()
  if 10000 < L0_2 then
    L0_2 = false
    return L0_2
  end
  L0_2 = L2_1
  if L0_2 then
    L0_2 = log
    L0_2 = L0_2.show
    L1_2 = "ltv.uploadToServer"
    L2_2 = {}
    L3_2 = yellow
    L2_2.textColor = L3_2
    L2_2.pos = 1
    L0_2(L1_2, L2_2)
  end
  L0_2 = {}
  L0_2["Accept-Language"] = "en-US"
  L0_2["Content-Type"] = "application/x-www-form-urlencoded"
  L1_2 = {}
  L1_2.headers = L0_2
  L1_2.body = "Command=Games_ReportLTV"
  L2_2 = ""
  L3_2 = L2_2
  L4_2 = "&game="
  L5_2 = APP_ID
  L2_2 = L3_2 .. L4_2 .. L5_2
  L3_2 = L2_2
  L4_2 = L0_1
  L4_2 = L4_2.generateParamsString
  L4_2 = L4_2()
  L2_2 = L3_2 .. L4_2
  L3_2 = L2_2
  L4_2 = fb_utils
  L4_2 = L4_2.generateFbParams
  L4_2 = L4_2()
  L2_2 = L3_2 .. L4_2
  L3_2 = L2_2
  L4_2 = "&"
  L5_2 = utils
  L5_2 = L5_2.getParametersForServer
  L5_2 = L5_2()
  L2_2 = L3_2 .. L4_2 .. L5_2
  L3_2 = L1_2.body
  L4_2 = L2_2
  L3_2 = L3_2 .. L4_2
  L1_2.body = L3_2
  L3_2 = L2_1
  if L3_2 then
    L3_2 = print
    L4_2 = L1_2.body
    L3_2(L4_2)
  end
  L3_2 = network
  L3_2 = L3_2.request
  L4_2 = utils
  L4_2 = L4_2.getURL
  L5_2 = "POST"
  L4_2 = L4_2(L5_2)
  L5_2 = "POST"
  L6_2 = L3_1
  L7_2 = L1_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
  L3_2 = gamethrive_utils
  L3_2 = L3_2.doCommonTags
  L3_2()
end

L0_1.uploadLastestDataToServer = L4_1
L4_1 = L0_1.startup
L4_1()
return L0_1
