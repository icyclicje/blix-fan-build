local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "game_pointandshoot.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = math
L2_1 = L2_1.random
L3_1 = math
L3_1 = L3_1.pow
L0_1.name = "PointAndShoot"
L0_1.displayName = "Point and Shoot"
L0_1.instructions = "Just clear all the colored dots. Earn big bonus points by clearing multiple dots on one go."
L0_1.scoring = true
L0_1.leveling = true
L0_1.lives = 3
L0_1.oneStrokeAtOnce = false
L0_1.oneStrokePerColorAtOnce = false
L0_1.multitouch = true

function L4_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = gamenetwork_utils
  L1_2 = L1_2.sendHighScore
  L2_2 = globals
  L2_2 = L2_2.LEADERBOARD_ID_POINTANDSHOOT
  L3_2 = _score
  L1_2(L2_2, L3_2)
end

L0_1.onEndGame = L4_1

function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L3_2 = A2_2.parent
  L4_2 = L3_2
  L3_2 = L3_2.localToContent
  L5_2 = A2_2.x
  L6_2 = A2_2.y
  L3_2, L4_2 = L3_2(L4_2, L5_2, L6_2)
  L5_2 = L3_1
  L6_2 = A1_2.targetsHit
  L6_2 = #L6_2
  L7_2 = 2
  L5_2 = L5_2(L6_2, L7_2)
  L6_2 = _addToScore
  L7_2 = L5_2
  L8_2 = 1
  L6_2(L7_2, L8_2)
  L6_2 = gameutils
  L6_2 = L6_2.showPopupScore
  L7_2 = L3_2
  L8_2 = L4_2
  L9_2 = L5_2
  L10_2 = A2_2.color
  L11_2 = 14
  L6_2(L7_2, L8_2, L9_2, L10_2, L11_2)
  L7_2 = A2_2
  L6_2 = A2_2.remove
  L8_2 = 200
  L6_2(L7_2, L8_2)
  L6_2 = target
  L6_2 = L6_2.numInPlay
  if L6_2 == 0 then
    L6_2 = timer
    L6_2 = L6_2.performWithDelay
    L7_2 = 100
    
    function L8_2()
      local L0_3, L1_3
      L0_3 = _levelUp
      L1_3 = 1000
      L0_3(L1_3)
    end
    
    L6_2(L7_2, L8_2)
  end
end

L0_1.onCorrectTargetHit = L4_1

function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
  L3_2 = _loseLife
  L3_2()
end

L0_1.onWrongTargetHit = L4_1

function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
  L3_2 = _loseLife
  L3_2()
end

L0_1.onObstacleHit = L4_1

function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = 1
  L2_2 = _level
  L2_2 = L2_2 * 2
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L2_1
    L6_2 = 10
    L7_2 = 20
    L5_2 = L5_2(L6_2, L7_2)
    L6_2 = gameutils
    L6_2 = L6_2.getRandomOpenSpotForCircle
    L7_2 = L5_2
    L6_2, L7_2 = L6_2(L7_2)
    if L6_2 == nil then
      break
    end
    L8_2 = target
    L8_2 = L8_2.new
    L9_2 = _group
    L10_2 = {}
    L11_2 = L4_2 - 1
    L11_2 = L11_2 * 100
    L10_2.delay = L11_2
    L10_2.x = L6_2
    L10_2.y = L7_2
    L10_2.radius = L5_2
    L11_2 = gameutils
    L11_2 = L11_2.getRandomColor
    L11_2 = L11_2()
    L10_2.color = L11_2
    L8_2(L9_2, L10_2)
  end
  L1_2 = 1
  L2_2 = _level
  L2_2 = L2_2 * 2
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L2_1
    L6_2 = 10
    L7_2 = 15
    L5_2 = L5_2(L6_2, L7_2)
    L6_2 = gameutils
    L6_2 = L6_2.getRandomOpenSpotForCircle
    L7_2 = L5_2
    L6_2, L7_2 = L6_2(L7_2)
    if L6_2 == nil then
      break
    end
    L8_2 = obstacle
    L8_2 = L8_2.new
    L9_2 = _group
    L10_2 = {}
    L11_2 = L4_2 - 1
    L11_2 = L11_2 * 100
    L10_2.delay = L11_2
    L10_2.x = L6_2
    L10_2.y = L7_2
    L10_2.radius = L5_2
    L8_2(L9_2, L10_2)
  end
end

L0_1.onLevelUp = L4_1
return L0_1
