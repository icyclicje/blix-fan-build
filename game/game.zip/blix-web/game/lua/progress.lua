local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "progress.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = saver
L2_1 = L2_1.Load
L3_1 = "progress.txt"
L2_1 = L2_1(L3_1)
if not L2_1 then
  L2_1 = {}
end
L0_1.savedData = L2_1
L2_1 = L0_1.savedData
L2_1 = L2_1.gameScores
if L2_1 == nil then
  L2_1 = L0_1.savedData
  L3_1 = {}
  L2_1.gameScores = L3_1
end
L2_1 = saver
L2_1 = L2_1.Save
L3_1 = L0_1.savedData
L4_1 = "progress.txt"
L2_1(L3_1, L4_1)

function L2_1(A0_2)
  local L1_2
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2 = L1_2.gameScores
  L1_2 = L1_2[A0_2]
  if not L1_2 then
    L1_2 = 0
    return L1_2
  end
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2 = L1_2.gameScores
  L1_2 = L1_2[A0_2]
  L1_2 = L1_2.highScore
  if not L1_2 then
    L1_2 = 0
  end
  return L1_2
end

L0_1.getHighScore = L2_1

function L2_1(A0_2)
  local L1_2
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2 = L1_2.gameScores
  L1_2 = L1_2[A0_2]
  if not L1_2 then
    L1_2 = 0
    return L1_2
  end
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2 = L1_2.gameScores
  L1_2 = L1_2[A0_2]
  L1_2 = L1_2.lastScore
  if not L1_2 then
    L1_2 = 0
  end
  return L1_2
end

L0_1.getLastScore = L2_1

function L2_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2
  L4_2 = L0_1
  L4_2 = L4_2.savedData
  L4_2 = L4_2.gameScores
  L4_2 = L4_2[A0_2]
  if not L4_2 then
    L4_2 = L0_1
    L4_2 = L4_2.savedData
    L4_2 = L4_2.gameScores
    L5_2 = {}
    L4_2[A0_2] = L5_2
  end
  L4_2 = L0_1
  L4_2 = L4_2.savedData
  L4_2 = L4_2.gameScores
  L4_2 = L4_2[A0_2]
  L4_2.lastScore = A1_2
  L4_2 = L0_1
  L4_2 = L4_2.savedData
  L4_2 = L4_2.gameScores
  L4_2 = L4_2[A0_2]
  L4_2 = L4_2.highScore
  if not L4_2 then
    L4_2 = 0
  end
  if A1_2 > L4_2 then
    L4_2 = L0_1
    L4_2 = L4_2.savedData
    L4_2 = L4_2.gameScores
    L4_2 = L4_2[A0_2]
    L4_2.highScore = A1_2
  end
  L4_2 = L0_1
  L4_2 = L4_2.savedData
  L4_2 = L4_2.gameScores
  L4_2 = L4_2[A0_2]
  L4_2 = L4_2.highestLevel
  if not L4_2 then
    L4_2 = 0
  end
  if A2_2 > L4_2 then
    L4_2 = L0_1
    L4_2 = L4_2.savedData
    L4_2 = L4_2.gameScores
    L4_2 = L4_2[A0_2]
    L4_2.highestLevel = A2_2
  end
  L4_2 = L0_1
  L4_2 = L4_2.savedData
  L4_2 = L4_2.gameScores
  L4_2 = L4_2[A0_2]
  L4_2 = L4_2.mostDotsCleared
  if not L4_2 then
    L4_2 = 0
  end
  if A3_2 > L4_2 then
    L4_2 = L0_1
    L4_2 = L4_2.savedData
    L4_2 = L4_2.gameScores
    L4_2 = L4_2[A0_2]
    L4_2.mostDotsCleared = A3_2
  end
  L4_2 = saver
  L4_2 = L4_2.Save
  L5_2 = L0_1
  L5_2 = L5_2.savedData
  L6_2 = "progress.txt"
  L4_2(L5_2, L6_2)
end

L0_1.reportScore = L2_1
return L0_1
