local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1
L0_1 = require
L1_1 = "composer"
L0_1 = L0_1(L1_1)
L1_1 = L0_1.newScene
L1_1 = L1_1()
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "scene_minigames_menu.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = -30
L4_1 = 33
L5_1 = nil
L6_1 = nil
L7_1 = nil
L8_1 = nil
L9_1 = nil
L10_1 = nil

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_minigames_menu:create()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = display
  L3_2 = L3_2.newRect
  L4_2 = L2_2
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = screenWidth
  L8_2 = screenHeight
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L5_1 = L3_2
  L3_2 = L5_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = black
  L3_2(L4_2, L5_2())
  L3_2 = L5_1
  L3_2.alpha = 0.1
  L3_2 = display
  L3_2 = L3_2.newRoundedRect
  L4_2 = L2_2
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = 200
  L8_2 = 190
  L9_2 = 20
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L6_1 = L3_2
  L3_2 = L6_1
  L3_2.alpha = 1
  L3_2 = L6_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = white
  L3_2(L4_2, L5_2())
  L3_2 = L6_1
  L3_2.strokeWidth = 2
  L3_2 = L6_1
  L4_2 = L3_2
  L3_2 = L3_2.setStrokeColor
  L5_2 = gray
  L3_2(L4_2, L5_2())
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = game_pointandshoot
  L4_2 = L4_2.displayName
  
  function L5_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    L0_3 = L0_1
    L0_3 = L0_3.gotoScene
    L1_3 = "scene_game"
    L2_3 = {}
    L3_3 = {}
    L4_3 = game_pointandshoot
    L3_3.game = L4_3
    L2_3.params = L3_3
    L0_3(L1_3, L2_3)
  end
  
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = blue
  L6_2.textColor = L7_2
  L6_2.frameless = true
  L6_2.fontSize = 24
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2.fontNum = L7_2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L8_1 = L3_2
  L3_2 = L8_1
  L4_2 = L8_1
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = L3_1
  L6_2 = L6_2 + L7_2
  L7_2 = L4_1
  L6_2 = L6_2 - L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = game_swarm
  L4_2 = L4_2.displayName
  
  function L5_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    L0_3 = L0_1
    L0_3 = L0_3.gotoScene
    L1_3 = "scene_game"
    L2_3 = {}
    L3_3 = {}
    L4_3 = game_swarm
    L3_3.game = L4_3
    L2_3.params = L3_3
    L0_3(L1_3, L2_3)
  end
  
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = red
  L6_2.textColor = L7_2
  L6_2.frameless = true
  L6_2.fontSize = 24
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2.fontNum = L7_2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L9_1 = L3_2
  L3_2 = L9_1
  L4_2 = L9_1
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = L3_1
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = "More Coming"
  L5_2 = nil
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = gray
  L6_2.textColor = L7_2
  L6_2.frameless = true
  L6_2.fontSize = 24
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2.fontNum = L7_2
  L6_2.disabled = true
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L10_1 = L3_2
  L3_2 = L10_1
  L4_2 = L10_1
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = L3_1
  L6_2 = L6_2 + L7_2
  L7_2 = L4_1
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = "Back"
  
  function L5_2()
    local L0_3, L1_3
    L0_3 = L0_1
    L0_3 = L0_3.hideOverlay
    L1_3 = true
    L0_3(L1_3)
  end
  
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = black
  L6_2.textColor = L7_2
  L6_2.alphaWhenEnabled = 0.6
  L6_2.frameless = true
  L6_2.fontSize = 16
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2.fontNum = L7_2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L7_1 = L3_2
  L3_2 = L7_1
  L4_2 = L7_1
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = L3_1
  L6_2 = L6_2 + L7_2
  L7_2 = L4_1
  L7_2 = L7_2 * 3
  L6_2 = L6_2 + L7_2
  L6_2 = L6_2 - 10
  L4_2.y = L6_2
  L3_2.x = L5_2
end

L1_1.create = L11_1

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_minigames_menu:show() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
    end
  end
end

L1_1.show = L11_1

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_minigames_menu:hide() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
    L3_2 = utils
    L3_2 = L3_2.cancelAllTimersAndTransitions
    L3_2()
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
    end
  end
end

L1_1.hide = L11_1

function L11_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_minigames_menu:destroy()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
end

L1_1.destroy = L11_1
L12_1 = L1_1
L11_1 = L1_1.addEventListener
L13_1 = "create"
L14_1 = L1_1
L11_1(L12_1, L13_1, L14_1)
L12_1 = L1_1
L11_1 = L1_1.addEventListener
L13_1 = "show"
L14_1 = L1_1
L11_1(L12_1, L13_1, L14_1)
L12_1 = L1_1
L11_1 = L1_1.addEventListener
L13_1 = "hide"
L14_1 = L1_1
L11_1(L12_1, L13_1, L14_1)
L12_1 = L1_1
L11_1 = L1_1.addEventListener
L13_1 = "destroy"
L14_1 = L1_1
L11_1(L12_1, L13_1, L14_1)
return L1_1
