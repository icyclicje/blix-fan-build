local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_toast.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = nil

function L3_1()
  local L0_2, L1_2
  L0_2 = L2_1
  if L0_2 then
    L0_2 = L2_1
    L0_2 = L0_2.deleteTimer
    if L0_2 then
      L0_2 = timer
      L0_2 = L0_2.cancel
      L1_2 = L2_1
      L1_2 = L1_2.deleteTimer
      L0_2(L1_2)
      L0_2 = L2_1
      L0_2.deleteTimer = nil
    end
    L0_2 = L2_1
    L0_2 = L0_2.fadeTransition
    if L0_2 then
      L0_2 = transition
      L0_2 = L0_2.cancel
      L1_2 = L2_1
      L1_2 = L1_2.fadeTransition
      L0_2(L1_2)
      L0_2 = L2_1
      L0_2.fadeTransition = nil
    end
    L0_2 = L2_1
    L1_2 = L0_2
    L0_2 = L0_2.removeSelf
    L0_2(L1_2)
    L0_2 = nil
    L2_1 = L0_2
  end
end

function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = L2_1
  if L0_2 then
    L0_2 = L2_1
    L1_2 = transition
    L1_2 = L1_2.to
    L2_2 = L2_1
    L3_2 = {}
    L3_2.delay = 0
    L3_2.time = 200
    L3_2.alpha = 0
    L4_2 = L3_1
    L3_2.onComplete = L4_2
    L1_2 = L1_2(L2_2, L3_2)
    L0_2.fadeTransition = L1_2
  end
end

L0_1.hide = L4_1

function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2
  if not A1_2 then
    L2_2 = {}
    A1_2 = L2_2
  end
  L2_2 = A1_2.fontSize
  if not L2_2 then
    L2_2 = 16
  end
  L3_2 = A1_2.textColor
  if not L3_2 then
    L3_2 = white
  end
  L4_2 = A1_2.bgColor
  if not L4_2 then
    L4_2 = verydarkblue
  end
  L5_2 = A1_2.strokeWidth
  if not L5_2 then
    L5_2 = L2_2 / 8
  end
  L6_2 = A1_2.strokeColor
  if not L6_2 then
    L6_2 = lightgray
  end
  L7_2 = A1_2.sound
  L8_2 = A1_2.fontNum
  if not L8_2 then
    L8_2 = globals
    L8_2 = L8_2.defaultFont
  end
  L9_2 = A1_2.grow
  L10_2 = A1_2.time
  L11_2 = A1_2.offsetY
  if not L11_2 then
    L11_2 = screenHeight
    L11_2 = L11_2 / 5
  end
  L12_2 = _isGear
  if L12_2 then
    L2_2 = L2_2 * 2
  end
  L12_2 = L3_1
  L12_2()
  L12_2 = display
  L12_2 = L12_2.newGroup
  L12_2 = L12_2()
  L2_1 = L12_2
  L12_2 = L2_1
  L13_2 = display
  L13_2 = L13_2.newText
  L14_2 = L2_1
  L15_2 = A0_2
  L16_2 = 0
  L17_2 = 0
  L18_2 = _ttf_font
  L18_2 = L18_2[L8_2]
  L19_2 = L2_2
  L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
  L12_2.text = L13_2
  L12_2 = L2_1
  L12_2 = L12_2.text
  L13_2 = L12_2
  L12_2 = L12_2.setFillColor
  L14_2 = L3_2
  L12_2(L13_2, L14_2())
  L12_2 = L2_1
  L12_2 = L12_2.text
  L13_2 = L2_1
  L13_2 = L13_2.text
  L14_2 = 0
  L15_2 = _ttf_font_offset
  L15_2 = L15_2[L8_2]
  L15_2 = L15_2 * L2_2
  L13_2.y = L15_2
  L12_2.x = L14_2
  L12_2 = L2_1
  L13_2 = display
  L13_2 = L13_2.newRoundedRect
  L14_2 = L2_1
  L15_2 = 0
  L16_2 = 0
  L17_2 = L2_1
  L17_2 = L17_2.text
  L17_2 = L17_2.width
  L18_2 = L2_2 * 2
  L17_2 = L17_2 + L18_2
  L18_2 = L2_1
  L18_2 = L18_2.text
  L18_2 = L18_2.height
  L19_2 = L2_2 * 0.5
  L18_2 = L18_2 + L19_2
  L19_2 = L2_2 / 2
  L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
  L12_2.bg = L13_2
  L12_2 = L2_1
  L12_2 = L12_2.bg
  L13_2 = L12_2
  L12_2 = L12_2.setFillColor
  L14_2 = L4_2
  L12_2(L13_2, L14_2())
  L12_2 = L2_1
  L12_2 = L12_2.bg
  L12_2.strokeWidth = L5_2
  L12_2 = L2_1
  L12_2 = L12_2.bg
  L13_2 = L12_2
  L12_2 = L12_2.setStrokeColor
  L14_2 = L6_2
  L12_2(L13_2, L14_2())
  L12_2 = L2_1
  L12_2 = L12_2.bg
  L13_2 = L2_1
  L13_2 = L13_2.bg
  L14_2 = 0
  L13_2.y = 0
  L12_2.x = L14_2
  L12_2 = L2_1
  L12_2 = L12_2.bg
  L13_2 = L12_2
  L12_2 = L12_2.toBack
  L12_2(L13_2)
  L12_2 = L2_1
  L13_2 = L2_1
  L14_2 = _W2
  L15_2 = screenTop
  L15_2 = L15_2 + L11_2
  L13_2.y = L15_2
  L12_2.x = L14_2
  if L7_2 then
    L12_2 = sounds
    L12_2 = L12_2.play
    L13_2 = L7_2
    L12_2(L13_2)
  end
  if L9_2 then
    L12_2 = L2_1
    L13_2 = L2_1
    L14_2 = 0.1
    L13_2.yScale = 0.1
    L12_2.xScale = L14_2
    L12_2 = transition
    L12_2 = L12_2.to
    L13_2 = L2_1
    L14_2 = {}
    L14_2.time = 200
    L14_2.xScale = 1
    L14_2.yScale = 1
    L12_2(L13_2, L14_2)
  end
  if L10_2 then
    L12_2 = L2_1
    L13_2 = timer
    L13_2 = L13_2.performWithDelay
    L14_2 = L10_2
    L15_2 = L0_1
    L15_2 = L15_2.hide
    L16_2 = 1
    L13_2 = L13_2(L14_2, L15_2, L16_2)
    L12_2.deleteTimer = L13_2
  end
end

L0_1.show = L4_1
return L0_1
