local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1
L0_1 = {}
L1_1 = math
L1_1 = L1_1.sqrt
L2_1 = math
L2_1 = L2_1.pow
L3_1 = math
L3_1 = L3_1.ceil
L4_1 = math
L4_1 = L4_1.random
L5_1 = require
L6_1 = "json"
L5_1 = L5_1(L6_1)
L6_1 = false
if L6_1 then
  L7_1 = log
  L7_1 = L7_1.show
  L8_1 = "building_block.lua DEBUGGING"
  L7_1(L8_1)
end
L7_1 = false
if L7_1 then
  L8_1 = log
  L8_1 = L8_1.show
  L9_1 = "_FORCE_BBS_IN_CLIENT"
  L8_1(L9_1)
end
L8_1 = nil
if L8_1 then
  L9_1 = log
  L9_1 = L9_1.show
  L10_1 = "_BBS_TEST_FILE_ON_SM4 "
  L11_1 = L8_1
  L10_1 = L10_1 .. L11_1
  L9_1(L10_1)
end
L0_1.MODIFIER_NORMAL = 1
L0_1.MODIFIER_ROTATED = 2
L0_1.MODIFIER_MULTICOLOR = 3
L0_1.MODIFIER_SLOWSPIN = 4
L0_1.MODIFIER_FASTSPIN = 5
L0_1.MODIFIER_MULTICOLOR_SPIN = 6
L0_1.NUM_MODIFIERS = 6
L0_1.types = nil
L0_1.types_array = nil
L9_1 = {}
L0_1.list = L9_1
L0_1.numInPlay = 0

function L9_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L5_2 = -A3_2
  L6_2 = A1_2 - 2
  L6_2 = L6_2 / 2
  L6_2 = L6_2 + 0.5
  L5_2 = L5_2 * L6_2
  L6_2 = -A3_2
  L7_2 = A2_2 - 2
  L7_2 = L7_2 / 2
  L7_2 = L7_2 + 0.5
  L6_2 = L6_2 * L7_2
  L7_2 = L5_2
  L8_2 = L6_2
  L9_2 = 1
  L10_2 = A2_2
  L11_2 = 1
  for L12_2 = L9_2, L10_2, L11_2 do
    L13_2 = 1
    L14_2 = A1_2
    L15_2 = 1
    for L16_2 = L13_2, L14_2, L15_2 do
      L17_2 = A0_2.obstacles
      L18_2 = A0_2.obstacles
      L18_2 = #L18_2
      L18_2 = L18_2 + 1
      L19_2 = obstacle
      L19_2 = L19_2.new
      L20_2 = A0_2
      L21_2 = {}
      L21_2.x = L7_2
      L21_2.y = L8_2
      L21_2.radius = A4_2
      L19_2 = L19_2(L20_2, L21_2)
      L17_2[L18_2] = L19_2
      L7_2 = L7_2 + A3_2
    end
    L7_2 = L5_2
    L8_2 = L8_2 + A3_2
  end
end

function L10_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L5_2 = -A3_2
  L6_2 = A1_2 - 2
  L6_2 = L6_2 / 2
  L6_2 = L6_2 + 0.5
  L5_2 = L5_2 * L6_2
  L6_2 = -A3_2
  L7_2 = A2_2 - 2
  L7_2 = L7_2 / 2
  L7_2 = L7_2 + 0.5
  L6_2 = L6_2 * L7_2
  L7_2 = L5_2
  L8_2 = L6_2
  L9_2 = 1
  L10_2 = A2_2
  L11_2 = 1
  for L12_2 = L9_2, L10_2, L11_2 do
    L13_2 = 1
    L14_2 = A1_2
    L15_2 = 1
    for L16_2 = L13_2, L14_2, L15_2 do
      L17_2 = false
      L17_2 = L16_2 == 1 or L16_2 == A1_2 or L12_2 == 1 or L12_2 == A2_2
      if L17_2 then
        L18_2 = A0_2.obstacles
        L19_2 = A0_2.obstacles
        L19_2 = #L19_2
        L19_2 = L19_2 + 1
        L20_2 = obstacle
        L20_2 = L20_2.new
        L21_2 = A0_2
        L22_2 = {}
        L22_2.x = L7_2
        L22_2.y = L8_2
        L22_2.radius = A4_2
        L20_2 = L20_2(L21_2, L22_2)
        L18_2[L19_2] = L20_2
      end
      L7_2 = L7_2 + A3_2
    end
    L7_2 = L5_2
    L8_2 = L8_2 + A3_2
  end
end

function L11_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L7_2.x = 0
  L8_2 = -A1_2
  L8_2 = L8_2 * 1.1
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L8_2 = A1_2 * 1.05
  L7_2.x = L8_2
  L8_2 = -A1_2
  L8_2 = L8_2 * 0.35
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L8_2 = A1_2 * 0.65
  L7_2.x = L8_2
  L8_2 = A1_2 * 0.9
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L8_2 = -A1_2
  L8_2 = L8_2 * 0.65
  L7_2.x = L8_2
  L8_2 = A1_2 * 0.9
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L8_2 = -A1_2
  L8_2 = L8_2 * 1.05
  L7_2.x = L8_2
  L8_2 = -A1_2
  L8_2 = L8_2 * 0.35
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
end

function L12_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L7_2.x = 0
  L8_2 = -A1_2
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L7_2.x = 0
  L7_2.y = A1_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L8_2 = -A1_2
  L7_2.x = L8_2
  L7_2.y = 0
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L7_2.x = A1_2
  L7_2.y = 0
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L8_2 = -A1_2
  L9_2 = L1_1
  L10_2 = 2
  L9_2 = L9_2(L10_2)
  L8_2 = L8_2 / L9_2
  L7_2.x = L8_2
  L8_2 = -A1_2
  L9_2 = L1_1
  L10_2 = 2
  L9_2 = L9_2(L10_2)
  L8_2 = L8_2 / L9_2
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L8_2 = L1_1
  L9_2 = 2
  L8_2 = L8_2(L9_2)
  L8_2 = A1_2 / L8_2
  L7_2.x = L8_2
  L8_2 = -A1_2
  L9_2 = L1_1
  L10_2 = 2
  L9_2 = L9_2(L10_2)
  L8_2 = L8_2 / L9_2
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L8_2 = -A1_2
  L9_2 = L1_1
  L10_2 = 2
  L9_2 = L9_2(L10_2)
  L8_2 = L8_2 / L9_2
  L7_2.x = L8_2
  L8_2 = L1_1
  L9_2 = 2
  L8_2 = L8_2(L9_2)
  L8_2 = A1_2 / L8_2
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = A0_2.obstacles
  L4_2 = A0_2.obstacles
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L5_2 = obstacle
  L5_2 = L5_2.new
  L6_2 = A0_2
  L7_2 = {}
  L8_2 = L1_1
  L9_2 = 2
  L8_2 = L8_2(L9_2)
  L8_2 = A1_2 / L8_2
  L7_2.x = L8_2
  L8_2 = L1_1
  L9_2 = 2
  L8_2 = L8_2(L9_2)
  L8_2 = A1_2 / L8_2
  L7_2.y = L8_2
  L7_2.radius = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
end

function L13_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L2_2 = display
  L2_2 = L2_2.newGroup
  L2_2 = L2_2()
  L3_2 = A1_2.name
  L2_2.name = L3_2
  L3_2 = A1_2.modifier
  L2_2.modifier = L3_2
  L3_2 = L0_1
  L3_2 = L3_2.types
  L4_2 = L2_2.name
  L3_2 = L3_2[L4_2]
  L3_2 = L3_2.difficulty
  L4_2 = L2_2.modifier
  L3_2 = L3_2[L4_2]
  L2_2.difficulty = L3_2
  L3_2 = A1_2.color
  L2_2.color = L3_2
  L3_2 = {}
  L2_2.obstacles = L3_2
  L3_2 = {}
  L2_2.targets = L3_2
  L3_2 = L0_1
  L3_2 = L3_2.types
  L4_2 = L2_2.name
  L3_2 = L3_2[L4_2]
  L4_2 = L3_2.obstacles
  if L4_2 then
    L4_2 = pairs
    L5_2 = L3_2.obstacles
    L4_2, L5_2, L6_2 = L4_2(L5_2)
    for L7_2, L8_2 in L4_2, L5_2, L6_2 do
      L9_2 = L2_2.obstacles
      L10_2 = L2_2.obstacles
      L10_2 = #L10_2
      L10_2 = L10_2 + 1
      L11_2 = obstacle
      L11_2 = L11_2.new
      L12_2 = L2_2
      L13_2 = {}
      L14_2 = L8_2.x
      L13_2.x = L14_2
      L14_2 = L8_2.y
      L13_2.y = L14_2
      L14_2 = L8_2.r
      L13_2.radius = L14_2
      L11_2 = L11_2(L12_2, L13_2)
      L9_2[L10_2] = L11_2
    end
  end
  L4_2 = L3_2.star_jail
  if L4_2 then
    L4_2 = L11_1
    L5_2 = L2_2
    L6_2 = L3_2.star_jail
    L6_2 = L6_2.size
    L7_2 = L3_2.star_jail
    L7_2 = L7_2.r
    L4_2(L5_2, L6_2, L7_2)
  end
  L4_2 = L3_2.octagon_jail
  if L4_2 then
    L4_2 = L12_1
    L5_2 = L2_2
    L6_2 = L3_2.octagon_jail
    L6_2 = L6_2.size
    L7_2 = L3_2.octagon_jail
    L7_2 = L7_2.r
    L4_2(L5_2, L6_2, L7_2)
  end
  L4_2 = L3_2.grid
  if L4_2 then
    L4_2 = L9_1
    L5_2 = L2_2
    L6_2 = L3_2.grid
    L6_2 = L6_2.cols
    L7_2 = L3_2.grid
    L7_2 = L7_2.rows
    L8_2 = L3_2.grid
    L8_2 = L8_2.spacing
    L9_2 = L3_2.grid
    L9_2 = L9_2.r
    L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
  end
  L4_2 = L3_2.hollow_grid
  if L4_2 then
    L4_2 = L10_1
    L5_2 = L2_2
    L6_2 = L3_2.hollow_grid
    L6_2 = L6_2.cols
    L7_2 = L3_2.hollow_grid
    L7_2 = L7_2.rows
    L8_2 = L3_2.hollow_grid
    L8_2 = L8_2.spacing
    L9_2 = L3_2.hollow_grid
    L9_2 = L9_2.r
    L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
  end
  L4_2 = pairs
  L5_2 = L3_2.targets
  L4_2, L5_2, L6_2 = L4_2(L5_2)
  for L7_2, L8_2 in L4_2, L5_2, L6_2 do
    L9_2 = L2_2.targets
    L10_2 = L2_2.targets
    L10_2 = #L10_2
    L10_2 = L10_2 + 1
    L11_2 = target
    L11_2 = L11_2.new
    L12_2 = L2_2
    L13_2 = {}
    L14_2 = L8_2.x
    L13_2.x = L14_2
    L14_2 = L8_2.y
    L13_2.y = L14_2
    L14_2 = L8_2.r
    L13_2.radius = L14_2
    L14_2 = L2_2.color
    L13_2.color = L14_2
    L11_2 = L11_2(L12_2, L13_2)
    L9_2[L10_2] = L11_2
  end
  L4_2 = L2_2.color
  if L4_2 == nil then
    L4_2 = L2_2.targets
    L4_2 = #L4_2
    if 1 < L4_2 then
      function L4_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
        
        L1_3 = pairs
        L2_3 = L2_2
        L2_3 = L2_3.targets
        L1_3, L2_3, L3_3 = L1_3(L2_3)
        for L4_3, L5_3 in L1_3, L2_3, L3_3 do
          if L0_3 ~= nil then
            L6_3 = L5_3.color
            if L0_3 ~= L6_3 then
              L6_3 = false
              return L6_3
            end
          end
          L0_3 = L5_3.color
        end
        L1_3 = true
        return L1_3
      end
      
      while true do
        L5_2 = L4_2
        L5_2 = L5_2()
        if not L5_2 then
          break
        end
        L5_2 = pairs
        L6_2 = L2_2.targets
        L5_2, L6_2, L7_2 = L5_2(L6_2)
        for L8_2, L9_2 in L5_2, L6_2, L7_2 do
          L11_2 = L9_2
          L10_2 = L9_2.remove
          L12_2 = 0
          L10_2(L11_2, L12_2)
        end
        L5_2 = {}
        L2_2.targets = L5_2
        L5_2 = pairs
        L6_2 = L3_2.targets
        L5_2, L6_2, L7_2 = L5_2(L6_2)
        for L8_2, L9_2 in L5_2, L6_2, L7_2 do
          L10_2 = L2_2.targets
          L11_2 = L2_2.targets
          L11_2 = #L11_2
          L11_2 = L11_2 + 1
          L12_2 = target
          L12_2 = L12_2.new
          L13_2 = L2_2
          L14_2 = {}
          L15_2 = L9_2.x
          L14_2.x = L15_2
          L15_2 = L9_2.y
          L14_2.y = L15_2
          L15_2 = L9_2.r
          L14_2.radius = L15_2
          L15_2 = L2_2.color
          L14_2.color = L15_2
          L12_2 = L12_2(L13_2, L14_2)
          L10_2[L11_2] = L12_2
        end
      end
    end
  end
  L2_2.type_building_block = true
  L2_2.removed = false
  L4_2 = system
  L4_2 = L4_2.getTimer
  L4_2 = L4_2()
  L2_2.timeCreated = L4_2
  L4_2 = A1_2.startRotation
  if not L4_2 then
    L4_2 = 0
  end
  L2_2.startRotation = L4_2
  L4_2 = A1_2.rotationTime
  L2_2.rotationTime = L4_2
  L4_2 = L2_2.startRotation
  L2_2.rotation = L4_2
  L4_2 = A1_2.scalefactor
  if not L4_2 then
    L4_2 = 1
  end
  L2_2.scalefactor = L4_2
  L4_2 = L2_2.scalefactor
  L5_2 = L2_2.scalefactor
  L2_2.yScale = L5_2
  L2_2.xScale = L4_2
  L5_2 = A0_2
  L4_2 = A0_2.insert
  L6_2 = L2_2
  L4_2(L5_2, L6_2)
  L4_2 = L0_1
  L4_2 = L4_2.list
  L5_2 = L0_1
  L5_2 = L5_2.list
  L5_2 = #L5_2
  L5_2 = L5_2 + 1
  L4_2[L5_2] = L2_2
  L4_2 = L0_1
  L4_2 = L4_2.list
  L4_2 = #L4_2
  L2_2.index = L4_2
  L4_2 = L0_1
  L5_2 = L0_1
  L5_2 = L5_2.numInPlay
  L5_2 = L5_2 + 1
  L4_2.numInPlay = L5_2
  
  function L4_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = L2_2
    L2_3.scalefactor = A1_3
    L2_3 = L2_2
    L3_3 = L2_2
    L4_3 = A1_3
    L3_3.yScale = A1_3
    L2_3.xScale = L4_3
  end
  
  L2_2.changeScaleFactor = L4_2
  
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = A0_3.rotationTransition
    if L1_3 then
      L1_3 = transition
      L1_3 = L1_3.cancel
      L2_3 = A0_3.rotationTransition
      L1_3(L2_3)
      A0_3.rotationTransition = nil
    end
    L1_3 = A0_3.removed
    if L1_3 then
      return
    end
    L1_3 = L2_2
    L2_3 = L2_2
    L2_3 = L2_3.startRotation
    L1_3.rotation = L2_3
    L1_3 = A0_3.rotationTime
    L2_3 = 360
    L3_3 = A0_3.rotationTime
    if L3_3 < 0 then
      L1_3 = -L1_3
      L2_3 = -L2_3
    end
    L3_3 = transition
    L3_3 = L3_3.to
    L4_3 = A0_3
    L5_3 = {}
    L5_3.time = L1_3
    L5_3.rotation = L2_3
    
    function L6_3()
      local L0_4, L1_4
      L0_4 = A0_3
      L1_4 = L0_4
      L0_4 = L0_4.startRotation
      L0_4(L1_4)
    end
    
    L5_3.onComplete = L6_3
    L3_3 = L3_3(L4_3, L5_3)
    A0_3.rotationTransition = L3_3
  end
  
  L2_2.startRotation = L4_2
  
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = A0_3.contentWidth
    L2_3 = A0_3.contentHeight
    L3_3 = A0_3.rotationTime
    if L3_3 then
      L3_3 = A0_3.contentWidth
      L4_3 = A0_3.contentHeight
      if L3_3 > L4_3 then
        L2_3 = L1_3
      end
      L3_3 = A0_3.contentWidth
      L4_3 = A0_3.contentHeight
      if L3_3 < L4_3 then
        L1_3 = L2_3
      end
    end
    L3_3 = A0_3.x
    L4_3 = L1_3 / 2
    L3_3 = L3_3 - L4_3
    L4_3 = A0_3.x
    L5_3 = L1_3 / 2
    L4_3 = L4_3 + L5_3
    L5_3 = A0_3.y
    L6_3 = L2_3 / 2
    L5_3 = L5_3 - L6_3
    L6_3 = A0_3.y
    L7_3 = L2_3 / 2
    L6_3 = L6_3 + L7_3
    return L3_3, L4_3, L5_3, L6_3
  end
  
  L2_2.getConservativeBounds = L4_2
  
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = false
    L2_3 = 1
    L3_3 = A0_3.targets
    L3_3 = #L3_3
    L4_3 = 1
    for L5_3 = L2_3, L3_3, L4_3 do
      L6_3 = A0_3.targets
      L6_3 = L6_3[L5_3]
      L7_3 = L6_3.removed
      if not L7_3 then
        L7_3 = L6_3.whenHit
        if not L7_3 then
          L1_3 = true
          break
        end
      end
    end
    if not L1_3 then
      L3_3 = A0_3
      L2_3 = A0_3.remove
      L4_3 = 500
      L2_3(L3_3, L4_3)
      L2_3 = timer
      L2_3 = L2_3.performWithDelay
      L3_3 = 500
      
      function L4_3()
        local L0_4, L1_4
        L0_4 = sounds
        L0_4 = L0_4.play
        L1_4 = sounds
        L1_4 = L1_4.bbCleared
        L0_4(L1_4)
      end
      
      L2_3(L3_3, L4_3)
      L2_3 = _game
      L2_3 = L2_3.onBuildingBlockSuccess
      if L2_3 then
        L2_3 = _game
        L3_3 = L2_3
        L2_3 = L2_3.onBuildingBlockSuccess
        L4_3 = A0_3
        L2_3(L3_3, L4_3)
      end
      L2_3 = true
      return L2_3
    else
      L2_3 = false
      return L2_3
    end
  end
  
  L2_2.removeIfAllTargetsGone = L4_2
  
  function L4_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = 1
    L2_3 = A0_3.targets
    L2_3 = #L2_3
    L3_3 = 1
    for L4_3 = L1_3, L2_3, L3_3 do
      L5_3 = A0_3.targets
      L5_3 = L5_3[L4_3]
      L6_3 = L5_3.removed
      if not L6_3 then
        L6_3 = L5_3.whenHit
        if L6_3 then
          L7_3 = L5_3
          L6_3 = L5_3.reappear
          L6_3(L7_3)
        end
      end
    end
  end
  
  L2_2.makeTargetsReappear = L4_2
  
  function L4_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L2_3 = A0_3.removed
    if L2_3 then
      return
    end
    A0_3.removed = true
    L2_3 = A0_3.rotationTransition
    if L2_3 then
      L2_3 = transition
      L2_3 = L2_3.cancel
      L3_3 = A0_3.rotationTransition
      L2_3(L3_3)
      A0_3.rotationTransition = nil
    end
    L2_3 = L0_1
    L3_3 = L0_1
    L3_3 = L3_3.numInPlay
    L3_3 = L3_3 - 1
    L2_3.numInPlay = L3_3
    if 0 < A1_3 then
      L2_3 = 1
      L3_3 = A0_3.targets
      L3_3 = #L3_3
      L4_3 = 1
      for L5_3 = L2_3, L3_3, L4_3 do
        L6_3 = A0_3.targets
        L6_3 = L6_3[L5_3]
        L7_3 = L6_3
        L6_3 = L6_3.remove
        L8_3 = A1_3
        L6_3(L7_3, L8_3)
      end
      L2_3 = 1
      L3_3 = A0_3.obstacles
      L3_3 = #L3_3
      L4_3 = 1
      for L5_3 = L2_3, L3_3, L4_3 do
        L6_3 = A0_3.obstacles
        L6_3 = L6_3[L5_3]
        L7_3 = L6_3
        L6_3 = L6_3.remove
        L8_3 = A1_3
        L6_3(L7_3, L8_3)
      end
      L2_3 = transition
      L2_3 = L2_3.to
      L3_3 = A0_3
      L4_3 = {}
      L4_3.delay = A1_3
      L4_3.time = 200
      L4_3.alpha = 0.01
      
      function L5_3()
        local L0_4, L1_4
        L0_4 = display
        L0_4 = L0_4.remove
        L1_4 = A0_3
        L0_4(L1_4)
      end
      
      L4_3.onComplete = L5_3
      L2_3(L3_3, L4_3)
    else
      L2_3 = 1
      L3_3 = A0_3.targets
      L3_3 = #L3_3
      L4_3 = 1
      for L5_3 = L2_3, L3_3, L4_3 do
        L6_3 = A0_3.targets
        L6_3 = L6_3[L5_3]
        L7_3 = L6_3
        L6_3 = L6_3.remove
        L8_3 = 0
        L6_3(L7_3, L8_3)
      end
      L2_3 = 1
      L3_3 = A0_3.obstacles
      L3_3 = #L3_3
      L4_3 = 1
      for L5_3 = L2_3, L3_3, L4_3 do
        L6_3 = A0_3.obstacles
        L6_3 = L6_3[L5_3]
        L7_3 = L6_3
        L6_3 = L6_3.remove
        L8_3 = 0
        L6_3(L7_3, L8_3)
      end
      L2_3 = display
      L2_3 = L2_3.remove
      L3_3 = A0_3
      L2_3(L3_3)
    end
  end
  
  L2_2.remove = L4_2
  L4_2 = L6_1
  if L4_2 then
    L4_2 = false
    if L4_2 then
      L4_2 = print
      L5_2 = "bb "
      L6_2 = L2_2.name
      L5_2 = L5_2 .. L6_2
      L6_2 = L2_2.contentWidth
      L7_2 = L2_2.contentHeight
      L4_2(L5_2, L6_2, L7_2)
    end
  end
  L4_2 = L2_2.name
  if L4_2 ~= "1 in ring jail" then
    L4_2 = L2_2.name
    if L4_2 ~= "2 in ring jail" then
      L4_2 = L2_2.name
      if L4_2 ~= "3 in ring jail" then
        goto lbl_255
      end
    end
  end
  L5_2 = L2_2
  L4_2 = L2_2.changeScaleFactor
  L6_2 = 1.25
  L4_2(L5_2, L6_2)
  ::lbl_255::
  L4_2 = A1_2.delay
  if L4_2 then
    L2_2.alpha = 0
    L4_2 = transition
    L4_2 = L4_2.to
    L5_2 = L2_2
    L6_2 = {}
    L7_2 = A1_2.delay
    L6_2.delay = L7_2
    L6_2.time = 300
    L6_2.alpha = 1
    
    function L7_2()
      local L0_3, L1_3
      L0_3 = L2_2
      L0_3 = L0_3.rotationTime
      if L0_3 then
        L0_3 = L2_2
        L1_3 = L0_3
        L0_3 = L0_3.startRotation
        L0_3(L1_3)
      end
    end
    
    L6_2.onComplete = L7_2
    L4_2(L5_2, L6_2)
    L4_2 = 0
    L5_2 = platform
    L5_2 = L5_2.android
    if L5_2 then
      L4_2 = 200
    end
    L5_2 = timer
    L5_2 = L5_2.performWithDelay
    L6_2 = A1_2.delay
    L6_2 = L6_2 - L4_2
    
    function L7_2()
      local L0_3, L1_3, L2_3
      L0_3 = L2_2
      L0_3 = L0_3.removed
      if not L0_3 then
        L0_3 = sounds
        L0_3 = L0_3.play
        L1_3 = sounds
        L1_3 = L1_3.bbAppear
        L2_3 = 0.75
        L0_3(L1_3, L2_3)
      end
    end
    
    L5_2(L6_2, L7_2)
  else
    L4_2 = sounds
    L4_2 = L4_2.play
    L5_2 = sounds
    L5_2 = L5_2.bbAppear
    L6_2 = 0.75
    L4_2(L5_2, L6_2)
    L4_2 = L2_2.rotationTime
    if L4_2 then
      L5_2 = L2_2
      L4_2 = L2_2.startRotation
      L4_2(L5_2)
    end
  end
  return L2_2
end

L0_1.new = L13_1

function L13_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = L0_1
  L0_2 = L0_2.list
  L0_2 = #L0_2
  L1_2 = 1
  L2_2 = L0_2
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L0_1
    L5_2 = L5_2.list
    L5_2 = L5_2[L4_2]
    L6_2 = L5_2
    L5_2 = L5_2.remove
    L7_2 = 0
    L5_2(L6_2, L7_2)
  end
  L1_2 = L0_1
  L2_2 = {}
  L1_2.list = L2_2
  L1_2 = L0_1
  L1_2.numInPlay = 0
end

L0_1.removeAll = L13_1

function L13_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L3_2 = 0
  L4_2 = nil
  L5_2 = nil
  L6_2 = nil
  while L3_2 == 0 or 10 <= L3_2 or A0_2 > L3_2 or A1_2 < L3_2 or L6_2 and not A2_2 do
    L7_2 = L0_1
    L7_2 = L7_2.types_array
    L8_2 = L4_1
    L9_2 = L0_1
    L9_2 = L9_2.types_array
    L9_2 = #L9_2
    L8_2 = L8_2(L9_2)
    L4_2 = L7_2[L8_2]
    L7_2 = L4_1
    L8_2 = L0_1
    L8_2 = L8_2.NUM_MODIFIERS
    L7_2 = L7_2(L8_2)
    L5_2 = L7_2
    L7_2 = L4_2.difficulty
    L3_2 = L7_2[L5_2]
    L6_2 = L4_2.solo
  end
  L7_2 = L4_2.name
  L8_2 = L5_2
  L9_2 = L3_2
  return L7_2, L8_2, L9_2
end

L0_1.getRandomTypeAndModifier = L13_1

function L13_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L1_2 = {}
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2 = L2_2(L3_2)
  for L5_2, L6_2 in L2_2, L3_2, L4_2 do
    L7_2 = L6_2.name
    L1_2[L7_2] = L6_2
  end
  L2_2 = {}
  L3_2 = pairs
  L4_2 = L1_2
  L3_2, L4_2, L5_2 = L3_2(L4_2)
  for L6_2, L7_2 in L3_2, L4_2, L5_2 do
    L7_2.name = L6_2
    L8_2 = #L2_2
    L8_2 = L8_2 + 1
    L2_2[L8_2] = L7_2
    L7_2.totalDifficulty = 0
    L8_2 = 1
    L9_2 = L0_1
    L9_2 = L9_2.NUM_MODIFIERS
    L10_2 = 1
    for L11_2 = L8_2, L9_2, L10_2 do
      L12_2 = L7_2.totalDifficulty
      L13_2 = L7_2.difficulty
      L13_2 = L13_2[L11_2]
      L12_2 = L12_2 + L13_2
      L7_2.totalDifficulty = L12_2
    end
  end
  L3_2 = table
  L3_2 = L3_2.sort
  L4_2 = L2_2
  
  function L5_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = A0_3.difficulty
    L2_3 = L2_3[1]
    L3_3 = A1_3.difficulty
    L3_3 = L3_3[1]
    L2_3 = L2_3 < L3_3
    return L2_3
  end
  
  L3_2(L4_2, L5_2)
  L3_2 = L6_1
  if L3_2 then
    L3_2 = 1
    L4_2 = #L2_2
    L5_2 = 1
    for L6_2 = L3_2, L4_2, L5_2 do
      L7_2 = print
      L8_2 = L6_2
      L9_2 = L2_2[L6_2]
      L9_2 = L9_2.name
      L10_2 = L2_2[L6_2]
      L10_2 = L10_2.difficulty
      L10_2 = L10_2[1]
      L11_2 = L2_2[L6_2]
      L11_2 = L11_2.totalDifficulty
      L7_2(L8_2, L9_2, L10_2, L11_2)
    end
  end
  L3_2 = L0_1
  L3_2.types = L1_2
  L3_2 = L0_1
  L3_2.types_array = L2_2
end

function L14_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L2_2 = false
  L3_2 = A0_2.isError
  if L3_2 then
    L3_2 = L6_1
    if L3_2 then
      L3_2 = log
      L3_2 = L3_2.show
      L4_2 = "building_block.lua: Network error"
      L3_2(L4_2)
    end
  else
    L3_2 = L6_1
    if L3_2 then
      L3_2 = print
      L4_2 = "STATUS CODE: "
      L5_2 = A0_2.status
      L4_2 = L4_2 .. L5_2
      L3_2(L4_2)
      L3_2 = print
      L4_2 = "RESPONSE: "
      L5_2 = A0_2.response
      L4_2 = L4_2 .. L5_2
      L3_2(L4_2)
    end
    L3_2 = L5_1
    L3_2 = L3_2.decode
    L4_2 = A0_2.response
    L3_2 = L3_2(L4_2)
    L1_2 = L3_2
    L3_2 = L6_1
    if L3_2 then
      L3_2 = print
      L4_2 = L1_2
      L3_2(L4_2)
    end
    if L1_2 then
      L3_2 = L1_2.building_blocks
      if L3_2 then
        L2_2 = true
        L3_2 = L6_1
        if L3_2 then
          L3_2 = log
          L3_2 = L3_2.show
          L4_2 = "Read bbs.jsp from network"
          L3_2(L4_2)
        end
        L3_2 = L13_1
        L4_2 = L1_2.building_blocks
        L3_2(L4_2)
        L3_2 = saver
        L3_2 = L3_2.Save
        L4_2 = L1_2.building_blocks
        L5_2 = "bbs.txt"
        L3_2(L4_2, L5_2)
        L3_2 = L6_1
        if L3_2 then
          L3_2 = log
          L3_2 = L3_2.show
          L4_2 = "Saved network-read bbs to disk"
          L3_2(L4_2)
        end
      end
    else
      L3_2 = log
      L3_2 = L3_2.show
      L4_2 = "building_block.lua: bad bbs data from network"
      L3_2(L4_2)
    end
  end
end

function L15_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = false
  L1_2 = L7_1
  if not L1_2 then
    L1_2 = saver
    L1_2 = L1_2.Load
    L2_2 = "bbs.txt"
    L1_2 = L1_2(L2_2)
    if L1_2 then
      L2_2 = table
      L2_2 = L2_2.getSize
      L3_2 = L1_2
      L2_2 = L2_2(L3_2)
      if 0 < L2_2 then
        L2_2 = L6_1
        if L2_2 then
          L2_2 = log
          L2_2 = L2_2.show
          L3_2 = "Read bbs from disk "
          L4_2 = table
          L4_2 = L4_2.getSize
          L5_2 = L1_2
          L4_2 = L4_2(L5_2)
          L3_2 = L3_2 .. L4_2
          L2_2(L3_2)
        end
        L2_2 = L13_1
        L3_2 = L1_2
        L2_2(L3_2)
        L0_2 = true
    end
    else
      L2_2 = L6_1
      if L2_2 then
        L2_2 = log
        L2_2 = L2_2.show
        L3_2 = "No bbs from disk"
        L2_2(L3_2)
      end
    end
  end
  if not L0_2 then
    L1_2 = system
    L1_2 = L1_2.pathForFile
    L2_2 = "bbs.txt"
    L3_2 = system
    L3_2 = L3_2.ResourceDirectory
    L1_2 = L1_2(L2_2, L3_2)
    L2_2 = io
    L2_2 = L2_2.open
    L3_2 = L1_2
    L4_2 = "r"
    L2_2 = L2_2(L3_2, L4_2)
    L4_2 = L2_2
    L3_2 = L2_2.read
    L5_2 = "*a"
    L3_2 = L3_2(L4_2, L5_2)
    L4_2 = L5_1
    L4_2 = L4_2.decode
    L5_2 = L3_2
    L4_2 = L4_2(L5_2)
    L5_2 = L13_1
    L6_2 = L4_2.building_blocks
    L5_2(L6_2)
    L5_2 = io
    L5_2 = L5_2.close
    L6_2 = L2_2
    L5_2(L6_2)
    L2_2 = nil
    L5_2 = L6_1
    if L5_2 then
      L5_2 = log
      L5_2 = L5_2.show
      L6_2 = "Read bbs.txt in package "
      L7_2 = table
      L7_2 = L7_2.getSize
      L8_2 = L4_2.building_blocks
      L7_2 = L7_2(L8_2)
      L6_2 = L6_2 .. L7_2
      L5_2(L6_2)
    end
  end
  L1_2 = L7_1
  if not L1_2 then
    L1_2 = {}
    L1_2["Accept-Language"] = "en-US"
    L2_2 = {}
    L2_2.headers = L1_2
    L3_2 = "bbs"
    L4_2 = L8_1
    if L4_2 then
      L3_2 = L8_1
    end
    L4_2 = "http://bonfiremedia.com/blix/"
    L5_2 = L3_2
    L6_2 = ".jsp?"
    L7_2 = utils
    L7_2 = L7_2.getParametersForServer
    L7_2 = L7_2()
    L4_2 = L4_2 .. L5_2 .. L6_2 .. L7_2
    if L3_2 ~= "bbs" then
      L5_2 = "http://sm4.bonfiremedia.com/blix/"
      L6_2 = L3_2
      L7_2 = ".jsp?"
      L8_2 = utils
      L8_2 = L8_2.getParametersForServer
      L8_2 = L8_2()
      L4_2 = L5_2 .. L6_2 .. L7_2 .. L8_2
    end
    L5_2 = L6_1
    if L5_2 then
      L5_2 = print
      L6_2 = L4_2
      L5_2(L6_2)
    end
    L5_2 = network
    L5_2 = L5_2.request
    L6_2 = L4_2
    L7_2 = "GET"
    L8_2 = L14_1
    L9_2 = L2_2
    L5_2(L6_2, L7_2, L8_2, L9_2)
  end
end

L16_1 = L15_1
L16_1()
return L0_1
