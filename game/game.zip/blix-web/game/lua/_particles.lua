local L0_1, L1_1, L2_1
L0_1 = {}
L1_1 = require
L2_1 = "json"
L1_1 = L1_1(L2_1)

function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L3_2 = system
  L3_2 = L3_2.pathForFile
  L4_2 = "particles/"
  L5_2 = A1_2
  L6_2 = ".json"
  L4_2 = L4_2 .. L5_2 .. L6_2
  L3_2 = L3_2(L4_2)
  L4_2 = io
  L4_2 = L4_2.open
  L5_2 = L3_2
  L6_2 = "r"
  L4_2 = L4_2(L5_2, L6_2)
  L6_2 = L4_2
  L5_2 = L4_2.read
  L7_2 = "*a"
  L5_2 = L5_2(L6_2, L7_2)
  L7_2 = L4_2
  L6_2 = L4_2.close
  L6_2(L7_2)
  L6_2 = L1_1
  L6_2 = L6_2.decode
  L7_2 = L5_2
  L6_2 = L6_2(L7_2)
  L7_2 = "particles/"
  L8_2 = L6_2.textureFileName
  L7_2 = L7_2 .. L8_2
  L6_2.textureFileName = L7_2
  if A2_2 then
    L7_2 = pairs
    L8_2 = A2_2
    L7_2, L8_2, L9_2 = L7_2(L8_2)
    for L10_2, L11_2 in L7_2, L8_2, L9_2 do
      L6_2[L10_2] = L11_2
    end
    L7_2 = A2_2.startColor
    if L7_2 then
      L7_2 = A2_2.startColor
      L7_2, L8_2, L9_2 = L7_2()
      L6_2.startColorBlue = L9_2
      L6_2.startColorGreen = L8_2
      L6_2.startColorRed = L7_2
    end
    L7_2 = A2_2.finishColor
    if L7_2 then
      L7_2 = A2_2.finishColor
      L7_2, L8_2, L9_2 = L7_2()
      L6_2.finishColorBlue = L9_2
      L6_2.finishColorGreen = L8_2
      L6_2.finishColorRed = L7_2
    end
  end
  L7_2 = display
  L7_2 = L7_2.newEmitter
  L8_2 = L6_2
  L7_2 = L7_2(L8_2)
  if A0_2 then
    L9_2 = A0_2
    L8_2 = A0_2.insert
    L10_2 = L7_2
    L8_2(L9_2, L10_2)
  end
  return L7_2
end

L0_1.newEmitter = L2_1
return L0_1
