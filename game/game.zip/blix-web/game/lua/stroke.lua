local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1
L0_1 = {}
L1_1 = math
L1_1 = L1_1.sqrt
L2_1 = math
L2_1 = L2_1.pow
L3_1 = math
L3_1 = L3_1.ceil
L4_1 = false
if L4_1 then
  L5_1 = log
  L5_1 = L5_1.show
  L6_1 = "stroke.lua DEBUGGING"
  L5_1(L6_1)
end
L5_1 = 700
L6_1 = 2.25
L7_1 = 500
L8_1 = 3
L9_1 = {}
L0_1.list = L9_1
L0_1.numInPlay = 0

function L9_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L2_2 = L5_1
  L3_2 = A0_2.lengthInTime
  if L3_2 then
    L3_2 = A0_2.lengthInTime
    if L2_2 > L3_2 then
      L2_2 = A0_2.lengthInTime
    end
  end
  L3_2 = L3_1
  L4_2 = L2_2 / A1_2
  L3_2 = L3_2(L4_2)
  L2_2 = L3_2 * 1
  L3_2 = L3_1
  L4_2 = L2_2 / 5
  L3_2 = L3_2(L4_2)
  L4_2 = L3_1
  L5_2 = L2_2 / 2
  L4_2 = L4_2(L5_2)
  L5_2 = L4_2 - L3_2
  L6_2 = L2_2 - L4_2
  L7_2 = L5_2 / 2
  L8_2 = L3_2
  L9_2 = L4_2
  L10_2 = L2_2
  L11_2 = L5_2
  L12_2 = L6_2
  L13_2 = L7_2
  return L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
end

function L10_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L6_2 = display
  L6_2 = L6_2.newCircle
  L7_2 = A0_2
  L8_2 = A1_2 + A3_2
  L9_2 = A2_2 + A4_2
  L10_2 = A0_2.thickness
  L10_2 = L10_2 / 2
  L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2)
  L6_2.alpha = 1
  L8_2 = L6_2
  L7_2 = L6_2.setFillColor
  L9_2 = A0_2.color
  L7_2(L8_2, L9_2())
  L7_2 = L9_1
  L8_2 = A0_2
  L9_2 = A5_2
  L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L7_2(L8_2, L9_2)
  L13_2 = transition
  L13_2 = L13_2.to
  L14_2 = L6_2
  L15_2 = {}
  L15_2.delay = L7_2
  L15_2.time = L10_2
  L16_2 = L6_1
  L16_2 = L16_2 * 0.8
  L15_2.xScale = L16_2
  L16_2 = L6_1
  L16_2 = L16_2 * 0.8
  L15_2.yScale = L16_2
  L13_2(L14_2, L15_2)
  L13_2 = transition
  L13_2 = L13_2.to
  L14_2 = L6_2
  L15_2 = {}
  L15_2.delay = L8_2
  L15_2.time = L11_2
  L15_2.xScale = 1
  L15_2.yScale = 1
  L13_2(L14_2, L15_2)
  L13_2 = transition
  L13_2 = L13_2.to
  L14_2 = L6_2
  L15_2 = {}
  L15_2.delay = L9_2
  L16_2 = L12_2 / 4
  L15_2.time = L16_2
  L15_2.alpha = 0
  
  function L16_2()
    local L0_3, L1_3
    L0_3 = L6_2
    L0_3.removed = true
    L0_3 = L6_2
    L0_3 = L0_3.s
    L0_3 = L0_3.removed
    if not L0_3 then
      L0_3 = L6_2
      L1_3 = L0_3
      L0_3 = L0_3.removeSelf
      L0_3(L1_3)
    end
  end
  
  L15_2.onComplete = L16_2
  L13_2(L14_2, L15_2)
  L13_2 = A0_2.thickness
  L13_2 = L13_2 / 2
  L6_2.radius = L13_2
  L6_2.removed = false
  L6_2.s = A0_2
  L13_2 = system
  L13_2 = L13_2.getTimer
  L13_2 = L13_2()
  L14_2 = A0_2.timeCreated
  L13_2 = L13_2 - L14_2
  L6_2.t = L13_2
  A0_2.head = L6_2
  return L6_2
end

function L11_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2)
  local L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2
  L8_2 = display
  L8_2 = L8_2.newLine
  L9_2 = A0_2
  L10_2 = A1_2 + A5_2
  L11_2 = A2_2 + A6_2
  L12_2 = A3_2 + A5_2
  L13_2 = A4_2 + A6_2
  L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2)
  L8_2.alpha = 1
  L9_2 = A0_2.thickness
  L8_2.strokeWidth = L9_2
  L10_2 = L8_2
  L9_2 = L8_2.setStrokeColor
  L11_2 = A0_2.color
  L9_2(L10_2, L11_2())
  L9_2 = L9_1
  L10_2 = A0_2
  L11_2 = A7_2
  L9_2, L10_2, L11_2, L12_2, L13_2, L14_2 = L9_2(L10_2, L11_2)
  L15_2 = transition
  L15_2 = L15_2.to
  L16_2 = L8_2
  L17_2 = {}
  L17_2.delay = L9_2
  L17_2.time = L12_2
  L18_2 = A0_2.thickness
  L19_2 = L6_1
  L18_2 = L18_2 * L19_2
  L17_2.strokeWidth = L18_2
  L15_2(L16_2, L17_2)
  L15_2 = transition
  L15_2 = L15_2.to
  L16_2 = L8_2
  L17_2 = {}
  L17_2.delay = L10_2
  L17_2.time = L13_2
  L18_2 = A0_2.thickness
  L17_2.strokeWidth = L18_2
  L15_2(L16_2, L17_2)
  L15_2 = transition
  L15_2 = L15_2.to
  L16_2 = L8_2
  L17_2 = {}
  L17_2.delay = L11_2
  L17_2.time = L14_2
  L17_2.alpha = 0
  
  function L18_2()
    local L0_3, L1_3
    L0_3 = L8_2
    L0_3.removed = true
    L0_3 = L8_2
    L0_3 = L0_3.s
    L0_3 = L0_3.removed
    if not L0_3 then
      L0_3 = L8_2
      L1_3 = L0_3
      L0_3 = L0_3.removeSelf
      L0_3(L1_3)
    end
  end
  
  L17_2.onComplete = L18_2
  L15_2(L16_2, L17_2)
  L15_2 = A1_2 + A5_2
  L16_2 = A2_2 + A6_2
  L17_2 = A3_2 + A5_2
  L18_2 = A4_2 + A6_2
  L8_2.y2 = L18_2
  L8_2.x2 = L17_2
  L8_2.y1 = L16_2
  L8_2.x1 = L15_2
  L8_2.removed = false
  L8_2.s = A0_2
  L15_2 = system
  L15_2 = L15_2.getTimer
  L15_2 = L15_2()
  L16_2 = A0_2.timeCreated
  L15_2 = L15_2 - L16_2
  L8_2.t = L15_2
  A0_2.headLine = L8_2
  L15_2 = A0_2.visibleLines
  L16_2 = A0_2.visibleLines
  L16_2 = #L16_2
  L16_2 = L16_2 + 1
  L15_2[L16_2] = L8_2
  return L8_2
end

function L12_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = display
  L2_2 = L2_2.newGroup
  L2_2 = L2_2()
  L3_2 = A1_2.thickness
  L2_2.thickness = L3_2
  L3_2 = A1_2.color
  if not L3_2 then
    L3_2 = black
  end
  L2_2.color = L3_2
  L3_2 = {}
  L2_2.points = L3_2
  L2_2.numPoints = 0
  L2_2.removed = false
  L3_2 = system
  L3_2 = L3_2.getTimer
  L3_2 = L3_2()
  L2_2.timeCreated = L3_2
  L2_2.pointCursor = 1
  L2_2.timeCursor = 0
  L2_2.timeOfLastProcessing = 0
  L3_2 = 0
  L2_2.offsetY = 0
  L2_2.offsetX = L3_2
  L4_2 = A0_2
  L3_2 = A0_2.insert
  L5_2 = L2_2
  L3_2(L4_2, L5_2)
  L3_2 = L0_1
  L3_2 = L3_2.list
  L4_2 = L0_1
  L4_2 = L4_2.list
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L3_2[L4_2] = L2_2
  L3_2 = L0_1
  L3_2 = L3_2.list
  L3_2 = #L3_2
  L2_2.index = L3_2
  L3_2 = {}
  L2_2.visibleLines = L3_2
  L2_2.head = nil
  L2_2.replayFrameCounter = 0
  L3_2 = {}
  L2_2.targetsHit = L3_2
  L3_2 = nil
  L4_2 = nil
  L5_2 = nil
  L2_2.maxY = nil
  L2_2.minY = L5_2
  L2_2.maxX = L4_2
  L2_2.minX = L3_2
  L3_2 = _game
  L3_2 = L3_2.replaySpeedMultiplier
  if not L3_2 then
    L3_2 = 1
  end
  L2_2.replay_speed_multiplier = L3_2
  
  function L3_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L3_3 = A0_3.points
    L4_3 = A0_3.numPoints
    L3_3 = L3_3[L4_3]
    L4_3 = nil
    if L3_3 then
      L5_3 = utils
      L5_3 = L5_3.distance
      L6_3 = L3_3.x
      L7_3 = L3_3.y
      L8_3 = A1_3
      L9_3 = A2_3
      L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
      L4_3 = L5_3
    end
    if L4_3 then
      L5_3 = L8_1
      if L4_3 < L5_3 then
        return
      end
    end
    L5_3 = L4_1
    if L5_3 then
      L5_3 = print
      L6_3 = "acceptable distance = "
      L7_3 = L4_3 or L7_3
      if not L4_3 then
        L7_3 = "nil"
      end
      L6_3 = L6_3 .. L7_3
      L5_3(L6_3)
    end
    L5_3 = A0_3.numPoints
    L5_3 = L5_3 + 1
    A0_3.numPoints = L5_3
    L5_3 = {}
    L6_3 = A0_3.numPoints
    L7_3 = A1_3
    L8_3 = A2_3
    L9_3 = system
    L9_3 = L9_3.getTimer
    L9_3 = L9_3()
    L10_3 = A0_3.timeCreated
    L9_3 = L9_3 - L10_3
    L5_3.t = L9_3
    L5_3.y = L8_3
    L5_3.x = L7_3
    L5_3.index = L6_3
    L6_3 = A0_3.points
    L7_3 = A0_3.numPoints
    L6_3[L7_3] = L5_3
    L6_3 = L4_1
    if L6_3 then
      L6_3 = print
      L7_3 = A0_3.numPoints
      L8_3 = L5_3.x
      L9_3 = L5_3.y
      L10_3 = L5_3.t
      L6_3(L7_3, L8_3, L9_3, L10_3)
    end
    L6_3 = L10_1
    L7_3 = A0_3
    L8_3 = A1_3
    L9_3 = A2_3
    L10_3 = 0
    L11_3 = 0
    L12_3 = 1
    L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3)
    if L3_3 then
      L6_3 = L11_1
      L7_3 = A0_3
      L8_3 = L3_3.x
      L9_3 = L3_3.y
      L10_3 = A1_3
      L11_3 = A2_3
      L12_3 = 0
      L13_3 = 0
      L14_3 = 1
      L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
    end
    L7_3 = A0_3
    L6_3 = A0_3.tidyVisibleLinesListAndCalculateBounds
    L6_3(L7_3)
  end
  
  L2_2.addPoint = L3_2
  
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = L2_2
    L2_3 = system
    L2_3 = L2_3.getTimer
    L2_3 = L2_3()
    L3_3 = L2_2
    L3_3 = L3_3.timeCreated
    L2_3 = L2_3 - L3_3
    L1_3.lengthInTime = L2_3
    L1_3 = A0_3.numPoints
    if L1_3 < 2 then
      L1_3 = L2_2
      L2_3 = L1_3
      L1_3 = L1_3.remove
      L3_3 = 0
      L1_3(L2_3, L3_3)
      return
    end
    L1_3 = L2_2
    L1_3 = L1_3.visibleLines
    L2_3 = L2_2
    L2_3 = L2_3.visibleLines
    L2_3 = #L2_3
    L1_3 = L1_3[L2_3]
    if L1_3 then
      L2_3 = L1_3.t
      L3_3 = L5_1
      L2_3 = L2_3 + L3_3
      L3_3 = L2_2
      L3_3 = L3_3.lengthInTime
      L3_3 = L2_3 - L3_3
      L4_3 = L2_2
      L4_3.firstReplayDelay = L3_3
    else
      L2_3 = L2_2
      L2_3.firstReplayDelay = 0
    end
    L2_3 = L0_1
    L3_3 = L0_1
    L3_3 = L3_3.numInPlay
    L3_3 = L3_3 + 1
    L2_3.numInPlay = L3_3
  end
  
  L2_2.endStroke = L3_2
  
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
    L1_3 = A0_3.removed
    if L1_3 then
      L1_3 = _SIMULATOR
      if L1_3 then
        L1_3 = print
        L2_3 = "ERROR: tried to call processReplay but stroke was removed"
        L1_3(L2_3)
      end
      L1_3 = A0_3.replayTimer
      if L1_3 then
        L1_3 = timer
        L1_3 = L1_3.cancel
        L2_3 = A0_3.replayTimer
        L1_3(L2_3)
        A0_3.replayTimer = nil
      end
      return
    end
    L1_3 = L2_2
    L1_3 = L1_3.replayFrameCounter
    L1_3 = L1_3 + 1
    A0_3.replayFrameCounter = L1_3
    L1_3 = system
    L1_3 = L1_3.getTimer
    L1_3 = L1_3()
    L2_3 = A0_3.timeOfLastProcessing
    L2_3 = L1_3 - L2_3
    L3_3 = A0_3.replay_speed_multiplier
    L2_3 = L2_3 * L3_3
    L3_3 = A0_3.pointCursor
    L4_3 = A0_3.numPoints
    if L3_3 == L4_3 then
      L3_3 = A0_3.lengthInTime
      L4_3 = A0_3.timeCursor
      L4_3 = L4_3 + L2_3
      L3_3 = L3_3 - L4_3
      if L3_3 <= 0 then
        A0_3.pointCursor = 1
        A0_3.timeCursor = 0
        L4_3 = A0_3.points
        L4_3 = L4_3[1]
        L5_3 = A0_3.points
        L6_3 = A0_3.numPoints
        L5_3 = L5_3[L6_3]
        L6_3 = A0_3.offsetX
        L7_3 = L5_3.x
        L6_3 = L6_3 + L7_3
        L7_3 = L4_3.x
        L6_3 = L6_3 - L7_3
        A0_3.offsetX = L6_3
        L6_3 = A0_3.offsetY
        L7_3 = L5_3.y
        L6_3 = L6_3 + L7_3
        L7_3 = L4_3.y
        L6_3 = L6_3 - L7_3
        A0_3.offsetY = L6_3
      else
        L4_3 = L7_1
        if L3_3 > L4_3 then
          L4_3 = L7_1
          L4_3 = L3_3 - L4_3
          L2_3 = L2_3 + L4_3
        end
        L4_3 = A0_3.timeCursor
        L4_3 = L4_3 + L2_3
        A0_3.timeCursor = L4_3
        A0_3.timeOfLastProcessing = L1_3
        return
      end
    end
    L3_3 = A0_3.points
    L4_3 = A0_3.pointCursor
    L4_3 = L4_3 + 1
    L3_3 = L3_3[L4_3]
    L4_3 = L3_3.t
    L5_3 = A0_3.timeCursor
    L5_3 = L5_3 + L2_3
    L4_3 = L4_3 - L5_3
    L5_3 = false
    while L4_3 <= 0 do
      L5_3 = true
      L6_3 = A0_3.points
      L7_3 = A0_3.pointCursor
      L6_3 = L6_3[L7_3]
      L7_3 = L10_1
      L8_3 = A0_3
      L9_3 = L3_3.x
      L10_3 = L3_3.y
      L11_3 = A0_3.offsetX
      L12_3 = A0_3.offsetY
      L13_3 = A0_3.replay_speed_multiplier
      L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L7_3 = L11_1
      L8_3 = A0_3
      L9_3 = L6_3.x
      L10_3 = L6_3.y
      L11_3 = L3_3.x
      L12_3 = L3_3.y
      L13_3 = A0_3.offsetX
      L14_3 = A0_3.offsetY
      L15_3 = A0_3.replay_speed_multiplier
      L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
      L7_3 = A0_3.pointCursor
      L7_3 = L7_3 + 1
      A0_3.pointCursor = L7_3
      L7_3 = A0_3.pointCursor
      L8_3 = A0_3.numPoints
      if L7_3 == L8_3 then
        break
      end
      L7_3 = A0_3.points
      L8_3 = A0_3.pointCursor
      L8_3 = L8_3 + 1
      L3_3 = L7_3[L8_3]
      L7_3 = L3_3.t
      L8_3 = A0_3.timeCursor
      L8_3 = L8_3 + L2_3
      L4_3 = L7_3 - L8_3
    end
    if L5_3 then
      L6_3 = A0_3.removed
      if not L6_3 then
        L7_3 = A0_3
        L6_3 = A0_3.tidyVisibleLinesListAndCalculateBounds
        L6_3(L7_3)
      end
    end
    L6_3 = L7_1
    if L4_3 > L6_3 then
      L6_3 = L7_1
      L6_3 = L4_3 - L6_3
      L2_3 = L2_3 + L6_3
    end
    L6_3 = A0_3.timeCursor
    L6_3 = L6_3 + L2_3
    A0_3.timeCursor = L6_3
    A0_3.timeOfLastProcessing = L1_3
    L6_3 = _game
    L6_3 = L6_3.onStrokeProcessReplay
    if L6_3 then
      L6_3 = _game
      L7_3 = L6_3
      L6_3 = L6_3.onStrokeProcessReplay
      L8_3 = A0_3
      L6_3(L7_3, L8_3)
    end
  end
  
  L2_2.processReplay = L3_2
  
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = A0_3.removed
    if L1_3 then
      return
    end
    L1_3 = A0_3.lengthInTime
    A0_3.timeCursor = L1_3
    L1_3 = system
    L1_3 = L1_3.getTimer
    L1_3 = L1_3()
    A0_3.timeOfLastProcessing = L1_3
    L1_3 = A0_3.numPoints
    A0_3.pointCursor = L1_3
    L2_3 = A0_3
    L1_3 = A0_3.processReplay
    L1_3(L2_3)
    L1_3 = timer
    L1_3 = L1_3.performWithDelay
    L2_3 = math
    L2_3 = L2_3.ceil
    L3_3 = _FPS
    L3_3 = 1000 / L3_3
    L2_3 = L2_3(L3_3)
    
    function L3_3()
      local L0_4, L1_4
      L0_4 = A0_3
      L1_4 = L0_4
      L0_4 = L0_4.processReplay
      L0_4(L1_4)
    end
    
    L4_3 = -1
    L1_3 = L1_3(L2_3, L3_3, L4_3)
    A0_3.replayTimer = L1_3
  end
  
  L2_2.startReplay = L3_2
  
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3
    L2_3 = _game
    L2_3 = L2_3.onStrokeLost
    if L2_3 then
      L2_3 = _game
      L3_3 = L2_3
      L2_3 = L2_3.onStrokeLost
      L4_3 = A0_3
      L2_3(L3_3, L4_3)
    end
    L3_3 = A0_3
    L2_3 = A0_3.remove
    L4_3 = A1_3
    L2_3(L3_3, L4_3)
  end
  
  L2_2.lost = L3_2
  
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = A0_3.removed
    if L2_3 then
      return
    end
    A0_3.removed = true
    L2_3 = A0_3.replayTimer
    if L2_3 then
      L2_3 = timer
      L2_3 = L2_3.cancel
      L3_3 = A0_3.replayTimer
      L2_3(L3_3)
      A0_3.replayTimer = nil
    end
    A0_3.points = nil
    A0_3.targetsHit = nil
    if 0 < A1_3 then
      L2_3 = transition
      L2_3 = L2_3.to
      L3_3 = A0_3
      L4_3 = {}
      L4_3.delay = A1_3
      L4_3.time = 200
      L4_3.alpha = 0
      
      function L5_3()
        local L0_4, L1_4
        L0_4 = display
        L0_4 = L0_4.remove
        L1_4 = A0_3
        L0_4(L1_4)
      end
      
      L4_3.onComplete = L5_3
      L2_3(L3_3, L4_3)
    else
      L2_3 = display
      L2_3 = L2_3.remove
      L3_3 = A0_3
      L2_3(L3_3)
    end
  end
  
  L2_2.remove = L3_2
  
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = A0_3.removed
    if L1_3 then
      return
    end
    L1_3 = L4_1
    if L1_3 then
      L1_3 = print
      L2_3 = "stroke:tidyVisibleLinesList() BEFORE "
      L3_3 = A0_3.index
      L2_3 = L2_3 .. L3_3
      L3_3 = A0_3.visibleLines
      L3_3 = #L3_3
      L1_3(L2_3, L3_3)
    end
    L1_3 = L2_2
    L1_3 = L1_3.visibleLines
    L1_3 = #L1_3
    L2_3 = {}
    L3_3 = nil
    L4_3 = nil
    L5_3 = nil
    A0_3.maxY = nil
    A0_3.minY = L5_3
    A0_3.maxX = L4_3
    A0_3.minX = L3_3
    L3_3 = 1
    L4_3 = L1_3
    L5_3 = 1
    for L6_3 = L3_3, L4_3, L5_3 do
      L7_3 = A0_3.visibleLines
      L7_3 = L7_3[L6_3]
      L8_3 = L7_3.removed
      if not L8_3 then
        L8_3 = #L2_3
        L8_3 = L8_3 + 1
        L2_3[L8_3] = L7_3
        L8_3 = A0_3.minX
        if L8_3 ~= nil then
          L8_3 = L7_3.x1
          L9_3 = A0_3.minX
          if not (L8_3 < L9_3) then
            goto lbl_45
          end
        end
        L8_3 = L7_3.x1
        A0_3.minX = L8_3
        ::lbl_45::
        L8_3 = A0_3.maxX
        if L8_3 ~= nil then
          L8_3 = L7_3.x1
          L9_3 = A0_3.maxX
          if not (L8_3 > L9_3) then
            goto lbl_54
          end
        end
        L8_3 = L7_3.x1
        A0_3.maxX = L8_3
        ::lbl_54::
        L8_3 = A0_3.minY
        if L8_3 ~= nil then
          L8_3 = L7_3.y1
          L9_3 = A0_3.minY
          if not (L8_3 < L9_3) then
            goto lbl_63
          end
        end
        L8_3 = L7_3.y1
        A0_3.minY = L8_3
        ::lbl_63::
        L8_3 = A0_3.maxY
        if L8_3 ~= nil then
          L8_3 = L7_3.y1
          L9_3 = A0_3.maxY
          if not (L8_3 > L9_3) then
            goto lbl_72
          end
        end
        L8_3 = L7_3.y1
        A0_3.maxY = L8_3
        ::lbl_72::
        L8_3 = L7_3.x2
        L9_3 = A0_3.minX
        if L8_3 < L9_3 then
          L8_3 = L7_3.x2
          A0_3.minX = L8_3
        end
        L8_3 = L7_3.x2
        L9_3 = A0_3.maxX
        if L8_3 > L9_3 then
          L8_3 = L7_3.x2
          A0_3.maxX = L8_3
        end
        L8_3 = L7_3.y2
        L9_3 = A0_3.minY
        if L8_3 < L9_3 then
          L8_3 = L7_3.y2
          A0_3.minY = L8_3
        end
        L8_3 = L7_3.y2
        L9_3 = A0_3.maxY
        if L8_3 > L9_3 then
          L8_3 = L7_3.y2
          A0_3.maxY = L8_3
        end
      end
    end
    A0_3.visibleLines = L2_3
    L3_3 = A0_3.replayFrameCounter
    if 0 < L3_3 then
      L3_3 = A0_3.minX
      L4_3 = _canvasRight
      if not (L3_3 > L4_3) then
        L3_3 = A0_3.maxX
        L4_3 = _canvasLeft
        if not (L3_3 < L4_3) then
          L3_3 = A0_3.minY
          L4_3 = _canvasBottom
          if not (L3_3 > L4_3) then
            L3_3 = A0_3.maxY
            L4_3 = _canvasTop
            if not (L3_3 < L4_3) then
              goto lbl_133
            end
          end
        end
      end
      L3_3 = _game
      L3_3 = L3_3.onStrokeExitedScreen
      if L3_3 then
        L3_3 = _game
        L4_3 = L3_3
        L3_3 = L3_3.onStrokeExitedScreen
        L5_3 = A0_3
        L3_3(L4_3, L5_3)
      end
      L4_3 = A0_3
      L3_3 = A0_3.lost
      L5_3 = 0
      L3_3(L4_3, L5_3)
      L3_3 = L0_1
      L4_3 = L0_1
      L4_3 = L4_3.numInPlay
      L4_3 = L4_3 - 1
      L3_3.numInPlay = L4_3
    end
    ::lbl_133::
    L3_3 = L4_1
    if L3_3 then
      L3_3 = print
      L4_3 = "stroke:tidyVisibleLinesList() AFTER "
      L5_3 = L2_2
      L5_3 = L5_3.index
      L4_3 = L4_3 .. L5_3
      L5_3 = L2_2
      L5_3 = L5_3.visibleLines
      L5_3 = #L5_3
      L3_3(L4_3, L5_3)
    end
  end
  
  L2_2.tidyVisibleLinesListAndCalculateBounds = L3_2
  
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3
    L2_3 = A0_3.removed
    if not L2_3 then
      L2_3 = A1_3.removed
      if not L2_3 then
        goto lbl_9
      end
    end
    L2_3 = nil
    do return L2_3 end
    ::lbl_9::
    L2_3 = utils
    L2_3 = L2_3.intersectRect
    L3_3 = A0_3.minX
    L4_3 = A0_3.maxX
    L5_3 = A0_3.minY
    L6_3 = A0_3.maxY
    L7_3 = A1_3.minX
    L8_3 = A1_3.maxX
    L9_3 = A1_3.minY
    L10_3 = A1_3.maxY
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
    L3_3 = L4_1
    if L3_3 then
      L3_3 = print
      L4_3 = A0_3.index
      L5_3 = A0_3.minX
      L6_3 = A0_3.maxX
      L7_3 = A0_3.minY
      L8_3 = A0_3.maxY
      L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
      L3_3 = print
      L4_3 = A1_3.index
      L5_3 = A1_3.minX
      L6_3 = A1_3.maxX
      L7_3 = A1_3.minY
      L8_3 = A1_3.maxY
      L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
      L3_3 = print
      L4_3 = "intersectRect() "
      L5_3 = A0_3.index
      L6_3 = "vs"
      L7_3 = A1_3.index
      L8_3 = " "
      L9_3 = tostring
      L10_3 = L2_3
      L9_3 = L9_3(L10_3)
      L4_3 = L4_3 .. L5_3 .. L6_3 .. L7_3 .. L8_3 .. L9_3
      L3_3(L4_3)
    end
    if not L2_3 then
      L3_3 = nil
      return L3_3
    end
    L3_3 = A0_3.visibleLines
    L3_3 = #L3_3
    L4_3 = A1_3.visibleLines
    L4_3 = #L4_3
    L5_3 = 1
    L6_3 = L3_3
    L7_3 = 1
    for L8_3 = L5_3, L6_3, L7_3 do
      L9_3 = A0_3.visibleLines
      L9_3 = L9_3[L8_3]
      L10_3 = L9_3.removed
      if not L10_3 then
        L10_3 = 1
        L11_3 = L4_3
        L12_3 = 1
        for L13_3 = L10_3, L11_3, L12_3 do
          L14_3 = A1_3.visibleLines
          L14_3 = L14_3[L13_3]
          L15_3 = L14_3.removed
          if not L15_3 then
            L15_3 = utils
            L15_3 = L15_3.intersection
            L16_3 = {}
            L17_3 = L9_3.x1
            L16_3.x = L17_3
            L17_3 = L9_3.y1
            L16_3.y = L17_3
            L17_3 = {}
            L18_3 = L9_3.x2
            L17_3.x = L18_3
            L18_3 = L9_3.y2
            L17_3.y = L18_3
            L18_3 = {}
            L19_3 = L14_3.x1
            L18_3.x = L19_3
            L19_3 = L14_3.y1
            L18_3.y = L19_3
            L19_3 = {}
            L20_3 = L14_3.x2
            L19_3.x = L20_3
            L20_3 = L14_3.y2
            L19_3.y = L20_3
            L15_3 = L15_3(L16_3, L17_3, L18_3, L19_3)
            if L15_3 then
              return L15_3
            end
          end
        end
      end
    end
    L5_3 = nil
    return L5_3
  end
  
  L2_2.intersectionWithStroke = L3_2
  return L2_2
end

L0_1.new = L12_1

function L12_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L0_2 = L0_1
  L0_2 = L0_2.list
  L0_2 = #L0_2
  L1_2 = 1
  L2_2 = L0_2
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L0_1
    L5_2 = L5_2.list
    L5_2 = L5_2[L4_2]
    L6_2 = L5_2.removed
    if not L6_2 then
      L6_2 = L4_2 + 1
      L7_2 = L0_2
      L8_2 = 1
      for L9_2 = L6_2, L7_2, L8_2 do
        L10_2 = L0_1
        L10_2 = L10_2.list
        L10_2 = L10_2[L9_2]
        L11_2 = L10_2.removed
        if not L11_2 then
          L11_2 = L5_2.removed
          if not L11_2 then
            L12_2 = L5_2
            L11_2 = L5_2.intersectionWithStroke
            L13_2 = L10_2
            L11_2 = L11_2(L12_2, L13_2)
            if L11_2 then
              L12_2 = L4_1
              if L12_2 then
                L12_2 = print
                L13_2 = "Collision between stroke "
                L14_2 = L5_2.index
                L15_2 = " and stroke "
                L16_2 = L10_2.index
                L13_2 = L13_2 .. L14_2 .. L15_2 .. L16_2
                L12_2(L13_2)
              end
              L12_2 = _game
              L12_2 = L12_2.onStrokesCollide
              if L12_2 then
                L12_2 = _game
                L13_2 = L12_2
                L12_2 = L12_2.onStrokesCollide
                L14_2 = L5_2
                L15_2 = L10_2
                L12_2(L13_2, L14_2, L15_2)
              end
            end
          end
        end
      end
    end
  end
end

L0_1.findIntersectingStrokes = L12_1

function L12_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2
  L0_2 = L0_1
  L0_2 = L0_2.list
  L0_2 = #L0_2
  L1_2 = target
  L1_2 = L1_2.list
  L1_2 = #L1_2
  L2_2 = 1
  L3_2 = L0_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = L0_1
    L6_2 = L6_2.list
    L6_2 = L6_2[L5_2]
    L7_2 = L6_2.removed
    if not L7_2 then
      L7_2 = L6_2.visibleLines
      L7_2 = #L7_2
      L8_2 = 1
      L9_2 = L1_2
      L10_2 = 1
      for L11_2 = L8_2, L9_2, L10_2 do
        L12_2 = target
        L12_2 = L12_2.list
        L12_2 = L12_2[L11_2]
        L13_2 = L12_2.removed
        if not L13_2 then
          L13_2 = L6_2.removed
          if not L13_2 then
            L13_2 = L12_2.whenHit
            if not L13_2 then
              L13_2 = L12_2.parent
              L13_2 = L13_2.type_building_block
              if L13_2 then
                L13_2 = L12_2.parent
                L14_2 = L13_2
                L13_2 = L13_2.toFront
                L13_2(L14_2)
              else
                L14_2 = L12_2
                L13_2 = L12_2.toFront
                L13_2(L14_2)
              end
              L13_2 = L12_2.parent
              L14_2 = L13_2
              L13_2 = L13_2.localToContent
              L15_2 = L12_2.x
              L16_2 = L12_2.y
              L13_2, L14_2 = L13_2(L14_2, L15_2, L16_2)
              L15_2 = L12_2.parent
              L15_2 = L15_2.scalefactor
              if not L15_2 then
                L15_2 = 1
              end
              L16_2 = false
              L17_2 = 1
              L18_2 = L7_2
              L19_2 = 1
              for L20_2 = L17_2, L18_2, L19_2 do
                L21_2 = L6_2.visibleLines
                L21_2 = L21_2[L20_2]
                L22_2 = utils
                L22_2 = L22_2.lineIntersectsCircle2
                L23_2 = L21_2.x1
                L24_2 = L21_2.y1
                L25_2 = L21_2.x2
                L26_2 = L21_2.y2
                L27_2 = L13_2
                L28_2 = L14_2
                L29_2 = L12_2.radius
                L29_2 = L29_2 * L15_2
                L22_2 = L22_2(L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2)
                L16_2 = L22_2
                if L16_2 then
                  break
                end
              end
              if L16_2 then
                L17_2 = L6_2.lengthInTime
                if not L17_2 then
                  L18_2 = L6_2
                  L17_2 = L6_2.remove
                  L19_2 = 0
                  L17_2(L18_2, L19_2)
                  return
                end
                L17_2 = L6_2.color
                L18_2 = L12_2.color
                if L17_2 == L18_2 then
                  L17_2 = L6_2.targetsHit
                  L18_2 = L6_2.targetsHit
                  L18_2 = #L18_2
                  L18_2 = L18_2 + 1
                  L17_2[L18_2] = L12_2
                  L17_2 = L6_2.targetsHit
                  L17_2 = #L17_2
                  if 9 < L17_2 then
                    L17_2 = 9
                  end
                  L18_2 = sounds
                  L18_2 = L18_2.play
                  L19_2 = sounds
                  L19_2 = L19_2.hits
                  L19_2 = L19_2[L17_2]
                  L20_2 = 1
                  L18_2(L19_2, L20_2)
                  L19_2 = L12_2
                  L18_2 = L12_2.hit
                  L18_2(L19_2)
                  L18_2 = L12_2.parent
                  L18_2 = L18_2.type_building_block
                  if L18_2 then
                    L18_2 = L12_2.parent
                    L19_2 = L18_2
                    L18_2 = L18_2.removeIfAllTargetsGone
                    L18_2(L19_2)
                  end
                  L18_2 = _game
                  L18_2 = L18_2.onCorrectTargetHit
                  if L18_2 then
                    L18_2 = _game
                    L19_2 = L18_2
                    L18_2 = L18_2.onCorrectTargetHit
                    L20_2 = L6_2
                    L21_2 = L12_2
                    L18_2(L19_2, L20_2, L21_2)
                  end
                else
                  L17_2 = _game
                  L17_2 = L17_2.onWrongTargetHit
                  if L17_2 then
                    L17_2 = _game
                    L18_2 = L17_2
                    L17_2 = L17_2.onWrongTargetHit
                    L19_2 = L6_2
                    L20_2 = L12_2
                    L17_2(L18_2, L19_2, L20_2)
                  end
                end
              end
            end
          end
        end
      end
    end
  end
end

L0_1.findIntersectingTargets = L12_1

function L12_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2
  L0_2 = L0_1
  L0_2 = L0_2.list
  L0_2 = #L0_2
  L1_2 = obstacle
  L1_2 = L1_2.list
  L1_2 = #L1_2
  L2_2 = 1
  L3_2 = L0_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = L0_1
    L6_2 = L6_2.list
    L6_2 = L6_2[L5_2]
    L7_2 = L6_2.removed
    if not L7_2 then
      L7_2 = L6_2.visibleLines
      L7_2 = #L7_2
      L8_2 = 1
      L9_2 = L1_2
      L10_2 = 1
      for L11_2 = L8_2, L9_2, L10_2 do
        L12_2 = obstacle
        L12_2 = L12_2.list
        L12_2 = L12_2[L11_2]
        L13_2 = L12_2.removed
        if not L13_2 then
          L13_2 = L6_2.removed
          if not L13_2 then
            L13_2 = L12_2.parent
            L13_2 = L13_2.type_building_block
            if L13_2 then
              L13_2 = L12_2.parent
              L14_2 = L13_2
              L13_2 = L13_2.toFront
              L13_2(L14_2)
            else
              L14_2 = L12_2
              L13_2 = L12_2.toFront
              L13_2(L14_2)
            end
            L13_2 = L12_2.parent
            L14_2 = L13_2
            L13_2 = L13_2.localToContent
            L15_2 = L12_2.x
            L16_2 = L12_2.y
            L13_2, L14_2 = L13_2(L14_2, L15_2, L16_2)
            L15_2 = L12_2.parent
            L15_2 = L15_2.scalefactor
            if not L15_2 then
              L15_2 = 1
            end
            L16_2 = false
            L17_2 = 1
            L18_2 = L7_2
            L19_2 = 1
            for L20_2 = L17_2, L18_2, L19_2 do
              L21_2 = L6_2.visibleLines
              L21_2 = L21_2[L20_2]
              L22_2 = utils
              L22_2 = L22_2.lineIntersectsCircle2
              L23_2 = L21_2.x1
              L24_2 = L21_2.y1
              L25_2 = L21_2.x2
              L26_2 = L21_2.y2
              L27_2 = L13_2
              L28_2 = L14_2
              L29_2 = L12_2.radius
              L29_2 = L29_2 * L15_2
              L22_2 = L22_2(L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2)
              L16_2 = L22_2
              if L16_2 then
                break
              end
            end
            if L16_2 then
              L17_2 = L6_2.lengthInTime
              if not L17_2 then
                L18_2 = L6_2
                L17_2 = L6_2.remove
                L19_2 = 0
                L17_2(L18_2, L19_2)
                return
              end
              L17_2 = _game
              L17_2 = L17_2.onObstacleHit
              if L17_2 then
                L17_2 = _game
                L18_2 = L17_2
                L17_2 = L17_2.onObstacleHit
                L19_2 = L6_2
                L20_2 = L12_2
                L17_2(L18_2, L19_2, L20_2)
              end
            end
          end
        end
      end
    end
  end
end

L0_1.findIntersectingObstacles = L12_1

function L12_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = L0_1
  L1_2 = L1_2.list
  L1_2 = #L1_2
  L2_2 = 1
  L3_2 = L1_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = L0_1
    L6_2 = L6_2.list
    L6_2 = L6_2[L5_2]
    L7_2 = L6_2.removed
    if not L7_2 then
      L7_2 = L6_2.lengthInTime
      if L7_2 then
        L7_2 = L6_2.color
        if L7_2 == A0_2 then
          L8_2 = L6_2
          L7_2 = L6_2.lost
          L9_2 = 1
          L7_2(L8_2, L9_2)
        end
      end
    end
  end
end

L0_1.killAllStrokesOfColor = L12_1

function L12_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = L0_1
  L0_2 = L0_2.list
  L0_2 = #L0_2
  L1_2 = 1
  L2_2 = L0_2
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L0_1
    L5_2 = L5_2.list
    L5_2 = L5_2[L4_2]
    L6_2 = L5_2
    L5_2 = L5_2.remove
    L7_2 = 0
    L5_2(L6_2, L7_2)
  end
  L1_2 = L0_1
  L2_2 = {}
  L1_2.list = L2_2
  L1_2 = L0_1
  L1_2.numInPlay = 0
end

L0_1.removeAll = L12_1
return L0_1
