local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_frame_rate.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = _FPS
L2_1 = L2_1 / 3
L3_1 = nil
L4_1 = 0
L5_1 = 0
L6_1 = 99
L7_1 = -1
L8_1 = {}
L9_1 = {}
L10_1 = nil
L11_1 = nil
L12_1 = nil
L13_1 = nil
L14_1 = nil
L15_1 = nil
L16_1 = 0
L17_1 = math
L17_1 = L17_1.round
round = L17_1
L17_1 = saver
L17_1 = L17_1.Load
L18_1 = "fr.txt"
L17_1 = L17_1(L18_1)
if not L17_1 then
  L17_1 = {}
end
L0_1.savedData = L17_1
L17_1 = L0_1.savedData
L17_1 = L17_1.frameRate
if L17_1 == nil then
  L17_1 = L0_1.savedData
  L17_1.frameRate = -1
end
L17_1 = L0_1.savedData
L17_1 = L17_1.whenLastMeasured
if L17_1 == nil then
  L17_1 = L0_1.savedData
  L17_1.whenLastMeasured = 0
end

function L17_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = system
  L0_2 = L0_2.getTimer
  L0_2 = L0_2()
  L1_2 = L5_1
  L1_2 = L0_2 - L1_2
  L5_1 = L0_2
  L2_2 = L8_1
  L3_2 = L4_1
  L4_2 = L2_1
  L3_2 = L3_2 % L4_2
  L3_2 = L3_2 + 1
  L2_2[L3_2] = L1_2
  L2_2 = L4_1
  L2_2 = L2_2 + 1
  L4_1 = L2_2
end

function L18_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = 0
  L1_2 = L9_1
  L1_2 = #L1_2
  L2_2 = 1
  L3_2 = L1_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = L9_1
    L6_2 = L6_2[L5_2]
    L0_2 = L0_2 + L6_2
  end
  L2_2 = L0_2 / L1_2
  return L2_2
end

function L19_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L0_2 = 0
  L1_2 = ipairs
  L2_2 = L8_1
  L1_2, L2_2, L3_2 = L1_2(L2_2)
  for L4_2, L5_2 in L1_2, L2_2, L3_2 do
    L0_2 = L0_2 + L5_2
  end
  L1_2 = L2_1
  L1_2 = L0_2 / L1_2
  L2_2 = 1000 / L1_2
  L3_2 = round
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = L4_1
  L5_2 = _FPS
  L5_2 = L5_2 * 10
  if L4_2 > L5_2 then
    L4_2 = L7_1
    if L3_2 > L4_2 then
      L7_1 = L3_2
    end
    L4_2 = L6_1
    if L3_2 < L4_2 then
      L6_1 = L3_2
    end
  end
  L4_2 = L9_1
  L5_2 = L9_1
  L5_2 = #L5_2
  L5_2 = L5_2 + 1
  L4_2[L5_2] = L2_2
  L4_2 = L9_1
  L4_2 = #L4_2
  if 1 < L4_2 then
    L4_2 = L15_1
    if L4_2 then
      L4_2 = L15_1
      if L2_2 < L4_2 then
        L4_2 = L16_1
        L4_2 = L4_2 + 1
        L16_1 = L4_2
        L4_2 = L10_1
        if L4_2 then
          L4_2 = log
          L4_2 = L4_2.show
          L5_2 = "Alert framerate = "
          L6_2 = L3_2
          L5_2 = L5_2 .. L6_2
          L4_2(L5_2)
        end
        L4_2 = L12_1
        if L4_2 then
          L4_2 = L12_1
          L4_2()
        end
      end
    end
  end
  L4_2 = L10_1
  if L4_2 then
    L4_2 = L6_1
    L5_2 = "/"
    L6_2 = L3_2
    L7_2 = "/"
    L8_2 = L7_1
    L4_2 = L4_2 .. L5_2 .. L6_2 .. L7_2 .. L8_2
    L5_2 = L6_1
    if L5_2 == 99 then
      L5_2 = " - /"
      L6_2 = L3_2
      L7_2 = "/ -"
      L4_2 = L5_2 .. L6_2 .. L7_2
    end
    L5_2 = L3_1
    if L5_2 == nil then
      L5_2 = display
      L5_2 = L5_2.newText
      L6_2 = L4_2
      L7_2 = 0
      L8_2 = 0
      L9_2 = nil
      L10_2 = 10
      L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
      L3_1 = L5_2
      L5_2 = L3_1
      L6_2 = L5_2
      L5_2 = L5_2.setFillColor
      L7_2 = gray
      L5_2(L6_2, L7_2())
      L5_2 = L3_1
      L6_2 = L3_1
      L7_2 = 1
      L6_2.anchorY = 1
      L5_2.anchorX = L7_2
      L5_2 = L3_1
      L6_2 = L3_1
      L7_2 = screenRight
      L7_2 = L7_2 - 3
      L8_2 = screenBottom
      L8_2 = L8_2 - 2
      L6_2.y = L8_2
      L5_2.x = L7_2
      L5_2 = L3_1
      L5_2.alpha = 1
    else
      L5_2 = L3_1
      L5_2.text = L4_2
      L5_2 = L3_1
      L6_2 = L5_2
      L5_2 = L5_2.toFront
      L5_2(L6_2)
    end
  end
end

function L20_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = L8_1
  L0_2 = #L0_2
  if L0_2 == 0 then
    return
  end
  L0_2 = Runtime
  L1_2 = L0_2
  L0_2 = L0_2.removeEventListener
  L2_2 = "enterFrame"
  L3_2 = L17_1
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = L13_1
  if L0_2 then
    L0_2 = timer
    L0_2 = L0_2.cancel
    L1_2 = L13_1
    L0_2(L1_2)
    L0_2 = nil
    L13_1 = L0_2
  end
  L0_2 = L14_1
  if L0_2 then
    L0_2 = timer
    L0_2 = L0_2.cancel
    L1_2 = L14_1
    L0_2(L1_2)
    L0_2 = nil
    L14_1 = L0_2
  end
  L0_2 = L3_1
  if L0_2 then
    L0_2 = L3_1
    L1_2 = L0_2
    L0_2 = L0_2.removeSelf
    L0_2(L1_2)
    L0_2 = nil
    L3_1 = L0_2
  end
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L1_2 = L18_1
  L1_2 = L1_2()
  L0_2.frameRate = L1_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L1_2 = os
  L1_2 = L1_2.time
  L1_2 = L1_2()
  L0_2.whenLastMeasured = L1_2
  L0_2 = saver
  L0_2 = L0_2.Save
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L2_2 = "fr.txt"
  L0_2(L1_2, L2_2)
  L0_2 = L10_1
  if L0_2 then
    L0_2 = log
    L0_2 = L0_2.show
    L1_2 = "Avg framerate = "
    L2_2 = L0_1
    L2_2 = L2_2.savedData
    L2_2 = L2_2.frameRate
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
  end
  L0_2 = L11_1
  if L0_2 then
    L0_2 = L11_1
    L0_2()
  end
  L0_2 = {}
  L8_1 = L0_2
  L0_2 = {}
  L9_1 = L0_2
end

L0_1.stopMeasuring = L20_1

function L20_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2 = L0_2.frameRate
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2 = L1_2.whenLastMeasured
  return L0_2, L1_2
end

L0_1.getLastMeasuredFrameRate = L20_1

function L20_1()
  local L0_2, L1_2
  L0_2 = L16_1
  return L0_2
end

L0_1.getNumberOfAlertsSoFarThisMeasurementSession = L20_1

function L20_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2
  L5_2 = 0
  L16_1 = L5_2
  L5_2 = {}
  L8_1 = L5_2
  L5_2 = {}
  L9_1 = L5_2
  L10_1 = A1_2
  L11_1 = A2_2
  L12_1 = A3_2
  L15_1 = A4_2
  L5_2 = Runtime
  L6_2 = L5_2
  L5_2 = L5_2.addEventListener
  L7_2 = "enterFrame"
  L8_2 = L17_1
  L5_2(L6_2, L7_2, L8_2)
  L5_2 = timer
  L5_2 = L5_2.performWithDelay
  L6_2 = 333
  L7_2 = L19_1
  L8_2 = -1
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L13_1 = L5_2
  if 0 < A0_2 then
    L5_2 = timer
    L5_2 = L5_2.performWithDelay
    L6_2 = A0_2
    L7_2 = L0_1
    L7_2 = L7_2.stopMeasuring
    L5_2 = L5_2(L6_2, L7_2)
    L14_1 = L5_2
  end
end

L0_1.measureFrameRate = L20_1
return L0_1
