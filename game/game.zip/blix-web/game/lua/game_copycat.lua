local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "game_copycat.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = math
L2_1 = L2_1.random
L3_1 = math
L3_1 = L3_1.ceil
L4_1 = math
L4_1 = L4_1.floor
L0_1.name = "CopyCat"
L0_1.displayName = "Copy Cat"
L0_1.instructions = "See how far you can get by copying what I do."
L0_1.scoring = true
L0_1.leveling = true
L0_1.lives = 0
L0_1.oneStrokeAtOnce = true
L0_1.oneStrokePerColorAtOnce = true
L0_1.multitouch = false
L5_1 = nil
L6_1 = nil
L7_1 = false
L8_1 = nil

function L9_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
end

L0_1.onWrongTargetHit = L9_1

function L9_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
end

L0_1.onObstacleHit = L9_1

function L9_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L3_2 = A2_2.parent
  L4_2 = L3_2
  L3_2 = L3_2.localToContent
  L5_2 = A2_2.x
  L6_2 = A2_2.y
  L3_2, L4_2 = L3_2(L4_2, L5_2, L6_2)
  L5_2 = _addToScore
  L6_2 = 1
  L7_2 = 1
  L5_2(L6_2, L7_2)
  L5_2 = gameutils
  L5_2 = L5_2.showPopupScore
  L6_2 = L3_2
  L7_2 = L4_2
  L8_2 = 1
  L9_2 = A2_2.color
  L10_2 = 14
  L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  L5_2 = target
  L5_2 = L5_2.numInPlay
  if L5_2 == 0 then
    L5_2 = stroke
    L5_2 = L5_2.numInPlay
    if L5_2 == 1 then
      L5_2 = timer
      L5_2 = L5_2.performWithDelay
      L6_2 = 500
      
      function L7_2()
        local L0_3, L1_3
        L0_3 = _levelUp
        L1_3 = 500
        L0_3(L1_3)
      end
      
      L5_2(L6_2, L7_2)
    end
  end
  L6_2 = A2_2
  L5_2 = A2_2.remove
  L7_2 = 200
  L5_2(L6_2, L7_2)
end

L0_1.onCorrectTargetHit = L9_1

function L9_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = timer
  L2_2 = L2_2.performWithDelay
  L3_2 = 500
  
  function L4_2()
    local L0_3, L1_3
    L0_3 = _levelUp
    L1_3 = 500
    L0_3(L1_3)
  end
  
  L2_2(L3_2, L4_2)
end

L0_1.onStrokeLost = L9_1

function L9_1(A0_2)
  local L1_2
end

L0_1.onSetupGame = L9_1

function L9_1(A0_2)
  local L1_2, L2_2
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L5_1
  L1_2(L2_2)
  L1_2 = nil
  L5_1 = L1_2
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L6_1
  L1_2(L2_2)
  L1_2 = nil
  L6_1 = L1_2
end

L0_1.onCleanUp = L9_1

function L9_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = A1_2.replayFrameCounter
  L3_2 = _FPS
  L2_2 = L2_2 / L3_2
  if 15 < L2_2 then
    L3_2 = L6_1
    if L3_2 == nil then
      L3_2 = buttons
      L3_2 = L3_2.newPlainText
      L4_2 = "skip >"
      L5_2 = _levelUp
      L6_2 = {}
      L7_2 = _group
      L6_2.group = L7_2
      L7_2 = gray
      L6_2.textColor = L7_2
      L6_2.frameless = true
      L6_2.textAnchorX = 1
      L6_2.fontSize = 14
      L7_2 = globals
      L7_2 = L7_2.defaultFont
      L6_2.fontNum = L7_2
      L3_2 = L3_2(L4_2, L5_2, L6_2)
      L6_1 = L3_2
      L3_2 = L6_1
      L4_2 = L6_1
      L5_2 = screenRight
      L5_2 = L5_2 - 30
      L6_2 = screenBottom
      L6_2 = L6_2 - 15
      L4_2.y = L6_2
      L3_2.x = L5_2
    end
  end
end

L0_1.onStrokeProcessReplay = L9_1

function L9_1(A0_2)
  local L1_2
end

L0_1.onLevelUp = L9_1

function L9_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = gamenetwork_utils
  L1_2 = L1_2.sendHighScore
  L2_2 = globals
  L2_2 = L2_2.LEADERBOARD_ID_xxxxxxxxxxxx
  L3_2 = _score
  L1_2(L2_2, L3_2)
end

L0_1.onEndGame = L9_1

function L9_1(A0_2)
  local L1_2
end

L0_1.onAddToScore = L9_1
return L0_1
