local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = (...)
_launchArgs = L0_1
L0_1 = io
L0_1 = L0_1.stdout
L1_1 = L0_1
L0_1 = L0_1.setvbuf
L2_1 = "line"
L0_1(L1_1, L2_1)
L0_1 = false
if L0_1 then
  L1_1 = log
  L1_1 = L1_1.show
  L2_1 = "main.lua DEBUGGING"
  L1_1(L2_1)
end
L1_1 = 0
_whenAppWasLastSuspendedInSec = L1_1
L1_1 = 0
_lengthOfLastSuspensionInSec = L1_1
L1_1 = require
L2_1 = "globals"
L1_1 = L1_1(L2_1)
globals = L1_1
L1_1 = require
L2_1 = "__all"
L1_1(L2_1)
L1_1 = require
L2_1 = "composer"
L1_1 = L1_1(L2_1)
L2_1 = require
L3_1 = "analytics"
L2_1 = L2_1(L3_1)
analytics = L2_1
L2_1 = require
L3_1 = "android_back_button"
L2_1(L3_1)
L2_1 = require
L3_1 = "progress"
L2_1 = L2_1(L3_1)
progress = L2_1
L2_1 = require
L3_1 = "collisions"
L2_1 = L2_1(L3_1)
collisions = L2_1
L2_1 = require
L3_1 = "stroke"
L2_1 = L2_1(L3_1)
stroke = L2_1
L2_1 = require
L3_1 = "target"
L2_1 = L2_1(L3_1)
target = L2_1
L2_1 = require
L3_1 = "palette"
L2_1 = L2_1(L3_1)
palette = L2_1
L2_1 = require
L3_1 = "obstacle"
L2_1 = L2_1(L3_1)
obstacle = L2_1
L2_1 = require
L3_1 = "gameutils"
L2_1 = L2_1(L3_1)
gameutils = L2_1
L2_1 = require
L3_1 = "building_block"
L2_1 = L2_1(L3_1)
building_block = L2_1
L2_1 = require
L3_1 = "game_tester"
L2_1 = L2_1(L3_1)
game_tester = L2_1
L2_1 = require
L3_1 = "game_main"
L2_1 = L2_1(L3_1)
game_main = L2_1
L2_1 = require
L3_1 = "game_pointandshoot"
L2_1 = L2_1(L3_1)
game_pointandshoot = L2_1
L2_1 = require
L3_1 = "game_swarm"
L2_1 = L2_1(L3_1)
game_swarm = L2_1
L2_1 = require
L3_1 = "game_tutorial"
L2_1 = L2_1(L3_1)
game_tutorial = L2_1
L2_1 = display
L2_1 = L2_1.setStatusBar
L3_1 = display
L3_1 = L3_1.HiddenStatusBar
L2_1(L3_1)

function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = progress
  L0_2 = L0_2.getHighScore
  L1_2 = game_main
  L1_2 = L1_2.name
  L0_2 = L0_2(L1_2)
  if L0_2 <= 0 then
    L0_2 = L1_1
    L0_2 = L0_2.gotoScene
    L1_2 = "scene_game"
    L2_2 = {}
    L3_2 = {}
    L4_2 = game_tutorial
    L3_2.game = L4_2
    L3_2.skip_instructions = false
    L2_2.params = L3_2
    L0_2(L1_2, L2_2)
  else
    L0_2 = L1_1
    L0_2 = L0_2.gotoScene
    L1_2 = "scene_title"
    L0_2(L1_2)
  end
end

L3_1 = settings
L3_1 = L3_1.callServer
L4_1 = L2_1
L5_1 = {}
L5_1.initMsg = "Welcome..."
L6_1 = verydarkgray
L5_1.bgColor = L6_1
L6_1 = lightgray
L5_1.textColor = L6_1
L3_1(L4_1, L5_1)
L3_1 = platform
L3_1 = L3_1.ios
if not L3_1 then
  L3_1 = platform
  L3_1 = L3_1.android
  if not L3_1 then
    goto lbl_117
  end
end
L3_1 = gamenetwork_utils
L3_1 = L3_1.initGC
L4_1 = "main.lua"
L3_1(L4_1)
::lbl_117::

function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L0_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "main.lua: got system event type "
    L3_2 = A0_2.type
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
    L1_2 = print
    L2_2 = "main.lua: got system event type "
    L3_2 = A0_2.type
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
  L1_2 = A0_2.type
  if "applicationStart" == L1_2 then
    L1_2 = true
    return L1_2
  end
  L1_2 = A0_2.type
  if "applicationSuspend" == L1_2 then
    L1_2 = os
    L1_2 = L1_2.time
    L1_2 = L1_2()
    _whenAppWasLastSuspendedInSec = L1_2
  end
  L1_2 = A0_2.type
  if "applicationResume" == L1_2 then
    L1_2 = os
    L1_2 = L1_2.time
    L1_2 = L1_2()
    L2_2 = _whenAppWasLastSuspendedInSec
    L1_2 = L1_2 - L2_2
    _lengthOfLastSuspensionInSec = L1_2
    L1_2 = L0_1
    if L1_2 then
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "App resumed from suspended for "
      L3_2 = _lengthOfLastSuspensionInSec
      L4_2 = " sec"
      L2_2 = L2_2 .. L3_2 .. L4_2
      L1_2(L2_2)
    end
  end
  L1_2 = A0_2.type
  if "applicationExit" == L1_2 then
    L1_2 = os
    L1_2 = L1_2.time
    L1_2 = L1_2()
    L2_2 = bsi
    L2_2 = L2_2.getTimeOfThisSessionStartup
    L2_2 = L2_2()
    L1_2 = L1_2 - L2_2
  end
end

L4_1 = Runtime
L5_1 = L4_1
L4_1 = L4_1.addEventListener
L6_1 = "system"
L7_1 = L3_1
L4_1(L5_1, L6_1, L7_1)
if L0_1 then
  L4_1 = log
  L4_1 = L4_1.show
  L5_1 = "main.lua: Added system event listener"
  L4_1(L5_1)
end
L4_1 = _DEV_TAKE_PIC_MODE
if L4_1 then
  L4_1 = log
  L4_1 = L4_1.show
  L5_1 = "_DEV_TAKE_PIC_MODE"
  L4_1(L5_1)
end
L4_1 = _LEVEL_CREATION_MODE
if L4_1 then
  L4_1 = log
  L4_1 = L4_1.show
  L5_1 = "_LEVEL_CREATION_MODE"
  L4_1(L5_1)
end
L4_1 = _REDDIT_HACK_MODE
if L4_1 then
  L4_1 = log
  L4_1 = L4_1.show
  L5_1 = "_REDDIT_HACK_MODE"
  L4_1(L5_1)
end
if L0_1 then
  L4_1 = log
  L4_1 = L4_1.show
  L5_1 = "main finished"
  L4_1(L5_1)
end
