local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1
L0_1 = require
L1_1 = "composer"
L0_1 = L0_1(L1_1)
L1_1 = L0_1.newScene
L1_1 = L1_1()
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "_scene_popup.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = false
L4_1 = _lastTimeHid
if not L4_1 then
  L4_1 = 0
end
_lastTimeHid = L4_1
L4_1 = _lastSceneName
if not L4_1 then
  L4_1 = ""
end
_lastSceneName = L4_1
L4_1 = _paramsStack
if not L4_1 then
  L4_1 = {}
end
_paramsStack = L4_1
L4_1 = _fnToCallWhenClosedDueToBeingKilled
if not L4_1 then
  L4_1 = nil
end
_fnToCallWhenClosedDueToBeingKilled = L4_1
L4_1 = nil
L5_1 = nil
L6_1 = nil
L7_1 = nil
L8_1 = nil
L9_1 = nil
L10_1 = nil
L11_1 = nil

function L12_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_popup:create()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = display
  L3_2 = L3_2.newRect
  L4_2 = L2_2
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = screenWidth
  L8_2 = screenHeight
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L4_1 = L3_2
  L3_2 = L4_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = black
  L3_2(L4_2, L5_2())
end

L1_1.create = L12_1

function L12_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2, L34_2, L35_2, L36_2, L37_2, L38_2, L39_2, L40_2, L41_2, L42_2, L43_2, L44_2, L45_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_popup:show() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
      L3_2 = _paramsStack
      L4_2 = _paramsStack
      L4_2 = #L4_2
      L4_2 = L4_2 + 1
      L5_2 = A1_2.params
      L3_2[L4_2] = L5_2
      L3_2 = A1_2.params
      L3_2 = L3_2.url
      L4_2 = A1_2.params
      L4_2 = L4_2.image
      L5_2 = A1_2.params
      L5_2 = L5_2.directory
      L6_2 = A1_2.params
      L6_2 = L6_2.imageCallBackFn
      L7_2 = A1_2.params
      L7_2 = L7_2.title
      L8_2 = A1_2.params
      L8_2 = L8_2.text
      L9_2 = A1_2.params
      L9_2 = L9_2.textWidth
      if not L9_2 then
        L9_2 = 200
      end
      L10_2 = A1_2.params
      L10_2 = L10_2.fontNum
      if not L10_2 then
        L10_2 = globals
        L10_2 = L10_2.defaultFont
      end
      L11_2 = A1_2.params
      L11_2 = L11_2.fontSize
      if not L11_2 then
        L11_2 = 16
      end
      L12_2 = A1_2.params
      L12_2 = L12_2.lineSpacingAdjust
      if not L12_2 then
        L12_2 = 2
      end
      L13_2 = A1_2.params
      L13_2 = L13_2.titleColor
      if not L13_2 then
        L13_2 = white
      end
      L14_2 = A1_2.params
      L14_2 = L14_2.textColor
      if not L14_2 then
        L14_2 = white
      end
      L15_2 = A1_2.params
      L15_2 = L15_2.embossed
      if not L15_2 then
        L15_2 = false
      end
      L16_2 = A1_2.params
      L16_2 = L16_2.dimAlpha
      if not L16_2 then
        L16_2 = 0.1
      end
      L17_2 = A1_2.params
      L17_2 = L17_2.bgColor
      if not L17_2 then
        L17_2 = black
      end
      L18_2 = A1_2.params
      L18_2 = L18_2.bgAlpha
      if not L18_2 then
        L18_2 = 0.9
      end
      L19_2 = A1_2.params
      L19_2 = L19_2.bgStrokeWidth
      if not L19_2 then
        L19_2 = 2
      end
      L20_2 = A1_2.params
      L20_2 = L20_2.bgStrokeColor
      if not L20_2 then
        L20_2 = white
      end
      L21_2 = A1_2.params
      L21_2 = L21_2.bgCornerRadius
      if not L21_2 then
        L21_2 = 10
      end
      L22_2 = A1_2.params
      L22_2 = L22_2.bgMargin
      if not L22_2 then
        L22_2 = 20
      end
      L23_2 = A1_2.params
      L23_2 = L23_2.okText
      if not L23_2 then
        L23_2 = "Ok"
      end
      L24_2 = A1_2.params
      L24_2 = L24_2.okTextColor
      if not L24_2 then
        L24_2 = white
      end
      L25_2 = A1_2.params
      L25_2 = L25_2.okCallBackFn
      L26_2 = A1_2.params
      L26_2 = L26_2.cancelText
      L27_2 = A1_2.params
      L27_2 = L27_2.cancelTextColor
      if not L27_2 then
        L27_2 = white
      end
      L28_2 = A1_2.params
      L28_2 = L28_2.cancelCallBackFn
      L29_2 = A1_2.params
      L29_2 = L29_2.buttonFontSize
      if not L29_2 then
        L29_2 = L11_2 + 2
      end
      L30_2 = L4_1
      L30_2.alpha = L16_2
      L30_2 = L4_1
      L31_2 = L30_2
      L30_2 = L30_2.toBack
      L30_2(L31_2)
      L30_2 = display
      L30_2 = L30_2.newGroup
      L30_2 = L30_2()
      L31_2 = L11_2 + L12_2
      L32_2 = _W2
      L33_2 = _H2
      if L7_2 then
        L34_2 = display
        L34_2 = L34_2.newText
        L35_2 = L30_2
        L36_2 = L7_2
        L37_2 = 0
        L38_2 = 0
        L39_2 = _ttf_font
        L39_2 = L39_2[L10_2]
        L40_2 = L11_2
        L34_2 = L34_2(L35_2, L36_2, L37_2, L38_2, L39_2, L40_2)
        L6_1 = L34_2
        L34_2 = L6_1
        L35_2 = L34_2
        L34_2 = L34_2.setFillColor
        L36_2 = L13_2
        L34_2(L35_2, L36_2())
        L34_2 = L6_1
        L34_2.anchorY = 0
        L34_2 = L6_1
        L35_2 = L6_1
        L36_2 = L32_2
        L37_2 = _ttf_font_offset
        L37_2 = L37_2[L10_2]
        L37_2 = L37_2 * L11_2
        L37_2 = L33_2 + L37_2
        L35_2.y = L37_2
        L34_2.x = L36_2
        L34_2 = L6_1
        L34_2 = L34_2.height
        L34_2 = L33_2 + L34_2
        L33_2 = L34_2 + L31_2
      end
      if L4_2 and L5_2 then
        L34_2 = display
        L34_2 = L34_2.newImage
        L35_2 = L30_2
        L36_2 = L4_2
        L37_2 = L5_2
        L34_2 = L34_2(L35_2, L36_2, L37_2)
        L7_1 = L34_2
        while true do
          L34_2 = L7_1
          L34_2 = L34_2.contentWidth
          L35_2 = screenWidth
          L35_2 = L35_2 - 20
          if not (L34_2 > L35_2) then
            L34_2 = L7_1
            L34_2 = L34_2.contentHeight
            L35_2 = screenHeight
            L35_2 = L35_2 - 80
            if not (L34_2 > L35_2) then
              break
            end
          end
          L34_2 = L7_1
          L35_2 = L7_1
          L36_2 = L7_1
          L36_2 = L36_2.xScale
          L36_2 = L36_2 * 0.95
          L37_2 = L7_1
          L37_2 = L37_2.yScale
          L37_2 = L37_2 * 0.95
          L35_2.yScale = L37_2
          L34_2.xScale = L36_2
        end
        L34_2 = L7_1
        L34_2.anchorY = 0
        L34_2 = L7_1
        L35_2 = L7_1
        L36_2 = L32_2
        L35_2.y = L33_2
        L34_2.x = L36_2
        L34_2 = L7_1
        L34_2 = L34_2.contentHeight
        L34_2 = L33_2 + L34_2
        L33_2 = L34_2 + L31_2
        L34_2 = L7_1
        
        function L35_2(A0_3, A1_3)
          local L2_3
          L2_3 = A1_3.phase
          if L2_3 == "began" then
            L2_3 = L0_1
            L2_3 = L2_3.hideOverlay
            L2_3()
            L2_3 = L6_2
            L2_3()
          end
        end
        
        L34_2.touch = L35_2
        if L6_2 then
          L34_2 = L7_1
          L35_2 = L34_2
          L34_2 = L34_2.addEventListener
          L36_2 = "touch"
          L37_2 = L7_1
          L34_2(L35_2, L36_2, L37_2)
        end
      end
      if L3_2 then
        L34_2 = screenWidth
        L34_2 = L34_2 - 20
        L35_2 = screenHeight
        L35_2 = L35_2 - 80
        if 400 < L34_2 then
          L34_2 = 400
        end
        if 400 < L35_2 then
          L35_2 = 400
        end
        L36_2 = native
        L36_2 = L36_2.newWebView
        L37_2 = 0
        L38_2 = 0
        L39_2 = L34_2
        L40_2 = L35_2
        L36_2 = L36_2(L37_2, L38_2, L39_2, L40_2)
        L8_1 = L36_2
        L37_2 = L30_2
        L36_2 = L30_2.insert
        L38_2 = L8_1
        L36_2(L37_2, L38_2)
        L36_2 = L8_1
        L36_2.anchorY = 0
        L36_2 = L8_1
        L37_2 = L8_1
        L38_2 = L32_2
        L37_2.y = L33_2
        L36_2.x = L38_2
        L36_2 = L8_1
        L37_2 = L36_2
        L36_2 = L36_2.request
        L38_2 = L3_2
        L36_2(L37_2, L38_2)
        L36_2 = L8_1
        L36_2 = L36_2.height
        L36_2 = L33_2 + L36_2
        L33_2 = L36_2 + L31_2
      end
      if L8_2 then
        L34_2 = utils
        L34_2 = L34_2.newTextWithWrap
        L35_2 = L30_2
        L36_2 = L8_2
        L37_2 = L9_2
        L38_2 = L10_2
        L39_2 = L11_2
        L40_2 = L31_2
        L41_2 = L14_2
        L42_2 = L15_2
        L34_2 = L34_2(L35_2, L36_2, L37_2, L38_2, L39_2, L40_2, L41_2, L42_2)
        L9_1 = L34_2
        L34_2 = L9_1
        L34_2.anchorY = 0
        L34_2 = L9_1
        L35_2 = L9_1
        L36_2 = L32_2
        L37_2 = _ttf_font_offset
        L37_2 = L37_2[L10_2]
        L37_2 = L37_2 * L11_2
        L37_2 = L33_2 + L37_2
        L35_2.y = L37_2
        L34_2.x = L36_2
        L34_2 = L9_1
        L34_2 = L34_2.height
        L34_2 = L33_2 + L34_2
        L33_2 = L34_2 + L31_2
      end
      
      function L34_2()
        local L0_3, L1_3
        L0_3 = L0_1
        L0_3 = L0_3.hideOverlay
        L0_3()
        L0_3 = L25_2
        if L0_3 then
          L0_3 = L25_2
          L0_3()
        end
      end
      
      L35_2 = buttons
      L35_2 = L35_2.newPlainText
      L36_2 = L23_2
      L37_2 = L34_2
      L38_2 = {}
      L38_2.group = L30_2
      L38_2.textColor = L24_2
      L38_2.alphaWhenEnabled = 1
      L38_2.frameless = true
      L38_2.fontSize = L29_2
      L38_2.fontNum = L10_2
      L35_2 = L35_2(L36_2, L37_2, L38_2)
      L10_1 = L35_2
      L35_2 = L10_1
      L35_2.anchorY = 0
      L35_2 = L10_1
      L36_2 = L10_1
      L37_2 = L32_2
      L36_2.y = L33_2
      L35_2.x = L37_2
      if L26_2 then
        function L35_2()
          local L0_3, L1_3
          
          L0_3 = L0_1
          L0_3 = L0_3.hideOverlay
          L0_3()
          L0_3 = L28_2
          if L0_3 then
            L0_3 = L28_2
            L0_3()
          end
        end
        
        L36_2 = buttons
        L36_2 = L36_2.newPlainText
        L37_2 = L26_2
        L38_2 = L35_2
        L39_2 = {}
        L39_2.group = L30_2
        L39_2.textColor = L27_2
        L39_2.alphaWhenEnabled = 1
        L39_2.frameless = true
        L39_2.fontSize = L29_2
        L39_2.fontNum = L10_2
        L36_2 = L36_2(L37_2, L38_2, L39_2)
        L11_1 = L36_2
        L36_2 = L11_1
        L36_2.anchorY = 0
        L36_2 = L11_1
        L37_2 = L11_1
        L38_2 = L32_2
        L39_2 = L10_1
        L39_2 = L39_2.y
        L37_2.y = L39_2
        L36_2.x = L38_2
        L36_2 = L10_1
        L37_2 = L32_2 + 50
        L36_2.x = L37_2
        L36_2 = L11_1
        L37_2 = L32_2 - 50
        L36_2.x = L37_2
      end
      L35_2 = L10_1
      L35_2 = L35_2.height
      L33_2 = L33_2 + L35_2
      L36_2 = L2_2
      L35_2 = L2_2.insert
      L37_2 = L30_2
      L35_2(L36_2, L37_2)
      L35_2 = 0
      L36_2 = L30_2.height
      L36_2 = -L36_2
      L36_2 = L36_2 / 2
      L30_2.y = L36_2
      L30_2.x = L35_2
      L35_2 = display
      L35_2 = L35_2.newRoundedRect
      L36_2 = L2_2
      L37_2 = _W2
      L38_2 = _H2
      L39_2 = L30_2.width
      L39_2 = L39_2 + L22_2
      L40_2 = L30_2.height
      L40_2 = L40_2 + L22_2
      L41_2 = L21_2
      L35_2 = L35_2(L36_2, L37_2, L38_2, L39_2, L40_2, L41_2)
      L5_1 = L35_2
      L35_2 = L5_1
      L36_2 = L35_2
      L35_2 = L35_2.setFillColor
      L37_2 = L17_2
      L35_2(L36_2, L37_2())
      L35_2 = L5_1
      L35_2.strokeWidth = L19_2
      L35_2 = L5_1
      L36_2 = L35_2
      L35_2 = L35_2.setStrokeColor
      L37_2 = L20_2
      L35_2(L36_2, L37_2())
      L35_2 = L5_1
      L35_2.alpha = L18_2
      L35_2 = L5_1
      L36_2 = L35_2
      L35_2 = L35_2.toFront
      L35_2(L36_2)
      L36_2 = L30_2
      L35_2 = L30_2.toFront
      L35_2(L36_2)
      L35_2 = L0_1
      L35_2 = L35_2.getSceneName
      L36_2 = "current"
      L35_2 = L35_2(L36_2)
      L36_2 = system
      L36_2 = L36_2.getTimer
      L36_2 = L36_2()
      L37_2 = _lastTimeHid
      L36_2 = L36_2 - L37_2
      L37_2 = _lastSceneName
      L37_2 = A1_2.params
      L37_2 = L37_2.dontStack
      L37_2 = L36_2 < 100 and L37_2
      L3_1 = L37_2
      L37_2 = L2_1
      if L37_2 then
        L37_2 = print
        L38_2 = L7_2
        L39_2 = "nowTime="
        L40_2 = system
        L40_2 = L40_2.getTimer
        L40_2 = L40_2()
        L39_2 = L39_2 .. L40_2
        L40_2 = "timeBetweenLastHideAndThisShow="
        L41_2 = L36_2
        L40_2 = L40_2 .. L41_2
        L41_2 = "_lastSceneName="
        L42_2 = _lastSceneName
        L41_2 = L41_2 .. L42_2
        L42_2 = "thisSceneName="
        L43_2 = L35_2
        L42_2 = L42_2 .. L43_2
        L43_2 = "thisOneCausedPreviousOneToClose="
        L44_2 = tostring
        L45_2 = L3_1
        L44_2 = L44_2(L45_2)
        L43_2 = L43_2 .. L44_2
        L37_2(L38_2, L39_2, L40_2, L41_2, L42_2, L43_2)
      end
      L37_2 = L0_1
      L37_2 = L37_2.getSceneName
      L38_2 = "current"
      L37_2 = L37_2(L38_2)
      _lastSceneName = L37_2
    end
  end
end

L1_1.show = L12_1

function L12_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_popup:hide() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
    L3_2 = utils
    L3_2 = L3_2.cancelAllTimersAndTransitions
    L3_2()
    L3_2 = L8_1
    if L3_2 then
      L3_2 = display
      L3_2 = L3_2.remove
      L4_2 = L8_1
      L3_2(L4_2)
    end
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
      L3_2 = L3_1
      if L3_2 then
        L3_2 = L2_1
        if L3_2 then
          L3_2 = print
          L4_2 = "_scene_popup had thisOneCausedPreviousOneToClose so calling another _scene_popup now"
          L3_2(L4_2)
        end
        
        function L3_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3
          L0_3 = L0_1
          L0_3 = L0_3.showOverlay
          L1_3 = "_scene_popup"
          L2_3 = {}
          L2_3.isModal = true
          L3_3 = _paramsStack
          L4_3 = _paramsStack
          L4_3 = #L4_3
          L4_3 = L4_3 - 1
          L3_3 = L3_3[L4_3]
          L2_3.params = L3_3
          L0_3(L1_3, L2_3)
        end
        
        L4_2 = timer
        L4_2 = L4_2.performWithDelay
        L5_2 = 1
        L6_2 = L3_2
        L4_2(L5_2, L6_2)
        L4_2 = 0
        _lastTimeHid = L4_2
      else
        L3_2 = _fnToCallWhenClosedDueToBeingKilled
        if L3_2 then
          L3_2 = L2_1
          if L3_2 then
            L3_2 = print
            L4_2 = "_scene_popup had _fnToCallWhenClosedDueToBeingKilled so calling _fnToCallWhenClosedDueToBeingKilled now"
            L3_2(L4_2)
          end
          L3_2 = timer
          L3_2 = L3_2.performWithDelay
          L4_2 = 1
          L5_2 = _fnToCallWhenClosedDueToBeingKilled
          L3_2(L4_2, L5_2)
          L3_2 = nil
          _fnToCallWhenClosedDueToBeingKilled = L3_2
          L3_2 = 0
          _lastTimeHid = L3_2
        else
          L3_2 = L2_1
          if L3_2 then
            L3_2 = print
            L4_2 = "_scene_popup hiding normally"
            L3_2(L4_2)
          end
          L3_2 = system
          L3_2 = L3_2.getTimer
          L3_2 = L3_2()
          _lastTimeHid = L3_2
        end
      end
    end
  end
end

L1_1.hide = L12_1

function L12_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_popup:destroy()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
end

L1_1.destroy = L12_1
L13_1 = L1_1
L12_1 = L1_1.addEventListener
L14_1 = "create"
L15_1 = L1_1
L12_1(L13_1, L14_1, L15_1)
L13_1 = L1_1
L12_1 = L1_1.addEventListener
L14_1 = "show"
L15_1 = L1_1
L12_1(L13_1, L14_1, L15_1)
L13_1 = L1_1
L12_1 = L1_1.addEventListener
L14_1 = "hide"
L15_1 = L1_1
L12_1(L13_1, L14_1, L15_1)
L13_1 = L1_1
L12_1 = L1_1.addEventListener
L14_1 = "destroy"
L15_1 = L1_1
L12_1(L13_1, L14_1, L15_1)
return L1_1
