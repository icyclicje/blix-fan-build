local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1
L0_1 = {}
L0_1._VERSION = "inspect.lua 2.0.0"
L0_1._URL = "http://github.com/kikito/inspect.lua"
L0_1._DESCRIPTION = "human-readable representations of tables"
L0_1._LICENSE = "    MIT LICENSE\n\n    Copyright (c) 2013 Enrique Garc\195\173a Cota\n\n    Permission is hereby granted, free of charge, to any person obtaining a\n    copy of this software and associated documentation files (the\n    \"Software\"), to deal in the Software without restriction, including\n    without limitation the rights to use, copy, modify, merge, publish,\n    distribute, sublicense, and/or sell copies of the Software, and to\n    permit persons to whom the Software is furnished to do so, subject to\n    the following conditions:\n\n    The above copyright notice and this permission notice shall be included\n    in all copies or substantial portions of the Software.\n\n    THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS\n    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF\n    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.\n    IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY\n    CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,\n    TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE\n    SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\n  "

function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L2_2 = A0_2
  L1_2 = A0_2.match
  L3_2 = "\""
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = A0_2
    L1_2 = A0_2.match
    L3_2 = "'"
    L1_2 = L1_2(L2_2, L3_2)
    if not L1_2 then
      L1_2 = "'"
      L2_2 = A0_2
      L3_2 = "'"
      L1_2 = L1_2 .. L2_2 .. L3_2
      return L1_2
    end
  end
  L1_2 = "\""
  L3_2 = A0_2
  L2_2 = A0_2.gsub
  L4_2 = "\""
  L5_2 = "\\\""
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  L3_2 = "\""
  L1_2 = L1_2 .. L2_2 .. L3_2
  return L1_2
end

L2_1 = {}
L2_1["\a"] = "\\a"
L2_1["\b"] = "\\b"
L2_1["\f"] = "\\f"
L2_1["\n"] = "\\n"
L2_1["\r"] = "\\r"
L2_1["\t"] = "\\t"
L2_1["\v"] = "\\v"

function L3_1(A0_2)
  local L1_2
  L1_2 = L2_1
  L1_2 = L1_2[A0_2]
  return L1_2
end

function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L2_2 = A0_2
  L1_2 = A0_2.gsub
  L3_2 = "\\"
  L4_2 = "\\\\"
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L2_2 = L1_2
  L1_2 = L1_2.gsub
  L3_2 = "(%c)"
  L4_2 = L3_1
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  return L1_2
end

function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = A0_2
  L1_2 = A0_2.match
  L3_2 = "^[_%a][_%a%d]*$"
  L1_2 = L1_2 == "string" and L1_2
  return L1_2
end

function L6_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = type
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L2_2 = L2_2 == "number" and 1 <= A0_2 and A0_2 <= A1_2
  return L2_2
end

function L7_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L6_1
  L3_2 = A0_2
  L4_2 = A1_2
  L2_2 = L2_2(L3_2, L4_2)
  L2_2 = not L2_2
  return L2_2
end

L8_1 = {}
L8_1.number = 1
L8_1.boolean = 2
L8_1.string = 3
L8_1.table = 4
L8_1["function"] = 5
L8_1.userdata = 6
L8_1.thread = 7

function L9_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = type
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = type
  L4_2 = A1_2
  L3_2 = L3_2(L4_2)
  if L2_2 == L3_2 and (L2_2 == "string" or L2_2 == "number") then
    L4_2 = A0_2 < A1_2
    return L4_2
  end
  L4_2 = L8_1
  L4_2 = L4_2[L2_2]
  L5_2 = L8_1
  L5_2 = L5_2[L3_2]
  if L4_2 and L5_2 then
    L6_2 = L8_1
    L6_2 = L6_2[L2_2]
    L7_2 = L8_1
    L7_2 = L7_2[L3_2]
    L6_2 = L6_2 < L7_2
    return L6_2
  elseif L4_2 then
    L6_2 = true
    return L6_2
  elseif L5_2 then
    L6_2 = false
    return L6_2
  end
  L6_2 = L2_2 < L3_2
  return L6_2
end

function L10_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = {}
  L2_2 = #A0_2
  L3_2 = pairs
  L4_2 = A0_2
  L3_2, L4_2, L5_2 = L3_2(L4_2)
  for L6_2, L7_2 in L3_2, L4_2, L5_2 do
    L8_2 = L7_1
    L9_2 = L6_2
    L10_2 = L2_2
    L8_2 = L8_2(L9_2, L10_2)
    if L8_2 then
      L8_2 = table
      L8_2 = L8_2.insert
      L9_2 = L1_2
      L10_2 = L6_2
      L8_2(L9_2, L10_2)
    end
  end
  L3_2 = table
  L3_2 = L3_2.sort
  L4_2 = L1_2
  L5_2 = L9_1
  L3_2(L4_2, L5_2)
  return L1_2
end

function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = type
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  L2_2 = rawget
  L3_2 = A1_2
  L4_2 = "__tostring"
  L2_2 = L2_2 == "table" and L2_2
  L3_2 = nil
  L4_2 = nil
  L5_2 = type
  L6_2 = L2_2
  L5_2 = L5_2(L6_2)
  if L5_2 == "function" then
    L5_2 = pcall
    L6_2 = L2_2
    L7_2 = A0_2
    L5_2, L6_2 = L5_2(L6_2, L7_2)
    L3_2 = L6_2
    L4_2 = L5_2
    if not L4_2 or not L3_2 then
      L5_2 = "error: "
      L6_2 = tostring
      L7_2 = L3_2
      L6_2 = L6_2(L7_2)
      L3_2 = L5_2 .. L6_2
    end
  end
  L5_2 = type
  L6_2 = L3_2
  L5_2 = L5_2(L6_2)
  if L5_2 == "string" then
    L5_2 = #L3_2
    if 0 < L5_2 then
      return L3_2
    end
  end
end

L12_1 = {}

function L13_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = rawset
  L3_2 = A0_2
  L4_2 = A1_2
  L5_2 = 0
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = 0
  return L2_2
end

L12_1.__index = L13_1
L13_1 = {}

function L14_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = setmetatable
  L3_2 = {}
  L4_2 = {}
  L4_2.__mode = "kv"
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = rawset
  L4_2 = A0_2
  L5_2 = A1_2
  L6_2 = L2_2
  L3_2(L4_2, L5_2, L6_2)
  return L2_2
end

L13_1.__index = L14_1

function L14_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  if not A1_2 then
    L2_2 = setmetatable
    L3_2 = {}
    L4_2 = {}
    L4_2.__mode = "k"
    L2_2 = L2_2(L3_2, L4_2)
    A1_2 = L2_2
  end
  L2_2 = type
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if L2_2 == "table" then
    L2_2 = A1_2[A0_2]
    if not L2_2 then
      A1_2[A0_2] = 1
      L2_2 = pairs
      L3_2 = A0_2
      L2_2, L3_2, L4_2 = L2_2(L3_2)
      for L5_2, L6_2 in L2_2, L3_2, L4_2 do
        L7_2 = L14_1
        L8_2 = L5_2
        L9_2 = A1_2
        L7_2(L8_2, L9_2)
        L7_2 = L14_1
        L8_2 = L6_2
        L9_2 = A1_2
        L7_2(L8_2, L9_2)
      end
      L2_2 = L14_1
      L3_2 = getmetatable
      L4_2 = A0_2
      L3_2 = L3_2(L4_2)
      L4_2 = A1_2
      L2_2(L3_2, L4_2)
    else
      L2_2 = A1_2[A0_2]
      L2_2 = L2_2 + 1
      A1_2[A0_2] = L2_2
    end
  end
  return A1_2
end

function L15_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if L1_2 == "function" then
    return A0_2
  end
  L1_2 = type
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if L1_2 ~= "table" or not A0_2 then
    L1_2 = {}
    L2_2 = A0_2
    L1_2[1] = L2_2
    A0_2 = L1_2
  end
  L1_2 = {}
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2 = L2_2(L3_2)
  for L5_2, L6_2 in L2_2, L3_2, L4_2 do
    L1_2[L6_2] = true
  end
  
  function L2_2(A0_3)
    local L1_3
    L1_3 = L1_2
    L1_3 = L1_3[A0_3]
    return L1_3
  end
  
  return L2_2
end

function L16_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = {}
  L3_2 = #A0_2
  L4_2 = 1
  L5_2 = L3_2
  L6_2 = 1
  for L7_2 = L4_2, L5_2, L6_2 do
    L8_2 = A0_2[L7_2]
    L2_2[L7_2] = L8_2
  end
  L4_2 = L3_2 + 1
  L2_2[L4_2] = A1_2
  return L2_2
end

function L17_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  if not A1_2 then
    L2_2 = {}
    A1_2 = L2_2
  end
  L2_2 = A1_2.depth
  if not L2_2 then
    L2_2 = math
    L2_2 = L2_2.huge
  end
  L3_2 = L15_1
  L4_2 = A1_2.filter
  if not L4_2 then
    L4_2 = {}
  end
  L3_2 = L3_2(L4_2)
  L4_2 = L14_1
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  L5_2 = {}
  L6_2 = setmetatable
  L7_2 = {}
  L8_2 = L12_1
  L6_2 = L6_2(L7_2, L8_2)
  L7_2 = setmetatable
  L8_2 = {}
  L9_2 = L13_1
  L7_2 = L7_2(L8_2, L9_2)
  L8_2 = 0
  L9_2 = 0
  
  function L10_2(...)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    L1_3 = {}
    L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3 = ...
    L1_3[1] = L2_3
    L1_3[2] = L3_3
    L1_3[3] = L4_3
    L1_3[4] = L5_3
    L1_3[5] = L6_3
    L1_3[6] = L7_3
    L1_3[7] = L8_3
    L1_3[8] = L9_3
    L2_3 = 1
    L3_3 = #L1_3
    L4_3 = 1
    for L5_3 = L2_3, L3_3, L4_3 do
      L6_3 = L9_2
      L6_3 = L6_3 + 1
      L9_2 = L6_3
      L6_3 = L5_2
      L7_3 = L9_2
      L8_3 = tostring
      L9_3 = L1_3[L5_3]
      L8_3 = L8_3(L9_3)
      L6_3[L7_3] = L8_3
    end
  end
  
  function L11_2(A0_3)
    local L1_3
    L1_3 = L8_2
    L1_3 = L1_3 + 1
    L8_2 = L1_3
    L1_3 = A0_3
    L1_3()
    L1_3 = L8_2
    L1_3 = L1_3 - 1
    L8_2 = L1_3
  end
  
  function L12_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    L0_3 = L10_2
    L1_3 = "\n"
    L2_3 = string
    L2_3 = L2_3.rep
    L3_3 = "  "
    L4_3 = L8_2
    L0_3(L1_3, L2_3(L3_3, L4_3))
  end
  
  function L13_2(A0_3)
    local L1_3, L2_3
    if A0_3 then
      L1_3 = L10_2
      L2_3 = ","
      L1_3(L2_3)
    end
    L1_3 = true
    return L1_3
  end
  
  function L14_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L7_2
    L2_3 = type
    L3_3 = A0_3
    L2_3 = L2_3(L3_3)
    L1_3 = L1_3[L2_3]
    L1_3 = L1_3[A0_3]
    L1_3 = L1_3 ~= nil
    return L1_3
  end
  
  function L15_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = type
    L2_3 = A0_3
    L1_3 = L1_3(L2_3)
    L2_3 = L7_2
    L2_3 = L2_3[L1_3]
    L2_3 = L2_3[A0_3]
    if not L2_3 then
      L3_3 = L6_2
      L3_3 = L3_3[L1_3]
      L2_3 = L3_3 + 1
      L3_3 = L6_2
      L3_3[L1_3] = L2_3
      L3_3 = L7_2
      L3_3 = L3_3[L1_3]
      L3_3[A0_3] = L2_3
    end
    return L2_3
  end
  
  L16_2 = nil
  
  function L17_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L5_1
    L2_3 = A0_3
    L1_3 = L1_3(L2_3)
    if L1_3 then
      L1_3 = L10_2
      L2_3 = A0_3
      return L1_3(L2_3)
    end
    L1_3 = L10_2
    L2_3 = "["
    L1_3(L2_3)
    L1_3 = L16_2
    L2_3 = A0_3
    L3_3 = {}
    L1_3(L2_3, L3_3)
    L1_3 = L10_2
    L2_3 = "]"
    L1_3(L2_3)
  end
  
  function L18_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L2_3 = L14_2
    L3_3 = A0_3
    L2_3 = L2_3(L3_3)
    if L2_3 then
      L2_3 = L10_2
      L3_3 = "<table "
      L4_3 = L15_2
      L5_3 = A0_3
      L4_3 = L4_3(L5_3)
      L5_3 = ">"
      L2_3(L3_3, L4_3, L5_3)
    else
      L2_3 = L8_2
      L3_3 = L2_2
      if L2_3 >= L3_3 then
        L2_3 = L10_2
        L3_3 = "{...}"
        L2_3(L3_3)
      else
        L2_3 = L4_2
        L2_3 = L2_3[A0_3]
        if 1 < L2_3 then
          L2_3 = L10_2
          L3_3 = "<"
          L4_3 = L15_2
          L5_3 = A0_3
          L4_3 = L4_3(L5_3)
          L5_3 = ">"
          L2_3(L3_3, L4_3, L5_3)
        end
        L2_3 = L10_1
        L3_3 = A0_3
        L2_3 = L2_3(L3_3)
        L3_3 = #A0_3
        L4_3 = getmetatable
        L5_3 = A0_3
        L4_3 = L4_3(L5_3)
        L5_3 = L11_1
        L6_3 = A0_3
        L7_3 = L4_3
        L5_3 = L5_3(L6_3, L7_3)
        L6_3 = L10_2
        L7_3 = "{"
        L6_3(L7_3)
        L6_3 = L11_2
        
        function L7_3()
          local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4
          L0_4 = L5_3
          if L0_4 then
            L0_4 = L10_2
            L1_4 = " -- "
            L2_4 = L4_1
            L3_4 = L5_3
            L0_4(L1_4, L2_4(L3_4))
            L0_4 = L3_3
            if 1 <= L0_4 then
              L0_4 = L12_2
              L0_4()
            end
          end
          L0_4 = false
          L1_4 = 1
          L2_4 = L3_3
          L3_4 = 1
          for L4_4 = L1_4, L2_4, L3_4 do
            L5_4 = L13_2
            L6_4 = L0_4
            L5_4 = L5_4(L6_4)
            L0_4 = L5_4
            L5_4 = L10_2
            L6_4 = " "
            L5_4(L6_4)
            L5_4 = L16_2
            L6_4 = A0_3
            L6_4 = L6_4[L4_4]
            L7_4 = L16_1
            L8_4 = A1_3
            L9_4 = L4_4
            L5_4(L6_4, L7_4(L8_4, L9_4))
          end
          L1_4 = ipairs
          L2_4 = L2_3
          L1_4, L2_4, L3_4 = L1_4(L2_4)
          for L4_4, L5_4 in L1_4, L2_4, L3_4 do
            L6_4 = L13_2
            L7_4 = L0_4
            L6_4 = L6_4(L7_4)
            L0_4 = L6_4
            L6_4 = L12_2
            L6_4()
            L6_4 = L17_2
            L7_4 = L5_4
            L6_4(L7_4)
            L6_4 = L10_2
            L7_4 = " = "
            L6_4(L7_4)
            L6_4 = L16_2
            L7_4 = A0_3
            L7_4 = L7_4[L5_4]
            L8_4 = L16_1
            L9_4 = A1_3
            L10_4 = L5_4
            L6_4(L7_4, L8_4(L9_4, L10_4))
          end
          L1_4 = L4_3
          if L1_4 then
            L1_4 = L13_2
            L2_4 = L0_4
            L1_4 = L1_4(L2_4)
            L0_4 = L1_4
            L1_4 = L12_2
            L1_4()
            L1_4 = L10_2
            L2_4 = "<metatable> = "
            L1_4(L2_4)
            L1_4 = L16_2
            L2_4 = L4_3
            L3_4 = L16_1
            L4_4 = A1_3
            L5_4 = "<metatable>"
            L1_4(L2_4, L3_4(L4_4, L5_4))
          end
        end
        
        L6_3(L7_3)
        L6_3 = #L2_3
        if 0 < L6_3 or L4_3 then
          L6_3 = L12_2
          L6_3()
        elseif 0 < L3_3 then
          L6_3 = L10_2
          L7_3 = " "
          L6_3(L7_3)
        end
        L6_3 = L10_2
        L7_3 = "}"
        L6_3(L7_3)
      end
    end
  end
  
  function L16_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L2_3 = L3_2
    L3_3 = A0_3
    L4_3 = A1_3
    L2_3 = L2_3(L3_3, L4_3)
    if L2_3 then
      L2_3 = L10_2
      L3_3 = "<filtered>"
      L2_3(L3_3)
    else
      L2_3 = type
      L3_3 = A0_3
      L2_3 = L2_3(L3_3)
      if L2_3 == "string" then
        L3_3 = L10_2
        L4_3 = L1_1
        L5_3 = L4_1
        L6_3 = A0_3
        L5_3, L6_3, L7_3, L8_3 = L5_3(L6_3)
        L3_3(L4_3(L5_3, L6_3, L7_3, L8_3))
      elseif L2_3 == "number" or L2_3 == "boolean" or L2_3 == "nil" then
        L3_3 = L10_2
        L4_3 = tostring
        L5_3 = A0_3
        L3_3(L4_3(L5_3))
      elseif L2_3 == "table" then
        L3_3 = L18_2
        L4_3 = A0_3
        L5_3 = A1_3
        L3_3(L4_3, L5_3)
      else
        L3_3 = L10_2
        L4_3 = "<"
        L5_3 = L2_3
        L6_3 = " "
        L7_3 = L15_2
        L8_3 = A0_3
        L7_3 = L7_3(L8_3)
        L8_3 = ">"
        L3_3(L4_3, L5_3, L6_3, L7_3, L8_3)
      end
    end
  end
  
  L19_2 = L16_2
  L20_2 = A0_2
  L21_2 = {}
  L19_2(L20_2, L21_2)
  L19_2 = table
  L19_2 = L19_2.concat
  L20_2 = L5_2
  return L19_2(L20_2)
end

L0_1.inspect = L17_1
L17_1 = setmetatable
L18_1 = L0_1
L19_1 = {}

function L20_1(A0_2, ...)
  local L2_2, L3_2
  L2_2 = L0_1
  L2_2 = L2_2.inspect
  L3_2 = ...
  return L2_2(L3_2)
end

L19_1.__call = L20_1
L17_1(L18_1, L19_1)
return L0_1
