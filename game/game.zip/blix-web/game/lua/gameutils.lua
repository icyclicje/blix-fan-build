local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1
L0_1 = {}
L1_1 = math
L1_1 = L1_1.sqrt
L2_1 = math
L2_1 = L2_1.pow
L3_1 = math
L3_1 = L3_1.ceil
L4_1 = math
L4_1 = L4_1.random
L5_1 = false
if L5_1 then
  L6_1 = log
  L6_1 = L6_1.show
  L7_1 = "gameutils.lua DEBUGGING"
  L6_1(L7_1)
end
L6_1 = {}
L7_1 = red
L8_1 = orange
L9_1 = yellow
L10_1 = green
L11_1 = blue
L12_1 = purple
L6_1[1] = L7_1
L6_1[2] = L8_1
L6_1[3] = L9_1
L6_1[4] = L10_1
L6_1[5] = L11_1
L6_1[6] = L12_1
L0_1.colors = L6_1

function L6_1()
  local L0_2, L1_2, L2_2
  L0_2 = L0_1
  L0_2 = L0_2.colors
  L1_2 = L4_1
  L2_2 = L0_1
  L2_2 = L2_2.colors
  L2_2 = #L2_2
  L1_2 = L1_2(L2_2)
  L0_2 = L0_2[L1_2]
  return L0_2
end

L0_1.getRandomColor = L6_1

function L6_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L5_2 = display
  L5_2 = L5_2.newEmbossedText
  L6_2 = "+"
  L7_2 = A2_2
  L6_2 = L6_2 .. L7_2
  L7_2 = A0_2
  L8_2 = _ttf_font_offset
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2 = L8_2[L9_2]
  L8_2 = L8_2 * A4_2
  L8_2 = A1_2 + L8_2
  L9_2 = _ttf_font
  L10_2 = globals
  L10_2 = L10_2.defaultFont
  L9_2 = L9_2[L10_2]
  L10_2 = A4_2
  L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  L7_2 = L5_2
  L6_2 = L5_2.setFillColor
  L8_2 = colors
  L8_2 = L8_2.getDarker
  L9_2 = A3_2
  L10_2 = 1
  L6_2(L7_2, L8_2(L9_2, L10_2))
  L7_2 = L5_2
  L6_2 = L5_2.setEmbossColor
  L8_2 = {}
  L9_2 = {}
  L9_2.r = 0
  L9_2.g = 0
  L9_2.b = 0
  L9_2.a = 0.12549019607843137
  L8_2.highlight = L9_2
  L9_2 = {}
  L9_2.r = 0
  L9_2.g = 0
  L9_2.b = 0
  L9_2.a = 0
  L8_2.shadow = L9_2
  L6_2(L7_2, L8_2)
  L6_2 = transition
  L6_2 = L6_2.to
  L7_2 = L5_2
  L8_2 = {}
  L8_2.delay = 700
  L8_2.time = 300
  L8_2.alpha = 0.1
  L9_2 = _canvasTop
  L8_2.y = L9_2
  L9_2 = easing
  L9_2 = L9_2.inQuad
  L8_2.transition = L9_2
  
  function L9_2()
    local L0_3, L1_3
    L0_3 = L5_2
    L1_3 = L0_3
    L0_3 = L0_3.removeSelf
    L0_3(L1_3)
  end
  
  L8_2.onComplete = L9_2
  L6_2(L7_2, L8_2)
  L6_2 = transition
  L6_2 = L6_2.to
  L7_2 = L5_2
  L8_2 = {}
  L8_2.delay = 700
  L8_2.time = 290
  L9_2 = _canvasW2
  L8_2.x = L9_2
  L6_2(L7_2, L8_2)
end

L0_1.showPopupScore = L6_1

function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L1_2 = 2
  L2_2 = _canvasLeft
  L2_2 = L2_2 + A0_2
  L2_2 = L2_2 + L1_2
  L3_2 = _canvasRight
  L3_2 = L3_2 - A0_2
  L3_2 = L3_2 - L1_2
  L4_2 = _canvasTop
  L4_2 = L4_2 + A0_2
  L4_2 = L4_2 + L1_2
  L5_2 = _canvasBottom
  L5_2 = L5_2 - A0_2
  L5_2 = L5_2 - L1_2
  L6_2 = target
  L6_2 = L6_2.list
  L6_2 = #L6_2
  L7_2 = obstacle
  L7_2 = L7_2.list
  L7_2 = #L7_2
  L8_2 = nil
  L9_2 = nil
  L10_2 = false
  L11_2 = 0
  while not L10_2 do
    L10_2 = true
    L12_2 = L4_1
    L13_2 = L2_2
    L14_2 = L3_2
    L12_2 = L12_2(L13_2, L14_2)
    L13_2 = L4_1
    L14_2 = L4_2
    L15_2 = L5_2
    L13_2 = L13_2(L14_2, L15_2)
    L9_2 = L13_2
    L8_2 = L12_2
    L12_2 = 1
    L13_2 = L6_2
    L14_2 = 1
    for L15_2 = L12_2, L13_2, L14_2 do
      L16_2 = target
      L16_2 = L16_2.list
      L16_2 = L16_2[L15_2]
      L17_2 = utils
      L17_2 = L17_2.distance
      L18_2 = L8_2
      L19_2 = L9_2
      L20_2 = L16_2.x
      L21_2 = L16_2.y
      L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2)
      L18_2 = L16_2.radius
      L18_2 = A0_2 + L18_2
      L18_2 = L18_2 + L1_2
      if L17_2 < L18_2 then
        L10_2 = false
      end
    end
    L12_2 = 1
    L13_2 = L7_2
    L14_2 = 1
    for L15_2 = L12_2, L13_2, L14_2 do
      L16_2 = obstacle
      L16_2 = L16_2.list
      L16_2 = L16_2[L15_2]
      L17_2 = utils
      L17_2 = L17_2.distance
      L18_2 = L8_2
      L19_2 = L9_2
      L20_2 = L16_2.x
      L21_2 = L16_2.y
      L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2)
      L18_2 = L16_2.radius
      L18_2 = A0_2 + L18_2
      L18_2 = L18_2 + L1_2
      if L17_2 < L18_2 then
        L10_2 = false
      end
    end
    if L10_2 == false then
      L11_2 = L11_2 + 1
      if 200 <= L11_2 then
        L12_2 = nil
        L13_2 = nil
        return L12_2, L13_2
      end
    end
  end
  L12_2 = L8_2
  L13_2 = L9_2
  return L12_2, L13_2
end

L0_1.getRandomOpenSpotForCircle = L6_1

function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2, L34_2, L35_2
  L1_2 = 25
  L2_2 = L1_2 / 2
  L4_2 = A0_2
  L3_2 = A0_2.getConservativeBounds
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  L7_2 = L4_2 - L3_2
  L7_2 = L7_2 + 1
  L8_2 = L6_2 - L5_2
  L8_2 = L8_2 + 1
  L9_2 = _canvasLeft
  L10_2 = L7_2 / 2
  L9_2 = L9_2 + L10_2
  L9_2 = L9_2 + L1_2
  L10_2 = _canvasRight
  L11_2 = L7_2 / 2
  L10_2 = L10_2 - L11_2
  L10_2 = L10_2 - L1_2
  L11_2 = _canvasTop
  L12_2 = L8_2 / 2
  L11_2 = L11_2 + L12_2
  L11_2 = L11_2 + L1_2
  L12_2 = _canvasBottom
  L13_2 = L8_2 / 2
  L12_2 = L12_2 - L13_2
  L12_2 = L12_2 - L1_2
  L13_2 = building_block
  L13_2 = L13_2.list
  L13_2 = #L13_2
  L14_2 = nil
  L15_2 = nil
  L16_2 = false
  L17_2 = 0
  while not L16_2 do
    L16_2 = true
    L18_2 = L4_1
    L19_2 = L9_2
    L20_2 = L10_2
    L18_2 = L18_2(L19_2, L20_2)
    L19_2 = L4_1
    L20_2 = L11_2
    L21_2 = L12_2
    L19_2 = L19_2(L20_2, L21_2)
    L15_2 = L19_2
    L14_2 = L18_2
    L18_2 = 1
    L19_2 = L13_2
    L20_2 = 1
    for L21_2 = L18_2, L19_2, L20_2 do
      L22_2 = building_block
      L22_2 = L22_2.list
      L22_2 = L22_2[L21_2]
      L24_2 = L22_2
      L23_2 = L22_2.getConservativeBounds
      L23_2, L24_2, L25_2, L26_2 = L23_2(L24_2)
      L27_2 = utils
      L27_2 = L27_2.intersectRect
      L28_2 = L23_2 - L2_2
      L29_2 = L24_2 + L2_2
      L30_2 = L25_2 - L2_2
      L31_2 = L26_2 + L2_2
      L32_2 = L7_2 / 2
      L32_2 = L14_2 - L32_2
      L32_2 = L32_2 - L2_2
      L33_2 = L7_2 / 2
      L33_2 = L14_2 + L33_2
      L33_2 = L33_2 + L2_2
      L34_2 = L8_2 / 2
      L34_2 = L15_2 - L34_2
      L34_2 = L34_2 - L2_2
      L35_2 = L8_2 / 2
      L35_2 = L15_2 + L35_2
      L35_2 = L35_2 + L2_2
      L27_2 = L27_2(L28_2, L29_2, L30_2, L31_2, L32_2, L33_2, L34_2, L35_2)
      if L27_2 then
        L16_2 = false
      end
    end
    if L16_2 == false then
      L17_2 = L17_2 + 1
      if 200 <= L17_2 then
        L18_2 = _SIMULATOR
        if L18_2 then
          L18_2 = print
          L19_2 = "Could not find a place for bb "
          L20_2 = A0_2.name
          L19_2 = L19_2 .. L20_2
          L18_2(L19_2)
        end
        L18_2 = nil
        L19_2 = nil
        return L18_2, L19_2
      end
    end
  end
  L18_2 = L14_2
  L19_2 = L15_2
  return L18_2, L19_2
end

L0_1.getRandomOpenSpotForBuildingBlock = L6_1
return L0_1
