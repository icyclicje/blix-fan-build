local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1
L0_1 = {}
L1_1 = math
L1_1 = L1_1.sqrt
L2_1 = math
L2_1 = L2_1.pow
L3_1 = math
L3_1 = L3_1.ceil
L4_1 = false
if L4_1 then
  L5_1 = log
  L5_1 = L5_1.show
  L6_1 = "palette.lua DEBUGGING"
  L5_1(L6_1)
end
L5_1 = screenHeight
L5_1 = L5_1 / 6
L0_1.size = L5_1
L5_1 = red
L0_1.selectedColor = L5_1

function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  L1_2 = display
  L1_2 = L1_2.newGroup
  L1_2 = L1_2()
  L3_2 = A0_2
  L2_2 = A0_2.insert
  L4_2 = L1_2
  L2_2(L3_2, L4_2)
  L2_2 = screenLeft
  L3_2 = L0_1
  L3_2 = L3_2.size
  L3_2 = L3_2 / 2
  L2_2 = L2_2 + L3_2
  L3_2 = screenTop
  L4_2 = L0_1
  L4_2 = L4_2.size
  L4_2 = L4_2 / 2
  L3_2 = L3_2 + L4_2
  L4_2 = L0_1
  L4_2 = L4_2.size
  L5_2 = nil
  L6_2 = nil
  L7_2 = nil
  L8_2 = nil
  L9_2 = nil
  L10_2 = nil
  L11_2 = nil
  
  function L12_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    L1_3 = L0_1
    L1_3 = L1_3.selectedColor
    L2_3 = red
    if L1_3 == L2_3 then
      L0_3 = L5_2
    end
    L1_3 = L0_1
    L1_3 = L1_3.selectedColor
    L2_3 = orange
    if L1_3 == L2_3 then
      L0_3 = L6_2
    end
    L1_3 = L0_1
    L1_3 = L1_3.selectedColor
    L2_3 = yellow
    if L1_3 == L2_3 then
      L0_3 = L7_2
    end
    L1_3 = L0_1
    L1_3 = L1_3.selectedColor
    L2_3 = green
    if L1_3 == L2_3 then
      L0_3 = L8_2
    end
    L1_3 = L0_1
    L1_3 = L1_3.selectedColor
    L2_3 = blue
    if L1_3 == L2_3 then
      L0_3 = L9_2
    end
    L1_3 = L0_1
    L1_3 = L1_3.selectedColor
    L2_3 = purple
    if L1_3 == L2_3 then
      L0_3 = L10_2
    end
    L1_3 = transition
    L1_3 = L1_3.to
    L2_3 = L11_2
    L3_3 = {}
    L3_3.time = 300
    L4_3 = L0_3.x
    L3_3.x = L4_3
    L4_3 = L0_3.y
    L3_3.y = L4_3
    L4_3 = easing
    L4_3 = L4_3.outExpo
    L3_3.transition = L4_3
    L1_3(L2_3, L3_3)
  end
  
  function L13_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = _inPlay
    if not L1_3 then
      L1_3 = false
      return L1_3
    end
    L1_3 = L0_1
    L1_3 = L1_3.selectedColor
    L2_3 = A0_3.target
    L2_3 = L2_3.color
    if L1_3 ~= L2_3 then
      L1_3 = L0_1
      L2_3 = A0_3.target
      L2_3 = L2_3.color
      L1_3.selectedColor = L2_3
      L1_3 = platform
      L1_3 = L1_3.android
      if not L1_3 then
        L1_3 = sounds
        L1_3 = L1_3.play
        L2_3 = A0_3.target
        L2_3 = L2_3.sound
        L3_3 = 0.5
        L1_3(L2_3, L3_3)
      else
        L1_3 = sounds
        L1_3 = L1_3.playFast
        L2_3 = A0_3.target
        L2_3 = L2_3.sound
        L1_3(L2_3)
      end
      L1_3 = L12_2
      L1_3()
    end
    L1_3 = true
    return L1_3
  end
  
  L14_2 = sounds
  L14_2 = L14_2.palette
  L15_2 = platform
  L15_2 = L15_2.android
  if L15_2 then
    L15_2 = sounds
    L14_2 = L15_2.palette_fast
  end
  L15_2 = display
  L15_2 = L15_2.newRect
  L16_2 = L1_2
  L17_2 = 0
  L18_2 = 0
  L19_2 = L4_2
  L20_2 = L4_2
  L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
  L5_2 = L15_2
  L15_2 = red
  L5_2.color = L15_2
  L15_2 = L14_2[1]
  L5_2.sound = L15_2
  L16_2 = L5_2
  L15_2 = L5_2.setFillColor
  L17_2 = red
  L15_2(L16_2, L17_2())
  L15_2 = L2_2
  L5_2.y = L3_2
  L5_2.x = L15_2
  L16_2 = L5_2
  L15_2 = L5_2.addEventListener
  L17_2 = "touch"
  L18_2 = L13_2
  L15_2(L16_2, L17_2, L18_2)
  L3_2 = L3_2 + L4_2
  L15_2 = display
  L15_2 = L15_2.newRect
  L16_2 = L1_2
  L17_2 = 0
  L18_2 = 0
  L19_2 = L4_2
  L20_2 = L4_2
  L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
  L6_2 = L15_2
  L15_2 = orange
  L6_2.color = L15_2
  L15_2 = L14_2[2]
  L6_2.sound = L15_2
  L16_2 = L6_2
  L15_2 = L6_2.setFillColor
  L17_2 = orange
  L15_2(L16_2, L17_2())
  L15_2 = L2_2
  L6_2.y = L3_2
  L6_2.x = L15_2
  L16_2 = L6_2
  L15_2 = L6_2.addEventListener
  L17_2 = "touch"
  L18_2 = L13_2
  L15_2(L16_2, L17_2, L18_2)
  L3_2 = L3_2 + L4_2
  L15_2 = display
  L15_2 = L15_2.newRect
  L16_2 = L1_2
  L17_2 = 0
  L18_2 = 0
  L19_2 = L4_2
  L20_2 = L4_2
  L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
  L7_2 = L15_2
  L15_2 = yellow
  L7_2.color = L15_2
  L15_2 = L14_2[3]
  L7_2.sound = L15_2
  L16_2 = L7_2
  L15_2 = L7_2.setFillColor
  L17_2 = yellow
  L15_2(L16_2, L17_2())
  L15_2 = L2_2
  L7_2.y = L3_2
  L7_2.x = L15_2
  L16_2 = L7_2
  L15_2 = L7_2.addEventListener
  L17_2 = "touch"
  L18_2 = L13_2
  L15_2(L16_2, L17_2, L18_2)
  L3_2 = L3_2 + L4_2
  L15_2 = display
  L15_2 = L15_2.newRect
  L16_2 = L1_2
  L17_2 = 0
  L18_2 = 0
  L19_2 = L4_2
  L20_2 = L4_2
  L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
  L8_2 = L15_2
  L15_2 = green
  L8_2.color = L15_2
  L15_2 = L14_2[4]
  L8_2.sound = L15_2
  L16_2 = L8_2
  L15_2 = L8_2.setFillColor
  L17_2 = green
  L15_2(L16_2, L17_2())
  L15_2 = L2_2
  L8_2.y = L3_2
  L8_2.x = L15_2
  L16_2 = L8_2
  L15_2 = L8_2.addEventListener
  L17_2 = "touch"
  L18_2 = L13_2
  L15_2(L16_2, L17_2, L18_2)
  L3_2 = L3_2 + L4_2
  L15_2 = display
  L15_2 = L15_2.newRect
  L16_2 = L1_2
  L17_2 = 0
  L18_2 = 0
  L19_2 = L4_2
  L20_2 = L4_2
  L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
  L9_2 = L15_2
  L15_2 = blue
  L9_2.color = L15_2
  L15_2 = L14_2[5]
  L9_2.sound = L15_2
  L16_2 = L9_2
  L15_2 = L9_2.setFillColor
  L17_2 = blue
  L15_2(L16_2, L17_2())
  L15_2 = L2_2
  L9_2.y = L3_2
  L9_2.x = L15_2
  L16_2 = L9_2
  L15_2 = L9_2.addEventListener
  L17_2 = "touch"
  L18_2 = L13_2
  L15_2(L16_2, L17_2, L18_2)
  L3_2 = L3_2 + L4_2
  L15_2 = display
  L15_2 = L15_2.newRect
  L16_2 = L1_2
  L17_2 = 0
  L18_2 = 0
  L19_2 = L4_2
  L20_2 = L4_2
  L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
  L10_2 = L15_2
  L15_2 = purple
  L10_2.color = L15_2
  L15_2 = L14_2[6]
  L10_2.sound = L15_2
  L16_2 = L10_2
  L15_2 = L10_2.setFillColor
  L17_2 = purple
  L15_2(L16_2, L17_2())
  L15_2 = L2_2
  L10_2.y = L3_2
  L10_2.x = L15_2
  L16_2 = L10_2
  L15_2 = L10_2.addEventListener
  L17_2 = "touch"
  L18_2 = L13_2
  L15_2(L16_2, L17_2, L18_2)
  L3_2 = L3_2 + L4_2
  L15_2 = display
  L15_2 = L15_2.newImageRect
  L16_2 = L1_2
  L17_2 = "images/palette_selection_square_240.png"
  L18_2 = L4_2
  L19_2 = L4_2
  L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2)
  L11_2 = L15_2
  L16_2 = L11_2
  L15_2 = L11_2.setFillColor
  L17_2 = black
  L15_2(L16_2, L17_2())
  L11_2.alpha = 0.25
  L15_2 = L5_2.x
  L16_2 = L5_2.y
  L11_2.y = L16_2
  L11_2.x = L15_2
  L15_2 = L12_2
  L15_2()
  return L1_2
end

L0_1.new = L5_1
return L0_1
