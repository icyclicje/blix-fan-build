local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1, L22_1, L23_1, L24_1, L25_1, L26_1, L27_1, L28_1
L0_1 = require
L1_1 = "composer"
L0_1 = L0_1(L1_1)
L1_1 = L0_1.newScene
L1_1 = L1_1()
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "scene_game.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = math
L3_1 = L3_1.random
L4_1 = nil
L5_1 = nil
L6_1 = nil
L7_1 = nil
L8_1 = nil
L9_1 = nil
L10_1 = nil
L11_1 = nil
L12_1 = nil
L13_1 = nil
L14_1 = nil
L15_1 = 20
_HEADER_HEIGHT = L15_1
L15_1 = nil
_group = L15_1
L15_1 = false
_game_started = L15_1
L15_1 = false
_game_ended = L15_1
L15_1 = false
_game_paused = L15_1
L15_1 = false
_inPlay = L15_1
L15_1 = 0
_lives = L15_1
L15_1 = 0
_score = L15_1
L15_1 = 0
_level = L15_1
L15_1 = 0
_dots_cleared = L15_1
L15_1 = 0
_frame_counter = L15_1
L15_1 = nil
L16_1 = nil
L17_1 = nil
L18_1 = nil
_canvasBottom = L18_1
_canvasTop = L17_1
_canvasRight = L16_1
_canvasLeft = L15_1
L15_1 = nil
L16_1 = nil
_canvasHeight = L16_1
_canvasWidth = L15_1
L15_1 = nil
L16_1 = nil
_canvasH2 = L16_1
_canvasW2 = L15_1
L15_1 = nil
L16_1 = nil
_canvasH3 = L16_1
_canvasW3 = L15_1
L15_1 = nil
L16_1 = nil
_canvasH4 = L16_1
_canvasW4 = L15_1
L15_1 = nil
L16_1 = nil
_canvasH34 = L16_1
_canvasW34 = L15_1
L15_1 = nil
L16_1 = nil
_canvasH23 = L16_1
_canvasW23 = L15_1
L15_1 = nil
L16_1 = nil
_canvasH5 = L16_1
_canvasW5 = L15_1
L15_1 = nil
L16_1 = nil
_canvasH45 = L16_1
_canvasW45 = L15_1
L15_1 = nil
_game = L15_1
L15_1 = false
_hasFrameRateProblems = L15_1
L15_1 = false
_hasFrameRateProblemsAgain = L15_1

function L15_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = _lives
  if L1_2 == 1 then
    L1_2 = L8_1
    L1_2.text = "1 Life"
  else
    L1_2 = L8_1
    L2_2 = _lives
    L3_2 = " Lives"
    L2_2 = L2_2 .. L3_2
    L1_2.text = L2_2
  end
  if A0_2 then
    L1_2 = utils
    L1_2 = L1_2.pop
    L2_2 = L8_1
    L1_2(L2_2)
  end
end

function L16_1(A0_2)
  local L1_2, L2_2, L3_2
  if A0_2 then
    L1_2 = timer
    L1_2 = L1_2.performWithDelay
    L2_2 = 1000
    
    function L3_2()
      local L0_3, L1_3, L2_3
      L0_3 = utils
      L0_3 = L0_3.pop
      L1_3 = L9_1
      L0_3(L1_3)
      L0_3 = L9_1
      L1_3 = "Score "
      L2_3 = _score
      L1_3 = L1_3 .. L2_3
      L0_3.text = L1_3
    end
    
    L1_2(L2_2, L3_2)
  else
    L1_2 = L9_1
    L2_2 = "Score "
    L3_2 = _score
    L2_2 = L2_2 .. L3_2
    L1_2.text = L2_2
  end
end

function L17_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = L10_1
  L2_2 = "Level "
  L3_2 = _level
  L2_2 = L2_2 .. L3_2
  L1_2.text = L2_2
  if A0_2 then
    L1_2 = utils
    L1_2 = L1_2.pop
    L2_2 = L10_1
    L1_2(L2_2)
  end
end

function L18_1()
  local L0_2, L1_2, L2_2
  L0_2 = sounds
  L0_2 = L0_2.play
  L1_2 = sounds
  L1_2 = L1_2.die
  L2_2 = 0.3
  L0_2(L1_2, L2_2)
  L0_2 = _lives
  L0_2 = L0_2 - 1
  _lives = L0_2
  L0_2 = L15_1
  L1_2 = true
  L0_2(L1_2)
  L0_2 = _lives
  if L0_2 <= 0 then
    L0_2 = _game
    L0_2 = L0_2.lives
    if L0_2 then
      L0_2 = _game
      L0_2 = L0_2.lives
      if 0 < L0_2 then
        L0_2 = _endGame
        L1_2 = 200
        L0_2(L1_2)
      end
    end
  end
end

_loseLife = L18_1

function L18_1(A0_2)
  local L1_2, L2_2
  _score = A0_2
  L1_2 = L16_1
  L2_2 = false
  L1_2(L2_2)
end

_setScore = L18_1

function L18_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = _score
  L2_2 = L2_2 + A0_2
  _score = L2_2
  L2_2 = _dots_cleared
  L2_2 = L2_2 + A1_2
  _dots_cleared = L2_2
  L2_2 = _game
  L2_2 = L2_2.addToScore
  if L2_2 then
    L2_2 = _game
    L3_2 = L2_2
    L2_2 = L2_2.addToScore
    L4_2 = A0_2
    L5_2 = A1_2
    L2_2(L3_2, L4_2, L5_2)
  end
  L2_2 = L16_1
  L3_2 = true
  L2_2(L3_2)
end

_addToScore = L18_1

function L18_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = _inPlay
  if L1_2 then
    L1_2 = _game_paused
    if not L1_2 then
      goto lbl_9
    end
  end
  L1_2 = false
  do return L1_2 end
  ::lbl_9::
  L1_2 = tostring
  L2_2 = A0_2.id
  L1_2 = L1_2(L2_2)
  L2_2 = A0_2.phase
  if L2_2 == "began" then
    L2_2 = _game
    L2_2 = L2_2.oneStrokeAtOnce
    if L2_2 then
      L2_2 = stroke
      L2_2 = L2_2.numInPlay
      if 0 < L2_2 then
        return
      end
    end
    L2_2 = L13_1
    L3_2 = stroke
    L3_2 = L3_2.new
    L4_2 = _group
    L5_2 = {}
    L5_2.thickness = 3
    L6_2 = palette
    L6_2 = L6_2.selectedColor
    L5_2.color = L6_2
    L3_2 = L3_2(L4_2, L5_2)
    L2_2[L1_2] = L3_2
    L2_2 = L13_1
    L2_2 = L2_2[L1_2]
    L3_2 = L2_2
    L2_2 = L2_2.addPoint
    L4_2 = A0_2.x
    L5_2 = A0_2.y
    L2_2(L3_2, L4_2, L5_2)
    L2_2 = _game
    L2_2 = L2_2.onStrokeStarted
    if L2_2 then
      L2_2 = _game
      L3_2 = L2_2
      L2_2 = L2_2.onStrokeStarted
      L4_2 = L13_1
      L4_2 = L4_2[L1_2]
      L2_2(L3_2, L4_2)
    end
    L2_2 = _game
    L2_2 = L2_2.oneStrokePerColorAtOnce
    if L2_2 then
      L2_2 = stroke
      L2_2 = L2_2.killAllStrokesOfColor
      L3_2 = palette
      L3_2 = L3_2.selectedColor
      L2_2(L3_2)
    end
  else
    L2_2 = A0_2.phase
    if L2_2 == "moved" then
      L2_2 = L13_1
      L2_2 = L2_2[L1_2]
      if L2_2 then
        L2_2 = L13_1
        L2_2 = L2_2[L1_2]
        L2_2 = L2_2.removed
        if not L2_2 then
          L2_2 = L13_1
          L2_2 = L2_2[L1_2]
          L3_2 = L2_2
          L2_2 = L2_2.addPoint
          L4_2 = A0_2.x
          L5_2 = A0_2.y
          L2_2(L3_2, L4_2, L5_2)
          L2_2 = _game
          L2_2 = L2_2.onStrokeAppended
          if L2_2 then
            L2_2 = _game
            L3_2 = L2_2
            L2_2 = L2_2.onStrokeAppended
            L4_2 = L13_1
            L4_2 = L4_2[L1_2]
            L2_2(L3_2, L4_2)
          end
        end
      end
    else
      L2_2 = A0_2.phase
      if L2_2 == "ended" then
        L2_2 = L13_1
        L2_2 = L2_2[L1_2]
        if L2_2 then
          L2_2 = L13_1
          L2_2 = L2_2[L1_2]
          L2_2 = L2_2.removed
          if not L2_2 then
            L2_2 = L13_1
            L2_2 = L2_2[L1_2]
            L3_2 = L2_2
            L2_2 = L2_2.endStroke
            L2_2(L3_2)
            L2_2 = L13_1
            L2_2 = L2_2[L1_2]
            L2_2 = L2_2.removed
            if not L2_2 then
              L2_2 = timer
              L2_2 = L2_2.performWithDelay
              L3_2 = L13_1
              L3_2 = L3_2[L1_2]
              L3_2 = L3_2.firstReplayDelay
              L3_2 = L3_2 * 3
              L3_2 = L3_2 / 4
              
              function L4_2()
                local L0_3, L1_3
                L0_3 = L13_1
                L1_3 = L1_2
                L0_3 = L0_3[L1_3]
                L0_3 = L0_3.removed
                if not L0_3 then
                  L0_3 = L13_1
                  L1_3 = L1_2
                  L0_3 = L0_3[L1_3]
                  L1_3 = L0_3
                  L0_3 = L0_3.startReplay
                  L0_3(L1_3)
                end
              end
              
              L2_2(L3_2, L4_2)
              L2_2 = _game
              L2_2 = L2_2.onStrokeFinished
              if L2_2 then
                L2_2 = _game
                L3_2 = L2_2
                L2_2 = L2_2.onStrokeFinished
                L4_2 = L13_1
                L4_2 = L4_2[L1_2]
                L2_2(L3_2, L4_2)
              end
            end
          end
        end
      end
    end
  end
end

function L19_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = _game_paused
  if L1_2 then
    return
  end
  L1_2 = _game_started
  if not L1_2 then
    return
  end
  L1_2 = _frame_counter
  L1_2 = L1_2 + 1
  _frame_counter = L1_2
  L1_2 = _inPlay
  if L1_2 then
    L1_2 = _frame_counter
    L1_2 = L1_2 % 3
    if L1_2 == 0 then
      L1_2 = stroke
      L1_2 = L1_2.findIntersectingTargets
      L1_2()
    end
  end
  L1_2 = _inPlay
  if L1_2 then
    L1_2 = _frame_counter
    L1_2 = L1_2 % 10
    if L1_2 == 0 then
      L1_2 = stroke
      L1_2 = L1_2.findIntersectingStrokes
      L1_2()
      L1_2 = stroke
      L1_2 = L1_2.findIntersectingObstacles
      L1_2()
    end
  end
  L1_2 = _inPlay
  if L1_2 then
    L1_2 = _frame_counter
    L1_2 = L1_2 % 30
    if L1_2 == 0 then
    end
  end
  L1_2 = _game
  L1_2 = L1_2.onEnterFrame
  if L1_2 then
    L1_2 = _game
    L2_2 = L1_2
    L1_2 = L1_2.onEnterFrame
    L3_2 = _frame_counter
    L1_2(L2_2, L3_2)
  end
end

function L20_1()
  local L0_2, L1_2
  L0_2 = stroke
  L0_2 = L0_2.removeAll
  L0_2()
  L0_2 = target
  L0_2 = L0_2.removeAll
  L0_2()
  L0_2 = obstacle
  L0_2 = L0_2.removeAll
  L0_2()
  L0_2 = building_block
  L0_2 = L0_2.removeAll
  L0_2()
  L0_2 = {}
  L13_1 = L0_2
end

function L21_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = _game_ended
  if L1_2 then
    return
  end
  L1_2 = _level
  if 0 < L1_2 then
    L1_2 = sounds
    L1_2 = L1_2.play
    L2_2 = sounds
    L2_2 = L2_2.levelup
    L3_2 = 1
    L1_2(L2_2, L3_2)
  end
  L1_2 = _level
  L1_2 = L1_2 + 1
  _level = L1_2
  L1_2 = L17_1
  L2_2 = _level
  L2_2 = 1 < L2_2
  L1_2(L2_2)
  L1_2 = L20_1
  L1_2()
  L1_2 = timer
  L1_2 = L1_2.performWithDelay
  L2_2 = A0_2 or L2_2
  if not A0_2 then
    L2_2 = 0
  end
  
  function L3_2()
    local L0_3, L1_3, L2_3
    L0_3 = _game
    L0_3 = L0_3.onLevelUp
    if L0_3 then
      L0_3 = _game
      L1_3 = L0_3
      L0_3 = L0_3.onLevelUp
      L2_3 = _level
      L0_3(L1_3, L2_3)
    end
  end
  
  L1_2(L2_2, L3_2)
end

_levelUp = L21_1

function L21_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = Runtime
  L1_2 = L0_2
  L0_2 = L0_2.removeEventListener
  L2_2 = "touch"
  L3_2 = L18_1
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = Runtime
  L1_2 = L0_2
  L0_2 = L0_2.removeEventListener
  L2_2 = "enterFrame"
  L3_2 = L19_1
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = system
  L0_2 = L0_2.deactivate
  L1_2 = "multitouch"
  L0_2(L1_2)
  L0_2 = L20_1
  L0_2()
  L0_2 = _game
  L0_2 = L0_2.onCleanUp
  if L0_2 then
    L0_2 = _game
    L1_2 = L0_2
    L0_2 = L0_2.onCleanUp
    L0_2(L1_2)
  end
end

function L22_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = sounds
  L1_2 = L1_2.play
  L2_2 = sounds
  L2_2 = L2_2.endGame
  L1_2(L2_2)
  L1_2 = false
  _game_paused = L1_2
  L1_2 = true
  _game_ended = L1_2
  L1_2 = false
  _inPlay = L1_2
  L1_2 = _game
  L1_2 = L1_2.onEndGame
  if L1_2 then
    L1_2 = _game
    L2_2 = L1_2
    L1_2 = L1_2.onEndGame
    L1_2(L2_2)
  end
  L1_2 = progress
  L1_2 = L1_2.reportScore
  L2_2 = _game
  L2_2 = L2_2.name
  L3_2 = _score
  L4_2 = _level
  L5_2 = _dots_cleared
  L1_2(L2_2, L3_2, L4_2, L5_2)
  L1_2 = ltv
  L1_2 = L1_2.recordGamePlayed
  L1_2()
  L1_2 = analytics
  L1_2 = L1_2.logEvent
  L2_2 = "Game Ended - "
  L3_2 = _game
  L3_2 = L3_2.name
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
  
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    
    function L0_3()
      local L0_4, L1_4
      L0_4 = L21_1
      L0_4()
      L0_4 = _setupGame
      L1_4 = _group
      L0_4(L1_4)
      L0_4 = _startGame
      L1_4 = _group
      L0_4(L1_4)
    end
    
    L1_3 = L0_1
    L1_3 = L1_3.showOverlay
    L2_3 = "_scene_result"
    L3_3 = {}
    L3_3.isModal = true
    L3_3.effect = "zoomOutIn"
    L3_3.time = 100
    L4_3 = {}
    L4_3.retryFn = L0_3
    L5_3 = black
    L4_3.textColor = L5_3
    L4_3.bgStrokeWidth = 2
    L5_3 = darkgray
    L4_3.bgStrokeColor = L5_3
    L5_3 = white
    L4_3.bgColor = L5_3
    L4_3.bgAlpha = 1
    L5_3 = _game
    L5_3 = L5_3.leveling
    L4_3.showLevel = L5_3
    L5_3 = progress
    L5_3 = L5_3.getHighScore
    L6_3 = _game
    L6_3 = L6_3.name
    L5_3 = L5_3(L6_3)
    L4_3.highScore = L5_3
    L5_3 = "I scored "
    L6_3 = _score
    L7_3 = " in "
    L8_3 = _game
    L8_3 = L8_3.displayName
    L9_3 = " of "
    L10_3 = APP_NAME
    L11_3 = "! "
    L5_3 = L5_3 .. L6_3 .. L7_3 .. L8_3 .. L9_3 .. L10_3 .. L11_3
    L4_3.shareMsgPrefix = L5_3
    L3_3.params = L4_3
    L1_3(L2_3, L3_3)
  end
  
  L2_2 = timerStash
  L3_2 = timer
  L3_2 = L3_2.performWithDelay
  L4_2 = A0_2 or L4_2
  if not A0_2 then
    L4_2 = 1
  end
  L5_2 = L1_2
  L3_2 = L3_2(L4_2, L5_2)
  L2_2["endgame popupDelay"] = L3_2
end

_endGame = L22_1

function L22_1()
  local L0_2, L1_2, L2_2
  L0_2 = frame_rate
  L0_2 = L0_2.getNumberOfAlertsSoFarThisMeasurementSession
  L0_2 = L0_2()
  if 2 <= L0_2 then
    L0_2 = true
    _hasFrameRateProblems = L0_2
  end
  L0_2 = frame_rate
  L0_2 = L0_2.getNumberOfAlertsSoFarThisMeasurementSession
  L0_2 = L0_2()
  if 4 <= L0_2 then
    L0_2 = true
    _hasFrameRateProblemsAgain = L0_2
  end
  L0_2 = _hasFrameRateProblems
  if L0_2 then
    L0_2 = L2_1
    if L0_2 then
      L0_2 = log
      L0_2 = L0_2.show
      L1_2 = "Frame rate alerts = "
      L2_2 = frame_rate
      L2_2 = L2_2.getNumberOfAlertsSoFarThisMeasurementSession
      L2_2 = L2_2()
      L1_2 = L1_2 .. L2_2
      L0_2(L1_2)
    end
  end
end

function L23_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = true
  _game_started = L0_2
  L0_2 = true
  _inPlay = L0_2
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Game Started - "
  L2_2 = _game
  L2_2 = L2_2.name
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = frame_rate
  L0_2 = L0_2.measureFrameRate
  L1_2 = 60000
  L2_2 = L2_1
  L3_2 = nil
  L4_2 = L22_1
  L5_2 = 40
  L0_2(L1_2, L2_2, L3_2, L4_2, L5_2)
  L0_2 = Runtime
  L1_2 = L0_2
  L0_2 = L0_2.addEventListener
  L2_2 = "touch"
  L3_2 = L18_1
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = Runtime
  L1_2 = L0_2
  L0_2 = L0_2.addEventListener
  L2_2 = "enterFrame"
  L3_2 = L19_1
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = _game
  L0_2 = L0_2.multitouch
  if L0_2 then
    L0_2 = system
    L0_2 = L0_2.activate
    L1_2 = "multitouch"
    L0_2(L1_2)
  end
  L0_2 = _levelUp
  L0_2()
  L0_2 = _game
  L0_2 = L0_2.onStartGame
  if L0_2 then
    L0_2 = _game
    L1_2 = L0_2
    L0_2 = L0_2.onStartGame
    L0_2(L1_2)
  end
end

_startGame = L23_1

function L23_1()
  local L0_2, L1_2
  L0_2 = _game
  L0_2 = L0_2.lives
  if not L0_2 then
    L0_2 = 0
  end
  _lives = L0_2
  L0_2 = 0
  _score = L0_2
  L0_2 = 0
  _level = L0_2
  L0_2 = 0
  _dots_cleared = L0_2
  L0_2 = false
  _game_started = L0_2
  L0_2 = false
  _game_ended = L0_2
  L0_2 = false
  _game_paused = L0_2
  L0_2 = false
  _inPlay = L0_2
  L0_2 = {}
  L13_1 = L0_2
  L0_2 = L15_1
  L1_2 = false
  L0_2(L1_2)
  L0_2 = L16_1
  L1_2 = false
  L0_2(L1_2)
  L0_2 = L17_1
  L1_2 = false
  L0_2(L1_2)
  L0_2 = L8_1
  L1_2 = L0_2
  L0_2 = L0_2.toFront
  L0_2(L1_2)
  L0_2 = L10_1
  L1_2 = L0_2
  L0_2 = L0_2.toFront
  L0_2(L1_2)
  L0_2 = L9_1
  L1_2 = L0_2
  L0_2 = L0_2.toFront
  L0_2(L1_2)
  L0_2 = L8_1
  L1_2 = _game
  L1_2 = L1_2.lives
  if L1_2 then
    L1_2 = _game
    L1_2 = L1_2.lives
    L1_2 = 0 < L1_2
  end
  L0_2.isVisible = L1_2
  L0_2 = L9_1
  L1_2 = _game
  L1_2 = L1_2.scoring
  L0_2.isVisible = L1_2
  L0_2 = L10_1
  L1_2 = _game
  L1_2 = L1_2.leveling
  L0_2.isVisible = L1_2
  L0_2 = L11_1
  L0_2.text = "Pause"
  L0_2 = L11_1
  L1_2 = L0_2
  L0_2 = L0_2.render
  L0_2(L1_2)
  L0_2 = L11_1
  L0_2.isVisible = false
  L0_2 = L12_1
  L0_2.isVisible = false
  L0_2 = L11_1
  L1_2 = L0_2
  L0_2 = L0_2.toFront
  L0_2(L1_2)
  L0_2 = L12_1
  L1_2 = L0_2
  L0_2 = L0_2.toFront
  L0_2(L1_2)
  L0_2 = _game
  L0_2 = L0_2.onSetupGame
  if L0_2 then
    L0_2 = _game
    L1_2 = L0_2
    L0_2 = L0_2.onSetupGame
    L0_2(L1_2)
  end
end

_setupGame = L23_1

function L23_1()
  local L0_2, L1_2, L2_2
  L0_2 = _game_paused
  if not L0_2 then
    L0_2 = true
    _game_paused = L0_2
    L0_2 = L11_1
    L0_2.text = "Continue"
    L0_2 = L11_1
    L1_2 = L0_2
    L0_2 = L0_2.render
    L0_2(L1_2)
    L0_2 = L12_1
    L0_2.isVisible = true
    L0_2 = _game
    L0_2 = L0_2.onPauseGame
    if L0_2 then
      L0_2 = _game
      L1_2 = L0_2
      L0_2 = L0_2.onPauseGame
      L0_2(L1_2)
    end
    L0_2 = analytics
    L0_2 = L0_2.logEvent
    L1_2 = "Game Paused - "
    L2_2 = _game
    L2_2 = L2_2.name
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
  else
    L0_2 = false
    _game_paused = L0_2
    L0_2 = L11_1
    L0_2.text = "Pause"
    L0_2 = L11_1
    L1_2 = L0_2
    L0_2 = L0_2.render
    L0_2(L1_2)
    L0_2 = L12_1
    L0_2.isVisible = false
    L0_2 = _game
    L0_2 = L0_2.onContinueGame
    if L0_2 then
      L0_2 = _game
      L1_2 = L0_2
      L0_2 = L0_2.onContinueGame
      L0_2(L1_2)
    end
    L0_2 = analytics
    L0_2 = L0_2.logEvent
    L1_2 = "Game Continued - "
    L2_2 = _game
    L2_2 = L2_2.name
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
  end
end

function L24_1()
  local L0_2, L1_2, L2_2
  L0_2 = L0_1
  L0_2 = L0_2.gotoScene
  L1_2 = "scene_title"
  L0_2(L1_2)
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Game Quit - "
  L2_2 = _game
  L2_2 = L2_2.name
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
end

function L25_1()
  local L0_2, L1_2
  L0_2 = L5_1
  L1_2 = L0_2
  L0_2 = L0_2.toBack
  L0_2(L1_2)
  L0_2 = L5_1
  L1_2 = L0_2
  L0_2 = L0_2.toBack
  L0_2(L1_2)
end

_moveBgToBack = L25_1

function L25_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_game:create()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = palette
  L3_2 = L3_2.new
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L6_1 = L3_2
  L3_2 = display
  L3_2 = L3_2.newRect
  L4_2 = L2_2
  L5_2 = _W2
  L6_2 = screenTop
  L7_2 = _HEADER_HEIGHT
  L7_2 = L7_2 / 2
  L6_2 = L6_2 + L7_2
  L7_2 = screenWidth
  L8_2 = _HEADER_HEIGHT
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L7_1 = L3_2
  L3_2 = L7_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = verylightgray
  L3_2(L4_2, L5_2())
  L3_2 = screenLeft
  L4_2 = L6_1
  L4_2 = L4_2.width
  L3_2 = L3_2 + L4_2
  _canvasLeft = L3_2
  L3_2 = screenTop
  L4_2 = L7_1
  L4_2 = L4_2.height
  L3_2 = L3_2 + L4_2
  _canvasTop = L3_2
  L3_2 = screenRight
  _canvasRight = L3_2
  L3_2 = screenBottom
  _canvasBottom = L3_2
  L3_2 = screenRight
  L4_2 = screenLeft
  L3_2 = L3_2 - L4_2
  _canvasWidth = L3_2
  L3_2 = screenBottom
  L4_2 = screenTop
  L3_2 = L3_2 - L4_2
  _canvasHeight = L3_2
  L3_2 = _canvasLeft
  L4_2 = _canvasRight
  L3_2 = L3_2 + L4_2
  L3_2 = L3_2 / 2
  _canvasW2 = L3_2
  L3_2 = _canvasTop
  L4_2 = _canvasBottom
  L3_2 = L3_2 + L4_2
  L3_2 = L3_2 / 2
  _canvasH2 = L3_2
  L3_2 = _canvasLeft
  L4_2 = _canvasW2
  L3_2 = L3_2 + L4_2
  L3_2 = L3_2 / 2
  _canvasW4 = L3_2
  L3_2 = _canvasRight
  L4_2 = _canvasW2
  L3_2 = L3_2 + L4_2
  L3_2 = L3_2 / 2
  _canvasW34 = L3_2
  L3_2 = _canvasTop
  L4_2 = _canvasH2
  L3_2 = L3_2 + L4_2
  L3_2 = L3_2 / 2
  _canvasH4 = L3_2
  L3_2 = _canvasBottom
  L4_2 = _canvasH2
  L3_2 = L3_2 + L4_2
  L3_2 = L3_2 / 2
  _canvasH34 = L3_2
  L3_2 = _canvasLeft
  L4_2 = _canvasWidth
  L4_2 = L4_2 / 3
  L3_2 = L3_2 + L4_2
  _canvasW3 = L3_2
  L3_2 = _canvasRight
  L4_2 = _canvasWidth
  L4_2 = L4_2 / 3
  L3_2 = L3_2 - L4_2
  _canvasW23 = L3_2
  L3_2 = _canvasTop
  L4_2 = _canvasHeight
  L4_2 = L4_2 / 3
  L3_2 = L3_2 + L4_2
  _canvasH3 = L3_2
  L3_2 = _canvasBottom
  L4_2 = _canvasHeight
  L4_2 = L4_2 / 3
  L3_2 = L3_2 - L4_2
  _canvasH23 = L3_2
  L3_2 = _canvasLeft
  L4_2 = _canvasWidth
  L4_2 = L4_2 / 5
  L3_2 = L3_2 + L4_2
  _canvasW5 = L3_2
  L3_2 = _canvasRight
  L4_2 = _canvasWidth
  L4_2 = L4_2 / 5
  L3_2 = L3_2 - L4_2
  _canvasW45 = L3_2
  L3_2 = _canvasTop
  L4_2 = _canvasHeight
  L4_2 = L4_2 / 5
  L3_2 = L3_2 + L4_2
  _canvasH5 = L3_2
  L3_2 = _canvasBottom
  L4_2 = _canvasHeight
  L4_2 = L4_2 / 5
  L3_2 = L3_2 - L4_2
  _canvasH45 = L3_2
  L3_2 = display
  L3_2 = L3_2.newRect
  L4_2 = L2_2
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = screenWidth
  L8_2 = screenHeight
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L4_1 = L3_2
  L3_2 = L4_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = white
  L3_2(L4_2, L5_2())
  L3_2 = display
  L3_2 = L3_2.newImageRect
  L4_2 = L2_2
  L5_2 = "images/graph_paper_1230x919.jpg"
  L6_2 = screenWidth
  L7_2 = screenWidth
  L7_2 = L7_2 * 919
  L7_2 = L7_2 / 1230
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2)
  L5_1 = L3_2
  L3_2 = L5_1
  L3_2.alpha = 0.15
  L3_2 = L5_1
  L4_2 = L5_1
  L5_2 = _canvasW2
  L6_2 = _canvasH2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = display
  L3_2 = L3_2.newText
  L4_2 = L2_2
  L5_2 = "Lives 0"
  L6_2 = 0
  L7_2 = 0
  L8_2 = _ttf_font
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2 = L8_2[L9_2]
  L9_2 = 15
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L8_1 = L3_2
  L3_2 = L8_1
  L4_2 = L8_1
  L5_2 = 0
  L4_2.anchorY = 0.5
  L3_2.anchorX = L5_2
  L3_2 = L8_1
  L4_2 = L8_1
  L5_2 = _canvasLeft
  L5_2 = L5_2 + 4
  L6_2 = screenTop
  L7_2 = _HEADER_HEIGHT
  L7_2 = L7_2 / 2
  L6_2 = L6_2 + L7_2
  L7_2 = _ttf_font_offset
  L8_2 = globals
  L8_2 = L8_2.defaultFont
  L7_2 = L7_2[L8_2]
  L7_2 = L7_2 * 15
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = L8_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = darkgray
  L3_2(L4_2, L5_2())
  L3_2 = display
  L3_2 = L3_2.newText
  L4_2 = L2_2
  L5_2 = "0"
  L6_2 = 0
  L7_2 = 0
  L8_2 = _ttf_font
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2 = L8_2[L9_2]
  L9_2 = 15
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L9_1 = L3_2
  L3_2 = L9_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = darkgray
  L3_2(L4_2, L5_2())
  L3_2 = L9_1
  L4_2 = L9_1
  L5_2 = _canvasW2
  L6_2 = screenTop
  L7_2 = _HEADER_HEIGHT
  L7_2 = L7_2 / 2
  L6_2 = L6_2 + L7_2
  L7_2 = _ttf_font_offset
  L8_2 = globals
  L8_2 = L8_2.defaultFont
  L7_2 = L7_2[L8_2]
  L7_2 = L7_2 * 15
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = display
  L3_2 = L3_2.newText
  L4_2 = L2_2
  L5_2 = "Level 0"
  L6_2 = 0
  L7_2 = 0
  L8_2 = _ttf_font
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2 = L8_2[L9_2]
  L9_2 = 15
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L10_1 = L3_2
  L3_2 = L10_1
  L4_2 = L10_1
  L5_2 = 1
  L4_2.anchorY = 0.5
  L3_2.anchorX = L5_2
  L3_2 = L10_1
  L4_2 = L10_1
  L5_2 = _canvasRight
  L5_2 = L5_2 - 4
  L6_2 = screenTop
  L7_2 = _HEADER_HEIGHT
  L7_2 = L7_2 / 2
  L6_2 = L6_2 + L7_2
  L7_2 = _ttf_font_offset
  L8_2 = globals
  L8_2 = L8_2.defaultFont
  L7_2 = L7_2[L8_2]
  L7_2 = L7_2 * 15
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = L10_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = darkgray
  L3_2(L4_2, L5_2())
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = "Pause"
  L5_2 = L23_1
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = white
  L6_2.textColor = L7_2
  L6_2.alphaWhenEnabled = 0.6
  L6_2.frameless = true
  L6_2.fixedWidth = 180
  L6_2.fixedHeight = 50
  L6_2.textAnchorX = 0
  L6_2.fontSize = 16
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2.fontNum = L7_2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L11_1 = L3_2
  L3_2 = L11_1
  L4_2 = L11_1
  L5_2 = 0
  L4_2.anchorY = 0
  L3_2.anchorX = L5_2
  L3_2 = L11_1
  L4_2 = L11_1
  L5_2 = _canvasLeft
  L5_2 = L5_2 - 84
  L6_2 = screenTop
  L6_2 = L6_2 - 14
  L7_2 = _ttf_font_offset
  L8_2 = globals
  L8_2 = L8_2.defaultFont
  L7_2 = L7_2[L8_2]
  L7_2 = L7_2 * 16
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = "Quit"
  L5_2 = L24_1
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = white
  L6_2.textColor = L7_2
  L6_2.alphaWhenEnabled = 0.6
  L6_2.frameless = true
  L6_2.fixedWidth = 180
  L6_2.fixedHeight = 50
  L6_2.textAnchorX = 1
  L6_2.fontSize = 16
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2.fontNum = L7_2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L12_1 = L3_2
  L3_2 = L12_1
  L4_2 = L12_1
  L5_2 = 2
  L4_2.anchorY = 0
  L3_2.anchorX = L5_2
  L3_2 = L12_1
  L4_2 = L12_1
  L5_2 = screenRight
  L5_2 = L5_2 + 84
  L6_2 = screenTop
  L6_2 = L6_2 - 14
  L7_2 = _ttf_font_offset
  L8_2 = globals
  L8_2 = L8_2.defaultFont
  L7_2 = L7_2[L8_2]
  L7_2 = L7_2 * 16
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = L5_1
  L4_2 = L3_2
  L3_2 = L3_2.toBack
  L3_2(L4_2)
  L3_2 = L4_1
  L4_2 = L3_2
  L3_2 = L3_2.toBack
  L3_2(L4_2)
  L3_2 = L6_1
  L4_2 = L3_2
  L3_2 = L3_2.toFront
  L3_2(L4_2)
end

L1_1.create = L25_1

function L25_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_game:show() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
      L3_2 = A1_2.params
      if not L3_2 then
        L3_2 = {}
        _game = L3_2
        L3_2 = toast
        L3_2 = L3_2.show
        L4_2 = "An error occurred."
        L5_2 = {}
        L5_2.time = 2000
        L6_2 = red
        L5_2.textColor = L6_2
        L3_2(L4_2, L5_2)
        L3_2 = timer
        L3_2 = L3_2.performWithDelay
        L4_2 = 500
        
        function L5_2()
          local L0_3, L1_3
          L0_3 = L0_1
          L0_3 = L0_3.gotoScene
          L1_3 = "scene_title"
          L0_3(L1_3)
        end
        
        L3_2(L4_2, L5_2)
        L3_2 = analytics
        L3_2 = L3_2.logEvent
        L4_2 = "ERROR event.params==nil"
        L3_2(L4_2)
        return
      end
      L3_2 = A1_2.params
      L3_2 = L3_2.game
      if not L3_2 then
        L3_2 = {}
      end
      _game = L3_2
      L3_2 = A1_2.params
      L3_2 = L3_2.skip_instructions
      L14_1 = L3_2
      L3_2 = false
      L4_2 = false
      _hasFrameRateProblemsAgain = L4_2
      _hasFrameRateProblems = L3_2
      _group = L2_2
      L3_2 = transition
      L3_2 = L3_2.from
      L4_2 = L6_1
      L5_2 = {}
      L5_2.time = 1000
      L6_2 = screenRight
      L5_2.x = L6_2
      L6_2 = easing
      L6_2 = L6_2.outBack
      L5_2.transition = L6_2
      L3_2(L4_2, L5_2)
      L3_2 = _setupGame
      L3_2()
      L3_2 = progress
      L3_2 = L3_2.getHighScore
      L4_2 = _game
      L4_2 = L4_2.name
      L3_2 = L3_2(L4_2)
      if L3_2 ~= 0 then
      end
      L3_2 = _game
      L3_2 = L3_2.instructions
      if L3_2 then
        L3_2 = L14_1
        if not L3_2 then
          L3_2 = L0_1
          L3_2 = L3_2.showOverlay
          L4_2 = "_scene_popup"
          L5_2 = {}
          L5_2.isModal = true
          L6_2 = {}
          L7_2 = "High Score: "
          L8_2 = progress
          L8_2 = L8_2.getHighScore
          L9_2 = _game
          L9_2 = L9_2.name
          L8_2 = L8_2(L9_2)
          L7_2 = L7_2 .. L8_2
          L6_2.title = L7_2
          L6_2.bgStrokeWidth = 2
          L7_2 = black
          L6_2.bgStrokeColor = L7_2
          L7_2 = white
          L6_2.bgColor = L7_2
          L6_2.bgAlpha = 1
          L6_2.dimAlpha = 0.1
          L6_2.lineSpacingAdjust = 6
          L7_2 = gray
          L6_2.titleColor = L7_2
          L6_2.textWidth = 250
          L6_2.fontSize = 20
          L7_2 = _game
          L7_2 = L7_2.instructions
          L6_2.text = L7_2
          L7_2 = darkgray
          L6_2.textColor = L7_2
          L6_2.okText = "Start!"
          L7_2 = red
          L6_2.okTextColor = L7_2
          L7_2 = _startGame
          L6_2.okCallBackFn = L7_2
          L5_2.params = L6_2
          L3_2(L4_2, L5_2)
      end
      else
        L3_2 = _startGame
        L3_2()
      end
    end
  end
end

L1_1.show = L25_1

function L25_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_game:hide() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
    L3_2 = L21_1
    L3_2()
    L3_2 = utils
    L3_2 = L3_2.cancelAllTimersAndTransitions
    L3_2()
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
    end
  end
end

L1_1.hide = L25_1

function L25_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_game:destroy()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
end

L1_1.destroy = L25_1
L26_1 = L1_1
L25_1 = L1_1.addEventListener
L27_1 = "create"
L28_1 = L1_1
L25_1(L26_1, L27_1, L28_1)
L26_1 = L1_1
L25_1 = L1_1.addEventListener
L27_1 = "show"
L28_1 = L1_1
L25_1(L26_1, L27_1, L28_1)
L26_1 = L1_1
L25_1 = L1_1.addEventListener
L27_1 = "hide"
L28_1 = L1_1
L25_1(L26_1, L27_1, L28_1)
L26_1 = L1_1
L25_1 = L1_1.addEventListener
L27_1 = "destroy"
L28_1 = L1_1
L25_1(L26_1, L27_1, L28_1)
return L1_1
