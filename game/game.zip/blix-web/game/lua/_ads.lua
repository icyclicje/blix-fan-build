local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1, L22_1, L23_1, L24_1, L25_1, L26_1
L0_1 = {}
L1_1 = require
L2_1 = "json"
L1_1 = L1_1(L2_1)
L2_1 = 1
L3_1 = 2
L4_1 = 3
L5_1 = 4
L6_1 = 5
L7_1 = false
if L7_1 then
  L8_1 = log
  L8_1 = L8_1.show
  L9_1 = "_ads.lua DEBUGGING"
  L8_1(L9_1)
end
L8_1 = false
if L8_1 then
  L9_1 = log
  L9_1 = L9_1.show
  L10_1 = "_ads.lua HACK_MANY_ADS"
  L9_1(L10_1)
end
L9_1 = 0
L10_1 = nil
L11_1 = nil
L12_1 = nil
L13_1 = math
L13_1 = L13_1.randomseed
L14_1 = os
L14_1 = L14_1.time
L13_1(L14_1())
L13_1 = require
L14_1 = "_applovin"
L13_1 = L13_1(L14_1)
L14_1 = platform
L14_1 = L14_1.ios
L15_1 = require
L16_1 = "ads"
L15_1 = L15_1(L16_1)
L16_1 = platform
L16_1 = L16_1.android
if L16_1 then
  L16_1 = platform
  L16_1 = L16_1.version
  L17_1 = L16_1
  L16_1 = L16_1.startsWith
  L18_1 = "1"
  L16_1 = L16_1(L17_1, L18_1)
  if not L16_1 then
    L16_1 = platform
    L16_1 = L16_1.version
    L17_1 = L16_1
    L16_1 = L16_1.startsWith
    L18_1 = "2.0"
    L16_1 = L16_1(L17_1, L18_1)
    if not L16_1 then
      L16_1 = platform
      L16_1 = L16_1.version
      L17_1 = L16_1
      L16_1 = L16_1.startsWith
      L18_1 = "2.1"
      L16_1 = L16_1(L17_1, L18_1)
    end
  end
end

function L17_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = L7_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "vungle_listener "
    L3_2 = tostring
    L4_2 = A0_2.type
    L3_2 = L3_2(L4_2)
    L4_2 = ", isError="
    L5_2 = tostring
    L6_2 = A0_2.isError
    L5_2 = L5_2(L6_2)
    L2_2 = L2_2 .. L3_2 .. L4_2 .. L5_2
    L1_2(L2_2)
  end
  L1_2 = A0_2.type
  if L1_2 == "adStart" then
    L1_2 = A0_2.isError
    if L1_2 then
    end
  end
  L1_2 = A0_2.type
  if L1_2 == "adStart" then
    L1_2 = A0_2.isError
    if not L1_2 then
      L1_2 = ltv
      L1_2 = L1_2.recordAdView
      L1_2()
      L1_2 = os
      L1_2 = L1_2.time
      L1_2 = L1_2()
      L9_1 = L1_2
    end
  end
  L1_2 = A0_2.type
  if L1_2 == "adEnd" then
    L1_2 = A0_2.isError
    if L1_2 then
    end
  end
  L1_2 = A0_2.type
  if L1_2 == "adEnd" then
    L1_2 = A0_2.isError
    if not L1_2 then
    end
  end
  L1_2 = A0_2.type
  if L1_2 == "adView" then
    L1_2 = A0_2.isError
    if L1_2 then
    end
  end
  L1_2 = A0_2.type
  if L1_2 == "adView" then
    L1_2 = A0_2.isError
    if not L1_2 then
    end
  end
end

L18_1 = require
L19_1 = "plugin.playhaven"
L18_1 = L18_1(L19_1)
L19_1 = platform
L19_1 = L19_1.android
if L19_1 then
  L19_1 = platform
  L19_1 = L19_1.version
  L20_1 = L19_1
  L19_1 = L19_1.startsWith
  L21_1 = "1"
  L19_1 = L19_1(L20_1, L21_1)
  if not L19_1 then
    L19_1 = platform
    L19_1 = L19_1.version
    L20_1 = L19_1
    L19_1 = L19_1.startsWith
    L21_1 = "2"
    L19_1 = L19_1(L20_1, L21_1)
  end
end

function L20_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L7_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "playhaven_listener "
    L3_2 = tostring
    L4_2 = A0_2.status
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
  if A0_2 then
    L1_2 = A0_2.status
    if L1_2 ~= "contentDidDisplay" then
      L1_2 = A0_2.status
      if L1_2 ~= "didDisplayContent" then
        goto lbl_27
      end
    end
    L1_2 = ltv
    L1_2 = L1_2.recordAdView
    L1_2()
    L1_2 = os
    L1_2 = L1_2.time
    L1_2 = L1_2()
    L9_1 = L1_2
  end
  ::lbl_27::
  if A0_2 then
    L1_2 = A0_2.data
    if L1_2 then
      L1_2 = L7_1
      if L1_2 then
        L1_2 = L1_1
        L1_2 = L1_2.decode
        L2_2 = A0_2.data
        L1_2 = L1_2(L2_2)
        L2_2 = log
        L2_2 = L2_2.show
        L3_2 = "ph type:"
        L4_2 = L1_2.type
        L3_2 = L3_2 .. L4_2
        L2_2(L3_2)
        L2_2 = print
        L3_2 = inspect
        L4_2 = A0_2
        L2_2(L3_2(L4_2))
        L2_2 = print
        L3_2 = "____________________"
        L2_2(L3_2)
        L2_2 = print
        L3_2 = inspect
        L4_2 = L1_2
        L2_2(L3_2(L4_2))
      end
    end
  end
end

L21_1 = require
L22_1 = "plugin.adbuddiz"
L21_1 = L21_1(L22_1)
L22_1 = platform
L22_1 = L22_1.android
if L22_1 then
  L22_1 = platform
  L22_1 = L22_1.version
  L23_1 = L22_1
  L22_1 = L22_1.startsWith
  L24_1 = "1"
  L22_1 = L22_1(L23_1, L24_1)
  if not L22_1 then
    L22_1 = platform
    L22_1 = L22_1.version
    L23_1 = L22_1
    L22_1 = L22_1.startsWith
    L24_1 = "2.0"
    L22_1 = L22_1(L23_1, L24_1)
  end
end

function L23_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = L7_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "adbuddiz_listener "
    L3_2 = tostring
    L4_2 = A0_2.value
    L3_2 = L3_2(L4_2)
    L4_2 = " "
    L5_2 = tostring
    L6_2 = A0_2.detail
    L5_2 = L5_2(L6_2)
    L2_2 = L2_2 .. L3_2 .. L4_2 .. L5_2
    L1_2(L2_2)
  end
  L1_2 = A0_2.value
  if L1_2 == "didCacheAd" then
  end
  L1_2 = A0_2.value
  if L1_2 == "didShowAd" then
    L1_2 = ltv
    L1_2 = L1_2.recordAdView
    L1_2()
    L1_2 = os
    L1_2 = L1_2.time
    L1_2 = L1_2()
    L9_1 = L1_2
  end
  L1_2 = A0_2.value
  if L1_2 == "didClick" then
    L1_2 = ltv
    L1_2 = L1_2.recordAdClick
    L1_2()
  end
  L1_2 = A0_2.value
  if L1_2 == "didHideAd" then
  end
  L1_2 = A0_2.value
  if L1_2 == "didFailToShowAd" then
  end
end

function L24_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = L10_1
  if L0_2 ~= nil then
    L0_2 = L11_1
    if L0_2 ~= nil then
      L0_2 = L12_1
      if L0_2 ~= nil then
        return
      end
    end
  end
  L0_2 = L14_1
  if L0_2 then
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 0
    L4_2 = 0
    L2_2.applovin_exit_share = 0
    L1_2.applovin_startup_share = L4_2
    L0_2.applovin_interstitial_share = L3_2
  end
  L0_2 = L16_1
  if L0_2 then
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 0
    L4_2 = 0
    L2_2.vungle_exit_share = 0
    L1_2.vungle_startup_share = L4_2
    L0_2.vungle_interstitial_share = L3_2
  end
  L0_2 = L19_1
  if L0_2 then
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 0
    L4_2 = 0
    L2_2.playhaven_exit_share = 0
    L1_2.playhaven_startup_share = L4_2
    L0_2.playhaven_interstitial_share = L3_2
  end
  L0_2 = L22_1
  if L0_2 then
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 0
    L4_2 = 0
    L2_2.adbuddiz_exit_share = 0
    L1_2.adbuddiz_startup_share = L4_2
    L0_2.adbuddiz_interstitial_share = L3_2
  end
  L0_2 = settings
  L0_2 = L0_2.t
  L0_2 = L0_2.offers
  L0_2 = #L0_2
  if L0_2 == 0 then
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 0
    L4_2 = 0
    L2_2.offers_exit_share = 0
    L1_2.offers_startup_share = L4_2
    L0_2.offers_interstitial_share = L3_2
  end
  L0_2 = nil
  L1_2 = {}
  L10_1 = L1_2
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.applovin_interstitial_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L10_1
    L6_2 = L10_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L2_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.vungle_interstitial_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L10_1
    L6_2 = L10_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L3_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.playhaven_interstitial_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L10_1
    L6_2 = L10_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L4_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.adbuddiz_interstitial_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L10_1
    L6_2 = L10_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L5_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.offers_interstitial_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L10_1
    L6_2 = L10_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L6_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = {}
  L11_1 = L1_2
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.applovin_startup_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L11_1
    L6_2 = L11_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L2_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.vungle_startup_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L11_1
    L6_2 = L11_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L3_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.playhaven_startup_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L11_1
    L6_2 = L11_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L4_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.adbuddiz_startup_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L11_1
    L6_2 = L11_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L5_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.offers_startup_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L11_1
    L6_2 = L11_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L6_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = {}
  L12_1 = L1_2
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.applovin_exit_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L12_1
    L6_2 = L12_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L2_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.vungle_exit_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L12_1
    L6_2 = L12_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L3_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.playhaven_exit_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L12_1
    L6_2 = L12_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L4_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.adbuddiz_exit_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L12_1
    L6_2 = L12_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L5_1
    L5_2[L6_2] = L7_2
  end
  L1_2 = 1
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.offers_exit_share
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L12_1
    L6_2 = L12_1
    L6_2 = #L6_2
    L6_2 = L6_2 + 1
    L7_2 = L6_1
    L5_2[L6_2] = L7_2
  end
end

function L25_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = L7_1
  if L2_2 then
    L2_2 = log
    L2_2 = L2_2.show
    L3_2 = "showAd() "
    L4_2 = A0_2
    L5_2 = " "
    L6_2 = A1_2
    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
    L4_2 = {}
    L5_2 = green
    L4_2.textColor = L5_2
    L2_2(L3_2, L4_2)
  end
  L2_2 = L2_1
  if A0_2 == L2_2 then
    L2_2 = L13_1
    L2_2 = L2_2.showInterstitial
    L2_2()
    L2_2 = os
    L2_2 = L2_2.time
    L2_2 = L2_2()
    L9_1 = L2_2
    L2_2 = true
    return L2_2
  end
  L2_2 = L3_1
  if A0_2 == L2_2 then
    L2_2 = L7_1
    if L2_2 then
      L2_2 = _SIMULATOR
      if not L2_2 then
        L2_2 = log
        L2_2 = L2_2.show
        L3_2 = "showAd-vungle isAdAvailable()="
        L4_2 = tostring
        L5_2 = L15_1
        L5_2 = L5_2.isAdAvailable
        L4_2 = L4_2(L5_2())
        L3_2 = L3_2 .. L4_2
        L2_2(L3_2)
      end
    end
    L2_2 = L15_1
    L2_2 = L2_2.show
    L3_2 = "interstitial"
    L4_2 = {}
    L5_2 = settings
    L5_2 = L5_2.t
    L5_2 = L5_2.vungle_enable_sound
    L4_2.isSoundEnabled = L5_2
    L2_2 = L2_2(L3_2, L4_2)
    L3_2 = L7_1
    if L3_2 then
      L3_2 = log
      L3_2 = L3_2.show
      L4_2 = "showAd-vungle shown="
      L5_2 = tostring
      L6_2 = L2_2
      L5_2 = L5_2(L6_2)
      L4_2 = L4_2 .. L5_2
      L3_2(L4_2)
    end
    return L2_2
  end
  L2_2 = L4_1
  if A0_2 == L2_2 then
    L2_2 = L18_1
    L2_2 = L2_2.contentRequest
    L3_2 = A1_2
    L4_2 = true
    L2_2(L3_2, L4_2)
    L2_2 = true
    return L2_2
  end
  L2_2 = L5_1
  if A0_2 == L2_2 then
    L2_2 = L21_1
    L2_2 = L2_2.isReadyToShowAd
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = L7_1
      if L2_2 then
        L2_2 = log
        L2_2 = L2_2.show
        L3_2 = "showAd() tried to show AdBuddiz but not ready."
        L2_2(L3_2)
      end
      L2_2 = false
      return L2_2
    end
    L2_2 = L21_1
    L2_2 = L2_2.showAd
    L2_2()
    L2_2 = true
    return L2_2
  end
  L2_2 = L6_1
  if A0_2 == L2_2 then
    L2_2 = offers
    L2_2 = L2_2.showAd
    L2_2 = L2_2()
    if L2_2 then
      L3_2 = ltv
      L3_2 = L3_2.recordAdView
      L3_2()
      L3_2 = os
      L3_2 = L3_2.time
      L3_2 = L3_2()
      L9_1 = L3_2
    end
    return L2_2
  end
  L2_2 = log
  L2_2 = L2_2.show
  L3_2 = "showAd() Error adProvider="
  L4_2 = A0_2
  L3_2 = L3_2 .. L4_2
  L2_2(L3_2)
  L2_2 = false
  return L2_2
end

function L26_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = L8_1
  if L0_2 then
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2.ads_startup_chance = 100
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2.ads_interstitial_chance = 100
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2.ads_exit_chance = 100
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2.ads_min_seconds_between_interstitials = 10
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2.ads_min_seconds_into_session_before_interstitial = 10
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 0
    L4_2 = 0
    L2_2.applovin_exit_share = 0
    L1_2.applovin_interstitial_share = L4_2
    L0_2.applovin_startup_share = L3_2
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 0
    L4_2 = 0
    L2_2.vungle_exit_share = 0
    L1_2.vungle_interstitial_share = L4_2
    L0_2.vungle_startup_share = L3_2
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 0
    L4_2 = 0
    L2_2.playhaven_exit_share = 0
    L1_2.playhaven_interstitial_share = L4_2
    L0_2.playhaven_startup_share = L3_2
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 0
    L4_2 = 0
    L2_2.adbuddiz_exit_share = 0
    L1_2.adbuddiz_interstitial_share = L4_2
    L0_2.adbuddiz_startup_share = L3_2
    L0_2 = settings
    L0_2 = L0_2.t
    L1_2 = settings
    L1_2 = L1_2.t
    L2_2 = settings
    L2_2 = L2_2.t
    L3_2 = 1
    L4_2 = 1
    L2_2.offers_exit_share = 1
    L1_2.offers_interstitial_share = L4_2
    L0_2.offers_startup_share = L3_2
  end
  L0_2 = L7_1
  if L0_2 then
    L0_2 = print
    L1_2 = "\n"
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "ads_startup_chance="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.ads_startup_chance
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "ads_interstitial_chance="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.ads_interstitial_chance
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "ads_exit_chance="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.ads_exit_chance
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "ads_min_seconds_into_session_before_interstitial="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.ads_min_seconds_into_session_before_interstitial
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "ads_min_seconds_between_interstitials="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.ads_min_seconds_between_interstitials
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "\n"
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "applovin_startup_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.applovin_startup_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "applovin_interstitial_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.applovin_interstitial_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "applovin_exit_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.applovin_exit_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "vungle_startup_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.vungle_startup_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "vungle_interstitial_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.vungle_interstitial_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "vungle_exit_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.vungle_exit_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "playhaven_startup_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.playhaven_startup_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "playhaven_interstitial_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.playhaven_interstitial_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "playhaven_exit_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.playhaven_exit_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "adbuddiz_startup_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.adbuddiz_startup_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "adbuddiz_interstitial_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.adbuddiz_interstitial_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "adbuddiz_exit_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.adbuddiz_exit_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "offers_startup_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.offers_startup_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "offers_interstitial_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.offers_interstitial_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "offers_exit_share="
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.offers_exit_share
    L1_2 = L1_2 .. L2_2
    L0_2(L1_2)
    L0_2 = print
    L1_2 = "\n"
    L0_2(L1_2)
  end
  L0_2 = L24_1
  L0_2()
  L0_2 = settings
  L0_2 = L0_2.t
  L0_2 = L0_2.applovin_startup_share
  if not (0 < L0_2) then
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2 = L0_2.applovin_interstitial_share
    if not (0 < L0_2) then
      L0_2 = settings
      L0_2 = L0_2.t
      L0_2 = L0_2.applovin_exit_share
      if 0 < L0_2 then
      end
    end
  end
  L0_2 = settings
  L0_2 = L0_2.t
  L0_2 = L0_2.vungle_startup_share
  if not (0 < L0_2) then
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2 = L0_2.vungle_interstitial_share
    if not (0 < L0_2) then
      L0_2 = settings
      L0_2 = L0_2.t
      L0_2 = L0_2.vungle_exit_share
      if not (0 < L0_2) then
        goto lbl_274
      end
    end
  end
  L0_2 = settings
  L0_2 = L0_2.t
  L0_2 = L0_2.vungle_appid_ios
  L1_2 = platform
  L1_2 = L1_2.android
  if L1_2 then
    L1_2 = settings
    L1_2 = L1_2.t
    L0_2 = L1_2.vungle_appid_android
  end
  L1_2 = L15_1
  L1_2 = L1_2.init
  L2_2 = "vungle"
  L3_2 = L0_2
  L4_2 = L17_1
  L1_2(L2_2, L3_2, L4_2)
  ::lbl_274::
  L0_2 = settings
  L0_2 = L0_2.t
  L0_2 = L0_2.playhaven_startup_share
  if not (0 < L0_2) then
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2 = L0_2.playhaven_interstitial_share
    if not (0 < L0_2) then
      L0_2 = settings
      L0_2 = L0_2.t
      L0_2 = L0_2.playhaven_exit_share
      if not (0 < L0_2) then
        goto lbl_317
      end
    end
  end
  L0_2 = {}
  L1_2 = settings
  L1_2 = L1_2.t
  L1_2 = L1_2.playhaven_token_ios
  L0_2.token = L1_2
  L1_2 = settings
  L1_2 = L1_2.t
  L1_2 = L1_2.playhaven_secret_ios
  L0_2.secret = L1_2
  L1_2 = platform
  L1_2 = L1_2.android
  if L1_2 then
    L1_2 = {}
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.playhaven_token_android
    L1_2.token = L2_2
    L2_2 = settings
    L2_2 = L2_2.t
    L2_2 = L2_2.playhaven_secret_android
    L1_2.secret = L2_2
    L0_2 = L1_2
  end
  L1_2 = L18_1
  L1_2 = L1_2.init
  L2_2 = L20_1
  L3_2 = L0_2
  L1_2(L2_2, L3_2)
  ::lbl_317::
  L0_2 = settings
  L0_2 = L0_2.t
  L0_2 = L0_2.adbuddiz_startup_share
  if not (0 < L0_2) then
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2 = L0_2.adbuddiz_interstitial_share
    if not (0 < L0_2) then
      L0_2 = settings
      L0_2 = L0_2.t
      L0_2 = L0_2.adbuddiz_exit_share
      if not (0 < L0_2) then
        goto lbl_357
      end
    end
  end
  L0_2 = platform
  L0_2 = L0_2.android
  if L0_2 then
    L0_2 = L21_1
    L0_2 = L0_2.setAndroidPublisherKey
    L1_2 = settings
    L1_2 = L1_2.t
    L1_2 = L1_2.adbuddiz_apppublisherkey_android
    L0_2(L1_2)
  else
    L0_2 = L21_1
    L0_2 = L0_2.setIOSPublisherKey
    L1_2 = settings
    L1_2 = L1_2.t
    L1_2 = L1_2.adbuddiz_apppublisherkey_ios
    L0_2(L1_2)
  end
  L0_2 = L21_1
  L0_2 = L0_2.cacheAds
  L0_2()
  L0_2 = Runtime
  L1_2 = L0_2
  L0_2 = L0_2.addEventListener
  L2_2 = "AdBuddizEvent"
  L3_2 = L23_1
  L0_2(L1_2, L2_2, L3_2)
  ::lbl_357::
  L0_2 = settings
  L0_2 = L0_2.t
  L0_2 = L0_2.offers_startup_share
  if not (0 < L0_2) then
    L0_2 = settings
    L0_2 = L0_2.t
    L0_2 = L0_2.offers_interstitial_share
    if not (0 < L0_2) then
      L0_2 = settings
      L0_2 = L0_2.t
      L0_2 = L0_2.offers_exit_share
      if not (0 < L0_2) then
        goto lbl_375
      end
    end
  end
  L0_2 = offers
  L0_2 = L0_2.init
  L0_2()
  ::lbl_375::
end

L0_1.initAdProviders = L26_1

function L26_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = L7_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "possiblyShowInterstitial()"
    L3_2 = {}
    L4_2 = yellow
    L3_2.textColor = L4_2
    L1_2(L2_2, L3_2)
  end
  L1_2 = _inPlay
  if L1_2 then
    L1_2 = false
    return L1_2
  end
  L1_2 = settings
  L1_2 = L1_2.getInternetLatency
  L1_2 = L1_2()
  if 5000 < L1_2 and not A0_2 then
    L1_2 = false
    return L1_2
  end
  L1_2 = os
  L1_2 = L1_2.time
  L1_2 = L1_2()
  L2_2 = bsi
  L2_2 = L2_2.getTimeOfThisSessionStartup
  L2_2 = L2_2()
  L1_2 = L1_2 - L2_2
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.ads_min_seconds_into_session_before_interstitial
  if L1_2 < L2_2 and not A0_2 then
    L2_2 = false
    return L2_2
  end
  L2_2 = os
  L2_2 = L2_2.time
  L2_2 = L2_2()
  L3_2 = L9_1
  L2_2 = L2_2 - L3_2
  L3_2 = settings
  L3_2 = L3_2.t
  L3_2 = L3_2.ads_min_seconds_between_interstitials
  if L2_2 < L3_2 and not A0_2 then
    L3_2 = false
    return L3_2
  end
  L3_2 = math
  L3_2 = L3_2.random
  L4_2 = 1
  L5_2 = 100
  L3_2 = L3_2(L4_2, L5_2)
  L4_2 = settings
  L4_2 = L4_2.t
  L4_2 = L4_2.ads_interstitial_chance
  if L3_2 > L4_2 and not A0_2 then
    L3_2 = false
    return L3_2
  end
  L3_2 = L10_1
  L3_2 = #L3_2
  if L3_2 == 0 then
    L3_2 = false
    return L3_2
  end
  L3_2 = L10_1
  L4_2 = math
  L4_2 = L4_2.random
  L5_2 = 1
  L6_2 = L10_1
  L6_2 = #L6_2
  L4_2 = L4_2(L5_2, L6_2)
  L3_2 = L3_2[L4_2]
  L4_2 = L25_1
  L5_2 = L3_2
  L6_2 = "interstitial"
  L4_2 = L4_2(L5_2, L6_2)
  return L4_2
end

L0_1.possiblyShowInterstitial = L26_1

function L26_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L7_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "possiblyShowStartupAd()"
    L3_2 = {}
    L4_2 = yellow
    L3_2.textColor = L4_2
    L1_2(L2_2, L3_2)
  end
  L1_2 = _inPlay
  if L1_2 then
    L1_2 = false
    return L1_2
  end
  L1_2 = settings
  L1_2 = L1_2.getInternetLatency
  L1_2 = L1_2()
  if 5000 < L1_2 and not A0_2 then
    L1_2 = false
    return L1_2
  end
  L1_2 = math
  L1_2 = L1_2.random
  L2_2 = 1
  L3_2 = 100
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.ads_startup_chance
  if L1_2 > L2_2 and not A0_2 then
    L1_2 = false
    return L1_2
  end
  L1_2 = L11_1
  L1_2 = #L1_2
  if L1_2 == 0 then
    L1_2 = false
    return L1_2
  end
  L1_2 = L11_1
  L2_2 = math
  L2_2 = L2_2.random
  L3_2 = 1
  L4_2 = L11_1
  L4_2 = #L4_2
  L2_2 = L2_2(L3_2, L4_2)
  L1_2 = L1_2[L2_2]
  L2_2 = timer
  L2_2 = L2_2.performWithDelay
  L3_2 = 1000
  
  function L4_2()
    local L0_3, L1_3, L2_3
    L0_3 = L25_1
    L1_3 = L1_2
    L2_3 = "startup"
    L0_3(L1_3, L2_3)
  end
  
  L2_2(L3_2, L4_2)
end

L0_1.possiblyShowStartupAd = L26_1

function L26_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L7_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "possiblyShowExitAd()"
    L3_2 = {}
    L4_2 = yellow
    L3_2.textColor = L4_2
    L1_2(L2_2, L3_2)
  end
  L1_2 = _inPlay
  if L1_2 then
    L1_2 = false
    return L1_2
  end
  L1_2 = settings
  L1_2 = L1_2.getInternetLatency
  L1_2 = L1_2()
  if 5000 < L1_2 and not A0_2 then
    L1_2 = false
    return L1_2
  end
  L1_2 = math
  L1_2 = L1_2.random
  L2_2 = 1
  L3_2 = 100
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.ads_exit_chance
  if L1_2 > L2_2 and not A0_2 then
    L1_2 = false
    return L1_2
  end
  L1_2 = L12_1
  L1_2 = #L1_2
  if L1_2 == 0 then
    L1_2 = false
    return L1_2
  end
  L1_2 = L12_1
  L2_2 = math
  L2_2 = L2_2.random
  L3_2 = 1
  L4_2 = L12_1
  L4_2 = #L4_2
  L2_2 = L2_2(L3_2, L4_2)
  L1_2 = L1_2[L2_2]
  L2_2 = L25_1
  L3_2 = L1_2
  L4_2 = "exit"
  L2_2(L3_2, L4_2)
end

L0_1.possiblyShowExitAd = L26_1
return L0_1
