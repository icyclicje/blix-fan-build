local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_sharing.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = globals
L2_1 = L2_1.sharing_url
L0_1.url = L2_1
L2_1 = "Play "
L3_1 = APP_NAME
L4_1 = " with me!"
L2_1 = L2_1 .. L3_1 .. L4_1
L0_1.title = L2_1
L2_1 = "Come play "
L3_1 = APP_NAME
L4_1 = " with me!"
L2_1 = L2_1 .. L3_1 .. L4_1
L0_1.message = L2_1
L2_1 = {}
L2_1.filename = "Icon-152.png"
L3_1 = system
L3_1 = L3_1.ResourceDirectory
L2_1.baseDir = L3_1
L0_1.image = L2_1

function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = analytics
  L2_2 = L2_2.logEvent
  L3_2 = "Share via Google from "
  L4_2 = A0_2
  L3_2 = L3_2 .. L4_2
  L2_2(L3_2)
  L2_2 = native
  L2_2 = L2_2.showPopup
  L3_2 = "social"
  L4_2 = {}
  L5_2 = A1_2
  L6_2 = L0_1
  L6_2 = L6_2.message
  L5_2 = L5_2 .. L6_2
  L4_2.message = L5_2
  L5_2 = L0_1
  L5_2 = L5_2.url
  L4_2.url = L5_2
  L5_2 = L0_1
  L5_2 = L5_2.image
  L4_2.image = L5_2
  L2_2(L3_2, L4_2)
end

L0_1.shareViaGoogle = L2_1
return L0_1
