local L0_1, L1_1
L0_1 = string

function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  if A0_2 then
    L1_2 = string
    L1_2 = L1_2.gsub
    L2_2 = A0_2
    L3_2 = "\n"
    L4_2 = "\r\n"
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    A0_2 = L1_2
    L1_2 = string
    L1_2 = L1_2.gsub
    L2_2 = A0_2
    L3_2 = "([^%w ])"
    
    function L4_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3
      L1_3 = string
      L1_3 = L1_3.format
      L2_3 = "%%%02X"
      L3_3 = string
      L3_3 = L3_3.byte
      L4_3 = A0_3
      return L1_3(L2_3, L3_3(L4_3))
    end
    
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    A0_2 = L1_2
    L1_2 = string
    L1_2 = L1_2.gsub
    L2_2 = A0_2
    L3_2 = " "
    L4_2 = "+"
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    A0_2 = L1_2
  end
  return A0_2
end

L0_1.urlEncode = L1_1
L0_1 = string

function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = string
  L2_2 = L2_2.sub
  L3_2 = A0_2
  L4_2 = 1
  L5_2 = string
  L5_2 = L5_2.len
  L6_2 = A1_2
  L2_2 = L2_2(L3_2, L4_2, L5_2(L6_2))
  L2_2 = L2_2 == A1_2
  return L2_2
end

L0_1.startsWith = L1_1
L0_1 = string

function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L2_2 = {}
  L3_2 = "(.-)"
  L4_2 = A1_2
  L3_2 = L3_2 .. L4_2
  L4_2 = 1
  L6_2 = A0_2
  L5_2 = A0_2.find
  L7_2 = L3_2
  L8_2 = 1
  L5_2, L6_2, L7_2 = L5_2(L6_2, L7_2, L8_2)
  while L5_2 do
    if L5_2 ~= 1 or L7_2 ~= "" then
      L8_2 = table
      L8_2 = L8_2.insert
      L9_2 = L2_2
      L10_2 = L7_2
      L8_2(L9_2, L10_2)
    end
    L4_2 = L6_2 + 1
    L9_2 = A0_2
    L8_2 = A0_2.find
    L10_2 = L3_2
    L11_2 = L4_2
    L8_2, L9_2, L10_2 = L8_2(L9_2, L10_2, L11_2)
    L7_2 = L10_2
    L6_2 = L9_2
    L5_2 = L8_2
  end
  L8_2 = #A0_2
  if L4_2 <= L8_2 then
    L9_2 = A0_2
    L8_2 = A0_2.sub
    L10_2 = L4_2
    L8_2 = L8_2(L9_2, L10_2)
    L7_2 = L8_2
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L2_2
    L10_2 = L7_2
    L8_2(L9_2, L10_2)
  end
  return L2_2
end

L0_1.split = L1_1
L0_1 = string

function L1_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L4_2 = A1_2
  L5_2 = -1
  while L5_2 == -1 or A2_2 < L5_2 do
    L6_2 = display
    L6_2 = L6_2.newText
    L7_2 = A0_2
    L8_2 = 0
    L9_2 = 0
    L10_2 = A3_2
    L11_2 = L4_2
    L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2)
    L5_2 = L6_2.width
    if A2_2 < L5_2 then
      L4_2 = L4_2 - 1
    end
    L8_2 = L6_2
    L7_2 = L6_2.removeSelf
    L7_2(L8_2)
    L6_2 = nil
  end
  return L4_2
end

L0_1.getFontSizeThatFit = L1_1
