local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1
L0_1 = {}
L1_1 = require
L2_1 = "json"
L1_1 = L1_1(L2_1)
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "_fb_friends.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = 604800
L4_1 = nil
L5_1 = saver
L5_1 = L5_1.Load
L6_1 = "friends.txt"
L5_1 = L5_1(L6_1)
if not L5_1 then
  L5_1 = {}
end
L0_1.savedData = L5_1
L5_1 = L0_1.savedData
L5_1 = L5_1.allFriends
if L5_1 == nil then
  L5_1 = L0_1.savedData
  L6_1 = {}
  L5_1.allFriends = L6_1
end
L5_1 = L0_1.savedData
L5_1 = L5_1.lastTimeSaved
if L5_1 == nil then
  L5_1 = L0_1.savedData
  L5_1.lastTimeSaved = 0
end

function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2.allFriends = A0_2
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L2_2 = os
  L2_2 = L2_2.time
  L2_2 = L2_2()
  L1_2.lastTimeSaved = L2_2
  L1_2 = saver
  L1_2 = L1_2.Save
  L2_2 = L0_1
  L2_2 = L2_2.savedData
  L3_2 = "friends.txt"
  L1_2(L2_2, L3_2)
end

L0_1.saveAllFriends = L5_1

function L5_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2 = L0_2.allFriends
  L0_2 = #L0_2
  return L0_2
end

L0_1.getNumFriends = L5_1

function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = {}
  L1_2 = pairs
  L2_2 = L0_1
  L2_2 = L2_2.savedData
  L2_2 = L2_2.allFriends
  L1_2, L2_2, L3_2 = L1_2(L2_2)
  for L4_2, L5_2 in L1_2, L2_2, L3_2 do
    L6_2 = L5_2.installed
    if L6_2 then
      L6_2 = L2_1
      if L6_2 then
        L6_2 = print
        L7_2 = "installed"
        L8_2 = L5_2.name
        L6_2(L7_2, L8_2)
      end
      L6_2 = #L0_2
      L6_2 = L6_2 + 1
      L0_2[L6_2] = L5_2
    end
  end
  return L0_2
end

L0_1.getFriendsWhoHaveInstalled = L5_1

function L5_1()
  local L0_2, L1_2, L2_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2 = L0_2.allFriends
  L1_2 = math
  L1_2 = L1_2.random
  L2_2 = L0_1
  L2_2 = L2_2.savedData
  L2_2 = L2_2.allFriends
  L2_2 = #L2_2
  L1_2 = L1_2(L2_2)
  L0_2 = L0_2[L1_2]
  return L0_2
end

L0_1.getRandomFriend = L5_1

function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = A0_2.isError
  if L1_2 then
    L1_2 = print
    L2_2 = "getFriendsListener: Network error"
    L1_2(L2_2)
  else
    L1_2 = L2_1
    if L1_2 then
      L1_2 = print
      L2_2 = "STATUS CODE: "
      L3_2 = A0_2.status
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
    end
    L1_2 = L2_1
    if L1_2 then
      L1_2 = print
      L2_2 = "RESPONSE: "
      L3_2 = A0_2.response
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
    end
    L1_2 = L2_1
    if L1_2 then
      L1_2 = print
      L2_2 = "RESPONSE length: "
      L3_2 = string
      L3_2 = L3_2.len
      L4_2 = A0_2.response
      L3_2 = L3_2(L4_2)
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
    end
    L1_2 = L1_1
    L1_2 = L1_2.decode
    L2_2 = A0_2.response
    L1_2 = L1_2(L2_2)
    L2_2 = L2_1
    if L2_2 then
      L2_2 = print
      L3_2 = L1_2
      L2_2(L3_2)
    end
    if L1_2 then
      L2_2 = L1_2.status
      if L2_2 == 0 then
        L3_2 = L1_2.friends
        if L3_2 ~= nil then
          L4_2 = #L3_2
          if 0 < L4_2 then
            L4_2 = L0_1
            L4_2 = L4_2.saveAllFriends
            L5_2 = L3_2
            L4_2(L5_2)
          end
        end
      end
      L3_2 = L2_1
      if L3_2 then
        L3_2 = log
        L3_2 = L3_2.show
        L4_2 = "getFriendsListener: status="
        L5_2 = L2_2
        L4_2 = L4_2 .. L5_2
        L5_2 = {}
        L6_2 = yellow
        L5_2.textColor = L6_2
        L3_2(L4_2, L5_2)
      end
    else
      L2_2 = L2_1
      if L2_2 then
        L2_2 = log
        L2_2 = L2_2.show
        L3_2 = "ERROR: getFriendsListener() table_response was nil"
        L2_2(L3_2)
      end
    end
  end
  L1_2 = L4_1
  if L1_2 then
    L1_2 = L4_1
    L1_2()
    L1_2 = nil
    L4_1 = L1_2
  end
end

function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L4_1 = A0_2
  L1_2 = os
  L1_2 = L1_2.time
  L1_2 = L1_2()
  L2_2 = L0_1
  L2_2 = L2_2.savedData
  L2_2 = L2_2.lastTimeSaved
  L1_2 = L1_2 - L2_2
  L2_2 = L3_1
  if L1_2 < L2_2 then
    L1_2 = L0_1
    L1_2 = L1_2.getNumFriends
    L1_2 = L1_2()
    if 0 < L1_2 then
      L1_2 = L4_1
      if L1_2 then
        L1_2 = L4_1
        L1_2()
        L1_2 = nil
        L4_1 = L1_2
      end
      return
    end
  end
  L1_2 = {}
  L1_2["Accept-Language"] = "en-US"
  L1_2["Content-Type"] = "application/x-www-form-urlencoded"
  L2_2 = {}
  L2_2.headers = L1_2
  L2_2.body = "Command=Games_GetFriends"
  L3_2 = ""
  L4_2 = L3_2
  L5_2 = "&game="
  L6_2 = APP_ID
  L3_2 = L4_2 .. L5_2 .. L6_2
  L4_2 = L3_2
  L5_2 = fb_utils
  L5_2 = L5_2.generateFbParams
  L5_2 = L5_2()
  L3_2 = L4_2 .. L5_2
  L4_2 = L3_2
  L5_2 = "&getTopFriends=false"
  L3_2 = L4_2 .. L5_2
  L4_2 = L3_2
  L5_2 = "&"
  L6_2 = utils
  L6_2 = L6_2.getParametersForServer
  L6_2 = L6_2()
  L3_2 = L4_2 .. L5_2 .. L6_2
  L4_2 = L2_2.body
  L5_2 = L3_2
  L4_2 = L4_2 .. L5_2
  L2_2.body = L4_2
  L4_2 = L2_1
  if L4_2 then
    L4_2 = print
    L5_2 = L2_2.body
    L4_2(L5_2)
  end
  L4_2 = network
  L4_2 = L4_2.request
  L5_2 = utils
  L5_2 = L5_2.getURL
  L6_2 = "POST"
  L5_2 = L5_2(L6_2)
  L6_2 = "POST"
  L7_2 = L5_1
  L8_2 = L2_2
  L4_2(L5_2, L6_2, L7_2, L8_2)
  L4_2 = L2_1
  if L4_2 then
    L4_2 = log
    L4_2 = L4_2.show
    L5_2 = "possiblyFetchAndSaveFriends()"
    L6_2 = {}
    L7_2 = yellow
    L6_2.textColor = L7_2
    L7_2 = 1
    L4_2(L5_2, L6_2, L7_2)
  end
end

L0_1.possiblyFetchAndSaveFriends = L6_1
return L0_1
