local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = require
L1_1 = "composer"
L0_1 = L0_1(L1_1)
L1_1 = L0_1.newScene
L1_1 = L1_1()
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "scene_template.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = nil

function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_template:create()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = "Start"
  
  function L5_2()
    local L0_3, L1_3
    L0_3 = L0_1
    L0_3 = L0_3.gotoScene
    L1_3 = "scene_game"
    L0_3(L1_3)
  end
  
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = white
  L6_2.textColor = L7_2
  L7_2 = white
  L6_2.strokeColor = L7_2
  L7_2 = black
  L6_2.bgColor = L7_2
  L6_2.fontSize = 36
  L6_2.fontNum = 6
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L3_1 = L3_2
end

L1_1.create = L4_1

function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_template:show() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
      L3_2 = L3_1
      L4_2 = L3_1
      L5_2 = _W2
      L6_2 = _H2
      L4_2.y = L6_2
      L3_2.x = L5_2
    end
  end
end

L1_1.show = L4_1

function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_template:hide() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
    L3_2 = utils
    L3_2 = L3_2.cancelAllTimersAndTransitions
    L3_2()
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
    end
  end
end

L1_1.hide = L4_1

function L4_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "scene_template:destroy()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
end

L1_1.destroy = L4_1
L5_1 = L1_1
L4_1 = L1_1.addEventListener
L6_1 = "create"
L7_1 = L1_1
L4_1(L5_1, L6_1, L7_1)
L5_1 = L1_1
L4_1 = L1_1.addEventListener
L6_1 = "show"
L7_1 = L1_1
L4_1(L5_1, L6_1, L7_1)
L5_1 = L1_1
L4_1 = L1_1.addEventListener
L6_1 = "hide"
L7_1 = L1_1
L4_1(L5_1, L6_1, L7_1)
L5_1 = L1_1
L4_1 = L1_1.addEventListener
L6_1 = "destroy"
L7_1 = L1_1
L4_1(L5_1, L6_1, L7_1)
return L1_1
