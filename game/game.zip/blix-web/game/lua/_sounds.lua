local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_sounds.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = 0
L3_1 = {}
L4_1 = 31
L5_1 = 32
L6_1 = 0.04
L7_1 = platform
L7_1 = L7_1.android
if L7_1 then
  L6_1 = 0.08
end
L7_1 = nil
L8_1 = saver
L8_1 = L8_1.Load
L9_1 = "sound.txt"
L8_1 = L8_1(L9_1)
if not L8_1 then
  L8_1 = {}
end
L0_1.savedData = L8_1
L8_1 = L0_1.savedData
L8_1 = L8_1.soundOn
if L8_1 == nil then
  L8_1 = L0_1.savedData
  L8_1.soundOn = true
end
L8_1 = L0_1.savedData
L8_1 = L8_1.musicOn
if L8_1 == nil then
  L8_1 = L0_1.savedData
  L8_1.musicOn = true
end

function L8_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = L0_1
  L3_2 = L3_2.savedData
  L3_2 = L3_2.soundOn
  if not L3_2 then
    return
  end
  if not A0_2 then
    L3_2 = print
    L4_2 = "sounds.play() - sound not found"
    L3_2(L4_2)
    return
  end
  if not A1_2 then
    A1_2 = 1
  end
  L3_2 = system
  L3_2 = L3_2.getTimer
  L3_2 = L3_2()
  L4_2 = L3_1
  L5_2 = tostring
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  L4_2 = L4_2[L5_2]
  if not L4_2 then
    L4_2 = 0
  end
  L3_2 = L3_2 - L4_2
  if 100 < L3_2 or A2_2 then
    L3_2 = L2_1
    L3_2 = L3_2 + 1
    L2_1 = L3_2
    L3_2 = L2_1
    L4_2 = L4_1
    if L3_2 > L4_2 then
      L3_2 = 1
      L2_1 = L3_2
    end
    L3_2 = L1_1
    if L3_2 then
      L3_2 = print
      L4_2 = "sounds.play() channel="
      L5_2 = L2_1
      L6_2 = " and volume="
      L7_2 = A1_2
      L4_2 = L4_2 .. L5_2 .. L6_2 .. L7_2
      L3_2(L4_2)
    end
    L3_2 = audio
    L3_2 = L3_2.setVolume
    L4_2 = A1_2
    L5_2 = {}
    L6_2 = L2_1
    L5_2.channel = L6_2
    L3_2(L4_2, L5_2)
    L3_2 = audio
    L3_2 = L3_2.play
    L4_2 = A0_2
    L5_2 = {}
    L6_2 = L2_1
    L5_2.channel = L6_2
    L3_2(L4_2, L5_2)
    L3_2 = L3_1
    L4_2 = tostring
    L5_2 = A0_2
    L4_2 = L4_2(L5_2)
    L5_2 = system
    L5_2 = L5_2.getTimer
    L5_2 = L5_2()
    L3_2[L4_2] = L5_2
  end
end

L0_1.play = L8_1

function L8_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L0_1
  L2_2 = L2_2.savedData
  L2_2 = L2_2.soundOn
  if not L2_2 then
    return
  end
  if not A0_2 then
    L2_2 = print
    L3_2 = "sounds.play() - sound not found"
    L2_2(L3_2)
    return
  end
  L2_2 = system
  L2_2 = L2_2.getTimer
  L2_2 = L2_2()
  L3_2 = L3_1
  L4_2 = tostring
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  L3_2 = L3_2[L4_2]
  if not L3_2 then
    L3_2 = 0
  end
  L2_2 = L2_2 - L3_2
  if 100 < L2_2 or A1_2 then
    L2_2 = media
    L2_2 = L2_2.playEventSound
    L3_2 = A0_2
    L2_2(L3_2)
    L2_2 = L3_1
    L3_2 = tostring
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L4_2 = system
    L4_2 = L4_2.getTimer
    L4_2 = L4_2()
    L2_2[L3_2] = L4_2
  end
end

L0_1.playFast = L8_1

function L8_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = L0_1
  L0_2 = L0_2.bg_music
  L0_2 = #L0_2
  if L0_2 == 0 then
    return
  end
  L0_2 = math
  L0_2 = L0_2.random
  L1_2 = L0_1
  L1_2 = L1_2.bg_music
  L1_2 = #L1_2
  L0_2 = L0_2(L1_2)
  L1_2 = L1_1
  if L1_2 then
    L1_2 = print
    L2_2 = "getRandomBgMusic "
    L3_2 = L0_2
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
  L1_2 = L0_1
  L1_2 = L1_2.bg_music
  L1_2 = L1_2[L0_2]
  return L1_2
end

L0_1.getRandomBgMusic = L8_1

function L8_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L0_1
  L2_2 = L2_2.savedData
  L2_2 = L2_2.musicOn
  if not L2_2 then
    return
  end
  if not A1_2 then
    A1_2 = L6_1
  end
  if not A0_2 then
    L2_2 = L0_1
    L2_2 = L2_2.getRandomBgMusic
    L2_2 = L2_2()
    A0_2 = L2_2
  end
  if not A0_2 then
    return
  end
  L2_2 = audio
  L2_2 = L2_2.setVolume
  L3_2 = A1_2
  L4_2 = {}
  L5_2 = L5_1
  L4_2.channel = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = L7_1
  if L2_2 == nil then
    L2_2 = L1_1
    if L2_2 then
      L2_2 = print
      L3_2 = "playBgMusic audio.play"
      L2_2(L3_2)
    end
    L2_2 = audio
    L2_2 = L2_2.play
    L3_2 = A0_2
    L4_2 = {}
    L5_2 = L5_1
    L4_2.channel = L5_2
    L4_2.loops = -1
    L2_2 = L2_2(L3_2, L4_2)
    L7_1 = L2_2
  end
end

L0_1.playBgMusic = L8_1

function L8_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L7_1
  if not L2_2 then
    return
  end
  if A0_2 then
    L2_2 = L1_1
    if L2_2 then
      L2_2 = print
      L3_2 = "playBgMusic audio.fadeOut"
      L2_2(L3_2)
    end
    if not A1_2 then
      L2_2 = audio
      L2_2 = L2_2.fadeOut
      L3_2 = L7_1
      L4_2 = {}
      L5_2 = L5_1
      L4_2.channel = L5_2
      L4_2.time = A0_2
      L2_2(L3_2, L4_2)
      L2_2 = nil
      L7_1 = L2_2
    else
      L2_2 = audio
      L2_2 = L2_2.fade
      L3_2 = {}
      L4_2 = L5_1
      L3_2.channel = L4_2
      L3_2.time = A0_2
      L3_2.volume = 0
      L2_2(L3_2)
      
      function L2_2()
        local L0_3, L1_3, L2_3
        L0_3 = audio
        L0_3 = L0_3.rewind
        L1_3 = {}
        L2_3 = L5_1
        L1_3.channel = L2_3
        L0_3(L1_3)
        L0_3 = audio
        L0_3 = L0_3.stop
        L1_3 = L7_1
        L0_3(L1_3)
        L0_3 = nil
        L7_1 = L0_3
      end
      
      L3_2 = timer
      L3_2 = L3_2.performWithDelay
      L4_2 = A0_2
      L5_2 = L2_2
      L3_2(L4_2, L5_2)
    end
  else
    L2_2 = L1_1
    if L2_2 then
      L2_2 = print
      L3_2 = "playBgMusic audio.stop"
      L2_2(L3_2)
    end
    L2_2 = audio
    L2_2 = L2_2.stop
    L3_2 = L7_1
    L2_2(L3_2)
    L2_2 = nil
    L7_1 = L2_2
  end
end

L0_1.stopBgMusic = L8_1

function L8_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2 = L1_2.soundOn
  L1_2 = not L1_2
  L0_2.soundOn = L1_2
  L0_2 = saver
  L0_2 = L0_2.Save
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L2_2 = "sound.txt"
  L0_2(L1_2, L2_2)
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Toggled Sound to "
  L2_2 = tostring
  L3_2 = L0_1
  L3_2 = L3_2.savedData
  L3_2 = L3_2.soundOn
  L2_2 = L2_2(L3_2)
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
end

L0_1.toggleSoundSetting = L8_1

function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L2_2 = L0_1
  L2_2 = L2_2.savedData
  L2_2 = L2_2.musicOn
  L2_2 = not L2_2
  L1_2.musicOn = L2_2
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2 = L1_2.musicOn
  if L1_2 then
    L1_2 = L0_1
    L1_2 = L1_2.playBgMusic
    L2_2 = A0_2
    L1_2(L2_2)
  end
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L1_2 = L1_2.musicOn
  if not L1_2 then
    L1_2 = L0_1
    L1_2 = L1_2.stopBgMusic
    L2_2 = A0_2
    L1_2(L2_2)
  end
  L1_2 = saver
  L1_2 = L1_2.Save
  L2_2 = L0_1
  L2_2 = L2_2.savedData
  L3_2 = "sound.txt"
  L1_2(L2_2, L3_2)
  L1_2 = analytics
  L1_2 = L1_2.logEvent
  L2_2 = "Toggled Music to "
  L3_2 = tostring
  L4_2 = L0_1
  L4_2 = L4_2.savedData
  L4_2 = L4_2.musicOn
  L3_2 = L3_2(L4_2)
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
end

L0_1.toggleMusicSetting = L8_1
L8_1 = media
L8_1 = L8_1.newEventSound
L9_1 = "sounds/_button_click_low_volume.wav"
L8_1 = L8_1(L9_1)
L0_1._button_click_low_volume_fast = L8_1
L8_1 = media
L8_1 = L8_1.newEventSound
L9_1 = "sounds/_button_click.wav"
L8_1 = L8_1(L9_1)
L0_1._button_click_fast = L8_1
L8_1 = globals
L8_1 = L8_1.makeAppSpecificSounds
L9_1 = L0_1
L8_1(L9_1)
L8_1 = globals
L8_1 = L8_1.makeBgMusic
L9_1 = L0_1
L8_1(L9_1)
return L0_1
