local L0_1, L1_1, L2_1, L3_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_buttons.lua DEBUGGING"
  L2_1(L3_1)
end

function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  if not A2_2 then
    L3_2 = {}
    A2_2 = L3_2
  end
  L3_2 = display
  L3_2 = L3_2.newGroup
  L3_2 = L3_2()
  L3_2.anchorChildren = true
  L3_2.text = A0_2
  L4_2 = A2_2.fontSize
  if not L4_2 then
    L4_2 = 24
  end
  L3_2.fontSize = L4_2
  L4_2 = A2_2.textColor
  if not L4_2 then
    L4_2 = white
  end
  L3_2.textColor = L4_2
  L4_2 = A2_2.bgColor
  if not L4_2 then
    L4_2 = button_orange
  end
  L3_2.bgColor = L4_2
  L4_2 = A2_2.strokeWidth
  if not L4_2 then
    L4_2 = math
    L4_2 = L4_2.ceil
    L5_2 = L3_2.fontSize
    L5_2 = L5_2 / 12
    L4_2 = L4_2(L5_2)
  end
  L3_2.strokeWidth = L4_2
  L4_2 = A2_2.strokeColor
  if not L4_2 then
    L4_2 = yellow
  end
  L3_2.strokeColor = L4_2
  L4_2 = A2_2.alphaWhenEnabled
  if not L4_2 then
    L4_2 = 1
  end
  L3_2.alphaWhenEnabled = L4_2
  L4_2 = A2_2.alphaWhenDisabled
  if not L4_2 then
    L4_2 = 0.2
  end
  L3_2.alphaWhenDisabled = L4_2
  L4_2 = A2_2.sound
  if not L4_2 then
    L4_2 = sounds
    L4_2 = L4_2._button_click_fast
  end
  L3_2.sound = L4_2
  L4_2 = A2_2.fontNum
  if not L4_2 then
    L4_2 = 1
  end
  L3_2.fontNum = L4_2
  L4_2 = A2_2.frameless
  if not L4_2 then
    L4_2 = false
  end
  L3_2.frameless = L4_2
  L4_2 = A2_2.fixedWidth
  L3_2.fixedWidth = L4_2
  L4_2 = A2_2.fixedHeight
  L3_2.fixedHeight = L4_2
  L4_2 = A2_2.disabled
  if not L4_2 then
    L4_2 = false
  end
  L3_2.disabled = L4_2
  L4_2 = A2_2.textAnchorX
  if not L4_2 then
    L4_2 = 0.5
  end
  L5_2 = A2_2.textAnchorY
  if not L5_2 then
    L5_2 = 0.5
  end
  L3_2.textAnchorY = L5_2
  L3_2.textAnchorX = L4_2
  L4_2 = A2_2.emboss
  L3_2.emboss = L4_2
  L4_2 = A2_2.group
  
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3
    L1_3 = L3_2
    L1_3 = L1_3.x
    L2_3 = L3_2
    L2_3 = L2_3.y
    L3_3 = L3_2
    L3_3 = L3_3.textObj
    if L3_3 then
      L3_3 = L3_2
      L3_3 = L3_3.textObj
      L4_3 = L3_3
      L3_3 = L3_3.removeSelf
      L3_3(L4_3)
      L3_3 = L3_2
      L3_3.textObj = nil
    end
    L3_3 = L3_2
    L3_3 = L3_3.frameObj
    if L3_3 then
      L3_3 = L3_2
      L3_3 = L3_3.frameObj
      L4_3 = L3_3
      L3_3 = L3_3.removeSelf
      L3_3(L4_3)
      L3_3 = L3_2
      L3_3.frameObj = nil
    end
    L3_3 = L3_2
    L3_3 = L3_3.emboss
    if L3_3 then
      L3_3 = L3_2
      L4_3 = display
      L4_3 = L4_3.newEmbossedText
      L5_3 = L3_2
      L6_3 = L3_2
      L6_3 = L6_3.text
      L7_3 = 0
      L8_3 = 0
      L9_3 = _ttf_font
      L10_3 = L3_2
      L10_3 = L10_3.fontNum
      L9_3 = L9_3[L10_3]
      L10_3 = L3_2
      L10_3 = L10_3.fontSize
      L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
      L3_3.textObj = L4_3
      L3_3 = L3_2
      L3_3 = L3_3.textObj
      L4_3 = L3_3
      L3_3 = L3_3.setEmbossColor
      L5_3 = {}
      L6_3 = {}
      L6_3.r = 0
      L6_3.g = 0
      L6_3.b = 0
      L6_3.a = 0.5019607843137255
      L5_3.highlight = L6_3
      L6_3 = {}
      L6_3.r = 0
      L6_3.g = 0
      L6_3.b = 0
      L6_3.a = 0
      L5_3.shadow = L6_3
      L3_3(L4_3, L5_3)
    else
      L3_3 = L3_2
      L4_3 = display
      L4_3 = L4_3.newText
      L5_3 = L3_2
      L6_3 = L3_2
      L6_3 = L6_3.text
      L7_3 = 0
      L8_3 = 0
      L9_3 = _ttf_font
      L10_3 = L3_2
      L10_3 = L10_3.fontNum
      L9_3 = L9_3[L10_3]
      L10_3 = L3_2
      L10_3 = L10_3.fontSize
      L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
      L3_3.textObj = L4_3
    end
    L3_3 = L3_2
    L3_3 = L3_3.textObj
    L4_3 = L3_3
    L3_3 = L3_3.setFillColor
    L5_3 = L3_2
    L5_3 = L5_3.textColor
    L3_3(L4_3, L5_3())
    L3_3 = L3_2
    L3_3 = L3_3.textObj
    L4_3 = L3_2
    L4_3 = L4_3.textObj
    L5_3 = 0
    L6_3 = _ttf_font_offset
    L7_3 = L3_2
    L7_3 = L7_3.fontNum
    L6_3 = L6_3[L7_3]
    L7_3 = L3_2
    L7_3 = L7_3.fontSize
    L6_3 = L6_3 * L7_3
    L4_3.y = L6_3
    L3_3.x = L5_3
    L3_3 = L3_2
    L3_3 = L3_3.textObj
    L4_3 = L3_2
    L4_3 = L4_3.textObj
    L5_3 = L3_2
    L5_3 = L5_3.textAnchorX
    L6_3 = L3_2
    L6_3 = L6_3.textAnchorY
    L4_3.anchorY = L6_3
    L3_3.anchorX = L5_3
    L3_3 = L3_2
    L3_3 = L3_3.fixedWidth
    if not L3_3 then
      L3_3 = L3_2
      L3_3 = L3_3.textObj
      L3_3 = L3_3.width
      L4_3 = L3_2
      L4_3 = L4_3.fontSize
      L5_3 = L3_2
      L5_3 = L5_3.text
      L6_3 = L5_3
      L5_3 = L5_3.len
      L5_3 = L5_3(L6_3)
      L4_3 = L4_3 * L5_3
      L4_3 = L4_3 / 6
      L3_3 = L3_3 + L4_3
    end
    L4_3 = L3_2
    L4_3 = L4_3.fixedHeight
    if not L4_3 then
      L4_3 = L3_2
      L4_3 = L4_3.textObj
      L4_3 = L4_3.height
      L5_3 = L3_2
      L5_3 = L5_3.fontSize
      L6_3 = L3_2
      L6_3 = L6_3.text
      L7_3 = L6_3
      L6_3 = L6_3.len
      L6_3 = L6_3(L7_3)
      L5_3 = L5_3 * L6_3
      L5_3 = L5_3 / 30
      L4_3 = L4_3 + L5_3
    end
    L5_3 = L3_2
    L6_3 = display
    L6_3 = L6_3.newRoundedRect
    L7_3 = L3_2
    L8_3 = 0
    L9_3 = 0
    L10_3 = L3_3
    L11_3 = L4_3
    L12_3 = L3_2
    L12_3 = L12_3.fontSize
    L12_3 = L12_3 / 2
    L6_3 = L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3)
    L5_3.frameObj = L6_3
    L5_3 = L3_2
    L5_3 = L5_3.frameObj
    L6_3 = L5_3
    L5_3 = L5_3.setFillColor
    L7_3 = L3_2
    L7_3 = L7_3.bgColor
    L5_3(L6_3, L7_3())
    L5_3 = L3_2
    L5_3 = L5_3.frameObj
    L6_3 = L3_2
    L6_3 = L6_3.strokeWidth
    L5_3.strokeWidth = L6_3
    L5_3 = L3_2
    L5_3 = L5_3.frameObj
    L6_3 = L5_3
    L5_3 = L5_3.setStrokeColor
    L7_3 = L3_2
    L7_3 = L7_3.strokeColor
    L5_3(L6_3, L7_3())
    L5_3 = L3_2
    L5_3 = L5_3.frameObj
    L6_3 = L3_2
    L6_3 = L6_3.frameObj
    L7_3 = 0
    L6_3.y = 0
    L5_3.x = L7_3
    L5_3 = L3_2
    L5_3 = L5_3.frameObj
    L6_3 = L5_3
    L5_3 = L5_3.toBack
    L5_3(L6_3)
    L5_3 = L3_2
    L5_3 = L5_3.frameless
    if L5_3 then
      L5_3 = L1_1
      if L5_3 then
        L5_3 = L3_2
        L5_3 = L5_3.frameObj
        L5_3.alpha = 0.2
      else
        L5_3 = L3_2
        L5_3 = L5_3.frameObj
        L5_3.alpha = 0.005
      end
    end
    L5_3 = L3_2
    L5_3 = L5_3.disabled
    if L5_3 then
      L5_3 = L3_2
      L6_3 = L3_2
      L6_3 = L6_3.alphaWhenDisabled
      L5_3.alpha = L6_3
    else
      L5_3 = L3_2
      L6_3 = L3_2
      L6_3 = L6_3.alphaWhenEnabled
      L5_3.alpha = L6_3
    end
    L5_3 = L3_2
    L6_3 = L3_2
    L7_3 = L1_3
    L6_3.y = L2_3
    L5_3.x = L7_3
  end
  
  L3_2.render = L5_2
  L6_2 = L3_2
  L5_2 = L3_2.render
  L5_2(L6_2)
  if L4_2 then
    L6_2 = L4_2
    L5_2 = L4_2.insert
    L7_2 = L3_2
    L5_2(L6_2, L7_2)
  end
  
  function L5_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3
    L3_3 = L3_2
    L3_3[A1_3] = A2_3
    L4_3 = A0_3
    L3_3 = A0_3.render
    L3_3(L4_3)
  end
  
  L3_2.setParam = L5_2
  
  function L5_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = L3_2
    L2_3 = L2_3.disabled
    if L2_3 then
      L2_3 = false
      return L2_3
    end
    L2_3 = A1_3.phase
    if L2_3 == "began" then
      L2_3 = sounds
      L2_3 = L2_3.playFast
      L3_3 = A0_3.sound
      L2_3(L3_3)
      L2_3 = display
      L2_3 = L2_3.getCurrentStage
      L2_3 = L2_3()
      L3_3 = L2_3
      L2_3 = L2_3.setFocus
      L4_3 = A1_3.target
      L5_3 = A1_3.id
      L2_3(L3_3, L4_3, L5_3)
      L2_3 = A0_3.textObj
      L3_3 = L2_3
      L2_3 = L2_3.setFillColor
      L4_3 = darkgray
      L2_3(L3_3, L4_3())
      L2_3 = A0_3.frameObj
      if L2_3 then
        L2_3 = A0_3.frameObj
        L3_3 = L2_3
        L2_3 = L2_3.setFillColor
        L4_3 = gray
        L2_3(L3_3, L4_3())
        L2_3 = A0_3.frameObj
        L3_3 = L2_3
        L2_3 = L2_3.setStrokeColor
        L4_3 = darkgray
        L2_3(L3_3, L4_3())
      end
      L2_3 = L3_2
      L3_3 = system
      L3_3 = L3_3.getTimer
      L3_3 = L3_3()
      L2_3.whenBegan = L3_3
    else
      L2_3 = A1_3.phase
      if L2_3 == "ended" then
        L2_3 = display
        L2_3 = L2_3.getCurrentStage
        L2_3 = L2_3()
        L3_3 = L2_3
        L2_3 = L2_3.setFocus
        L4_3 = A1_3.target
        L5_3 = nil
        L2_3(L3_3, L4_3, L5_3)
        L2_3 = L3_2
        L2_3 = L2_3.whenBegan
        if L2_3 == nil then
          L2_3 = false
          return L2_3
        end
        L2_3 = system
        L2_3 = L2_3.getTimer
        L2_3 = L2_3()
        L3_3 = L3_2
        L3_3 = L3_3.whenBegan
        L2_3 = L2_3 - L3_3
        L3_3 = 0
        if L2_3 < 50 then
          L3_3 = 30
        end
        L4_3 = timer
        L4_3 = L4_3.performWithDelay
        L5_3 = L3_3
        
        function L6_3()
          local L0_4, L1_4, L2_4, L3_4
          L0_4 = A0_3
          L0_4 = L0_4.textObj
          L1_4 = L0_4
          L0_4 = L0_4.setFillColor
          L2_4 = A0_3
          L2_4 = L2_4.textColor
          L0_4(L1_4, L2_4())
          L0_4 = L3_2
          L0_4 = L0_4.emboss
          if L0_4 then
            L0_4 = A0_3
            L0_4 = L0_4.textObj
            L1_4 = L0_4
            L0_4 = L0_4.setEmbossColor
            L2_4 = {}
            L3_4 = {}
            L3_4.r = 0
            L3_4.g = 0
            L3_4.b = 0
            L3_4.a = 0.5019607843137255
            L2_4.highlight = L3_4
            L3_4 = {}
            L3_4.r = 0
            L3_4.g = 0
            L3_4.b = 0
            L3_4.a = 0
            L2_4.shadow = L3_4
            L0_4(L1_4, L2_4)
          end
          L0_4 = A0_3
          L0_4 = L0_4.frameObj
          if L0_4 then
            L0_4 = A0_3
            L0_4 = L0_4.frameObj
            L1_4 = L0_4
            L0_4 = L0_4.setFillColor
            L2_4 = A0_3
            L2_4 = L2_4.bgColor
            L0_4(L1_4, L2_4())
            L0_4 = A0_3
            L0_4 = L0_4.frameObj
            L1_4 = L0_4
            L0_4 = L0_4.setStrokeColor
            L2_4 = A0_3
            L2_4 = L2_4.strokeColor
            L0_4(L1_4, L2_4())
          end
          L0_4 = A1_2
          if L0_4 then
            L0_4 = A1_2
            L0_4()
          end
        end
        
        L4_3(L5_3, L6_3)
        L4_3 = L3_2
        L4_3.whenBegan = nil
      end
    end
    L2_3 = true
    return L2_3
  end
  
  L3_2.touch = L5_2
  if A1_2 then
    L6_2 = L3_2
    L5_2 = L3_2.addEventListener
    L7_2 = "touch"
    L8_2 = L3_2
    L5_2(L6_2, L7_2, L8_2)
  end
  return L3_2
end

L0_1.newPlainText = L2_1

function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  if not A2_2 then
    L3_2 = {}
    A2_2 = L3_2
  end
  L3_2 = display
  L3_2 = L3_2.newGroup
  L3_2 = L3_2()
  L3_2.anchorChildren = true
  L3_2.file = A0_2
  L4_2 = A2_2.alphaWhenEnabled
  if not L4_2 then
    L4_2 = 1
  end
  L3_2.alphaWhenEnabled = L4_2
  L4_2 = A2_2.alphaWhenDisabled
  if not L4_2 then
    L4_2 = 0.2
  end
  L3_2.alphaWhenDisabled = L4_2
  L4_2 = A2_2.sound
  if not L4_2 then
    L4_2 = sounds
    L4_2 = L4_2._button_click_fast
  end
  L3_2.sound = L4_2
  L4_2 = A2_2.fixedWidth
  L3_2.fixedWidth = L4_2
  L4_2 = A2_2.fixedHeight
  L3_2.fixedHeight = L4_2
  L4_2 = A2_2.disabled
  if not L4_2 then
    L4_2 = false
  end
  L3_2.disabled = L4_2
  L4_2 = A2_2.fillColor
  if not L4_2 then
    L4_2 = white
  end
  L3_2.fillColor = L4_2
  L4_2 = A2_2.group
  
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = A0_3.x
    L2_3 = A0_3.y
    L3_3 = A0_3.graphicObj
    if L3_3 then
      L3_3 = A0_3.graphicObj
      L4_3 = L3_3
      L3_3 = L3_3.removeSelf
      L3_3(L4_3)
    end
    L3_3 = display
    L3_3 = L3_3.newImageRect
    L4_3 = L3_2
    L5_3 = A0_3.file
    L6_3 = A0_3.fixedWidth
    L7_3 = A0_3.fixedHeight
    L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3)
    A0_3.graphicObj = L3_3
    L3_3 = A0_3.graphicObj
    L3_3 = L3_3.setFillColor
    if L3_3 then
      L3_3 = A0_3.graphicObj
      L4_3 = L3_3
      L3_3 = L3_3.setFillColor
      L5_3 = A0_3.fillColor
      L3_3(L4_3, L5_3())
    end
    L3_3 = A0_3.disabled
    if L3_3 then
      L3_3 = A0_3.alphaWhenDisabled
      A0_3.alpha = L3_3
    else
      L3_3 = A0_3.alphaWhenEnabled
      A0_3.alpha = L3_3
    end
    L3_3 = L1_3
    A0_3.y = L2_3
    A0_3.x = L3_3
  end
  
  L3_2.render = L5_2
  L6_2 = L3_2
  L5_2 = L3_2.render
  L5_2(L6_2)
  if L4_2 then
    L6_2 = L4_2
    L5_2 = L4_2.insert
    L7_2 = L3_2
    L5_2(L6_2, L7_2)
  end
  
  function L5_2(A0_3, A1_3, A2_3)
    local L3_3, L4_3
    L3_3 = L3_2
    L3_3[A1_3] = A2_3
    L4_3 = A0_3
    L3_3 = A0_3.render
    L3_3(L4_3)
  end
  
  L3_2.setParam = L5_2
  
  function L5_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3, L6_3
    L2_3 = A0_3.disabled
    if L2_3 then
      L2_3 = false
      return L2_3
    end
    L2_3 = A1_3.phase
    if L2_3 == "began" then
      L2_3 = sounds
      L2_3 = L2_3.playFast
      L3_3 = A0_3.sound
      L2_3(L3_3)
      L2_3 = display
      L2_3 = L2_3.getCurrentStage
      L2_3 = L2_3()
      L3_3 = L2_3
      L2_3 = L2_3.setFocus
      L4_3 = A1_3.target
      L5_3 = A1_3.id
      L2_3(L3_3, L4_3, L5_3)
      L2_3 = A0_3.graphicObj
      L3_3 = L2_3
      L2_3 = L2_3.setFillColor
      L4_3 = gray
      L2_3(L3_3, L4_3())
      L2_3 = system
      L2_3 = L2_3.getTimer
      L2_3 = L2_3()
      A0_3.whenBegan = L2_3
    else
      L2_3 = A1_3.phase
      if L2_3 == "ended" then
        L2_3 = display
        L2_3 = L2_3.getCurrentStage
        L2_3 = L2_3()
        L3_3 = L2_3
        L2_3 = L2_3.setFocus
        L4_3 = A1_3.target
        L5_3 = nil
        L2_3(L3_3, L4_3, L5_3)
        L2_3 = A0_3.whenBegan
        if L2_3 == nil then
          L2_3 = false
          return L2_3
        end
        L2_3 = system
        L2_3 = L2_3.getTimer
        L2_3 = L2_3()
        L3_3 = A0_3.whenBegan
        L2_3 = L2_3 - L3_3
        L3_3 = 0
        if L2_3 < 50 then
          L3_3 = 30
        end
        L4_3 = timer
        L4_3 = L4_3.performWithDelay
        L5_3 = L3_3
        
        function L6_3()
          local L0_4, L1_4, L2_4
          L0_4 = A0_3
          L0_4 = L0_4.graphicObj
          L0_4 = L0_4.setFillColor
          if L0_4 then
            L0_4 = A0_3
            L0_4 = L0_4.graphicObj
            L1_4 = L0_4
            L0_4 = L0_4.setFillColor
            L2_4 = A0_3
            L2_4 = L2_4.fillColor
            L2_4 = L2_4()
            L0_4(L1_4, L2_4)
          end
          L0_4 = A1_2
          if L0_4 then
            L0_4 = A1_2
            L0_4()
          end
        end
        
        L4_3(L5_3, L6_3)
        A0_3.whenBegan = nil
      end
    end
    L2_3 = true
    return L2_3
  end
  
  L3_2.touch = L5_2
  if A1_2 then
    L6_2 = L3_2
    L5_2 = L3_2.addEventListener
    L7_2 = "touch"
    L8_2 = L3_2
    L5_2(L6_2, L7_2, L8_2)
  end
  return L3_2
end

L0_1.newGraphical = L2_1
return L0_1
