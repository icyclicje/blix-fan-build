local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = {}
L1_1 = require
L2_1 = "json"
L1_1 = L1_1(L2_1)
L2_1 = require
L3_1 = "crypto"
L2_1 = L2_1(L3_1)
L3_1 = false
if L3_1 then
  L4_1 = log
  L4_1 = L4_1.show
  L5_1 = "_saver.lua DEBUGGING"
  L4_1(L5_1)
end

function L4_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  if not A3_2 then
    L4_2 = system
    A3_2 = L4_2.DocumentsDirectory
  end
  L4_2 = system
  L4_2 = L4_2.pathForFile
  L5_2 = A1_2
  L6_2 = A3_2
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = io
  L5_2 = L5_2.open
  L6_2 = L4_2
  L7_2 = "w"
  L5_2 = L5_2(L6_2, L7_2)
  L6_2 = L1_1
  L6_2 = L6_2.encode
  L7_2 = A0_2
  L6_2 = L6_2(L7_2)
  L8_2 = L5_2
  L7_2 = L5_2.write
  L9_2 = L6_2
  L7_2(L8_2, L9_2)
  L7_2 = io
  L7_2 = L7_2.close
  L8_2 = L5_2
  L7_2(L8_2)
  if not A2_2 then
    L7_2 = L2_1
    L7_2 = L7_2.digest
    L8_2 = L2_1
    L8_2 = L8_2.md5
    L9_2 = "BFM"
    L10_2 = L6_2
    L11_2 = "ADP"
    L9_2 = L9_2 .. L10_2 .. L11_2
    L7_2 = L7_2(L8_2, L9_2)
    L8_2 = system
    L8_2 = L8_2.pathForFile
    L9_2 = "__"
    L10_2 = A1_2
    L9_2 = L9_2 .. L10_2
    L10_2 = A3_2
    L8_2 = L8_2(L9_2, L10_2)
    L4_2 = L8_2
    L8_2 = io
    L8_2 = L8_2.open
    L9_2 = L4_2
    L10_2 = "w"
    L8_2 = L8_2(L9_2, L10_2)
    L5_2 = L8_2
    L9_2 = L5_2
    L8_2 = L5_2.write
    L10_2 = L7_2
    L8_2(L9_2, L10_2)
    L8_2 = io
    L8_2 = L8_2.close
    L9_2 = L5_2
    L8_2(L9_2)
  end
  L7_2 = L3_1
  if L7_2 then
    L7_2 = print
    L8_2 = "Save() "
    L9_2 = A1_2
    L8_2 = L8_2 .. L9_2
    L7_2(L8_2)
    L7_2 = print
    L8_2 = L6_2
    L7_2(L8_2)
  end
end

L0_1.Save = L4_1

function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  if not A2_2 then
    L3_2 = system
    A2_2 = L3_2.DocumentsDirectory
  end
  L3_2 = nil
  L4_2 = nil
  L5_2 = nil
  if not A1_2 then
    L6_2 = system
    L6_2 = L6_2.pathForFile
    L7_2 = "__"
    L8_2 = A0_2
    L7_2 = L7_2 .. L8_2
    L8_2 = A2_2
    L6_2 = L6_2(L7_2, L8_2)
    L4_2 = L6_2
    L6_2 = io
    L6_2 = L6_2.open
    L7_2 = L4_2
    L8_2 = "r"
    L6_2 = L6_2(L7_2, L8_2)
    L5_2 = L6_2
    if L5_2 then
      L7_2 = L5_2
      L6_2 = L5_2.read
      L8_2 = "*a"
      L6_2 = L6_2(L7_2, L8_2)
      L3_2 = L6_2
      L6_2 = io
      L6_2 = L6_2.close
      L7_2 = L5_2
      L6_2(L7_2)
    else
      L6_2 = nil
      return L6_2
    end
  end
  L6_2 = system
  L6_2 = L6_2.pathForFile
  L7_2 = A0_2
  L8_2 = A2_2
  L6_2 = L6_2(L7_2, L8_2)
  L4_2 = L6_2
  L6_2 = io
  L6_2 = L6_2.open
  L7_2 = L4_2
  L8_2 = "r"
  L6_2 = L6_2(L7_2, L8_2)
  L5_2 = L6_2
  L6_2 = nil
  if L5_2 then
    L8_2 = L5_2
    L7_2 = L5_2.read
    L9_2 = "*a"
    L7_2 = L7_2(L8_2, L9_2)
    L6_2 = L7_2
    L7_2 = L1_1
    L7_2 = L7_2.decode
    L8_2 = L6_2
    L7_2 = L7_2(L8_2)
    L8_2 = io
    L8_2 = L8_2.close
    L9_2 = L5_2
    L8_2(L9_2)
    if not A1_2 then
      L8_2 = L2_1
      L8_2 = L8_2.digest
      L9_2 = L2_1
      L9_2 = L9_2.md5
      L10_2 = "BFM"
      L11_2 = L6_2
      L12_2 = "ADP"
      L10_2 = L10_2 .. L11_2 .. L12_2
      L8_2 = L8_2(L9_2, L10_2)
      if L3_2 == L8_2 then
        return L7_2
      end
    else
      return L7_2
    end
  end
  L7_2 = nil
  return L7_2
end

L0_1.Load = L4_1
return L0_1
