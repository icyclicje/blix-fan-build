local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = print
  L3_1 = "_log.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = 0
L3_1 = 0
L4_1 = 18
L5_1 = _isGear
if L5_1 then
  L4_1 = 8
end

function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  if not A1_2 then
    L2_2 = {}
    A1_2 = L2_2
  end
  L2_2 = A1_2.textColor
  if not L2_2 then
    L2_2 = white
  end
  L3_2 = A1_2.bgColor
  if not L3_2 then
    L3_2 = verydarkblue
  end
  L4_2 = A1_2.pos
  L5_2 = A1_2.time
  if not L5_2 then
    L5_2 = 10000
  end
  L6_2 = A1_2.fontSize
  if not L6_2 then
    L6_2 = 9
  end
  L7_2 = A1_2.fontNum
  if not L7_2 then
    L7_2 = 0
  end
  L8_2 = A1_2.dontPrint
  if not L8_2 then
    L8_2 = false
  end
  L9_2 = _isGear
  if L9_2 then
    L6_2 = L6_2 * 2
  end
  L9_2 = L2_1
  L9_2 = L9_2 + 1
  L2_1 = L9_2
  L9_2 = L3_1
  L9_2 = L9_2 + 1
  L3_1 = L9_2
  if L4_2 then
    L2_1 = L4_2
    L3_1 = L4_2
  end
  L9_2 = L2_1
  L10_2 = L4_1
  if L9_2 > L10_2 then
    L9_2 = 1
    L2_1 = L9_2
  end
  if L5_2 == nil then
    L9_2 = L3_1
    L10_2 = ")  "
    L11_2 = A0_2
    A0_2 = L9_2 .. L10_2 .. L11_2
  end
  L9_2 = display
  L9_2 = L9_2.newGroup
  L9_2 = L9_2()
  L10_2 = display
  L10_2 = L10_2.newText
  L11_2 = L9_2
  L12_2 = L3_1
  L13_2 = ") "
  L14_2 = A0_2
  L12_2 = L12_2 .. L13_2 .. L14_2
  L13_2 = 0
  L14_2 = 0
  L15_2 = _ttf_font
  L15_2 = L15_2[L7_2]
  L16_2 = L6_2
  L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  L9_2.text = L10_2
  L10_2 = L9_2.text
  L11_2 = L10_2
  L10_2 = L10_2.setFillColor
  L12_2 = L2_2
  L10_2(L11_2, L12_2())
  L10_2 = L9_2.text
  L11_2 = L9_2.text
  L12_2 = 0
  L11_2.y = 0
  L10_2.x = L12_2
  L10_2 = display
  L10_2 = L10_2.newRoundedRect
  L11_2 = L9_2
  L12_2 = 0
  L13_2 = 0
  L14_2 = L9_2.text
  L14_2 = L14_2.width
  L15_2 = L6_2 * 1.5
  L14_2 = L14_2 + L15_2
  L15_2 = L9_2.text
  L15_2 = L15_2.height
  L16_2 = L6_2 * 0.75
  L15_2 = L15_2 + L16_2
  L16_2 = L6_2 / 2
  L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  L9_2.bg = L10_2
  L10_2 = L9_2.bg
  L11_2 = L10_2
  L10_2 = L10_2.setFillColor
  L12_2 = L3_2
  L10_2(L11_2, L12_2())
  L10_2 = L9_2.bg
  L10_2.strokeWidth = 1
  L10_2 = L9_2.bg
  L11_2 = L10_2
  L10_2 = L10_2.setStrokeColor
  L12_2 = gray
  L10_2(L11_2, L12_2())
  L10_2 = L9_2.bg
  L11_2 = L9_2.bg
  L12_2 = 0
  L11_2.y = 0
  L10_2.x = L12_2
  L10_2 = L9_2.bg
  L11_2 = L10_2
  L10_2 = L10_2.toBack
  L10_2(L11_2)
  L10_2 = _W2
  L11_2 = screenTop
  L12_2 = screenHeight
  L13_2 = L2_1
  L12_2 = L12_2 * L13_2
  L13_2 = L4_1
  L13_2 = L13_2 + 1
  L12_2 = L12_2 / L13_2
  L11_2 = L11_2 + L12_2
  L9_2.y = L11_2
  L9_2.x = L10_2
  
  function L10_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = A1_3.phase
    if L2_3 == "began" then
      L2_3 = L9_2
      L2_3 = L2_3.deleteTransition
      if L2_3 then
        L2_3 = transition
        L2_3 = L2_3.cancel
        L3_3 = L9_2
        L3_3 = L3_3.deleteTransition
        L2_3(L3_3)
        L2_3 = L9_2
        L2_3.deleteTransition = nil
      end
      L2_3 = L9_2
      L3_3 = L2_3
      L2_3 = L2_3.removeSelf
      L2_3(L3_3)
    end
    L2_3 = true
    return L2_3
  end
  
  L9_2.touch = L10_2
  L11_2 = L9_2
  L10_2 = L9_2.addEventListener
  L12_2 = "touch"
  L13_2 = L9_2
  L10_2(L11_2, L12_2, L13_2)
  if 0 < L5_2 then
    L10_2 = transition
    L10_2 = L10_2.to
    L11_2 = L9_2
    L12_2 = {}
    L13_2 = L5_2 / 5
    L12_2.delay = L13_2
    L13_2 = L5_2 * 4
    L13_2 = L13_2 / 5
    L12_2.time = L13_2
    L12_2.alpha = 0
    
    function L13_2()
      local L0_3, L1_3
      L0_3 = L9_2
      L0_3.deleteTransition = nil
      L0_3 = L9_2
      L1_3 = L0_3
      L0_3 = L0_3.removeSelf
      L0_3(L1_3)
    end
    
    L12_2.onComplete = L13_2
    L10_2 = L10_2(L11_2, L12_2)
    L9_2.deleteTransition = L10_2
    if not L8_2 then
      L10_2 = print
      L11_2 = L3_1
      L12_2 = ") "
      L13_2 = A0_2
      L11_2 = L11_2 .. L12_2 .. L13_2
      L10_2(L11_2)
    end
  end
end

L0_1.show = L5_1
return L0_1
