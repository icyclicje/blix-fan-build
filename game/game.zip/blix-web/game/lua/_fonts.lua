local L0_1, L1_1
L0_1 = {}
_ttf_font = L0_1
L0_1 = {}
_ttf_font_offset = L0_1
L0_1 = _ttf_font
L0_1[0] = nil
L0_1 = _ttf_font_offset
L0_1[0] = 0
L0_1 = platform
L0_1 = L0_1.ios
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[0] = 0
end
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[0] = -0.04
end
L0_1 = platform
L0_1 = L0_1.mac
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[0] = -0.03
end
L0_1 = _ttf_font
L0_1[1] = "VAGRounded BT"
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font
  L0_1[1] = "_font_VAGRounded_BT"
end
L0_1 = _ttf_font_offset
L0_1[1] = 0
L0_1 = platform
L0_1 = L0_1.ios
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[1] = -0.07
end
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[1] = -0.07
end
L0_1 = platform
L0_1 = L0_1.mac
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[1] = -0.17
end
L0_1 = _ttf_font
L0_1[2] = "DisposableDroid BB"
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font
  L0_1[2] = "_font_DisposableDroidBB_bld"
end
L0_1 = _ttf_font_offset
L0_1[2] = 0
L0_1 = platform
L0_1 = L0_1.ios
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[2] = -0.03
end
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[2] = 0.07
end
L0_1 = platform
L0_1 = L0_1.mac
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[2] = -0.03
end
L0_1 = _ttf_font
L0_1[3] = "Alex Brush"
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font
  L0_1[3] = "_font_Alex_Brush"
end
L0_1 = _ttf_font_offset
L0_1[3] = 0
L0_1 = platform
L0_1 = L0_1.ios
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[3] = 0
end
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[3] = 0
end
L0_1 = platform
L0_1 = L0_1.mac
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[3] = -0.08
end
L0_1 = _ttf_font
L0_1[4] = "Beautiful Every Time"
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font
  L0_1[4] = "_font_Beautiful_Every_Time"
end
L0_1 = _ttf_font_offset
L0_1[4] = 0
L0_1 = platform
L0_1 = L0_1.ios
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[4] = 0.12
end
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[4] = 0.12
end
L0_1 = platform
L0_1 = L0_1.mac
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[4] = -0.05
end
L0_1 = _ttf_font
L0_1[5] = "Brady Bunch Remastered"
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font
  L0_1[5] = "_font_Brady_Bunch_Remastered"
end
L0_1 = _ttf_font_offset
L0_1[5] = 0
L0_1 = platform
L0_1 = L0_1.ios
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[5] = 0
end
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[5] = 0
end
L0_1 = platform
L0_1 = L0_1.mac
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[5] = -0.03
end
L0_1 = _ttf_font
L0_1[6] = "Oregano"
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font
  L0_1[6] = "_font_Oregano"
end
L0_1 = _ttf_font_offset
L0_1[6] = 0
L0_1 = platform
L0_1 = L0_1.ios
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[6] = 0
end
L0_1 = platform
L0_1 = L0_1.android
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[6] = 0
end
L0_1 = platform
L0_1 = L0_1.mac
if L0_1 then
  L0_1 = _ttf_font_offset
  L0_1[6] = -0.15
end
