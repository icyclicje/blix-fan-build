local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1
L0_1 = {}
L1_1 = math
L1_1 = L1_1.sqrt
L2_1 = math
L2_1 = L2_1.pow
L3_1 = math
L3_1 = L3_1.ceil
L4_1 = false
if L4_1 then
  L5_1 = log
  L5_1 = L5_1.show
  L6_1 = "target.lua DEBUGGING"
  L5_1(L6_1)
end
L5_1 = {}
L0_1.list = L5_1
L0_1.numInPlay = 0

function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = display
  L2_2 = L2_2.newImageRect
  L3_2 = A0_2
  L4_2 = "images/circle_256.png"
  L5_2 = A1_2.radius
  L5_2 = L5_2 * 2
  L6_2 = A1_2.radius
  L6_2 = L6_2 * 2
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
  L3_2 = A1_2.x
  L4_2 = A1_2.y
  L2_2.y = L4_2
  L2_2.x = L3_2
  L2_2.type_target = true
  L2_2.name = "target"
  L3_2 = A1_2.radius
  L2_2.radius = L3_2
  L3_2 = A1_2.color
  if not L3_2 then
    L3_2 = gameutils
    L3_2 = L3_2.getRandomColor
    L3_2 = L3_2()
  end
  L2_2.color = L3_2
  L4_2 = L2_2
  L3_2 = L2_2.setFillColor
  L5_2 = L2_2.color
  L3_2(L4_2, L5_2())
  L2_2.removed = false
  L3_2 = system
  L3_2 = L3_2.getTimer
  L3_2 = L3_2()
  L2_2.timeCreated = L3_2
  L2_2.whenHit = nil
  L3_2 = L0_1
  L3_2 = L3_2.list
  L4_2 = L0_1
  L4_2 = L4_2.list
  L4_2 = #L4_2
  L4_2 = L4_2 + 1
  L3_2[L4_2] = L2_2
  L3_2 = L0_1
  L3_2 = L3_2.list
  L3_2 = #L3_2
  L2_2.index = L3_2
  L3_2 = L0_1
  L4_2 = L0_1
  L4_2 = L4_2.numInPlay
  L4_2 = L4_2 + 1
  L3_2.numInPlay = L4_2
  
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = A0_3.removed
    if L1_3 then
      return
    end
    L1_3 = A0_3.hitTransition
    if L1_3 then
      L1_3 = transition
      L1_3 = L1_3.cancel
      L2_3 = A0_3.hitTransition
      L1_3(L2_3)
      A0_3.hitTransition = nil
    end
    L1_3 = A0_3.reappearTransition
    if L1_3 then
      L1_3 = transition
      L1_3 = L1_3.cancel
      L2_3 = A0_3.reappearTransition
      L1_3(L2_3)
      A0_3.reappearTransition = nil
    end
    L1_3 = system
    L1_3 = L1_3.getTimer
    L1_3 = L1_3()
    A0_3.whenHit = L1_3
    L1_3 = transition
    L1_3 = L1_3.to
    L2_3 = A0_3
    L3_3 = {}
    L3_3.delay = 0
    L3_3.time = 300
    L3_3.xScale = 3
    L3_3.yScale = 3
    L3_3.alpha = 0.1
    
    function L4_3()
      local L0_4, L1_4, L2_4
      L0_4 = A0_3
      L1_4 = A0_3
      L2_4 = 1
      L1_4.yScale = 1
      L0_4.xScale = L2_4
      L0_4 = A0_3
      L0_4.hitTransition = nil
    end
    
    L3_3.onComplete = L4_3
    L1_3 = L1_3(L2_3, L3_3)
    A0_3.hitTransition = L1_3
  end
  
  L2_2.hit = L3_2
  
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = A0_3.removed
    if L1_3 then
      return
    end
    L1_3 = A0_3.hitTransition
    if L1_3 then
      L1_3 = transition
      L1_3 = L1_3.cancel
      L2_3 = A0_3.hitTransition
      L1_3(L2_3)
      A0_3.hitTransition = nil
    end
    L1_3 = A0_3.reappearTransition
    if L1_3 then
      L1_3 = transition
      L1_3 = L1_3.cancel
      L2_3 = A0_3.reappearTransition
      L1_3(L2_3)
      A0_3.reappearTransition = nil
    end
    A0_3.whenHit = nil
    A0_3.isVisible = true
    L1_3 = 1
    A0_3.yScale = 1
    A0_3.xScale = L1_3
    L1_3 = sounds
    L1_3 = L1_3.play
    L2_3 = sounds
    L2_3 = L2_3.targetReappear
    L3_3 = 0.5
    L1_3(L2_3, L3_3)
    L1_3 = transition
    L1_3 = L1_3.to
    L2_3 = A0_3
    L3_3 = {}
    L3_3.delay = 0
    L3_3.time = 300
    L3_3.alpha = 1
    
    function L4_3()
      local L0_4, L1_4
      L0_4 = A0_3
      L0_4.reappearTransition = nil
    end
    
    L3_3.onComplete = L4_3
    L1_3 = L1_3(L2_3, L3_3)
    A0_3.reappearTransition = L1_3
  end
  
  L2_2.reappear = L3_2
  
  function L3_2(A0_3, A1_3)
    local L2_3, L3_3, L4_3, L5_3
    L2_3 = A0_3.removed
    if L2_3 then
      return
    end
    A0_3.removed = true
    L2_3 = L0_1
    L3_3 = L0_1
    L3_3 = L3_3.numInPlay
    L3_3 = L3_3 - 1
    L2_3.numInPlay = L3_3
    if 0 < A1_3 then
      L2_3 = transition
      L2_3 = L2_3.to
      L3_3 = A0_3
      L4_3 = {}
      L4_3.delay = A1_3
      L4_3.time = 200
      L4_3.xScale = 0.1
      L4_3.yScale = 0.1
      
      function L5_3()
        local L0_4, L1_4
        L0_4 = display
        L0_4 = L0_4.remove
        L1_4 = A0_3
        L0_4(L1_4)
      end
      
      L4_3.onComplete = L5_3
      L2_3(L3_3, L4_3)
    else
      L2_3 = display
      L2_3 = L2_3.remove
      L3_3 = A0_3
      L2_3(L3_3)
    end
  end
  
  L2_2.remove = L3_2
  L3_2 = A1_2.delay
  if L3_2 then
    L2_2.alpha = 0
    L3_2 = transition
    L3_2 = L3_2.to
    L4_2 = L2_2
    L5_2 = {}
    L6_2 = A1_2.delay
    L5_2.delay = L6_2
    L5_2.time = 300
    L5_2.alpha = 1
    L3_2(L4_2, L5_2)
  end
  return L2_2
end

L0_1.new = L5_1

function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = L0_1
  L0_2 = L0_2.list
  L0_2 = #L0_2
  L1_2 = 1
  L2_2 = L0_2
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = L0_1
    L5_2 = L5_2.list
    L5_2 = L5_2[L4_2]
    L6_2 = L5_2
    L5_2 = L5_2.remove
    L7_2 = 0
    L5_2(L6_2, L7_2)
  end
  L1_2 = L0_1
  L2_2 = {}
  L1_2.list = L2_2
  L1_2 = L0_1
  L1_2.numInPlay = 0
end

L0_1.removeAll = L5_1
return L0_1
