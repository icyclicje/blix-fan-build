local L0_1, L1_1
L0_1 = {}
L1_1 = 103
APP_VERSION = L1_1
L1_1 = "Blix"
APP_NAME = L1_1
L1_1 = "blix"
APP_ID = L1_1
L1_1 = "http://1e79b1df0d29d00faf8b-7b4c00664b2a55a8effd53812dcc0ef7.r15.cf1.rackcdn.com/icon_150.png"
APP_ONLINE_ICON = L1_1
L1_1 = "com.bonfiremedia.blix"
PACKAGE_NAME = L1_1
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L1_1 = "com.bonfiremedia.blix"
  PACKAGE_NAME = L1_1
end
L1_1 = "support@bonfiremedia.com"
SUPPORT_EMAIL = L1_1
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L1_1 = "support@bonfiremedia.com"
  SUPPORT_EMAIL = L1_1
end
L0_1.GAMETHRIVE_APP_KEY = "31ed65ec-f13a-11e3-a2a1-a7fea3450581"
L0_1.FB_API_KEY = "1459449577632424"
L0_1.sharing_url = "http://bit.ly/1m8xjc9"
L0_1.ACH_FB_FRIENDS_NUMBER = 3
L0_1.ACH_ID_FB_LOGIN = "FB_LOGIN"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_FB_LOGIN = ""
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_FB_LOGIN = ""
end
L0_1.ACH_ID_FB_FRIENDS = "FB_FRIENDS"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_FB_FRIENDS = ""
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_FB_FRIENDS = ""
end
L0_1.ACH_ID_FB_SEND_GIFT = "FB_SEND_GIFT"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_FB_SEND_GIFT = ""
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_FB_SEND_GIFT = ""
end
L0_1.ACH_ID_TUTORIAL = "TUTORIAL"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_TUTORIAL = "ach_blix_tutorial"
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_TUTORIAL = "CgkI8qfunbQaEAIQCw"
end
L0_1.ACH_ID_LEVEL_05 = "LEVEL_05"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_LEVEL_05 = "ach_blix_level_05"
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_LEVEL_05 = "CgkI8qfunbQaEAIQBA"
end
L0_1.ACH_ID_LEVEL_10 = "LEVEL_10"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_LEVEL_10 = "ach_blix_level_10"
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_LEVEL_10 = "CgkI8qfunbQaEAIQBQ"
end
L0_1.ACH_ID_LEVEL_20 = "LEVEL_20"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_LEVEL_20 = "ach_blix_level_20"
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_LEVEL_20 = "CgkI8qfunbQaEAIQBg"
end
L0_1.ACH_ID_LEVEL_30 = "LEVEL_30"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_LEVEL_30 = "ach_blix_level_30"
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_LEVEL_30 = "CgkI8qfunbQaEAIQBw"
end
L0_1.ACH_ID_LEVEL_40 = "LEVEL_40"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_LEVEL_40 = "ach_blix_level_40"
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_LEVEL_40 = "CgkI8qfunbQaEAIQCA"
end
L0_1.ACH_ID_LEVEL_50 = "LEVEL_50"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.ACH_ID_LEVEL_50 = "ach_blix_level_50"
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.ACH_ID_LEVEL_50 = "CgkI8qfunbQaEAIQCQ"
end
L0_1.LEADERBOARD_ID_POINTANDSHOOT = "POINTANDSHOOT"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.LEADERBOARD_ID_POINTANDSHOOT = "blix_pointandshoot"
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.LEADERBOARD_ID_POINTANDSHOOT = "CgkI8qfunbQaEAIQAg"
end
L0_1.LEADERBOARD_ID_SWARM = "SWARM"
L1_1 = platform
L1_1 = L1_1.ios
if L1_1 then
  L0_1.LEADERBOARD_ID_SWARM = "blix_swarm"
end
L1_1 = platform
L1_1 = L1_1.android
if L1_1 then
  L0_1.LEADERBOARD_ID_SWARM = "CgkI8qfunbQaEAIQAw"
end
L0_1.MOMENT_BEAT_PERSONAL_BEST_IN_CLASSIC = "Personal best in Classic!"
L0_1.MOMENT_GREAT_SCORE_IN_CLASSIC = "Great score in Classic!"

function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  A0_2.whoosh = nil
  L1_2 = audio
  L1_2 = L1_2.loadSound
  L2_2 = "sounds/InterfaceAlertSound.mp3"
  L1_2 = L1_2(L2_2)
  A0_2.bbAppear = L1_2
  L1_2 = audio
  L1_2 = L1_2.loadSound
  L2_2 = "sounds/LiftBell.mp3"
  L1_2 = L1_2(L2_2)
  A0_2.targetReappear = L1_2
  L1_2 = audio
  L1_2 = L1_2.loadSound
  L2_2 = "sounds/glossy_fail_03.mp3"
  L1_2 = L1_2(L2_2)
  A0_2.die = L1_2
  L1_2 = audio
  L1_2 = L1_2.loadSound
  L2_2 = "sounds/funnysound3.mp3"
  L1_2 = L1_2(L2_2)
  A0_2.bbCleared = L1_2
  L1_2 = audio
  L1_2 = L1_2.loadSound
  L2_2 = "sounds/positive-win-game-sound-quieter.mp3"
  L1_2 = L1_2(L2_2)
  A0_2.levelup = L1_2
  L1_2 = platform
  L1_2 = L1_2.android
  if not L1_2 then
    L1_2 = {}
    A0_2.palette = L1_2
    L1_2 = 1
    L2_2 = 6
    L3_2 = 1
    for L4_2 = L1_2, L2_2, L3_2 do
      L5_2 = A0_2.palette
      L6_2 = audio
      L6_2 = L6_2.loadSound
      L7_2 = "sounds/gentle0"
      L8_2 = L4_2
      L9_2 = ".mp3"
      L7_2 = L7_2 .. L8_2 .. L9_2
      L6_2 = L6_2(L7_2)
      L5_2[L4_2] = L6_2
    end
  end
  L1_2 = {}
  A0_2.hits = L1_2
  L1_2 = 1
  L2_2 = 9
  L3_2 = 1
  for L4_2 = L1_2, L2_2, L3_2 do
    L5_2 = A0_2.hits
    L6_2 = audio
    L6_2 = L6_2.loadSound
    L7_2 = "sounds/Beep_0"
    L8_2 = L4_2
    L9_2 = ".mp3"
    L7_2 = L7_2 .. L8_2 .. L9_2
    L6_2 = L6_2(L7_2)
    L5_2[L4_2] = L6_2
  end
  L1_2 = media
  L1_2 = L1_2.newEventSound
  L2_2 = "sounds/gentle_sweet_click_1.mp3"
  L1_2 = L1_2(L2_2)
  A0_2.gentle_sweet_click_fast = L1_2
  L1_2 = platform
  L1_2 = L1_2.android
  if L1_2 then
    L1_2 = {}
    A0_2.palette_fast = L1_2
    L1_2 = 1
    L2_2 = 6
    L3_2 = 1
    for L4_2 = L1_2, L2_2, L3_2 do
      L5_2 = A0_2.palette_fast
      L6_2 = media
      L6_2 = L6_2.newEventSound
      L7_2 = "sounds/gentle0"
      L8_2 = L4_2
      L9_2 = ".mp3"
      L7_2 = L7_2 .. L8_2 .. L9_2
      L6_2 = L6_2(L7_2)
      L5_2[L4_2] = L6_2
    end
  end
end

L0_1.makeAppSpecificSounds = L1_1

function L1_1(A0_2)
  local L1_2
  L1_2 = {}
  A0_2.bg_music = L1_2
end

L0_1.makeBgMusic = L1_1
L0_1.defaultFont = 4
return L0_1
