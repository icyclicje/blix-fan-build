local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1
L0_1 = {}
L1_1 = require
L2_1 = "gameNetwork"
L1_1 = L1_1(L2_1)
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "_gamenetwork_utils.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = false
L0_1.loggedIntoGN = false
L4_1 = {}
L5_1 = {}
L6_1 = {}
L7_1 = saver
L7_1 = L7_1.Load
L8_1 = "gn.txt"
L7_1 = L7_1(L8_1)
L0_1.savedData = L7_1
L7_1 = L0_1.savedData
if not L7_1 then
  L3_1 = true
  L7_1 = {}
  L0_1.savedData = L7_1
  L7_1 = saver
  L7_1 = L7_1.Save
  L8_1 = L0_1.savedData
  L9_1 = "gn.txt"
  L7_1(L8_1, L9_1)
end
L7_1 = L0_1.savedData
L7_1 = L7_1.loggedInBefore
if L7_1 == nil then
  L7_1 = L0_1.savedData
  L7_1.loggedInBefore = false
end

function L7_1()
  local L0_2, L1_2, L2_2
  L0_2 = L0_1
  L0_2 = L0_2.savedData
  L0_2.loggedInBefore = true
  L0_2 = saver
  L0_2 = L0_2.Save
  L1_2 = L0_1
  L1_2 = L1_2.savedData
  L2_2 = "gn.txt"
  L0_2(L1_2, L2_2)
end

L8_1 = nil

function L9_1()
  local L0_2, L1_2, L2_2
  L0_2 = L0_1
  L1_2 = L1_1
  L1_2 = L1_2.request
  L2_2 = "isConnected"
  L1_2 = L1_2(L2_2)
  L0_2.loggedIntoGN = L1_2
  L0_2 = L0_1
  L0_2 = L0_2.loggedIntoGN
  if L0_2 then
    L0_2 = L2_1
    if L0_2 then
      L0_2 = log
      L0_2 = L0_2.show
      L1_2 = "Delay Logged into Google Play Games"
      L0_2(L1_2)
    end
    L0_2 = L7_1
    L0_2()
    L0_2 = L8_1
    if L0_2 then
      L0_2 = timer
      L0_2 = L0_2.cancel
      L1_2 = L8_1
      L0_2(L1_2)
      L0_2 = nil
      L8_1 = L0_2
    end
  else
    L0_2 = L2_1
    if L0_2 then
      L0_2 = log
      L0_2 = L0_2.show
      L1_2 = "Still not logged into Google Play Games"
      L0_2(L1_2)
    end
  end
  L0_2 = L0_1
  L0_2 = L0_2.loggedIntoGN
  return L0_2
end

L10_1 = nil

function L11_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L2_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "gpgsLoginCallback "
    L3_2 = inspect
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
  L1_2 = L0_1
  L2_2 = L1_1
  L2_2 = L2_2.request
  L3_2 = "isConnected"
  L2_2 = L2_2(L3_2)
  L1_2.loggedIntoGN = L2_2
  L1_2 = L0_1
  L1_2 = L1_2.loggedIntoGN
  if L1_2 then
    L1_2 = L2_1
    if L1_2 then
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "Logged into Google Play Games"
      L1_2(L2_2)
    end
    L1_2 = L7_1
    L1_2()
    L1_2 = L10_1
    if L1_2 then
      L1_2 = timer
      L1_2 = L1_2.performWithDelay
      L2_2 = 1000
      
      function L3_2()
        local L0_3, L1_3
        L0_3 = L1_1
        L0_3 = L0_3.show
        L1_3 = L10_1
        L0_3(L1_3)
      end
      
      L1_2(L2_2, L3_2)
    end
  else
    L1_2 = L2_1
    if L1_2 then
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "Not logged into Google Play Games"
      L1_2(L2_2)
    end
    L1_2 = timer
    L1_2 = L1_2.performWithDelay
    L2_2 = 10000
    L3_2 = L9_1
    L4_2 = 3
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    L8_1 = L1_2
  end
end

function L12_1(A0_2)
  local L1_2, L2_2
  L1_2 = L2_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "initCallback"
    L1_2(L2_2)
  end
  L1_2 = platform
  L1_2 = L1_2.ios
  if L1_2 then
    L1_2 = A0_2.data
    if L1_2 then
      L1_2 = L0_1
      L1_2.loggedIntoGN = true
      L1_2 = L2_1
      if L1_2 then
        L1_2 = log
        L1_2 = L1_2.show
        L2_2 = "Logged into GC"
        L1_2(L2_2)
      end
      L1_2 = L7_1
      L1_2()
    else
      L1_2 = L0_1
      L1_2.loggedIntoGN = false
      L1_2 = L2_1
      if L1_2 then
        L1_2 = log
        L1_2 = L1_2.show
        L2_2 = "Not logged into GC"
        L1_2(L2_2)
      end
    end
  end
end

function L13_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L10_1 = A0_2
  L1_2 = L1_1
  L1_2 = L1_2.request
  L2_2 = "login"
  L3_2 = {}
  L3_2.userInitiated = true
  L4_2 = L11_1
  L3_2.listener = L4_2
  L1_2(L2_2, L3_2)
end

L0_1.loginGPGS = L13_1

function L13_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L2_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "Logging into GN from "
    L3_2 = A0_2
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
  L1_2 = platform
  L1_2 = L1_2.ios
  if L1_2 then
    L1_2 = L1_1
    L1_2 = L1_2.init
    L2_2 = "gamecenter"
    L3_2 = {}
    L4_2 = L12_1
    L3_2.listener = L4_2
    L1_2(L2_2, L3_2)
  end
  L1_2 = platform
  L1_2 = L1_2.android
  if L1_2 then
    L1_2 = L1_1
    L1_2 = L1_2.init
    L2_2 = "google"
    L1_2(L2_2)
    L1_2 = L3_1
    if not L1_2 then
      L1_2 = L0_1
      L1_2 = L1_2.savedData
      L1_2 = L1_2.loggedInBefore
      if not L1_2 then
        goto lbl_41
      end
    end
    L1_2 = L0_1
    L1_2 = L1_2.loginGPGS
    L2_2 = nil
    L1_2(L2_2)
  end
  ::lbl_41::
end

L0_1.initGC = L13_1

function L13_1(A0_2)
  local L1_2, L2_2
  L1_2 = platform
  L1_2 = L1_2.android
  if L1_2 then
    L1_2 = L0_1
    L1_2 = L1_2.loggedIntoGN
    if L1_2 then
      L1_2 = L2_1
      if L1_2 then
        L1_2 = log
        L1_2 = L1_2.show
        L2_2 = "Calling gameNetwork.show(\"leaderboards\")"
        L1_2(L2_2)
      end
      L1_2 = L1_1
      L1_2 = L1_2.show
      L2_2 = "leaderboards"
      L1_2(L2_2)
    elseif A0_2 then
      L1_2 = L0_1
      L1_2 = L1_2.loginGPGS
      L2_2 = "leaderboards"
      L1_2(L2_2)
    end
  end
  L1_2 = platform
  L1_2 = L1_2.ios
  if L1_2 then
    L1_2 = L2_1
    if L1_2 then
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "Calling gameNetwork.show(\"leaderboards\")"
      L1_2(L2_2)
    end
    L1_2 = L1_1
    L1_2 = L1_2.show
    L2_2 = "leaderboards"
    L1_2(L2_2)
  end
end

L0_1.showLeaderboards = L13_1

function L13_1(A0_2)
  local L1_2, L2_2
  L1_2 = L0_1
  L1_2 = L1_2.loggedIntoGN
  if L1_2 then
    L1_2 = L2_1
    if L1_2 then
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "Calling gameNetwork.show(\"achievements\")"
      L1_2(L2_2)
    end
    L1_2 = L1_1
    L1_2 = L1_2.show
    L2_2 = "achievements"
    L1_2(L2_2)
  elseif A0_2 then
    L1_2 = L0_1
    L1_2 = L1_2.loginGPGS
    L2_2 = "achievements"
    L1_2(L2_2)
  end
end

L0_1.showAchievements = L13_1

function L13_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L2_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "requestCallback "
    L3_2 = inspect
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
  L1_2 = A0_2.type
  if L1_2 == "setHighScore" then
  end
end

function L14_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = _SIMULATOR
  if L2_2 then
    L2_2 = print
    L3_2 = "Possibly reporting high score to GN - "
    L4_2 = A0_2 or L4_2
    if not A0_2 then
      L4_2 = "nil"
    end
    L5_2 = " "
    L6_2 = A1_2
    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
    L2_2(L3_2)
  end
  L2_2 = L0_1
  L2_2 = L2_2.loggedIntoGN
  if not L2_2 then
    return
  end
  if not A0_2 then
    return
  end
  L2_2 = L5_1
  L2_2 = L2_2[A0_2]
  if L2_2 then
    L2_2 = L5_1
    L2_2 = L2_2[A0_2]
    if A1_2 <= L2_2 then
      return
    end
  end
  L2_2 = L5_1
  L2_2[A0_2] = A1_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = log
    L2_2 = L2_2.show
    L3_2 = "Reporting high score to GN - "
    L4_2 = A1_2
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = L1_1
  L2_2 = L2_2.request
  L3_2 = "setHighScore"
  L4_2 = {}
  L5_2 = {}
  L5_2.category = A0_2
  L5_2.value = A1_2
  L4_2.localPlayerScore = L5_2
  L5_2 = L13_1
  L4_2.listener = L5_2
  L2_2(L3_2, L4_2)
end

L0_1.sendHighScore = L14_1

function L14_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = _SIMULATOR
  if L2_2 then
    L2_2 = print
    L3_2 = "Possibly reporting low score to GN - "
    L4_2 = A0_2 or L4_2
    if not A0_2 then
      L4_2 = "nil"
    end
    L5_2 = " "
    L6_2 = A1_2
    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
    L2_2(L3_2)
  end
  L2_2 = L0_1
  L2_2 = L2_2.loggedIntoGN
  if not L2_2 then
    return
  end
  if not A0_2 then
    return
  end
  L2_2 = L6_1
  L2_2 = L2_2[A0_2]
  if L2_2 then
    L2_2 = L6_1
    L2_2 = L2_2[A0_2]
    if A1_2 >= L2_2 then
      return
    end
  end
  L2_2 = L6_1
  L2_2[A0_2] = A1_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = log
    L2_2 = L2_2.show
    L3_2 = "Reporting low score to GN - "
    L4_2 = A1_2
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = L1_1
  L2_2 = L2_2.request
  L3_2 = "setHighScore"
  L4_2 = {}
  L5_2 = {}
  L5_2.category = A0_2
  L5_2.value = A1_2
  L4_2.localPlayerScore = L5_2
  L5_2 = L13_1
  L4_2.listener = L5_2
  L2_2(L3_2, L4_2)
end

L0_1.sendLowScore = L14_1

function L14_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = _SIMULATOR
  if L2_2 then
    L2_2 = print
    L3_2 = "Possibly reporting achievement to GN - "
    L4_2 = A0_2 or L4_2
    if not A0_2 then
      L4_2 = "nil"
    end
    L5_2 = " "
    L6_2 = A1_2
    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
    L2_2(L3_2)
  end
  L2_2 = L0_1
  L2_2 = L2_2.loggedIntoGN
  if not L2_2 then
    return
  end
  L2_2 = platform
  L2_2 = L2_2.android
  if L2_2 and A1_2 < 100 then
    return
  end
  if not A0_2 then
    return
  end
  L2_2 = L4_1
  L2_2 = L2_2[A0_2]
  if L2_2 then
    L2_2 = L4_1
    L2_2 = L2_2[A0_2]
    if A1_2 <= L2_2 then
      return
    end
  end
  L2_2 = L4_1
  L2_2[A0_2] = A1_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = log
    L2_2 = L2_2.show
    L3_2 = "Reporting achievement to GN - "
    L4_2 = A0_2 or L4_2
    if not A0_2 then
      L4_2 = "nil"
    end
    L5_2 = " "
    L6_2 = A1_2
    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
    L2_2(L3_2)
  end
  L2_2 = L1_1
  L2_2 = L2_2.request
  L3_2 = "unlockAchievement"
  L4_2 = {}
  L5_2 = {}
  L5_2.identifier = A0_2
  L5_2.percentComplete = A1_2
  L5_2.showsCompletionBanner = true
  L4_2.achievement = L5_2
  L2_2(L3_2, L4_2)
end

L0_1.sendAchievementProgress = L14_1
return L0_1
