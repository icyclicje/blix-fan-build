local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1
L0_1 = require
L1_1 = "composer"
L0_1 = L0_1(L1_1)
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_android_back_button.lua DEBUGGING"
  L2_1(L3_1)
end

function L2_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = A0_2.index
  if L1_2 == 1 then
    L2_2 = analytics
    L2_2 = L2_2.logEvent
    L3_2 = "Exit dialog - user did not exit"
    L2_2(L3_2)
  elseif L1_2 == 2 then
    L2_2 = analytics
    L2_2 = L2_2.logEvent
    L3_2 = "Exit dialog - user exited"
    L2_2(L3_2)
    L2_2 = native
    L2_2 = L2_2.requestExit
    L2_2()
  end
end

function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = native
  L0_2 = L0_2.showAlert
  L1_2 = "Exit Game"
  L2_2 = "Are you sure?"
  L3_2 = {}
  L4_2 = "No"
  L5_2 = "Yes"
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L4_2 = L2_1
  L0_2(L1_2, L2_2, L3_2, L4_2)
end

L4_1 = false

function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = A0_2.phase
  if L1_2 == "down" then
    L1_2 = A0_2.keyName
    if L1_2 == "back" then
      L1_2 = true
      L4_1 = L1_2
      L1_2 = true
      return L1_2
  end
  else
    L1_2 = A0_2.phase
    if L1_2 == "up" then
      L1_2 = A0_2.keyName
      if L1_2 == "back" then
        L1_2 = L4_1
        if L1_2 then
          L1_2 = L0_1
          L1_2 = L1_2.getSceneName
          L2_2 = "current"
          L1_2 = L1_2(L2_2)
          L2_2 = L0_1
          L2_2 = L2_2.getSceneName
          L3_2 = "overlay"
          L2_2 = L2_2(L3_2)
          if L2_2 and (L2_2 == "_scene_share" or L2_2 == "scene_minigames_menu") then
            L3_2 = L0_1
            L3_2 = L3_2.hideOverlay
            L3_2()
            L3_2 = true
            return L3_2
          end
          L3_2 = L1_1
          if L3_2 then
            L3_2 = log
            L3_2 = L3_2.show
            L4_2 = "back key : "
            L5_2 = L1_2
            L4_2 = L4_2 .. L5_2
            L3_2(L4_2)
          end
          if L1_2 == "scene_game" then
            L3_2 = _game
            L4_2 = game_tutorial
            if L3_2 ~= L4_2 then
              L3_2 = L0_1
              L3_2 = L3_2.gotoScene
              L4_2 = "scene_title"
              L3_2(L4_2)
              L3_2 = analytics
              L3_2 = L3_2.logEvent
              L4_2 = "Game Quit with Android Back Button"
              L3_2(L4_2)
          end
          elseif L1_2 == "scene_title" then
            L3_2 = ads
            L3_2 = L3_2.possiblyShowExitAd
            L3_2()
            L3_2 = L3_1
            L3_2()
          end
          L3_2 = true
          return L3_2
        end
      end
    end
  end
  L1_2 = false
  return L1_2
end

L6_1 = Runtime
L7_1 = L6_1
L6_1 = L6_1.addEventListener
L8_1 = "key"
L9_1 = L5_1
L6_1(L7_1, L8_1, L9_1)
