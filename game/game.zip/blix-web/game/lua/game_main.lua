local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "game_main.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = math
L2_1 = L2_1.random
L3_1 = math
L3_1 = L3_1.ceil
L4_1 = math
L4_1 = L4_1.floor
L0_1.name = "Main"
L0_1.displayName = "Classic Mode"
L0_1.instructions = "Draw squiggles to collect the colored dots. How far can you go with 10 lives?"
L0_1.scoring = true
L0_1.leveling = true
L0_1.lives = 10
L0_1.oneStrokeAtOnce = false
L0_1.oneStrokePerColorAtOnce = true
L0_1.multitouch = false
L5_1 = nil
L6_1 = nil
L7_1 = nil
L8_1 = nil
L9_1 = false

function L10_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = L3_1
  L3_2 = A1_2.difficulty
  L4_2 = A1_2.targets
  L4_2 = #L4_2
  L3_2 = L3_2 * L4_2
  L2_2 = L2_2(L3_2)
  L3_2 = _addToScore
  L4_2 = L2_2
  L5_2 = A1_2.targets
  L5_2 = #L5_2
  L3_2(L4_2, L5_2)
  L3_2 = gameutils
  L3_2 = L3_2.showPopupScore
  L4_2 = A1_2.x
  L5_2 = A1_2.y
  L6_2 = L2_2
  L7_2 = gray
  L8_2 = 18
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L3_2 = building_block
  L3_2 = L3_2.numInPlay
  if L3_2 == 0 then
    L3_2 = timer
    L3_2 = L3_2.performWithDelay
    L4_2 = 1000
    
    function L5_2()
      local L0_3, L1_3
      L0_3 = _levelUp
      L1_3 = 1000
      L0_3(L1_3)
    end
    
    L3_2(L4_2, L5_2)
  end
end

L0_1.onBuildingBlockSuccess = L10_1

function L10_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
  L3_2 = L9_1
  if not L3_2 then
    L3_2 = _loseLife
    L3_2()
  end
end

L0_1.onWrongTargetHit = L10_1

function L10_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
  L3_2 = L9_1
  if not L3_2 then
    L3_2 = _loseLife
    L3_2()
  end
end

L0_1.onObstacleHit = L10_1

function L10_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L3_2 = L9_1
  if not L3_2 then
    return
  end
  L3_2 = A2_2.parent
  L4_2 = L3_2
  L3_2 = L3_2.localToContent
  L5_2 = A2_2.x
  L6_2 = A2_2.y
  L3_2, L4_2 = L3_2(L4_2, L5_2, L6_2)
  L5_2 = _addToScore
  L6_2 = 1
  L7_2 = 1
  L5_2(L6_2, L7_2)
  L5_2 = gameutils
  L5_2 = L5_2.showPopupScore
  L6_2 = L3_2
  L7_2 = L4_2
  L8_2 = 1
  L9_2 = A2_2.color
  L10_2 = 14
  L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  L5_2 = target
  L5_2 = L5_2.numInPlay
  if L5_2 == 0 then
    L5_2 = stroke
    L5_2 = L5_2.numInPlay
    if L5_2 == 1 then
      L5_2 = timer
      L5_2 = L5_2.performWithDelay
      L6_2 = 500
      
      function L7_2()
        local L0_3, L1_3
        L0_3 = _levelUp
        L1_3 = 500
        L0_3(L1_3)
      end
      
      L5_2(L6_2, L7_2)
    end
  end
  L6_2 = A2_2
  L5_2 = A2_2.remove
  L7_2 = 200
  L5_2(L6_2, L7_2)
end

L0_1.onCorrectTargetHit = L10_1

function L10_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = L9_1
  if L2_2 then
    L2_2 = timer
    L2_2 = L2_2.performWithDelay
    L3_2 = 500
    
    function L4_2()
      local L0_3, L1_3
      L0_3 = _levelUp
      L1_3 = 500
      L0_3(L1_3)
    end
    
    L2_2(L3_2, L4_2)
  else
    L2_2 = 1
    L3_2 = A1_2.targetsHit
    L3_2 = #L3_2
    L4_2 = 1
    for L5_2 = L2_2, L3_2, L4_2 do
      L6_2 = A1_2.targetsHit
      L6_2 = L6_2[L5_2]
      L7_2 = L6_2
      L6_2 = L6_2.reappear
      L6_2(L7_2)
    end
  end
end

L0_1.onStrokeLost = L10_1

function L10_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = _EASTER_EGG_MODE
  if not L1_2 then
    L1_2 = _DEV_TAKE_PIC_MODE
    if not L1_2 then
      goto lbl_81
    end
  end
  L1_2 = display
  L1_2 = L1_2.newText
  L2_2 = _group
  L3_2 = "developer mode"
  L4_2 = _canvasW2
  L5_2 = _canvasBottom
  L5_2 = L5_2 - 15
  L6_2 = _ttf_font_offset
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2 = L6_2[L7_2]
  L5_2 = L5_2 + L6_2
  L6_2 = _ttf_font
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2 = L6_2[L7_2]
  L7_2 = 14
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  L6_1 = L1_2
  L1_2 = L6_1
  L2_2 = L1_2
  L1_2 = L1_2.setFillColor
  L3_2 = gray
  L1_2(L2_2, L3_2())
  L1_2 = buttons
  L1_2 = L1_2.newPlainText
  L2_2 = "< prev"
  
  function L3_2()
    local L0_3, L1_3
    L0_3 = _level
    L0_3 = L0_3 - 2
    _level = L0_3
    L0_3 = _levelUp
    L0_3()
  end
  
  L4_2 = {}
  L5_2 = _group
  L4_2.group = L5_2
  L5_2 = gray
  L4_2.textColor = L5_2
  L4_2.frameless = true
  L4_2.textAnchorX = 0
  L4_2.fontSize = 14
  L5_2 = globals
  L5_2 = L5_2.defaultFont
  L4_2.fontNum = L5_2
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L7_1 = L1_2
  L1_2 = L7_1
  L2_2 = L7_1
  L3_2 = _canvasLeft
  L3_2 = L3_2 + 30
  L4_2 = screenBottom
  L4_2 = L4_2 - 15
  L2_2.y = L4_2
  L1_2.x = L3_2
  L1_2 = buttons
  L1_2 = L1_2.newPlainText
  L2_2 = "next >"
  L3_2 = _levelUp
  L4_2 = {}
  L5_2 = _group
  L4_2.group = L5_2
  L5_2 = gray
  L4_2.textColor = L5_2
  L4_2.frameless = true
  L4_2.textAnchorX = 1
  L4_2.fontSize = 14
  L5_2 = globals
  L5_2 = L5_2.defaultFont
  L4_2.fontNum = L5_2
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L8_1 = L1_2
  L1_2 = L8_1
  L2_2 = L8_1
  L3_2 = screenRight
  L3_2 = L3_2 - 30
  L4_2 = screenBottom
  L4_2 = L4_2 - 15
  L2_2.y = L4_2
  L1_2.x = L3_2
  ::lbl_81::
  L1_2 = _DEV_TAKE_PIC_MODE
  if L1_2 then
    L1_2 = L6_1
    L1_2.alpha = 0
    L1_2 = L7_1
    L1_2.alpha = 0.05
    L1_2 = L8_1
    L1_2.alpha = 0.05
  end
end

L0_1.onSetupGame = L10_1

function L10_1(A0_2)
  local L1_2, L2_2
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L5_1
  L1_2(L2_2)
  L1_2 = nil
  L5_1 = L1_2
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L6_1
  L1_2(L2_2)
  L1_2 = nil
  L6_1 = L1_2
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L7_1
  L1_2(L2_2)
  L1_2 = nil
  L7_1 = L1_2
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L8_1
  L1_2(L2_2)
  L1_2 = nil
  L8_1 = L1_2
end

L0_1.onCleanUp = L10_1

function L10_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = L9_1
  if L2_2 then
    L2_2 = A1_2.replayFrameCounter
    L3_2 = _FPS
    L2_2 = L2_2 / L3_2
    if 15 < L2_2 then
      L3_2 = L8_1
      if L3_2 == nil then
        L3_2 = buttons
        L3_2 = L3_2.newPlainText
        L4_2 = "skip >"
        L5_2 = _levelUp
        L6_2 = {}
        L7_2 = _group
        L6_2.group = L7_2
        L7_2 = gray
        L6_2.textColor = L7_2
        L6_2.frameless = true
        L6_2.textAnchorX = 1
        L6_2.fontSize = 14
        L7_2 = globals
        L7_2 = L7_2.defaultFont
        L6_2.fontNum = L7_2
        L3_2 = L3_2(L4_2, L5_2, L6_2)
        L8_1 = L3_2
        L3_2 = L8_1
        L4_2 = L8_1
        L5_2 = screenRight
        L5_2 = L5_2 - 30
        L6_2 = screenBottom
        L6_2 = L6_2 - 15
        L4_2.y = L6_2
        L3_2.x = L5_2
      end
    end
  end
end

L0_1.onStrokeProcessReplay = L10_1

function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  L0_2 = true
  L9_1 = L0_2
  L0_2 = L0_1
  L0_2.oneStrokeAtOnce = true
  L0_2 = 8
  L1_2 = 5
  L2_2 = L2_1
  L3_2 = 7
  L4_2 = 10
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = L2_1
  L4_2 = 27
  L5_2 = 35
  L3_2 = L3_2(L4_2, L5_2)
  L4_2 = L2_1
  L5_2 = 40
  L6_2 = 50
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = _canvasW2
  L6_2 = L2_2 + 1
  L6_2 = L6_2 / 2
  L6_2 = L6_2 * L3_2
  L5_2 = L5_2 - L6_2
  L6_2 = _canvasH2
  L7_2 = L1_2 + 1
  L7_2 = L7_2 / 2
  L7_2 = L7_2 * L4_2
  L6_2 = L6_2 - L7_2
  L7_2 = 1
  L8_2 = L1_2
  L9_2 = 1
  for L10_2 = L7_2, L8_2, L9_2 do
    L11_2 = 1
    L12_2 = L2_2
    L13_2 = 1
    for L14_2 = L11_2, L12_2, L13_2 do
      L15_2 = L14_2 * L3_2
      L15_2 = L5_2 + L15_2
      L16_2 = L10_2 * L4_2
      L16_2 = L6_2 + L16_2
      L17_2 = target
      L17_2 = L17_2.new
      L18_2 = _group
      L19_2 = {}
      L20_2 = L10_2 - 1
      L20_2 = L20_2 * 100
      L19_2.delay = L20_2
      L19_2.x = L15_2
      L19_2.y = L16_2
      L19_2.radius = L0_2
      L20_2 = palette
      L20_2 = L20_2.selectedColor
      L19_2.color = L20_2
      L17_2(L18_2, L19_2)
    end
  end
  L7_2 = obstacle
  L7_2 = L7_2.new
  L8_2 = _group
  L9_2 = {}
  L10_2 = L1_2 * 50
  L9_2.delay = L10_2
  L10_2 = L3_2 / 2
  L10_2 = L5_2 + L10_2
  L9_2.x = L10_2
  L10_2 = _canvasH2
  L11_2 = L4_2 / 2
  L10_2 = L10_2 - L11_2
  L9_2.y = L10_2
  L10_2 = L0_2 - 2
  L9_2.radius = L10_2
  L7_2(L8_2, L9_2)
  L7_2 = obstacle
  L7_2 = L7_2.new
  L8_2 = _group
  L9_2 = {}
  L10_2 = L1_2 * 50
  L9_2.delay = L10_2
  L10_2 = L2_2 * L3_2
  L10_2 = L5_2 + L10_2
  L10_2 = L10_2 + L3_2
  L11_2 = L3_2 / 2
  L10_2 = L10_2 - L11_2
  L9_2.x = L10_2
  L10_2 = _canvasH2
  L11_2 = L4_2 / 2
  L10_2 = L10_2 - L11_2
  L9_2.y = L10_2
  L10_2 = L0_2 - 2
  L9_2.radius = L10_2
  L7_2(L8_2, L9_2)
  L7_2 = obstacle
  L7_2 = L7_2.new
  L8_2 = _group
  L9_2 = {}
  L10_2 = L1_2 * 50
  L9_2.delay = L10_2
  L10_2 = L3_2 / 2
  L10_2 = L5_2 + L10_2
  L9_2.x = L10_2
  L10_2 = _canvasH2
  L11_2 = L4_2 / 2
  L10_2 = L10_2 + L11_2
  L9_2.y = L10_2
  L10_2 = L0_2 - 2
  L9_2.radius = L10_2
  L7_2(L8_2, L9_2)
  L7_2 = obstacle
  L7_2 = L7_2.new
  L8_2 = _group
  L9_2 = {}
  L10_2 = L1_2 * 50
  L9_2.delay = L10_2
  L10_2 = L2_2 * L3_2
  L10_2 = L5_2 + L10_2
  L10_2 = L10_2 + L3_2
  L11_2 = L3_2 / 2
  L10_2 = L10_2 - L11_2
  L9_2.x = L10_2
  L10_2 = _canvasH2
  L11_2 = L4_2 / 2
  L10_2 = L10_2 + L11_2
  L9_2.y = L10_2
  L10_2 = L0_2 - 2
  L9_2.radius = L10_2
  L7_2(L8_2, L9_2)
  L7_2 = display
  L7_2 = L7_2.newText
  L8_2 = _group
  L9_2 = "Bonus Level: clear as many dots as you can with one squiggle."
  L10_2 = _canvasW2
  L11_2 = _canvasBottom
  L11_2 = L11_2 - 15
  L12_2 = _ttf_font_offset
  L13_2 = globals
  L13_2 = L13_2.defaultFont
  L12_2 = L12_2[L13_2]
  L11_2 = L11_2 + L12_2
  L12_2 = _ttf_font
  L13_2 = globals
  L13_2 = L13_2.defaultFont
  L12_2 = L12_2[L13_2]
  L13_2 = 14
  L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
  L5_1 = L7_2
  L7_2 = L5_1
  L8_2 = L7_2
  L7_2 = L7_2.setFillColor
  L9_2 = darkgray
  L7_2(L8_2, L9_2())
  L7_2 = transitionStash
  L8_2 = transition
  L8_2 = L8_2.to
  L9_2 = L5_1
  L10_2 = {}
  L10_2.delay = 5000
  L10_2.time = 1000
  L10_2.alpha = 0
  L8_2 = L8_2(L9_2, L10_2)
  L7_2["disobj_msg fade"] = L8_2
end

function L11_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2
  L1_2 = _level
  if 5 < L1_2 then
    L1_2 = gamenetwork_utils
    L1_2 = L1_2.sendAchievementProgress
    L2_2 = globals
    L2_2 = L2_2.ACH_ID_LEVEL_05
    L3_2 = 100
    L1_2(L2_2, L3_2)
  end
  L1_2 = _level
  if 10 < L1_2 then
    L1_2 = gamenetwork_utils
    L1_2 = L1_2.sendAchievementProgress
    L2_2 = globals
    L2_2 = L2_2.ACH_ID_LEVEL_10
    L3_2 = 100
    L1_2(L2_2, L3_2)
  end
  L1_2 = _level
  if 20 < L1_2 then
    L1_2 = gamenetwork_utils
    L1_2 = L1_2.sendAchievementProgress
    L2_2 = globals
    L2_2 = L2_2.ACH_ID_LEVEL_20
    L3_2 = 100
    L1_2(L2_2, L3_2)
  end
  L1_2 = _level
  if 30 < L1_2 then
    L1_2 = gamenetwork_utils
    L1_2 = L1_2.sendAchievementProgress
    L2_2 = globals
    L2_2 = L2_2.ACH_ID_LEVEL_30
    L3_2 = 100
    L1_2(L2_2, L3_2)
  end
  L1_2 = _level
  if 40 < L1_2 then
    L1_2 = gamenetwork_utils
    L1_2 = L1_2.sendAchievementProgress
    L2_2 = globals
    L2_2 = L2_2.ACH_ID_LEVEL_40
    L3_2 = 100
    L1_2(L2_2, L3_2)
  end
  L1_2 = _level
  if 50 < L1_2 then
    L1_2 = gamenetwork_utils
    L1_2 = L1_2.sendAchievementProgress
    L2_2 = globals
    L2_2 = L2_2.ACH_ID_LEVEL_50
    L3_2 = 100
    L1_2(L2_2, L3_2)
  end
  L1_2 = _DEV_TAKE_PIC_MODE
  if L1_2 then
    L1_2 = _addToScore
    L2_2 = 8
    L3_2 = 3
    L1_2(L2_2, L3_2)
  end
  L1_2 = _DEV_TAKE_PIC_MODE
  if not L1_2 then
    L1_2 = display
    L1_2 = L1_2.remove
    L2_2 = L8_1
    L1_2(L2_2)
    L1_2 = nil
    L8_1 = L1_2
    L1_2 = display
    L1_2 = L1_2.remove
    L2_2 = L5_1
    L1_2(L2_2)
    L1_2 = nil
    L5_1 = L1_2
  end
  L1_2 = L0_1
  L1_2.oneStrokeAtOnce = false
  L1_2 = false
  L9_1 = L1_2
  L1_2 = _level
  L1_2 = L1_2 % 10
  if L1_2 == 0 then
    L1_2 = L10_1
    L1_2()
    return
  end
  L1_2 = {}
  L2_2 = 6
  L3_2 = 0
  L4_2 = L3_1
  L5_2 = _level
  L5_2 = L5_2 * 2
  L5_2 = L5_2 / 3
  L4_2 = L4_2(L5_2)
  L5_2 = L4_1
  L6_2 = _level
  L6_2 = L6_2 / 8
  L5_2 = L5_2(L6_2)
  if 3 < L5_2 then
    L5_2 = 3
  end
  L6_2 = L3_1
  L7_2 = L4_2 * 2
  L7_2 = L7_2 / 3
  L6_2 = L6_2(L7_2)
  L7_2 = nil
  L8_2 = nil
  L9_2 = nil
  while L3_2 < L4_2 and 1 <= L6_2 and L5_2 <= L6_2 do
    L10_2 = #L1_2
    if not (L2_2 > L10_2) then
      break
    end
    L10_2 = L1_1
    if L10_2 then
      L10_2 = print
      L11_2 = inspect
      L12_2 = L1_2
      L10_2(L11_2(L12_2))
      L10_2 = print
      L11_2 = "cummulativeDifficultySoFar="
      L12_2 = L3_2
      L11_2 = L11_2 .. L12_2
      L12_2 = "totalDifficulty="
      L13_2 = L4_2
      L12_2 = L12_2 .. L13_2
      L13_2 = "minDifficultyForBB="
      L14_2 = L5_2
      L13_2 = L13_2 .. L14_2
      L14_2 = "maxDifficultyForNextBB="
      L15_2 = L6_2
      L14_2 = L14_2 .. L15_2
      L10_2(L11_2, L12_2, L13_2, L14_2)
    end
    L10_2 = building_block
    L10_2 = L10_2.getRandomTypeAndModifier
    L11_2 = L5_2
    L12_2 = L6_2
    L13_2 = false
    L10_2, L11_2, L12_2 = L10_2(L11_2, L12_2, L13_2)
    L9_2 = L12_2
    L8_2 = L11_2
    L7_2 = L10_2
    L10_2 = #L1_2
    L10_2 = L10_2 + 1
    L11_2 = {}
    L11_2.bbname = L7_2
    L11_2.modifier = L8_2
    L11_2.difficulty = L9_2
    L1_2[L10_2] = L11_2
    L3_2 = L3_2 + L9_2
    L6_2 = L4_2 - L3_2
  end
  L10_2 = table
  L10_2 = L10_2.sort
  L11_2 = L1_2
  
  function L12_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = A0_3.difficulty
    L3_3 = A1_3.difficulty
    L2_3 = L2_3 > L3_3
    return L2_3
  end
  
  L10_2(L11_2, L12_2)
  L10_2 = {}
  
  function L11_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = gameutils
    L0_3 = L0_3.getRandomColor
    L0_3 = L0_3()
    while true do
      L1_3 = table
      L1_3 = L1_3.contains
      L2_3 = L10_2
      L3_3 = L0_3
      L1_3 = L1_3(L2_3, L3_3)
      if not L1_3 then
        break
      end
      L1_3 = gameutils
      L1_3 = L1_3.getRandomColor
      L1_3 = L1_3()
      L0_3 = L1_3
    end
    L1_3 = L10_2
    L2_3 = L10_2
    L2_3 = #L2_3
    L2_3 = L2_3 + 1
    L1_3[L2_3] = L0_3
    return L0_3
  end
  
  L12_2 = L1_1
  if L12_2 then
    L12_2 = print
    L13_2 = inspect
    L14_2 = L1_2
    L12_2(L13_2(L14_2))
  end
  L12_2 = 1
  L13_2 = #L1_2
  L14_2 = 1
  for L15_2 = L12_2, L13_2, L14_2 do
    L16_2 = nil
    L17_2 = nil
    L18_2 = nil
    L19_2 = L1_2[L15_2]
    L20_2 = L19_2.modifier
    L21_2 = building_block
    L21_2 = L21_2.MODIFIER_NORMAL
    if L20_2 == L21_2 then
      L20_2 = L11_2
      L20_2 = L20_2()
      L16_2 = L20_2
    else
      L20_2 = L19_2.modifier
      L21_2 = building_block
      L21_2 = L21_2.MODIFIER_ROTATED
      if L20_2 == L21_2 then
        L20_2 = L11_2
        L20_2 = L20_2()
        L16_2 = L20_2
        L20_2 = L2_1
        L21_2 = 30
        L22_2 = 150
        L20_2 = L20_2(L21_2, L22_2)
        L17_2 = L20_2
        L20_2 = L2_1
        L21_2 = 1
        L22_2 = 2
        L20_2 = L20_2(L21_2, L22_2)
        if L20_2 == 1 then
          L17_2 = -L17_2
        end
      else
        L20_2 = L19_2.modifier
        L21_2 = building_block
        L21_2 = L21_2.MODIFIER_MULTICOLOR
        if L20_2 == L21_2 then
          L16_2 = nil
        else
          L20_2 = L19_2.modifier
          L21_2 = building_block
          L21_2 = L21_2.MODIFIER_SLOWSPIN
          if L20_2 == L21_2 then
            L20_2 = L11_2
            L20_2 = L20_2()
            L16_2 = L20_2
            L20_2 = L2_1
            L21_2 = 40000
            L22_2 = 60000
            L20_2 = L20_2(L21_2, L22_2)
            L18_2 = L20_2
            L20_2 = L2_1
            L21_2 = 1
            L22_2 = 2
            L20_2 = L20_2(L21_2, L22_2)
            if L20_2 == 1 then
              L18_2 = -L18_2
            end
          else
            L20_2 = L19_2.modifier
            L21_2 = building_block
            L21_2 = L21_2.MODIFIER_FASTSPIN
            if L20_2 == L21_2 then
              L20_2 = L11_2
              L20_2 = L20_2()
              L16_2 = L20_2
              L20_2 = L2_1
              L21_2 = 1000
              L22_2 = 2000
              L20_2 = L20_2(L21_2, L22_2)
              L18_2 = L20_2
              L20_2 = L2_1
              L21_2 = 1
              L22_2 = 2
              L20_2 = L20_2(L21_2, L22_2)
              if L20_2 == 1 then
                L18_2 = -L18_2
              end
            else
              L20_2 = L19_2.modifier
              L21_2 = building_block
              L21_2 = L21_2.MODIFIER_MULTICOLOR_SPIN
              if L20_2 == L21_2 then
                L16_2 = nil
                L20_2 = L2_1
                L21_2 = 10000
                L22_2 = 30000
                L20_2 = L20_2(L21_2, L22_2)
                L18_2 = L20_2
                L20_2 = L2_1
                L21_2 = 1
                L22_2 = 2
                L20_2 = L20_2(L21_2, L22_2)
                if L20_2 == 1 then
                  L18_2 = -L18_2
                end
              end
            end
          end
        end
      end
    end
    L20_2 = building_block
    L20_2 = L20_2.new
    L21_2 = _group
    L22_2 = {}
    L23_2 = L15_2 * 500
    L23_2 = L23_2 + 1
    L22_2.delay = L23_2
    L23_2 = L19_2.bbname
    L22_2.name = L23_2
    L23_2 = L19_2.modifier
    L22_2.modifier = L23_2
    L22_2.color = L16_2
    L22_2.startRotation = L17_2
    L22_2.rotationTime = L18_2
    L20_2 = L20_2(L21_2, L22_2)
    if L15_2 == 1 then
      L22_2 = L20_2
      L21_2 = L20_2.changeScaleFactor
      L23_2 = L20_2.scalefactor
      L23_2 = 1.3 * L23_2
      L21_2(L22_2, L23_2)
    else
      L21_2 = _tablet
      if not L21_2 then
        L22_2 = L20_2
        L21_2 = L20_2.changeScaleFactor
        L23_2 = L20_2.scalefactor
        L23_2 = 1.3 * L23_2
        L21_2(L22_2, L23_2)
      end
    end
    L21_2 = nil
    L22_2 = nil
    if L15_2 == 1 then
      L23_2 = _canvasW2
      L22_2 = _canvasH2
      L21_2 = L23_2
    else
      L23_2 = gameutils
      L23_2 = L23_2.getRandomOpenSpotForBuildingBlock
      L24_2 = L20_2
      L23_2, L24_2 = L23_2(L24_2)
      L22_2 = L24_2
      L21_2 = L23_2
    end
    if L21_2 == nil then
      L24_2 = L20_2
      L23_2 = L20_2.remove
      L25_2 = 0
      L23_2(L24_2, L25_2)
      break
    end
    L23_2 = L21_2
    L20_2.y = L22_2
    L20_2.x = L23_2
  end
end

L0_1.onLevelUp = L11_1

function L11_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = settings
  L1_2 = L1_2.t
  L1_2 = L1_2.gc_ios_leaderboard_id
  L2_2 = platform
  L2_2 = L2_2.android
  if L2_2 then
    L2_2 = settings
    L2_2 = L2_2.t
    L1_2 = L2_2.gc_android_leaderboard_id
  end
  L2_2 = gamenetwork_utils
  L2_2 = L2_2.sendHighScore
  L3_2 = L1_2
  L4_2 = _score
  L2_2(L3_2, L4_2)
  L2_2 = gamenetwork_utils
  L2_2 = L2_2.sendHighScore
  L3_2 = globals
  L3_2 = L3_2.LEADERBOARD_ID_HIGHEST_LEVEL
  L4_2 = _level
  L2_2(L3_2, L4_2)
end

L0_1.onEndGame = L11_1

function L11_1(A0_2)
  local L1_2
end

L0_1.onAddToScore = L11_1
return L0_1
