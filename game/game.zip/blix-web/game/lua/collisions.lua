local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = {}
L1_1 = math
L1_1 = L1_1.abs
L2_1 = math
L2_1 = L2_1.random
L3_1 = math
L3_1 = L3_1.sqrt
L4_1 = math
L4_1 = L4_1.pow
L5_1 = false
if L5_1 then
  L6_1 = log
  L6_1 = L6_1.show
  L7_1 = "_collisions.lua DEBUGGING"
  L6_1(L7_1)
end
L6_1 = 0
_lastCollision = L6_1
return L0_1
