local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1
L0_1 = {}
L1_1 = math
L1_1 = L1_1.floor
L2_1 = math
L2_1 = L2_1.random
L3_1 = math
L3_1 = L3_1.sqrt
L4_1 = math
L4_1 = L4_1.pow
L5_1 = math
L5_1 = L5_1.abs
L6_1 = false
if L6_1 then
  L7_1 = log
  L7_1 = L7_1.show
  L8_1 = "_utils.lua DEBUGGING"
  L7_1(L8_1)
end
L7_1 = {}
timerStash = L7_1
L7_1 = {}
transitionStash = L7_1

function L7_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = pairs
  L3_2 = timerStash
  L2_2, L3_2, L4_2 = L2_2(L3_2)
  for L5_2, L6_2 in L2_2, L3_2, L4_2 do
    L7_2 = timer
    L7_2 = L7_2.cancel
    L8_2 = L6_2
    L7_2(L8_2)
  end
  L2_2 = {}
  timerStash = L2_2
  L2_2 = pairs
  L3_2 = transitionStash
  L2_2, L3_2, L4_2 = L2_2(L3_2)
  for L5_2, L6_2 in L2_2, L3_2, L4_2 do
    L7_2 = transition
    L7_2 = L7_2.cancel
    L8_2 = L6_2
    L7_2(L8_2)
  end
  L2_2 = {}
  transitionStash = L2_2
end

L0_1.cancelAllTimersAndTransitions = L7_1

function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = A0_2.numChildren
  L2_2 = 1
  L3_2 = L1_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L7_2 = A0_2
    L6_2 = A0_2.remove
    L8_2 = 1
    L6_2(L7_2, L8_2)
  end
  L2_2 = collectgarbage
  L3_2 = "collect"
  L2_2(L3_2)
end

L0_1.removeAllDisplayObjects = L7_1

function L7_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L5_2 = display
  L5_2 = L5_2.newGroup
  L5_2 = L5_2()
  L6_2 = 1
  L7_2 = A4_2
  L8_2 = 1
  for L9_2 = L6_2, L7_2, L8_2 do
    L10_2 = display
    L10_2 = L10_2.newImageRect
    L11_2 = L5_2
    L12_2 = A1_2
    L13_2 = A2_2
    L14_2 = A3_2
    L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2)
    if L10_2 == nil then
      L12_2 = L5_2
      L11_2 = L5_2.removeSelf
      L11_2(L12_2)
      L11_2 = nil
      return L11_2
    end
    L11_2 = 0
    L10_2.anchorY = 0
    L10_2.anchorX = L11_2
    L11_2 = L9_2 - 1
    L11_2 = L11_2 * A2_2
    L10_2.y = 0
    L10_2.x = L11_2
  end
  if A0_2 then
    L7_2 = A0_2
    L6_2 = A0_2.insert
    L8_2 = L5_2
    L6_2(L7_2, L8_2)
  end
  L5_2.anchorChildren = true
  return L5_2
end

L0_1.createRepeatingSideScrollerObject = L7_1

function L7_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  if not A2_2 then
    A2_2 = 1.2
  end
  if not A1_2 then
    A1_2 = 200
  end
  L3_2 = transitionStash
  L4_2 = tostring
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  L5_2 = "popbigger"
  L4_2 = L4_2 .. L5_2
  L5_2 = transition
  L5_2 = L5_2.to
  L6_2 = A0_2
  L7_2 = {}
  L7_2.time = A1_2
  L7_2.xScale = A2_2
  L7_2.yScale = A2_2
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
  L3_2 = transitionStash
  L4_2 = tostring
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  L5_2 = "popreturn"
  L4_2 = L4_2 .. L5_2
  L5_2 = transition
  L5_2 = L5_2.to
  L6_2 = A0_2
  L7_2 = {}
  L7_2.delay = A1_2
  L7_2.time = A1_2
  L7_2.xScale = 1
  L7_2.yScale = 1
  L5_2 = L5_2(L6_2, L7_2)
  L3_2[L4_2] = L5_2
end

L0_1.pop = L7_1

function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  if A0_2 == nil then
    return
  end
  L1_2 = 300
  L2_2 = 1.2
  L3_2 = A0_2.alpha
  L4_2 = 0
  L5_2 = A0_2.pulseTimeBigger
  if L5_2 then
    L1_2 = A0_2.pulseTimeBigger
  end
  L5_2 = A0_2.scaleBigger
  if L5_2 then
    L2_2 = A0_2.scaleBigger
  end
  L5_2 = A0_2.alphaBigger
  if L5_2 then
    L3_2 = A0_2.alphaBigger
  end
  L5_2 = A0_2.delayBigger
  if L5_2 then
    L4_2 = A0_2.delayBigger
  end
  L5_2 = transition
  L5_2 = L5_2.to
  L6_2 = A0_2
  L7_2 = {}
  L7_2.delay = L4_2
  L7_2.time = L1_2
  L7_2.xScale = L2_2
  L7_2.yScale = L2_2
  L7_2.alpha = L3_2
  L8_2 = L0_1
  L8_2 = L8_2.pulseToSmaller
  L7_2.onComplete = L8_2
  L5_2 = L5_2(L6_2, L7_2)
  A0_2.pulse = L5_2
  L5_2 = transitionStash
  L6_2 = "pulseToBigger"
  L7_2 = tostring
  L8_2 = A0_2._proxy
  L7_2 = L7_2(L8_2)
  L6_2 = L6_2 .. L7_2
  L7_2 = A0_2.pulse
  L5_2[L6_2] = L7_2
end

L0_1.pulseToBigger = L7_1

function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  if A0_2 == nil then
    return
  end
  L1_2 = 500
  L2_2 = 0.95
  L3_2 = A0_2.alpha
  L4_2 = 0
  L5_2 = A0_2.pulseTimeSmaller
  if L5_2 then
    L1_2 = A0_2.pulseTimeSmaller
  end
  L5_2 = A0_2.scaleSmaller
  if L5_2 then
    L2_2 = A0_2.scaleSmaller
  end
  L5_2 = A0_2.alphaSmaller
  if L5_2 then
    L3_2 = A0_2.alphaSmaller
  end
  L5_2 = A0_2.delaySmaller
  if L5_2 then
    L4_2 = A0_2.delaySmaller
  end
  L5_2 = transition
  L5_2 = L5_2.to
  L6_2 = A0_2
  L7_2 = {}
  L7_2.delay = L4_2
  L7_2.time = L1_2
  L7_2.xScale = L2_2
  L7_2.yScale = L2_2
  L7_2.alpha = L3_2
  L8_2 = L0_1
  L8_2 = L8_2.pulseToBigger
  L7_2.onComplete = L8_2
  L5_2 = L5_2(L6_2, L7_2)
  A0_2.pulse = L5_2
  L5_2 = transitionStash
  L6_2 = "pulseToSmaller"
  L7_2 = tostring
  L8_2 = A0_2._proxy
  L7_2 = L7_2(L8_2)
  L6_2 = L6_2 .. L7_2
  L7_2 = A0_2.pulse
  L5_2[L6_2] = L7_2
end

L0_1.pulseToSmaller = L7_1

function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  if A0_2 == nil then
    return
  end
  L1_2 = 250
  L2_2 = 0
  L3_2 = 0
  L4_2 = 0
  L5_2 = 0
  L6_2 = A0_2.pulseTime1
  if L6_2 then
    L1_2 = A0_2.pulseTime1
  end
  L6_2 = A0_2.xDiff1
  if L6_2 then
    L2_2 = A0_2.xDiff1
  end
  L6_2 = A0_2.yDiff1
  if L6_2 then
    L3_2 = A0_2.yDiff1
  end
  L6_2 = A0_2.rotDiff1
  if L6_2 then
    L4_2 = A0_2.rotDiff1
  end
  L6_2 = A0_2.delay1
  if L6_2 then
    L5_2 = A0_2.delay1
  end
  L6_2 = transition
  L6_2 = L6_2.to
  L7_2 = A0_2
  L8_2 = {}
  L8_2.delay = L5_2
  L8_2.time = L1_2
  L9_2 = A0_2.origX
  L9_2 = L9_2 + L2_2
  L8_2.x = L9_2
  L9_2 = A0_2.origY
  L9_2 = L9_2 + L3_2
  L8_2.y = L9_2
  L9_2 = A0_2.origRotation
  L9_2 = L9_2 + L4_2
  L8_2.rotation = L9_2
  L9_2 = L0_1
  L9_2 = L9_2.pulseMove2
  L8_2.onComplete = L9_2
  L6_2 = L6_2(L7_2, L8_2)
  A0_2.pulseMove = L6_2
  L6_2 = transitionStash
  L7_2 = "pulseMove1"
  L8_2 = tostring
  L9_2 = A0_2._proxy
  L8_2 = L8_2(L9_2)
  L7_2 = L7_2 .. L8_2
  L8_2 = A0_2.pulseMove
  L6_2[L7_2] = L8_2
end

L0_1.pulseMove1 = L7_1

function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  if A0_2 == nil then
    return
  end
  L1_2 = 250
  L2_2 = 0
  L3_2 = 0
  L4_2 = 0
  L5_2 = 0
  L6_2 = A0_2.pulseTime2
  if L6_2 then
    L1_2 = A0_2.pulseTime2
  end
  L6_2 = A0_2.xDiff2
  if L6_2 then
    L2_2 = A0_2.xDiff2
  end
  L6_2 = A0_2.yDiff2
  if L6_2 then
    L3_2 = A0_2.yDiff2
  end
  L6_2 = A0_2.rotDiff2
  if L6_2 then
    L4_2 = A0_2.rotDiff2
  end
  L6_2 = A0_2.delay2
  if L6_2 then
    L5_2 = A0_2.delay2
  end
  L6_2 = transition
  L6_2 = L6_2.to
  L7_2 = A0_2
  L8_2 = {}
  L8_2.delay = L5_2
  L8_2.time = L1_2
  L9_2 = A0_2.origX
  L9_2 = L9_2 + L2_2
  L8_2.x = L9_2
  L9_2 = A0_2.origY
  L9_2 = L9_2 + L3_2
  L8_2.y = L9_2
  L9_2 = A0_2.origRotation
  L9_2 = L9_2 + L4_2
  L8_2.rotation = L9_2
  L9_2 = L0_1
  L9_2 = L9_2.pulseMove1
  L8_2.onComplete = L9_2
  L6_2 = L6_2(L7_2, L8_2)
  A0_2.pulseMove = L6_2
  L6_2 = transitionStash
  L7_2 = "pulseMove2"
  L8_2 = tostring
  L9_2 = A0_2._proxy
  L8_2 = L8_2(L9_2)
  L7_2 = L7_2 .. L8_2
  L8_2 = A0_2.pulseMove
  L6_2[L7_2] = L8_2
end

L0_1.pulseMove2 = L7_1

function L7_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = A0_2.origX
  if L2_2 == nil then
    L2_2 = A0_2.x
    A0_2.origX = L2_2
  end
  L2_2 = A0_2.origY
  if L2_2 == nil then
    L2_2 = A0_2.y
    A0_2.origY = L2_2
  end
  L2_2 = A1_2 or L2_2
  if not A1_2 then
    L2_2 = 10
  end
  L3_2 = A0_2.x
  L3_2 = L3_2 + L2_2
  L4_2 = A0_2.x
  L4_2 = L4_2 - L2_2
  L5_2 = A0_2.y
  L5_2 = L5_2 - L2_2
  L6_2 = A0_2.y
  L6_2 = L6_2 + L2_2
  L7_2 = transition
  L7_2 = L7_2.to
  L8_2 = A0_2
  L9_2 = {}
  L9_2.time = 50
  L9_2.x = L3_2
  L9_2.y = L6_2
  L7_2(L8_2, L9_2)
  L7_2 = transition
  L7_2 = L7_2.to
  L8_2 = A0_2
  L9_2 = {}
  L9_2.delay = 50
  L9_2.time = 50
  L9_2.x = L4_2
  L9_2.y = L5_2
  L7_2(L8_2, L9_2)
  L7_2 = transition
  L7_2 = L7_2.to
  L8_2 = A0_2
  L9_2 = {}
  L9_2.delay = 101
  L9_2.time = 50
  L10_2 = A0_2.origX
  L9_2.x = L10_2
  L10_2 = A0_2.origY
  L9_2.y = L10_2
  L7_2(L8_2, L9_2)
end

L0_1.shakeGroup = L7_1

function L7_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  if A1_2 == 0 then
    L2_2 = L1_1
    L3_2 = A0_2 + 0.5
    return L2_2(L3_2)
  end
  L2_2 = A1_2 or L2_2
  if not A1_2 then
    L2_2 = 0
  end
  L2_2 = 10 ^ L2_2
  L3_2 = L1_1
  L4_2 = A0_2 * L2_2
  L4_2 = L4_2 + 0.5
  L3_2 = L3_2(L4_2)
  L3_2 = L3_2 / L2_2
  return L3_2
end

L0_1.round = L7_1

function L7_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = #A0_2
  L2_2 = {}
  L3_2 = {}
  L4_2 = 1
  L5_2 = L1_2
  L6_2 = 1
  for L7_2 = L4_2, L5_2, L6_2 do
    L8_2 = {}
    L9_2 = L2_1
    L9_2 = L9_2()
    L8_2.rnd = L9_2
    L8_2.idx = L7_2
    L2_2[L7_2] = L8_2
  end
  L4_2 = table
  L4_2 = L4_2.sort
  L5_2 = L2_2
  
  function L6_2(A0_3, A1_3)
    local L2_3, L3_3
    L2_3 = A0_3.rnd
    L3_3 = A1_3.rnd
    L2_3 = L2_3 < L3_3
    return L2_3
  end
  
  L4_2(L5_2, L6_2)
  L4_2 = 1
  L5_2 = L1_2
  L6_2 = 1
  for L7_2 = L4_2, L5_2, L6_2 do
    L8_2 = L2_2[L7_2]
    L8_2 = L8_2.idx
    L8_2 = A0_2[L8_2]
    L3_2[L7_2] = L8_2
  end
  return L3_2
end

L0_1.array_shuffle = L7_1

function L7_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L3_2 = ""
  L4_2 = A1_2
  L5_2 = A2_2
  L6_2 = 1
  for L7_2 = L4_2, L5_2, L6_2 do
    if A1_2 < L7_2 then
      L8_2 = L3_2
      L9_2 = " "
      L3_2 = L8_2 .. L9_2
    end
    L8_2 = L3_2
    L9_2 = A0_2[L7_2]
    L3_2 = L8_2 .. L9_2
  end
  return L3_2
end

function L8_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2)
  local L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L8_2 = display
  L8_2 = L8_2.newGroup
  L8_2 = L8_2()
  L8_2.anchorChildren = true
  L10_2 = A1_2
  L9_2 = A1_2.split
  L11_2 = " "
  L9_2 = L9_2(L10_2, L11_2)
  L10_2 = 1
  L11_2 = #L9_2
  L12_2 = L7_1
  L13_2 = L9_2
  L14_2 = L10_2
  L15_2 = L11_2
  L12_2 = L12_2(L13_2, L14_2, L15_2)
  L13_2 = -1
  L14_2 = nil
  L15_2 = 0
  while true do
    L16_2 = L7_1
    L17_2 = L9_2
    L18_2 = L10_2
    L19_2 = L11_2
    L16_2 = L16_2(L17_2, L18_2, L19_2)
    L12_2 = L16_2
    if A7_2 then
      L16_2 = display
      L16_2 = L16_2.newEmbossedText
      L17_2 = L12_2
      L18_2 = 0
      L19_2 = L15_2 * A5_2
      L20_2 = _ttf_font_offset
      L20_2 = L20_2[A3_2]
      L20_2 = L20_2 * A4_2
      L19_2 = L19_2 + L20_2
      L20_2 = _ttf_font
      L20_2 = L20_2[A3_2]
      L21_2 = A4_2
      L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
      L14_2 = L16_2
    else
      L16_2 = display
      L16_2 = L16_2.newText
      L17_2 = L12_2
      L18_2 = 0
      L19_2 = L15_2 * A5_2
      L20_2 = _ttf_font_offset
      L20_2 = L20_2[A3_2]
      L20_2 = L20_2 * A4_2
      L19_2 = L19_2 + L20_2
      L20_2 = _ttf_font
      L20_2 = L20_2[A3_2]
      L21_2 = A4_2
      L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
      L14_2 = L16_2
    end
    L13_2 = L14_2.width
    if A2_2 < L13_2 then
      L11_2 = L11_2 - 1
      L17_2 = L14_2
      L16_2 = L14_2.removeSelf
      L16_2(L17_2)
      L14_2 = nil
    else
      L17_2 = L14_2
      L16_2 = L14_2.setTextColor
      L18_2 = A6_2
      L16_2(L17_2, L18_2())
      if A7_2 then
        L17_2 = L14_2
        L16_2 = L14_2.setEmbossColor
        L18_2 = {}
        L19_2 = {}
        L19_2.r = 0
        L19_2.g = 0
        L19_2.b = 0
        L19_2.a = 200
        L18_2.highlight = L19_2
        L19_2 = {}
        L19_2.r = 0
        L19_2.g = 0
        L19_2.b = 0
        L19_2.a = 0
        L18_2.shadow = L19_2
        L16_2(L17_2, L18_2)
      end
      L17_2 = L8_2
      L16_2 = L8_2.insert
      L18_2 = L14_2
      L16_2(L17_2, L18_2)
      L15_2 = L15_2 + 1
      goto lbl_90
      goto lbl_96
      ::lbl_90::
      L16_2 = #L9_2
      if L11_2 == L16_2 then
        break
      end
      L10_2 = L11_2 + 1
      L11_2 = #L9_2
    end
    ::lbl_96::
  end
  if A0_2 then
    L17_2 = A0_2
    L16_2 = A0_2.insert
    L18_2 = L8_2
    L16_2(L17_2, L18_2)
  end
  return L8_2
end

L0_1.newTextWithWrap = L8_1

function L8_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L5_2 = A0_2.typeout1
  if L5_2 then
    L5_2 = timer
    L5_2 = L5_2.cancel
    L6_2 = A0_2.typeout1
    L5_2(L6_2)
    A0_2.typeout1 = nil
  end
  L5_2 = A0_2.typeout2
  if L5_2 then
    L5_2 = timer
    L5_2 = L5_2.cancel
    L6_2 = A0_2.typeout2
    L5_2(L6_2)
    A0_2.typeout2 = nil
  end
  L5_2 = A0_2.text
  L6_2 = A0_2.width
  L7_2 = A0_2.x
  L9_2 = L5_2
  L8_2 = L5_2.len
  L8_2 = L8_2(L9_2)
  A0_2.text = ""
  L9_2 = 1
  
  function L10_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
    L0_3 = A0_2
    if L0_3 ~= nil then
      L0_3 = A0_2
      L0_3 = L0_3.width
      if L0_3 ~= nil then
        goto lbl_9
      end
    end
    do return end
    ::lbl_9::
    L0_3 = A3_2
    if L0_3 then
      L0_3 = L9_2
      L0_3 = L0_3 % 2
      if L0_3 == 0 then
        L0_3 = platform
        L0_3 = L0_3.android
        if L0_3 then
          L0_3 = sounds
          L0_3 = L0_3.playFast
          L1_3 = sounds
          L1_3 = L1_3.click2_fast
          L0_3(L1_3)
        else
          L0_3 = sounds
          L0_3 = L0_3.play
          L1_3 = sounds
          L1_3 = L1_3.click2
          L2_3 = 0.1
          L0_3(L1_3, L2_3)
        end
      end
    end
    L0_3 = A0_2
    L0_3 = L0_3.setText
    if L0_3 then
      L0_3 = A0_2
      L1_3 = L0_3
      L0_3 = L0_3.setText
      L2_3 = L5_2
      L3_3 = L2_3
      L2_3 = L2_3.sub
      L4_3 = 1
      L5_3 = L9_2
      L0_3(L1_3, L2_3(L3_3, L4_3, L5_3))
    else
      L0_3 = A0_2
      L1_3 = L5_2
      L2_3 = L1_3
      L1_3 = L1_3.sub
      L3_3 = 1
      L4_3 = L9_2
      L1_3 = L1_3(L2_3, L3_3, L4_3)
      L0_3.text = L1_3
    end
    L0_3 = A0_2
    L0_3 = L0_3.anchorX
    if L0_3 == 0.5 then
      L0_3 = A0_2
      L1_3 = L7_2
      L2_3 = L6_2
      L3_3 = A0_2
      L3_3 = L3_3.width
      L2_3 = L2_3 - L3_3
      L2_3 = L2_3 / 2
      L1_3 = L1_3 - L2_3
      L0_3.x = L1_3
    end
    L0_3 = L9_2
    L0_3 = L0_3 + 1
    L9_2 = L0_3
    L0_3 = L9_2
    L1_3 = L8_2
    if L0_3 > L1_3 then
      L0_3 = A0_2
      L0_3 = L0_3.typeout
      if L0_3 then
        L0_3 = timer
        L0_3 = L0_3.cancel
        L1_3 = A0_2
        L1_3 = L1_3.typeout
        L0_3(L1_3)
        L0_3 = A0_2
        L0_3.typeout = nil
      end
      L0_3 = A4_2
      if L0_3 then
        L0_3 = A4_2
        L0_3()
      end
    end
  end
  
  A0_2.isVisible = false
  L11_2 = timerStash
  L12_2 = "typeout/"
  L13_2 = L5_2
  L12_2 = L12_2 .. L13_2
  L13_2 = timer
  L13_2 = L13_2.performWithDelay
  L14_2 = A1_2
  
  function L15_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
    L0_3 = A0_2
    L0_3.isVisible = true
    L0_3 = timerStash
    L1_3 = "typeout2/"
    L2_3 = L5_2
    L1_3 = L1_3 .. L2_3
    L2_3 = timer
    L2_3 = L2_3.performWithDelay
    L3_3 = A2_2
    L4_3 = L10_2
    L5_3 = L8_2
    L2_3 = L2_3(L3_3, L4_3, L5_3)
    L0_3[L1_3] = L2_3
    L0_3 = A0_2
    L1_3 = timerStash
    L2_3 = "typeout2/"
    L3_3 = L5_2
    L2_3 = L2_3 .. L3_3
    L1_3 = L1_3[L2_3]
    L0_3.typeout2 = L1_3
  end
  
  L13_2 = L13_2(L14_2, L15_2)
  L11_2[L12_2] = L13_2
  L11_2 = timerStash
  L12_2 = "typeout/"
  L13_2 = L5_2
  L12_2 = L12_2 .. L13_2
  L11_2 = L11_2[L12_2]
  A0_2.typeout1 = L11_2
  L11_2 = 1.2
  if A2_2 == 25 then
    L11_2 = 1.3
  end
  if A2_2 == 30 then
    L11_2 = 1.15
  end
  if A2_2 == 33 then
    L11_2 = 1.5
  end
  if A2_2 == 40 then
    L11_2 = 1.2
  end
  if A2_2 == 60 then
    L11_2 = 1.2
  end
  L12_2 = A2_2 * L8_2
  L12_2 = L12_2 * L11_2
  return L12_2
end

L0_1.typeOutTextObject = L8_1

function L8_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = "http://"
  L2_2 = settings
  L2_2 = L2_2.t
  L2_2 = L2_2.useSSL
  if L2_2 then
    L1_2 = "https://"
  end
  L2_2 = L1_2
  L3_2 = "games.bonfiremedia.com/es/s/"
  L1_2 = L2_2 .. L3_2
  if A0_2 == "GET" then
    L2_2 = L1_2
    L3_2 = "Ctrl"
    L1_2 = L2_2 .. L3_2
  elseif A0_2 == "POST" then
    L2_2 = L1_2
    L3_2 = "CP"
    L1_2 = L2_2 .. L3_2
  else
    L2_2 = log
    L2_2 = L2_2.show
    L3_2 = "ERROR in call to getURL()!"
    L2_2(L3_2)
  end
  return L1_2
end

L0_1.getURL = L8_1

function L8_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L0_2 = "av="
  L1_2 = APP_VERSION
  L2_2 = "&platform="
  L3_2 = platform
  L3_2 = L3_2.name
  L4_2 = L3_2
  L3_2 = L3_2.urlEncode
  L3_2 = L3_2(L4_2)
  L4_2 = "&model="
  L5_2 = _MODEL
  L6_2 = L5_2
  L5_2 = L5_2.urlEncode
  L5_2 = L5_2(L6_2)
  L6_2 = "&platformVersion="
  L7_2 = platform
  L7_2 = L7_2.version
  L8_2 = L7_2
  L7_2 = L7_2.urlEncode
  L7_2 = L7_2(L8_2)
  L0_2 = L0_2 .. L1_2 .. L2_2 .. L3_2 .. L4_2 .. L5_2 .. L6_2 .. L7_2
  L1_2 = L0_2
  L2_2 = "&ctry="
  L3_2 = _COUNTRY
  L4_2 = L3_2
  L3_2 = L3_2.urlEncode
  L3_2 = L3_2(L4_2)
  L4_2 = "&lang="
  L5_2 = _LANGUAGE
  L6_2 = L5_2
  L5_2 = L5_2.urlEncode
  L5_2 = L5_2(L6_2)
  L0_2 = L1_2 .. L2_2 .. L3_2 .. L4_2 .. L5_2
  L1_2 = L0_2
  L2_2 = "&ftu="
  L3_2 = bsi
  L3_2 = L3_2.getFirstTimeUse
  L3_2 = L3_2()
  L4_2 = "&avwi="
  L5_2 = bsi
  L5_2 = L5_2.getVersionWhenInstalled
  L5_2 = L5_2()
  L6_2 = "&tslu="
  L7_2 = bsi
  L7_2 = L7_2.getTimeSinceLastUse
  L7_2 = L7_2()
  L0_2 = L1_2 .. L2_2 .. L3_2 .. L4_2 .. L5_2 .. L6_2 .. L7_2
  L1_2 = L0_2
  L2_2 = "&nsc="
  L3_2 = settings
  L3_2 = L3_2.savedData
  L3_2 = L3_2.numServerCalls
  L4_2 = "&ltsd="
  L5_2 = settings
  L5_2 = L5_2.savedData
  L5_2 = L5_2.lastTimeShowedDialog
  L6_2 = "&nds="
  L7_2 = settings
  L7_2 = L7_2.savedData
  L7_2 = L7_2.noDialogStreak
  L0_2 = L1_2 .. L2_2 .. L3_2 .. L4_2 .. L5_2 .. L6_2 .. L7_2
  L1_2 = L0_2
  L2_2 = "&kindle="
  L3_2 = tostring
  L4_2 = _KINDLE
  L3_2 = L3_2(L4_2)
  L4_2 = "&nook="
  L5_2 = tostring
  L6_2 = _NOOK
  L5_2 = L5_2(L6_2)
  L0_2 = L1_2 .. L2_2 .. L3_2 .. L4_2 .. L5_2
  L1_2 = L0_2
  L2_2 = "&ifa="
  L3_2 = _IFA
  L4_2 = L3_2
  L3_2 = L3_2.urlEncode
  L3_2 = L3_2(L4_2)
  L4_2 = "&ifate="
  L5_2 = tostring
  L6_2 = _IFATE
  L5_2 = L5_2(L6_2)
  L6_2 = "&ifv="
  L7_2 = _IFV
  L8_2 = L7_2
  L7_2 = L7_2.urlEncode
  L7_2 = L7_2(L8_2)
  L0_2 = L1_2 .. L2_2 .. L3_2 .. L4_2 .. L5_2 .. L6_2 .. L7_2
  L1_2 = L0_2
  L2_2 = "&fps="
  L3_2 = _FPS
  L4_2 = "&did="
  L5_2 = _UUID
  L6_2 = L5_2
  L5_2 = L5_2.urlEncode
  L5_2 = L5_2(L6_2)
  L0_2 = L1_2 .. L2_2 .. L3_2 .. L4_2 .. L5_2
  L1_2 = L6_1
  if L1_2 then
    L1_2 = print
    L2_2 = L0_2
    L1_2(L2_2)
  end
  return L0_2
end

L0_1.getParametersForServer = L8_1

function L8_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L4_2 = A1_2.y
  L5_2 = A0_2.y
  L4_2 = L4_2 - L5_2
  L5_2 = A2_2.x
  L6_2 = A3_2.x
  L5_2 = L5_2 - L6_2
  L4_2 = L4_2 * L5_2
  L5_2 = A2_2.y
  L6_2 = A3_2.y
  L5_2 = L5_2 - L6_2
  L6_2 = A1_2.x
  L7_2 = A0_2.x
  L6_2 = L6_2 - L7_2
  L5_2 = L5_2 * L6_2
  L4_2 = L4_2 - L5_2
  L5_2 = A1_2.y
  L6_2 = A0_2.y
  L5_2 = L5_2 - L6_2
  L6_2 = A2_2.x
  L7_2 = A0_2.x
  L6_2 = L6_2 - L7_2
  L5_2 = L5_2 * L6_2
  L6_2 = A2_2.y
  L7_2 = A0_2.y
  L6_2 = L6_2 - L7_2
  L7_2 = A1_2.x
  L8_2 = A0_2.x
  L7_2 = L7_2 - L8_2
  L6_2 = L6_2 * L7_2
  L5_2 = L5_2 - L6_2
  L6_2 = A2_2.y
  L7_2 = A0_2.y
  L6_2 = L6_2 - L7_2
  L7_2 = A2_2.x
  L8_2 = A3_2.x
  L7_2 = L7_2 - L8_2
  L6_2 = L6_2 * L7_2
  L7_2 = A2_2.y
  L8_2 = A3_2.y
  L7_2 = L7_2 - L8_2
  L8_2 = A2_2.x
  L9_2 = A0_2.x
  L8_2 = L8_2 - L9_2
  L7_2 = L7_2 * L8_2
  L6_2 = L6_2 - L7_2
  if L4_2 == 0 and L5_2 == 0 and L6_2 == 0 then
    L7_2 = nil
    return L7_2
  end
  if L4_2 == 0 then
    L7_2 = nil
    return L7_2
  end
  L7_2 = L5_2 / L4_2
  L8_2 = L6_2 / L4_2
  L9_2 = {}
  L10_2 = A0_2.x
  L11_2 = A1_2.x
  L12_2 = A0_2.x
  L11_2 = L11_2 - L12_2
  L11_2 = L11_2 * L8_2
  L10_2 = L10_2 + L11_2
  L9_2.x = L10_2
  L10_2 = A0_2.y
  L11_2 = A1_2.y
  L12_2 = A0_2.y
  L11_2 = L11_2 - L12_2
  L11_2 = L11_2 * L8_2
  L10_2 = L10_2 + L11_2
  L9_2.y = L10_2
  if 0 <= L7_2 and L7_2 <= 1 and 0 <= L8_2 and L8_2 <= 1 then
  else
    L10_2 = nil
    return L10_2
  end
  return L9_2
end

L0_1.intersection = L8_1

function L8_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2
  L4_2 = L3_1
  L5_2 = L4_1
  L6_2 = A0_2 - A2_2
  L7_2 = 2
  L5_2 = L5_2(L6_2, L7_2)
  L6_2 = L4_1
  L7_2 = A1_2 - A3_2
  L8_2 = 2
  L6_2 = L6_2(L7_2, L8_2)
  L5_2 = L5_2 + L6_2
  return L4_2(L5_2)
end

L0_1.distance = L8_1

function L8_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2)
  local L8_2
  if A0_2 == nil or A4_2 == nil then
    L8_2 = false
    return L8_2
  end
  if A1_2 < A4_2 then
    L8_2 = false
    return L8_2
  end
  if A5_2 < A0_2 then
    L8_2 = false
    return L8_2
  end
  if A3_2 < A6_2 then
    L8_2 = false
    return L8_2
  end
  if A7_2 < A2_2 then
    L8_2 = false
    return L8_2
  end
  L8_2 = true
  return L8_2
end

L0_1.intersectRect = L8_1

function L8_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2
  L6_2 = L0_1
  L6_2 = L6_2.distance
  L7_2 = A0_2
  L8_2 = A1_2
  L9_2 = A3_2
  L10_2 = A4_2
  L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2)
  L7_2 = A2_2 + A5_2
  if L6_2 < L7_2 then
    L7_2 = true
    return L7_2
  end
  L7_2 = false
  return L7_2
end

L0_1.intersectCircle = L8_1

function L8_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2)
  local L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L7_2 = L5_1
  L8_2 = A2_2 - A0_2
  L9_2 = A5_2 - A1_2
  L8_2 = L8_2 * L9_2
  L9_2 = A4_2 - A0_2
  L10_2 = A3_2 - A1_2
  L9_2 = L9_2 * L10_2
  L8_2 = L8_2 - L9_2
  L7_2 = L7_2(L8_2)
  L8_2 = L0_1
  L8_2 = L8_2.distance
  L9_2 = A0_2
  L10_2 = A1_2
  L11_2 = A2_2
  L12_2 = A3_2
  L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2)
  L9_2 = L7_2 / L8_2
  L10_2 = print
  L11_2 = A0_2
  L12_2 = A1_2
  L13_2 = A2_2
  L14_2 = A3_2
  L15_2 = A4_2
  L16_2 = A5_2
  L17_2 = A6_2
  L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
  L10_2 = print
  L11_2 = L7_2
  L12_2 = L8_2
  L13_2 = L9_2
  L14_2 = A6_2
  L10_2(L11_2, L12_2, L13_2, L14_2)
  L10_2 = A6_2 > L9_2
  return L10_2
end

L0_1.lineIntersectsCircle = L8_1

function L8_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2)
  local L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L7_2 = A0_2
  L8_2 = A2_2
  if A2_2 < A0_2 then
    L9_2 = A2_2
    L8_2 = A0_2
    L7_2 = L9_2
  end
  L9_2 = A1_2
  L10_2 = A3_2
  if A3_2 < A1_2 then
    L11_2 = A3_2
    L10_2 = A1_2
    L9_2 = L11_2
  end
  L11_2 = L0_1
  L11_2 = L11_2.intersectRect
  L12_2 = L7_2
  L13_2 = L8_2
  L14_2 = L9_2
  L15_2 = L10_2
  L16_2 = A4_2 - A6_2
  L17_2 = A4_2 + A6_2
  L18_2 = A5_2 - A6_2
  L19_2 = A5_2 + A6_2
  L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
  if not L11_2 then
    L11_2 = false
    return L11_2
  end
  L11_2 = L0_1
  L11_2 = L11_2.distance
  L12_2 = A4_2
  L13_2 = A5_2
  L14_2 = A0_2
  L15_2 = A1_2
  L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2)
  if A6_2 >= L11_2 then
    L11_2 = true
    return L11_2
  end
  L11_2 = L0_1
  L11_2 = L11_2.distance
  L12_2 = A4_2
  L13_2 = A5_2
  L14_2 = A2_2
  L15_2 = A3_2
  L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2)
  if A6_2 >= L11_2 then
    L11_2 = true
    return L11_2
  end
  L11_2 = A0_2 + A2_2
  L11_2 = L11_2 / 2
  L12_2 = A1_2 + A3_2
  L12_2 = L12_2 / 2
  L13_2 = L0_1
  L13_2 = L13_2.distance
  L14_2 = A4_2
  L15_2 = A5_2
  L16_2 = L11_2
  L17_2 = L12_2
  L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2)
  if A6_2 >= L13_2 then
    L13_2 = true
    return L13_2
  end
  L13_2 = A0_2 + L11_2
  L13_2 = L13_2 / 2
  L14_2 = A1_2 + L12_2
  L14_2 = L14_2 / 2
  L15_2 = L0_1
  L15_2 = L15_2.distance
  L16_2 = A4_2
  L17_2 = A5_2
  L18_2 = L13_2
  L19_2 = L14_2
  L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2)
  if A6_2 >= L15_2 then
    L15_2 = true
    return L15_2
  end
  L15_2 = A2_2 + L11_2
  L15_2 = L15_2 / 2
  L16_2 = A3_2 + L12_2
  L16_2 = L16_2 / 2
  L17_2 = L0_1
  L17_2 = L17_2.distance
  L18_2 = A4_2
  L19_2 = A5_2
  L20_2 = L15_2
  L21_2 = L16_2
  L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2)
  if A6_2 >= L17_2 then
    L17_2 = true
    return L17_2
  end
  L17_2 = false
  return L17_2
end

L0_1.lineIntersectsCircle2 = L8_1

function L8_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  if not A0_2 then
    return
  end
  L4_2 = A0_2
  L3_2 = A0_2.getLinearVelocity
  L3_2, L4_2 = L3_2(L4_2)
  L6_2 = A0_2
  L5_2 = A0_2.setLinearVelocity
  L7_2 = _FPS
  L7_2 = A1_2 * L7_2
  L8_2 = _FPS
  L8_2 = A2_2 * L8_2
  L5_2(L6_2, L7_2, L8_2)
  L5_2 = timer
  L5_2 = L5_2.performWithDelay
  L6_2 = 1
  
  function L7_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = A0_2
    if L0_3 then
      L0_3 = A0_2
      L0_3 = L0_3.setLinearVelocity
      if L0_3 then
        L0_3 = A0_2
        L1_3 = L0_3
        L0_3 = L0_3.setLinearVelocity
        L2_3 = 0
        L3_3 = 0
        L0_3(L1_3, L2_3, L3_3)
      end
    end
  end
  
  L5_2(L6_2, L7_2)
end

L0_1.translateSafely = L8_1
return L0_1
