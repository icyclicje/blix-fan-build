local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "game_tester.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = math
L2_1 = L2_1.random
L0_1.name = "Tester"
L0_1.displayName = "Tester Mode"
L0_1.instructions = "This developer test mode goes through all the building blocks, one-by-one, and shows different variations of each so that you can try them out."
L0_1.scoring = true
L0_1.leveling = true
L0_1.lives = 0
L0_1.oneStrokeAtOnce = false
L0_1.oneStrokePerColorAtOnce = true
L0_1.multitouch = false
L3_1 = nil
L4_1 = nil
L5_1 = nil

function L6_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = A1_2.difficulty
  L3_2 = A1_2.targets
  L3_2 = #L3_2
  L2_2 = L2_2 * L3_2
  L3_2 = _addToScore
  L4_2 = L2_2
  L5_2 = A1_2.targets
  L5_2 = #L5_2
  L3_2(L4_2, L5_2)
  L3_2 = gameutils
  L3_2 = L3_2.showPopupScore
  L4_2 = A1_2.x
  L5_2 = A1_2.y
  L6_2 = L2_2
  L7_2 = lightgray
  L8_2 = 18
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
end

L0_1.onBuildingBlockSuccess = L6_1

function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L3_2 = A2_2.parent
  L4_2 = L3_2
  L3_2 = L3_2.removeIfAllTargetsGone
  L3_2(L4_2)
  L3_2 = building_block
  L3_2 = L3_2.numInPlay
  if L3_2 == 0 then
    L3_2 = timer
    L3_2 = L3_2.performWithDelay
    L4_2 = 500
    
    function L5_2()
      local L0_3, L1_3
      L0_3 = _levelUp
      L1_3 = 500
      L0_3(L1_3)
    end
    
    L3_2(L4_2, L5_2)
  end
end

L0_1.onCorrectTargetHit = L6_1

function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
end

L0_1.onWrongTargetHit = L6_1

function L6_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L4_2 = A1_2
  L3_2 = A1_2.lost
  L5_2 = 100
  L3_2(L4_2, L5_2)
  L3_2 = utils
  L3_2 = L3_2.pop
  L4_2 = A2_2
  L3_2(L4_2)
end

L0_1.onObstacleHit = L6_1

function L6_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = 1
  L3_2 = A1_2.targetsHit
  L3_2 = #L3_2
  L4_2 = 1
  for L5_2 = L2_2, L3_2, L4_2 do
    L6_2 = A1_2.targetsHit
    L6_2 = L6_2[L5_2]
    L7_2 = L6_2
    L6_2 = L6_2.reappear
    L6_2(L7_2)
  end
end

L0_1.onStrokeLost = L6_1

function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = display
  L1_2 = L1_2.newText
  L2_2 = _group
  L3_2 = "building block name"
  L4_2 = _canvasW2
  L5_2 = _canvasBottom
  L5_2 = L5_2 - 15
  L6_2 = _ttf_font_offset
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2 = L6_2[L7_2]
  L5_2 = L5_2 + L6_2
  L6_2 = _ttf_font
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2 = L6_2[L7_2]
  L7_2 = 14
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  L3_1 = L1_2
  L1_2 = L3_1
  L2_2 = L1_2
  L1_2 = L1_2.setFillColor
  L3_2 = gray
  L1_2(L2_2, L3_2())
  L1_2 = buttons
  L1_2 = L1_2.newPlainText
  L2_2 = "< prev"
  
  function L3_2()
    local L0_3, L1_3
    L0_3 = _level
    L0_3 = L0_3 - 2
    _level = L0_3
    L0_3 = _levelUp
    L0_3()
  end
  
  L4_2 = {}
  L5_2 = _group
  L4_2.group = L5_2
  L5_2 = gray
  L4_2.textColor = L5_2
  L4_2.frameless = true
  L4_2.textAnchorX = 0
  L4_2.fontSize = 14
  L5_2 = globals
  L5_2 = L5_2.defaultFont
  L4_2.fontNum = L5_2
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L4_1 = L1_2
  L1_2 = L4_1
  L2_2 = L4_1
  L3_2 = _canvasLeft
  L3_2 = L3_2 + 30
  L4_2 = screenBottom
  L4_2 = L4_2 - 15
  L2_2.y = L4_2
  L1_2.x = L3_2
  L1_2 = buttons
  L1_2 = L1_2.newPlainText
  L2_2 = "next >"
  L3_2 = _levelUp
  L4_2 = {}
  L5_2 = _group
  L4_2.group = L5_2
  L5_2 = gray
  L4_2.textColor = L5_2
  L4_2.frameless = true
  L4_2.textAnchorX = 1
  L4_2.fontSize = 14
  L5_2 = globals
  L5_2 = L5_2.defaultFont
  L4_2.fontNum = L5_2
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L5_1 = L1_2
  L1_2 = L5_1
  L2_2 = L5_1
  L3_2 = screenRight
  L3_2 = L3_2 - 30
  L4_2 = screenBottom
  L4_2 = L4_2 - 15
  L2_2.y = L4_2
  L1_2.x = L3_2
end

L0_1.onSetupGame = L6_1

function L6_1(A0_2)
  local L1_2, L2_2
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L3_1
  L1_2(L2_2)
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L4_1
  L1_2(L2_2)
  L1_2 = display
  L1_2 = L1_2.remove
  L2_2 = L5_1
  L1_2(L2_2)
end

L0_1.onCleanUp = L6_1

function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = building_block
  L1_2 = L1_2.types_array
  L2_2 = _level
  L1_2 = L1_2[L2_2]
  if not L1_2 then
    return
  end
  L1_2 = building_block
  L1_2 = L1_2.types_array
  L2_2 = _level
  L1_2 = L1_2[L2_2]
  L1_2 = L1_2.name
  L2_2 = building_block
  L2_2 = L2_2.types_array
  L3_2 = _level
  L2_2 = L2_2[L3_2]
  L2_2 = L2_2.suggestedRotationTime
  L3_2 = building_block
  L3_2 = L3_2.types_array
  L4_2 = _level
  L3_2 = L3_2[L4_2]
  L3_2 = L3_2.solo
  L4_2 = L3_1
  L4_2.text = L1_2
  if L3_2 then
    L4_2 = building_block
    L4_2 = L4_2.new
    L5_2 = _group
    L6_2 = {}
    L6_2.name = L1_2
    L7_2 = building_block
    L7_2 = L7_2.MODIFIER_NORMAL
    L6_2.modifier = L7_2
    L7_2 = blue
    L6_2.color = L7_2
    L4_2 = L4_2(L5_2, L6_2)
    L5_2 = _canvasW2
    L6_2 = _canvasH2
    L4_2.y = L6_2
    L4_2.x = L5_2
  else
    L4_2 = building_block
    L4_2 = L4_2.new
    L5_2 = _group
    L6_2 = {}
    L6_2.name = L1_2
    L7_2 = building_block
    L7_2 = L7_2.MODIFIER_NORMAL
    L6_2.modifier = L7_2
    L7_2 = red
    L6_2.color = L7_2
    L4_2 = L4_2(L5_2, L6_2)
    L5_2 = _canvasW5
    L6_2 = _canvasH4
    L4_2.y = L6_2
    L4_2.x = L5_2
    L5_2 = building_block
    L5_2 = L5_2.new
    L6_2 = _group
    L7_2 = {}
    L7_2.name = L1_2
    L8_2 = building_block
    L8_2 = L8_2.MODIFIER_ROTATED
    L7_2.modifier = L8_2
    L8_2 = orange
    L7_2.color = L8_2
    L7_2.startRotation = -30
    L5_2 = L5_2(L6_2, L7_2)
    L6_2 = _canvasW2
    L7_2 = _canvasH4
    L5_2.y = L7_2
    L5_2.x = L6_2
    L6_2 = building_block
    L6_2 = L6_2.new
    L7_2 = _group
    L8_2 = {}
    L8_2.name = L1_2
    L9_2 = building_block
    L9_2 = L9_2.MODIFIER_MULTICOLOR
    L8_2.modifier = L9_2
    L8_2.color = nil
    L6_2 = L6_2(L7_2, L8_2)
    L7_2 = _canvasW45
    L8_2 = _canvasH4
    L6_2.y = L8_2
    L6_2.x = L7_2
    L7_2 = building_block
    L7_2 = L7_2.new
    L8_2 = _group
    L9_2 = {}
    L9_2.name = L1_2
    L10_2 = building_block
    L10_2 = L10_2.MODIFIER_SLOWSPIN
    L9_2.modifier = L10_2
    L10_2 = green
    L9_2.color = L10_2
    L9_2.rotationTime = 50000
    L7_2 = L7_2(L8_2, L9_2)
    L8_2 = _canvasW5
    L9_2 = _canvasH34
    L7_2.y = L9_2
    L7_2.x = L8_2
    L8_2 = building_block
    L8_2 = L8_2.new
    L9_2 = _group
    L10_2 = {}
    L10_2.name = L1_2
    L11_2 = building_block
    L11_2 = L11_2.MODIFIER_FASTSPIN
    L10_2.modifier = L11_2
    L11_2 = blue
    L10_2.color = L11_2
    L10_2.rotationTime = 1500
    L8_2 = L8_2(L9_2, L10_2)
    L9_2 = _canvasW2
    L10_2 = _canvasH34
    L8_2.y = L10_2
    L8_2.x = L9_2
    L9_2 = building_block
    L9_2 = L9_2.new
    L10_2 = _group
    L11_2 = {}
    L11_2.name = L1_2
    L12_2 = building_block
    L12_2 = L12_2.MODIFIER_MULTICOLOR_SPIN
    L11_2.modifier = L12_2
    L11_2.color = nil
    L11_2.rotationTime = 20000
    L9_2 = L9_2(L10_2, L11_2)
    L10_2 = _canvasW45
    L11_2 = _canvasH34
    L9_2.y = L11_2
    L9_2.x = L10_2
  end
end

L0_1.onLevelUp = L6_1

function L6_1(A0_2)
  local L1_2
end

L0_1.onEndGame = L6_1

function L6_1(A0_2)
  local L1_2
end

L0_1.onAddToScore = L6_1
return L0_1
