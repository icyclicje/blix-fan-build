local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = print
  L3_1 = "_screen.lua DEBUGGING"
  L2_1(L3_1)
end

function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = display
  L0_2 = L0_2.contentCenterX
  centerX = L0_2
  L0_2 = display
  L0_2 = L0_2.contentCenterY
  centerY = L0_2
  L0_2 = display
  L0_2 = L0_2.screenOriginX
  screenX = L0_2
  L0_2 = display
  L0_2 = L0_2.screenOriginY
  screenY = L0_2
  L0_2 = display
  L0_2 = L0_2.contentWidth
  L1_2 = screenX
  L1_2 = L1_2 * 2
  L0_2 = L0_2 - L1_2
  screenWidth = L0_2
  L0_2 = display
  L0_2 = L0_2.contentHeight
  L1_2 = screenY
  L1_2 = L1_2 * 2
  L0_2 = L0_2 - L1_2
  screenHeight = L0_2
  L0_2 = screenX
  screenLeft = L0_2
  L0_2 = screenX
  L1_2 = screenWidth
  L0_2 = L0_2 + L1_2
  screenRight = L0_2
  L0_2 = screenY
  screenTop = L0_2
  L0_2 = screenY
  L1_2 = screenHeight
  L0_2 = L0_2 + L1_2
  screenBottom = L0_2
  L0_2 = display
  L0_2 = L0_2.contentWidth
  L1_2 = display
  L1_2 = L1_2.contentHeight
  _H = L1_2
  _W = L0_2
  L0_2 = centerX
  L1_2 = centerY
  _H2 = L1_2
  _W2 = L0_2
  L0_2 = screenLeft
  L1_2 = _W2
  L2_2 = screenLeft
  L1_2 = L1_2 - L2_2
  L1_2 = L1_2 / 2
  L0_2 = L0_2 + L1_2
  _W4 = L0_2
  L0_2 = screenTop
  L1_2 = _H2
  L2_2 = screenTop
  L1_2 = L1_2 - L2_2
  L1_2 = L1_2 / 2
  L0_2 = L0_2 + L1_2
  _H4 = L0_2
  L0_2 = screenRight
  L1_2 = _W2
  L2_2 = screenLeft
  L1_2 = L1_2 - L2_2
  L1_2 = L1_2 / 2
  L0_2 = L0_2 - L1_2
  _W34 = L0_2
  L0_2 = screenBottom
  L1_2 = _H2
  L2_2 = screenTop
  L1_2 = L1_2 - L2_2
  L1_2 = L1_2 / 2
  L0_2 = L0_2 - L1_2
  _H34 = L0_2
  L0_2 = system
  L0_2 = L0_2.getInfo
  L1_2 = "androidDisplayXDpi"
  L0_2 = L0_2(L1_2)
  L1_2 = system
  L1_2 = L1_2.getInfo
  L2_2 = "androidDisplayYDpi"
  L1_2 = L1_2(L2_2)
  L2_2 = system
  L2_2 = L2_2.getInfo
  L3_2 = "androidDisplayWidthInInches"
  L2_2 = L2_2(L3_2)
  L3_2 = system
  L3_2 = L3_2.getInfo
  L4_2 = "androidDisplayHeightInInches"
  L3_2 = L3_2(L4_2)
  L4_2 = nil
  _diagonalInches = L4_2
  if L2_2 and L3_2 and 0 < L2_2 and 0 < L3_2 then
    L4_2 = math
    L4_2 = L4_2.sqrt
    L5_2 = L2_2 * L2_2
    L6_2 = L3_2 * L3_2
    L5_2 = L5_2 + L6_2
    L4_2 = L4_2(L5_2)
    _diagonalInches = L4_2
  else
    -- (web build) unluac emitted a goto into a nested block here; same logic, restructured
    if _MODEL:find("iPhone") or _MODEL:find("iPod") then
      if _iVersion < 5 then
        _diagonalInches = 3.5
      else
        _diagonalInches = 4
      end
    elseif _MODEL:find("iPad") then
      _diagonalInches = 9.7
    else
      _diagonalInches = 4
    end
  end
  L4_2 = math
  L4_2 = L4_2.sqrt
  L5_2 = screenWidth
  L6_2 = screenWidth
  L5_2 = L5_2 * L6_2
  L6_2 = screenHeight
  L7_2 = screenHeight
  L6_2 = L6_2 * L7_2
  L5_2 = L5_2 + L6_2
  L4_2 = L4_2(L5_2)
  L5_2 = _diagonalInches
  L5_2 = L4_2 / L5_2
  _pixelsPerInch = L5_2
  L5_2 = system
  L5_2 = L5_2.orientation
  _orientation = L5_2
  L5_2 = "portrait"
  _simpleOrientation = L5_2
  L5_2 = screenWidth
  L6_2 = screenHeight
  if L5_2 > L6_2 then
    L5_2 = "landscape"
    _simpleOrientation = L5_2
  end
  L5_2 = _diagonalInches
  L5_2 = 6.33 <= L5_2
  _tablet = L5_2
end

L0_1.setScreenGlobals = L2_1
L2_1 = L0_1.setScreenGlobals
L2_1()

function L2_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "_MODEL="
  L2_2 = _MODEL
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "screenLeft="
  L2_2 = screenLeft
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "screenRight="
  L2_2 = screenRight
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "screenTop="
  L2_2 = screenTop
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "screenBottom="
  L2_2 = screenBottom
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "screenWidth="
  L2_2 = screenWidth
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "screenHeight="
  L2_2 = screenHeight
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "_diagonalInches="
  L2_2 = _diagonalInches
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "_tablet="
  L2_2 = tostring
  L3_2 = _tablet
  L2_2 = L2_2(L3_2)
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "_pixelsPerInch="
  L2_2 = _pixelsPerInch
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
  L0_2 = log
  L0_2 = L0_2.show
  L1_2 = "_simpleOrientation="
  L2_2 = _simpleOrientation
  L1_2 = L1_2 .. L2_2
  L0_2(L1_2)
end

if L1_1 then
  L3_1 = timer
  L3_1 = L3_1.performWithDelay
  L4_1 = 1000
  L5_1 = L2_1
  L3_1(L4_1, L5_1)
end
return L0_1
