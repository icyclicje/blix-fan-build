local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1, L22_1, L23_1, L24_1
L0_1 = require
L1_1 = "composer"
L0_1 = L0_1(L1_1)
L1_1 = L0_1.newScene
L1_1 = L1_1()
L2_1 = false
if L2_1 then
  L3_1 = log
  L3_1 = L3_1.show
  L4_1 = "_scene_result.lua DEBUGGING"
  L3_1(L4_1)
end
L3_1 = nil
L4_1 = nil
L5_1 = nil
L6_1 = nil
L7_1 = nil
L8_1 = nil
L9_1 = nil
L10_1 = nil
L11_1 = nil
L12_1 = nil
L13_1 = nil
L14_1 = false
L15_1 = nil
L16_1 = nil
L17_1 = false

function L18_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.hideOverlay
  L0_2()
  L0_2 = L0_1
  L0_2 = L0_2.gotoScene
  L1_2 = "scene_title"
  L0_2(L1_2)
end

function L19_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = "Result Screen"
  L1_2 = platform
  L1_2 = L1_2.android
  if L1_2 then
    L1_2 = sharing
    L1_2 = L1_2.shareViaGoogle
    L2_2 = L0_2
    L3_2 = L12_1
    L1_2(L2_2, L3_2)
  else
    L1_2 = L0_1
    L1_2 = L1_2.hideOverlay
    L1_2()
    
    function L1_2()
      local L0_3, L1_3, L2_3, L3_3
      L0_3 = L0_1
      L0_3 = L0_3.showOverlay
      L1_3 = "_scene_result"
      L2_3 = {}
      L2_3.isModal = true
      L3_3 = L13_1
      L2_3.params = L3_3
      L0_3(L1_3, L2_3)
    end
    
    L2_2 = L0_1
    L2_2 = L2_2.showOverlay
    L3_2 = "_scene_share"
    L4_2 = {}
    L4_2.isModal = true
    L4_2.effect = "zoomOutIn"
    L4_2.time = 100
    L5_2 = {}
    L6_2 = L12_1
    L5_2.shareMsgPrefix = L6_2
    L5_2.source = L0_2
    L5_2.fnBackCallback = L1_2
    L4_2.params = L5_2
    L2_2(L3_2, L4_2)
  end
end

function L20_1()
  local L0_2, L1_2
  L0_2 = L0_1
  L0_2 = L0_2.hideOverlay
  L0_2()
  L0_2 = L11_1
  if L0_2 then
    L0_2 = L11_1
    L0_2()
  end
end

function L21_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_result:create()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = display
  L3_2 = L3_2.newRect
  L4_2 = L2_2
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = screenWidth
  L8_2 = screenHeight
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L3_1 = L3_2
  L3_2 = L3_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = black
  L3_2(L4_2, L5_2())
  L3_2 = L3_1
  L3_2.alpha = 0
  L3_2 = display
  L3_2 = L3_2.newRoundedRect
  L4_2 = L2_2
  L5_2 = _W2
  L6_2 = _H2
  L6_2 = L6_2 - 12
  L7_2 = 200
  L8_2 = 180
  L9_2 = 20
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L4_1 = L3_2
  L3_2 = L4_1
  L3_2.alpha = 1
  L3_2 = L4_1
  L4_2 = L3_2
  L3_2 = L3_2.setFillColor
  L5_2 = black
  L3_2(L4_2, L5_2())
  L3_2 = L4_1
  L3_2.strokeWidth = 3
  L3_2 = L4_1
  L4_2 = L3_2
  L3_2 = L3_2.setStrokeColor
  L5_2 = white
  L3_2(L4_2, L5_2())
  L3_2 = display
  L3_2 = L3_2.newText
  L4_2 = L2_2
  L5_2 = "High score: "
  L6_2 = 0
  L7_2 = 0
  L8_2 = _ttf_font
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2 = L8_2[L9_2]
  L9_2 = 16
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L5_1 = L3_2
  L3_2 = L5_1
  L3_2.alpha = 0.33
  L3_2 = L5_1
  L4_2 = L5_1
  L5_2 = _W2
  L6_2 = _H2
  L6_2 = L6_2 - 80
  L7_2 = _ttf_font_offset
  L8_2 = globals
  L8_2 = L8_2.defaultFont
  L7_2 = L7_2[L8_2]
  L7_2 = L7_2 * 16
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = display
  L3_2 = L3_2.newText
  L4_2 = L2_2
  L5_2 = "Level 1"
  L6_2 = 0
  L7_2 = 0
  L8_2 = _ttf_font
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2 = L8_2[L9_2]
  L9_2 = 28
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L6_1 = L3_2
  L3_2 = L6_1
  L3_2.alpha = 0.67
  L3_2 = L6_1
  L4_2 = L6_1
  L5_2 = _W2
  L6_2 = _H2
  L6_2 = L6_2 - 40
  L7_2 = _ttf_font_offset
  L8_2 = globals
  L8_2 = L8_2.defaultFont
  L7_2 = L7_2[L8_2]
  L7_2 = L7_2 * 28
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = L6_1
  L4_2 = L6_1
  L5_2 = L6_1
  L5_2 = L5_2.x
  L6_2 = L6_1
  L6_2 = L6_2.y
  L4_2.origY = L6_2
  L3_2.origX = L5_2
  L3_2 = display
  L3_2 = L3_2.newText
  L4_2 = L2_2
  L5_2 = "0"
  L6_2 = 0
  L7_2 = 0
  L8_2 = _ttf_font
  L9_2 = globals
  L9_2 = L9_2.defaultFont
  L8_2 = L8_2[L9_2]
  L9_2 = 40
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  L7_1 = L3_2
  L3_2 = L7_1
  L3_2.alpha = 1
  L3_2 = L7_1
  L4_2 = L7_1
  L5_2 = _W2
  L6_2 = _H2
  L7_2 = _ttf_font_offset
  L8_2 = globals
  L8_2 = L8_2.defaultFont
  L7_2 = L7_2[L8_2]
  L7_2 = L7_2 * 40
  L6_2 = L6_2 + L7_2
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = L7_1
  L4_2 = L7_1
  L5_2 = L7_1
  L5_2 = L5_2.x
  L6_2 = L7_1
  L6_2 = L6_2.y
  L4_2.origY = L6_2
  L3_2.origX = L5_2
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = "Home"
  L5_2 = L18_1
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = orange
  L6_2.textColor = L7_2
  L6_2.alphaWhenEnabled = 1
  L6_2.frameless = true
  L6_2.fontSize = 18
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2.fontNum = L7_2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L8_1 = L3_2
  L3_2 = L8_1
  L4_2 = L8_1
  L5_2 = _W2
  L5_2 = L5_2 - 60
  L6_2 = _H2
  L6_2 = L6_2 + 50
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = "Share"
  L5_2 = L19_1
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = blue
  L6_2.textColor = L7_2
  L6_2.alphaWhenEnabled = 1
  L6_2.frameless = true
  L6_2.fontSize = 18
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2.fontNum = L7_2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L9_1 = L3_2
  L3_2 = L9_1
  L4_2 = L9_1
  L5_2 = _W2
  L6_2 = _H2
  L6_2 = L6_2 + 50
  L4_2.y = L6_2
  L3_2.x = L5_2
  L3_2 = buttons
  L3_2 = L3_2.newPlainText
  L4_2 = "Retry"
  L5_2 = L20_1
  L6_2 = {}
  L6_2.group = L2_2
  L7_2 = green
  L6_2.textColor = L7_2
  L6_2.alphaWhenEnabled = 1
  L6_2.frameless = true
  L6_2.fontSize = 18
  L7_2 = globals
  L7_2 = L7_2.defaultFont
  L6_2.fontNum = L7_2
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L10_1 = L3_2
  L3_2 = L10_1
  L4_2 = L10_1
  L5_2 = _W2
  L5_2 = L5_2 + 60
  L6_2 = _H2
  L6_2 = L6_2 + 50
  L4_2.y = L6_2
  L3_2.x = L5_2
end

L1_1.create = L21_1

function L21_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_result:show() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
      L3_2 = A1_2.params
      L13_1 = L3_2
      L3_2 = A1_2.params
      L3_2 = L3_2.retryFn
      L11_1 = L3_2
      L3_2 = A1_2.params
      L3_2 = L3_2.highScore
      L4_2 = A1_2.params
      L4_2 = L4_2.showLevel
      L5_2 = A1_2.params
      L5_2 = L5_2.shareMsgPrefix
      L12_1 = L5_2
      L5_2 = A1_2.params
      L5_2 = L5_2.bgAlpha
      if not L5_2 then
        L5_2 = 1
      end
      L6_2 = A1_2.params
      L6_2 = L6_2.bgColor
      if not L6_2 then
        L6_2 = black
      end
      L7_2 = A1_2.params
      L7_2 = L7_2.bgStrokeWidth
      if not L7_2 then
        L7_2 = 3
      end
      L8_2 = A1_2.params
      L8_2 = L8_2.bgStrokeColor
      if not L8_2 then
        L8_2 = white
      end
      L9_2 = A1_2.params
      L9_2 = L9_2.textColor
      if not L9_2 then
        L9_2 = white
      end
      L10_2 = L4_1
      L10_2.alpha = L5_2
      L10_2 = L4_1
      L11_2 = L10_2
      L10_2 = L10_2.setFillColor
      L12_2 = L6_2
      L12_2 = L12_2()
      L10_2(L11_2, L12_2)
      L10_2 = L4_1
      L10_2.strokeWidth = L7_2
      L10_2 = L4_1
      L11_2 = L10_2
      L10_2 = L10_2.setStrokeColor
      L12_2 = L8_2
      L12_2 = L12_2()
      L10_2(L11_2, L12_2)
      L10_2 = L5_1
      L11_2 = "High score: "
      L12_2 = L3_2
      L11_2 = L11_2 .. L12_2
      L10_2.text = L11_2
      if not L4_2 then
        L10_2 = L6_1
        L10_2.text = "Score"
      else
        L10_2 = L6_1
        L11_2 = "Level "
        L12_2 = _level
        L11_2 = L11_2 .. L12_2
        L10_2.text = L11_2
      end
      L10_2 = L7_1
      L11_2 = _score
      L10_2.text = L11_2
      L10_2 = L5_1
      L11_2 = L10_2
      L10_2 = L10_2.setFillColor
      L12_2 = L9_2
      L12_2 = L12_2()
      L10_2(L11_2, L12_2)
      L10_2 = L6_1
      L11_2 = L10_2
      L10_2 = L10_2.setFillColor
      L12_2 = L9_2
      L12_2 = L12_2()
      L10_2(L11_2, L12_2)
      L10_2 = L7_1
      L11_2 = L10_2
      L10_2 = L10_2.setFillColor
      L12_2 = L9_2
      L12_2 = L12_2()
      L10_2(L11_2, L12_2)
      L10_2 = system
      L10_2 = L10_2.getTimer
      L10_2 = L10_2()
      L15_1 = L10_2
      L10_2 = ads
      L10_2 = L10_2.possiblyShowInterstitial
      L10_2 = L10_2()
      L14_1 = L10_2
    end
  end
end

L1_1.show = L21_1

function L21_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_result:hide() "
    L4_2 = A1_2.phase
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
  L3_2 = A1_2.phase
  if L3_2 == "will" then
    L3_2 = utils
    L3_2 = L3_2.cancelAllTimersAndTransitions
    L3_2()
  else
    L3_2 = A1_2.phase
    if L3_2 == "did" then
      L3_2 = system
      L3_2 = L3_2.getTimer
      L3_2 = L3_2()
      L16_1 = L3_2
      L3_2 = L16_1
      L4_2 = L15_1
      L3_2 = L3_2 - L4_2
      L4_2 = L2_1
      if L4_2 then
        L4_2 = print
        L5_2 = "_scene_result: howLongShown="
        L6_2 = L3_2
        L5_2 = L5_2 .. L6_2
        L6_2 = "showedAd="
        L7_2 = tostring
        L8_2 = L14_1
        L7_2 = L7_2(L8_2)
        L6_2 = L6_2 .. L7_2
        L4_2(L5_2, L6_2)
      end
      if L3_2 < 200 then
        L4_2 = L14_1
        if L4_2 then
          function L4_2()
            local L0_3, L1_3, L2_3, L3_3
            
            L0_3 = L0_1
            L0_3 = L0_3.showOverlay
            L1_3 = "_scene_result"
            L2_3 = {}
            L2_3.isModal = true
            L3_3 = L13_1
            L2_3.params = L3_3
            L0_3(L1_3, L2_3)
          end
          
          _fnToCallWhenClosedDueToBeingKilled = L4_2
      end
      else
        L4_2 = nil
        _fnToCallWhenClosedDueToBeingKilled = L4_2
      end
    end
  end
end

L1_1.hide = L21_1

function L21_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = L2_1
  if L2_2 then
    L2_2 = print
    L3_2 = "_scene_result:destroy()"
    L2_2(L3_2)
  end
  L2_2 = A0_2.view
end

L1_1.destroy = L21_1
L22_1 = L1_1
L21_1 = L1_1.addEventListener
L23_1 = "create"
L24_1 = L1_1
L21_1(L22_1, L23_1, L24_1)
L22_1 = L1_1
L21_1 = L1_1.addEventListener
L23_1 = "show"
L24_1 = L1_1
L21_1(L22_1, L23_1, L24_1)
L22_1 = L1_1
L21_1 = L1_1.addEventListener
L23_1 = "hide"
L24_1 = L1_1
L21_1(L22_1, L23_1, L24_1)
L22_1 = L1_1
L21_1 = L1_1.addEventListener
L23_1 = "destroy"
L24_1 = L1_1
L21_1(L22_1, L23_1, L24_1)
return L1_1
