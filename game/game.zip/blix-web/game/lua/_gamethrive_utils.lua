local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_gamethrive_utils.lua DEBUGGING"
  L2_1(L3_1)
end

function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  if A1_2 then
    L3_2 = A1_2.discount
    if L3_2 then
      L3_2 = native
      L3_2 = L3_2.showAlert
      L4_2 = "Discount!"
      L5_2 = A0_2
      L6_2 = {}
      L7_2 = "OK"
      L6_2[1] = L7_2
      L3_2(L4_2, L5_2, L6_2)
  end
  elseif A1_2 then
    L3_2 = A1_2.bonusCredits
    if L3_2 then
      if A2_2 then
      end
      L3_2 = native
      L3_2 = L3_2.showAlert
      L4_2 = "Bonus Credits!"
      L5_2 = A0_2
      L6_2 = {}
      L7_2 = "OK"
      L6_2[1] = L7_2
      L3_2(L4_2, L5_2, L6_2)
    end
  end
end

L3_1 = require
L4_1 = "plugin.GameThrivePushNotifications"
L3_1 = L3_1(L4_1)
L4_1 = globals
L4_1 = L4_1.GAMETHRIVE_APP_KEY
if L4_1 then
  L4_1 = L3_1.HandleLaunchArgs
  L5_1 = _launchArgs
  L6_1 = globals
  L6_1 = L6_1.GAMETHRIVE_APP_KEY
  L7_1 = globals
  L7_1 = L7_1.GAMETHRIVE_NOTIFICATION_LISTENTER
  if not L7_1 then
    L7_1 = L2_1
  end
  L4_1(L5_1, L6_1, L7_1)
else
  L4_1 = log
  L4_1 = L4_1.show
  L5_1 = "ERROR: GAMETHRIVE_APP_KEY is nil"
  L4_1(L5_1)
end

function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = L1_1
  if L2_2 then
    L2_2 = print
    L3_2 = "gamethrive_utils.tagPlayer()"
    L2_2(L3_2)
  end
  L2_2 = L3_1
  L2_2 = L2_2.TagPlayer
  L3_2 = tostring
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L4_2 = A1_2
  L2_2(L3_2, L4_2)
end

L0_1.tagPlayer = L4_1

function L4_1(A0_2)
  local L1_2, L2_2
  L1_2 = L1_1
  if L1_2 then
    L1_2 = print
    L2_2 = "gamethrive_utils.tagPlayerMultiple()"
    L1_2(L2_2)
  end
  L1_2 = L3_1
  L1_2 = L1_2.TagPlayerWithTable
  L2_2 = A0_2
  L1_2(L2_2)
end

L0_1.tagPlayerMultiple = L4_1

function L4_1(A0_2)
  local L1_2, L2_2
  L1_2 = L1_1
  if L1_2 then
    L1_2 = print
    L2_2 = "gamethrive_utils.playerPurchase()"
    L1_2(L2_2)
  end
  L1_2 = L3_1
  L1_2 = L1_2.PlayerPurchase
  L2_2 = A0_2 / 100
  L1_2(L2_2)
end

L0_1.playerPurchase = L4_1

function L4_1()
  local L0_2, L1_2, L2_2
  L0_2 = L1_1
  if L0_2 then
    L0_2 = print
    L1_2 = "gamethrive_utils.doCommonTags()"
    L0_2(L1_2)
  end
  L0_2 = L0_1
  L0_2 = L0_2.tagPlayerMultiple
  L1_2 = {}
  L2_2 = APP_VERSION
  L1_2.av = L2_2
  L2_2 = bsi
  L2_2 = L2_2.savedData
  L2_2 = L2_2.versionWhenInstalled
  L1_2.avwi = L2_2
  L2_2 = bsi
  L2_2 = L2_2.savedData
  L2_2 = L2_2.firstTimeUse
  L1_2.ftu = L2_2
  L2_2 = ltv
  L2_2 = L2_2.data
  L2_2 = L2_2.numAdsViewed
  L1_2.adsv = L2_2
  L2_2 = ltv
  L2_2 = L2_2.data
  L2_2 = L2_2.numAdsClicked
  L1_2.adsc = L2_2
  L2_2 = ltv
  L2_2 = L2_2.data
  L2_2 = L2_2.gamesPlayed
  L1_2.gp = L2_2
  L2_2 = ltv
  L2_2 = L2_2.data
  L2_2 = L2_2.numSessions
  L1_2.ns = L2_2
  L0_2(L1_2)
end

L0_1.doCommonTags = L4_1
return L0_1
