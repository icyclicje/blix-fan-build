local L0_1, L1_1, L2_1, L3_1, L4_1
L0_1 = {}
L1_1 = false
if L1_1 then
  L2_1 = log
  L2_1 = L2_1.show
  L3_1 = "_applovin.lua DEBUGGING"
  L2_1(L3_1)
end
L2_1 = system
L2_1 = L2_1.getInfo
L3_1 = "platformName"
L2_1 = L2_1(L3_1)
L3_1 = {}
L3_1.sdk_key = "Eqg4h8GyK8hCJFtM0uP1TarOa41ON8Eczvhe2yaN5HZOWQmXJ9TnlOAJSChrLwSIq8yt4XE9poXJDHsWROIAnT"
L4_1 = PACKAGE_NAME
L3_1.android_package = L4_1
L4_1 = PACKAGE_NAME
L3_1.ios_package = L4_1
AppLovinConfig = L3_1
L3_1 = {}
L3_1.version = "1.5"
L3_1.POSITION_TOP = "-1"
L3_1.POSITION_BOTTOM = "-2"
L3_1.POSITION_CENTER = "-3"
L3_1.POSITION_LEFT = "-4"
L3_1.POSITION_RIGHT = "-5"
L3_1.initialized = false
L3_1.endpoint = "http://a.applovin.com/ad"
L3_1.dendpoint = "http://d.applovin.com/device"
L3_1.banner_webview = nil
L3_1.inter_webview = nil
L3_1.cached_file = "APPLOVIN_LAST_AD"

function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  if not A0_2 then
    L2_2 = L0_1
    A0_2 = L2_2.POSITION_CENTER
  end
  if not A1_2 then
    L2_2 = L0_1
    A1_2 = L2_2.POSITION_BOTTOM
  end
  L2_2 = AppLovinAdView
  L2_2 = L2_2.init
  L3_2 = "BANNER"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  L4_2 = L2_2
  L3_2 = L2_2.loadNextAd
  L3_2(L4_2)
  
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = A0_3.type
    if L1_3 == "applicationResume" then
      L1_3 = L2_2
      L2_3 = L1_3
      L1_3 = L1_3.loadNextAd
      L1_3(L2_3)
    end
  end
  
  L4_2 = Runtime
  L5_2 = L4_2
  L4_2 = L4_2.addEventListener
  L6_2 = "system"
  L7_2 = L3_2
  L4_2(L5_2, L6_2, L7_2)
  return L2_2
end

L3_1.newAdView = L4_1

function L4_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = AppLovinAdView
  L0_2 = L0_2.init
  L1_2 = "INTER"
  L2_2 = display
  L2_2 = L2_2.screenOriginX
  L3_2 = display
  L3_2 = L3_2.screenOriginY
  L0_2 = L0_2(L1_2, L2_2, L3_2)
  L2_2 = L0_2
  L1_2 = L0_2.loadNextAd
  L1_2(L2_2)
end

L3_1.showInterstitial = L4_1

function L4_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L4_2 = L0_1
  L4_2 = L4_2.log
  L5_2 = "handleAdResponse"
  L4_2(L5_2)
  if A0_2 then
    L4_2 = A0_2.isError
    if not L4_2 then
      goto lbl_21
    end
  end
  if A3_2 == "INTER" and A2_2 then
    L4_2 = A2_2.remove
    L4_2()
  end
  L4_2 = L0_1
  L4_2 = L4_2.log
  L5_2 = "Unable to receive an ad."
  L4_2(L5_2)
  goto lbl_70
  ::lbl_21::
  L4_2 = A0_2.url
  if L4_2 then
    L4_2 = A0_2.url
    if L4_2 ~= "" then
      L4_2 = L1_1
      if L4_2 then
        L4_2 = log
        L4_2 = L4_2.show
        L5_2 = "handleAdResponse()"
        L4_2(L5_2)
      end
      L4_2 = A0_2.url
      A2_2.adURL = L4_2
      L4_2 = L1_1
      if L4_2 then
        L4_2 = log
        L4_2 = L4_2.show
        L5_2 = "fetching "
        L6_2 = A0_2.url
        L7_2 = L6_2
        L6_2 = L6_2.sub
        L8_2 = 1
        L9_2 = 25
        L6_2 = L6_2(L7_2, L8_2, L9_2)
        L5_2 = L5_2 .. L6_2
        L4_2(L5_2)
      end
      L4_2 = L0_1
      L4_2 = L4_2.log
      L5_2 = "Received url string and cached: "
      L6_2 = A0_2.url
      L5_2 = L5_2 .. L6_2
      L4_2(L5_2)
      L4_2 = network
      L4_2 = L4_2.download
      L5_2 = A0_2.url
      L6_2 = "GET"
      L7_2 = A2_2.cacheAdHTML
      L8_2 = nil
      L9_2 = A1_2
      L10_2 = system
      L10_2 = L10_2.TemporaryDirectory
      L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
  end
  else
    L4_2 = L0_1
    L4_2 = L4_2.log
    L5_2 = "Failed to receive a valid ad URL."
    L4_2(L5_2)
  end
  ::lbl_70::
end

L3_1.handleAdResponse = L4_1

function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = require
  L2_2 = "crypto"
  L1_2 = L1_2(L2_2)
  L2_2 = L0_1
  L2_2 = L2_2.getDeviceInfo
  L2_2 = L2_2()
  L3_2 = "corona_"
  L4_2 = L0_1
  L4_2 = L4_2.version
  L3_2 = L3_2 .. L4_2
  L2_2.plugin_version = L3_2
  L3_2 = AppLovinConfig
  L3_2 = L3_2.sdk_key
  L2_2.sdk_key = L3_2
  L2_2.size = A0_2
  L2_2.format = "html"
  L3_2 = L2_1
  if L3_2 == "Android" then
    L3_2 = AppLovinConfig
    L3_2 = L3_2.android_package
    L2_2.package_name = L3_2
    L3_2 = L1_2.digest
    L4_2 = L1_2.sha1
    L5_2 = AppLovinConfig
    L5_2 = L5_2.android_package
    L3_2 = L3_2(L4_2, L5_2)
    L4_2 = L3_2
    L3_2 = L3_2.sub
    L5_2 = 0
    L6_2 = 16
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L2_2.app_id = L3_2
  else
    L3_2 = L2_1
    if L3_2 == "iPhone OS" then
      L3_2 = AppLovinConfig
      L3_2 = L3_2.ios_package
      L2_2.package_name = L3_2
      L3_2 = L1_2.digest
      L4_2 = L1_2.sha1
      L5_2 = AppLovinConfig
      L5_2 = L5_2.ios_package
      L3_2 = L3_2(L4_2, L5_2)
      L2_2.app_id = L3_2
    end
  end
  L3_2 = L0_1
  L3_2 = L3_2.endpoint
  L4_2 = L0_1
  L4_2 = L4_2.parametersToUrl
  L5_2 = L2_2
  L4_2 = L4_2(L5_2)
  L3_2 = L3_2 .. L4_2
  return L3_2
end

L3_1.buildAdUrl = L4_1

function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = require
  L1_2 = "crypto"
  L0_2 = L0_2(L1_2)
  L1_2 = {}
  L2_2 = L2_1
  if L2_2 == "Android" then
    L2_2 = system
    L2_2 = L2_2.getInfo
    L3_2 = "deviceID"
    L2_2 = L2_2(L3_2)
    L3_2 = L0_1
    L3_2 = L3_2.isValidString
    L4_2 = L2_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      L3_2 = L0_2.digest
      L4_2 = L0_2.sha1
      L5_2 = string
      L5_2 = L5_2.lower
      L6_2 = L2_2
      L3_2 = L3_2(L4_2, L5_2(L6_2))
      L1_2.hudid = L3_2
    end
  else
    L2_2 = L2_1
    if L2_2 == "iPhone OS" then
      L2_2 = system
      L2_2 = L2_2.getInfo
      L3_2 = "iosAdvertisingIdentifier"
      L2_2 = L2_2(L3_2)
      L3_2 = L0_1
      L3_2 = L3_2.isValidString
      L4_2 = L2_2
      L3_2 = L3_2(L4_2)
      if L3_2 then
        L3_2 = L0_2.digest
        L4_2 = L0_2.sha1
        L5_2 = string
        L5_2 = L5_2.lower
        L6_2 = L2_2
        L3_2 = L3_2(L4_2, L5_2(L6_2))
        L1_2.hadid = L3_2
        L1_2.adid = L2_2
      end
    end
  end
  L2_2 = system
  L2_2 = L2_2.getInfo
  L3_2 = "model"
  L2_2 = L2_2(L3_2)
  L3_2 = L0_1
  L3_2 = L3_2.isValidString
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if L3_2 then
    L1_2.model = L2_2
  end
  L3_2 = system
  L3_2 = L3_2.getInfo
  L4_2 = "platformVersion"
  L3_2 = L3_2(L4_2)
  L4_2 = L0_1
  L4_2 = L4_2.isValidString
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  if L4_2 then
    L1_2.os = L3_2
  end
  L4_2 = L0_1
  L4_2 = L4_2.isValidString
  L5_2 = L2_1
  L4_2 = L4_2(L5_2)
  if L4_2 then
    L4_2 = L2_1
    if L4_2 == "Android" then
      L1_2.type = "android"
      L1_2.platform = "android"
    else
      L4_2 = L2_1
      if L4_2 == "iPhone OS" then
        L1_2.type = "ios"
        L1_2.platform = "ios"
      end
    end
  end
  L4_2 = system
  L4_2 = L4_2.getPreference
  L5_2 = "locale"
  L6_2 = "identifier"
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = L0_1
  L5_2 = L5_2.isValidString
  L6_2 = L4_2
  L5_2 = L5_2(L6_2)
  if L5_2 then
    L1_2.locale = L4_2
  end
  return L1_2
end

L3_1.getDeviceInfo = L4_1

function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = ""
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2 = L2_2(L3_2)
  for L5_2, L6_2 in L2_2, L3_2, L4_2 do
    L7_2 = string
    L7_2 = L7_2.len
    L8_2 = L1_2
    L7_2 = L7_2(L8_2)
    if 0 < L7_2 then
      L7_2 = L1_2
      L8_2 = "&"
      L9_2 = L5_2
      L10_2 = "="
      L11_2 = L0_1
      L11_2 = L11_2.urlEncode
      L12_2 = L6_2
      L11_2 = L11_2(L12_2)
      L1_2 = L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2
    else
      L7_2 = L1_2
      L8_2 = "?"
      L9_2 = L5_2
      L10_2 = "="
      L11_2 = L0_1
      L11_2 = L11_2.urlEncode
      L12_2 = L6_2
      L11_2 = L11_2(L12_2)
      L1_2 = L7_2 .. L8_2 .. L9_2 .. L10_2 .. L11_2
    end
  end
  return L1_2
end

L3_1.parametersToUrl = L4_1

function L4_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  if A0_2 then
    L1_2 = string
    L1_2 = L1_2.gsub
    L2_2 = A0_2
    L3_2 = "\n"
    L4_2 = "\r\n"
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    A0_2 = L1_2
    L1_2 = string
    L1_2 = L1_2.gsub
    L2_2 = A0_2
    L3_2 = "([^%w ])"
    
    function L4_2(A0_3)
      local L1_3, L2_3, L3_3, L4_3
      L1_3 = string
      L1_3 = L1_3.format
      L2_3 = "%%%02X"
      L3_3 = string
      L3_3 = L3_3.byte
      L4_3 = A0_3
      return L1_3(L2_3, L3_3(L4_3))
    end
    
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    A0_2 = L1_2
    L1_2 = string
    L1_2 = L1_2.gsub
    L2_2 = A0_2
    L3_2 = " "
    L4_2 = "+"
    L1_2 = L1_2(L2_2, L3_2, L4_2)
    A0_2 = L1_2
  end
  return A0_2
end

L3_1.urlEncode = L4_1

function L4_1(A0_2)
  local L1_2, L2_2
  if A0_2 ~= nil then
    L1_2 = string
    L1_2 = L1_2.len
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 ~= 0 then
      goto lbl_11
    end
  end
  L1_2 = false
  do return L1_2 end
  ::lbl_11::
  L1_2 = true
  return L1_2
end

L3_1.isValidString = L4_1

function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = require
  L1_2 = "json"
  L0_2 = L0_2(L1_2)
  L1_2 = require
  L2_2 = "crypto"
  L1_2 = L1_2(L2_2)
  L2_2 = {}
  L3_2 = L0_1
  L3_2 = L3_2.getDeviceInfo
  L3_2 = L3_2()
  L2_2.device_info = L3_2
  L3_2 = {}
  L3_2.created_at = 0
  L4_2 = L2_1
  if L4_2 == "Android" then
    L4_2 = AppLovinConfig
    L4_2 = L4_2.android_package
    L3_2.package_name = L4_2
    L4_2 = AppLovinConfig
    L4_2 = L4_2.android_package
    L3_2.app_name = L4_2
  else
    L4_2 = L2_1
    if L4_2 == "iPhone OS" then
      L4_2 = AppLovinConfig
      L4_2 = L4_2.ios_package
      L3_2.package_name = L4_2
      L4_2 = AppLovinConfig
      L4_2 = L4_2.ios_package
      L3_2.app_name = L4_2
    end
  end
  L4_2 = L0_1
  L4_2 = L4_2.version
  L3_2.applovin_sdk_version = L4_2
  L2_2.app_info = L3_2
  L4_2 = {}
  L5_2 = L0_2.encode
  L6_2 = L2_2
  L5_2 = L5_2(L6_2)
  L4_2.body = L5_2
  L5_2 = L0_1
  L5_2 = L5_2.dendpoint
  L6_2 = "?api_key="
  L7_2 = AppLovinConfig
  L7_2 = L7_2.sdk_key
  L5_2 = L5_2 .. L6_2 .. L7_2
  L6_2 = network
  L6_2 = L6_2.request
  L7_2 = L5_2
  L8_2 = "POST"
  L9_2 = L0_1
  L9_2 = L9_2.initResponseListener
  L10_2 = L4_2
  L6_2(L7_2, L8_2, L9_2, L10_2)
  L6_2 = L0_1
  L6_2 = L6_2.log
  L7_2 = "Sending POST request to "
  L8_2 = L5_2
  L9_2 = ". Request is: "
  L10_2 = L0_2.encode
  L11_2 = L4_2.body
  L10_2 = L10_2(L11_2)
  L7_2 = L7_2 .. L8_2 .. L9_2 .. L10_2
  L6_2(L7_2)
end

L3_1.initializeSdk = L4_1

function L4_1(A0_2)
  local L1_2, L2_2, L3_2
  if A0_2 then
    L1_2 = A0_2.isError
    if not L1_2 then
      goto lbl_11
    end
  end
  L1_2 = L0_1
  L1_2 = L1_2.log
  L2_2 = "Initialize POST failure..."
  L1_2(L2_2)
  goto lbl_30
  ::lbl_11::
  L1_2 = L0_1
  L1_2 = L1_2.log
  L2_2 = "Init Response: "
  L3_2 = A0_2.response
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
  L1_2 = string
  L1_2 = L1_2.find
  L2_2 = A0_2.response
  L3_2 = "event_id"
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L1_2 = L0_1
    L1_2 = L1_2.log
    L2_2 = "Initialize successful"
    L1_2(L2_2)
    L1_2 = L0_1
    L1_2.initialized = true
  end
  ::lbl_30::
end

L3_1.initResponseListener = L4_1

function L4_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = L1_1
  if L1_2 then
    L1_2 = print
    L2_2 = "[AppLovinCorona] "
    L3_2 = A0_2
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
end

L3_1.log = L4_1

function L4_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L3_2 = A0_2
  L2_2 = A0_2.find
  L4_2 = "market://"
  L2_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    L3_2 = A0_2
    L2_2 = A0_2.find
    L4_2 = "itunes.apple.com"
    L2_2 = L2_2(L3_2, L4_2)
    if not L2_2 then
      goto lbl_34
    end
  end
  L2_2 = L1_1
  if L2_2 then
    L2_2 = log
    L2_2 = L2_2.show
    L3_2 = "safeOpenUrl ignoring"
    L2_2(L3_2)
  end
  L2_2 = L1_1
  if L2_2 then
    L2_2 = log
    L2_2 = L2_2.show
    L4_2 = A0_2
    L3_2 = A0_2.sub
    L5_2 = 1
    L6_2 = 35
    L2_2(L3_2(L4_2, L5_2, L6_2))
  end
  L2_2 = print
  L3_2 = "[AppLovinCorona] ... Ignoring direct app store invocation: "
  L4_2 = A0_2
  L3_2 = L3_2 .. L4_2
  L2_2(L3_2)
  goto lbl_100
  ::lbl_34::
  L2_2 = A1_2.clicked
  if not L2_2 then
    L2_2 = L1_1
    if L2_2 then
      L2_2 = log
      L2_2 = L2_2.show
      L3_2 = "safeOpenUrl opening"
      L2_2(L3_2)
    end
    L2_2 = L1_1
    if L2_2 then
      L2_2 = log
      L2_2 = L2_2.show
      L4_2 = A0_2
      L3_2 = A0_2.sub
      L5_2 = 1
      L6_2 = 35
      L2_2(L3_2(L4_2, L5_2, L6_2))
    end
    L2_2 = print
    L3_2 = "[AppLovinCorona] ... Opening URL: "
    L4_2 = A0_2
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
    A1_2.clicked = true
    A1_2.alpha = 0
    L2_2 = _app_lovin_disable_going_to_store
    if not L2_2 then
      L2_2 = system
      L2_2 = L2_2.openURL
      L3_2 = A0_2
      L2_2(L3_2)
    end
    L2_2 = Runtime
    L3_2 = L2_2
    L2_2 = L2_2.dispatchEvent
    L4_2 = {}
    L4_2.name = "adEvent"
    L4_2.phase = "clicked"
    L2_2(L3_2, L4_2)
    L2_2 = ltv
    L2_2 = L2_2.recordAdClick
    L2_2()
  else
    L2_2 = L1_1
    if L2_2 then
      L2_2 = log
      L2_2 = L2_2.show
      L3_2 = "safeOpenUrl duplicate"
      L2_2(L3_2)
    end
    L2_2 = L1_1
    if L2_2 then
      L2_2 = log
      L2_2 = L2_2.show
      L4_2 = A0_2
      L3_2 = A0_2.sub
      L5_2 = 1
      L6_2 = 35
      L2_2(L3_2(L4_2, L5_2, L6_2))
    end
    L2_2 = print
    L3_2 = "[AppLovinCorona] ... Ignoring duplicate click request: "
    L4_2 = A0_2
    L3_2 = L3_2 .. L4_2
    L2_2(L3_2)
  end
  ::lbl_100::
end

L3_1.safeOpenUrl = L4_1
L0_1 = L3_1
L3_1 = {}

function L4_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L3_2 = L0_1
  L3_2 = L3_2.initialized
  if not L3_2 then
    L3_2 = L0_1
    L3_2 = L3_2.initializeSdk
    L3_2()
  end
  if not A0_2 or A0_2 ~= "BANNER" and A0_2 ~= "INTER" then
    L3_2 = L0_1
    L3_2 = L3_2.log
    L4_2 = "Invalid Ad Size Passed."
    L3_2(L4_2)
    return
  end
  L3_2 = A1_2
  L4_2 = A2_2
  L5_2 = 0
  L6_2 = 50
  L7_2 = false
  if A0_2 == "BANNER" then
    L8_2 = display
    L8_2 = L8_2.contentWidth
    L9_2 = display
    L9_2 = L9_2.contentHeight
    if L8_2 > L9_2 then
      L8_2 = display
      L8_2 = L8_2.viewableContentHeight
      L9_2 = display
      L9_2 = L9_2.screenOriginY
      L9_2 = L9_2 * 2
      L9_2 = -1 * L9_2
      L5_2 = L8_2 + L9_2
    else
      L8_2 = display
      L8_2 = L8_2.viewableContentWidth
      L9_2 = display
      L9_2 = L9_2.screenOriginX
      L9_2 = L9_2 * 2
      L9_2 = -1 * L9_2
      L5_2 = L8_2 + L9_2
    end
    L8_2 = L0_1
    L8_2 = L8_2.POSITION_TOP
    if A2_2 == L8_2 then
      L4_2 = 0
    else
      L8_2 = L0_1
      L8_2 = L8_2.POSITION_BOTTOM
      if A2_2 == L8_2 then
        L8_2 = display
        L8_2 = L8_2.contentHeight
        L4_2 = L8_2 - L6_2
      end
    end
    L8_2 = L0_1
    L8_2 = L8_2.POSITION_LEFT
    if A1_2 == L8_2 then
      L3_2 = 0
    else
      L8_2 = L0_1
      L8_2 = L8_2.POSITION_RIGHT
      if A1_2 == L8_2 then
        L8_2 = display
        L8_2 = L8_2.contentWidth
        L3_2 = L8_2 - L5_2
      else
        L8_2 = L0_1
        L8_2 = L8_2.POSITION_CENTER
        if A1_2 == L8_2 then
          L8_2 = display
          L8_2 = L8_2.contentWidth
          L8_2 = L8_2 / 2
          L9_2 = L5_2 / 2
          L3_2 = L8_2 - L9_2
        end
      end
    end
  elseif A0_2 == "INTER" then
    L8_2 = display
    L8_2 = L8_2.viewableContentWidth
    L9_2 = display
    L9_2 = L9_2.screenOriginX
    L9_2 = L9_2 * 2
    L9_2 = -1 * L9_2
    L5_2 = L8_2 + L9_2
    L8_2 = display
    L8_2 = L8_2.viewableContentHeight
    L9_2 = display
    L9_2 = L9_2.screenOriginY
    L9_2 = L9_2 * 2
    L9_2 = -1 * L9_2
    L6_2 = L8_2 + L9_2
  end
  L8_2 = native
  L8_2 = L8_2.newWebView
  L9_2 = L3_2
  L10_2 = L4_2
  L11_2 = L5_2
  L12_2 = L6_2
  L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2)
  L9_2 = _W2
  L10_2 = _H2
  L8_2.y = L10_2
  L8_2.x = L9_2
  L8_2.hasBackground = false
  L8_2.applovin_size = A0_2
  
  function L9_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = L8_2
    L0_3 = L0_3.keyListener
    if L0_3 then
      L0_3 = Runtime
      L1_3 = L0_3
      L0_3 = L0_3.removeEventListener
      L2_3 = "key"
      L3_3 = L8_2
      L3_3 = L3_3.keyListener
      L0_3(L1_3, L2_3, L3_3)
      L0_3 = L8_2
      L0_3.keyListener = nil
    end
    L0_3 = L8_2
    L0_3.adURL = nil
    L0_3 = L8_2
    L1_3 = L0_3
    L0_3 = L0_3.removeEventListener
    L2_3 = "urlRequest"
    L3_3 = L8_2
    L3_3 = L3_3.webviewListener
    L0_3(L1_3, L2_3, L3_3)
    L0_3 = L8_2
    L0_3 = L0_3.frontTimer
    if L0_3 then
      L0_3 = timer
      L0_3 = L0_3.cancel
      L1_3 = L8_2
      L1_3 = L1_3.frontTimer
      L0_3(L1_3)
    end
    L0_3 = L8_2
    L0_3 = L0_3.disobj_alexCloseText
    if L0_3 then
      L0_3 = L8_2
      L0_3 = L0_3.disobj_alexCloseText
      L0_3 = L0_3.fadeInTransition
      if L0_3 then
        L0_3 = transition
        L0_3 = L0_3.cancel
        L1_3 = L8_2
        L1_3 = L1_3.disobj_alexCloseText
        L1_3 = L1_3.fadeInTransition
        L0_3(L1_3)
      end
    end
    L0_3 = L8_2
    L0_3 = L0_3.disobj_dimOverlay
    if L0_3 then
      L0_3 = L8_2
      L0_3 = L0_3.disobj_dimOverlay
      L1_3 = L0_3
      L0_3 = L0_3.removeSelf
      L0_3(L1_3)
    end
    L0_3 = L8_2
    L0_3 = L0_3.disobj_alexCloseText
    if L0_3 then
      L0_3 = L8_2
      L0_3 = L0_3.disobj_alexCloseText
      L1_3 = L0_3
      L0_3 = L0_3.removeSelf
      L0_3(L1_3)
    end
    L0_3 = L8_2
    L1_3 = L0_3
    L0_3 = L0_3.removeSelf
    L0_3(L1_3)
    L0_3 = nil
    L8_2 = L0_3
  end
  
  L8_2.remove = L9_2
  if A0_2 == "INTER" then
    function L9_2(A0_3)
      local L1_3
      
      L1_3 = A0_3.keyName
      if L1_3 == "back" then
        L1_3 = L8_2
        L1_3 = L1_3.isVisible
        if L1_3 then
          L1_3 = L8_2
          L1_3 = L1_3.remove
          L1_3()
          L1_3 = true
          return L1_3
        end
      end
      L1_3 = false
      return L1_3
    end
    
    L8_2.keyListener = L9_2
    L9_2 = Runtime
    L10_2 = L9_2
    L9_2 = L9_2.addEventListener
    L11_2 = "key"
    L12_2 = L8_2.keyListener
    L9_2(L10_2, L11_2, L12_2)
  end
  L9_2 = applovin_adviewCount
  L9_2 = L9_2 + 1
  applovin_adviewCount = L9_2
  L9_2 = L0_1
  L9_2 = L9_2.cached_file
  L10_2 = "_"
  L11_2 = applovin_adviewCount
  L12_2 = ".html"
  L9_2 = L9_2 .. L10_2 .. L11_2 .. L12_2
  L8_2.cached_file = L9_2
  
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L1_3 = A0_3.isError
    if L1_3 then
      L1_3 = L1_1
      if L1_3 then
        L1_3 = log
        L1_3 = L1_3.show
        L2_3 = "ERROR in cacheAdHTML"
        L1_3(L2_3)
      end
      L1_3 = print
      L2_3 = "ERROR in cacheAdHTML"
      L1_3(L2_3)
    else
      L1_3 = A0_3.phase
      if L1_3 == "ended" then
        L1_3 = L8_2
        L1_3.clicked = false
        L1_3 = A0_2
        if L1_3 == "INTER" then
          L1_3 = nil
          L2_3 = nil
          L3_3 = nil
          L4_3 = L1_1
          if L4_3 then
            L4_3 = system
            L4_3 = L4_3.pathForFile
            L5_3 = L8_2
            L5_3 = L5_3.cached_file
            L6_3 = system
            L6_3 = L6_3.TemporaryDirectory
            L4_3 = L4_3(L5_3, L6_3)
            L5_3 = io
            L5_3 = L5_3.open
            L6_3 = L4_3
            L7_3 = "r"
            L5_3 = L5_3(L6_3, L7_3)
            L6_3 = nil
            if L5_3 then
              L8_3 = L5_3
              L7_3 = L5_3.read
              L9_3 = "*a"
              L7_3 = L7_3(L8_3, L9_3)
              L6_3 = L7_3
              if L6_3 then
                L7_3 = log
                L7_3 = L7_3.show
                L9_3 = L6_3
                L8_3 = L6_3.sub
                L10_3 = 1
                L11_3 = 35
                L7_3(L8_3(L9_3, L10_3, L11_3))
              end
            end
          end
          L4_3 = L8_2
          L5_3 = L4_3
          L4_3 = L4_3.request
          L6_3 = L8_2
          L6_3 = L6_3.cached_file
          L7_3 = system
          L7_3 = L7_3.TemporaryDirectory
          L4_3(L5_3, L6_3, L7_3)
          L4_3 = L8_2
          if L4_3 then
            L4_3 = settings
            L4_3 = L4_3.t
            L4_3 = L4_3.applovin_use_easier_to_close_native_display
            if L4_3 then
              L4_3 = L8_2
              L5_3 = display
              L5_3 = L5_3.newRect
              L6_3 = screenLeft
              L7_3 = screenTop
              L8_3 = screenWidth
              L9_3 = screenHeight
              L5_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
              L4_3.disobj_dimOverlay = L5_3
              L4_3 = L8_2
              L4_3 = L4_3.disobj_dimOverlay
              L5_3 = L4_3
              L4_3 = L4_3.setFillColor
              L6_3 = 0
              L7_3 = 0
              L8_3 = 0
              L9_3 = 255
              L4_3(L5_3, L6_3, L7_3, L8_3, L9_3)
              L4_3 = L8_2
              L4_3 = L4_3.disobj_dimOverlay
              
              function L5_3(A0_4, A1_4)
                local L2_4
                L2_4 = L8_2
                if L2_4 then
                  L2_4 = L8_2
                  L2_4 = L2_4.remove
                  L2_4()
                end
                L2_4 = true
                return L2_4
              end
              
              L4_3.touch = L5_3
              L4_3 = L8_2
              L4_3 = L4_3.disobj_dimOverlay
              L5_3 = L4_3
              L4_3 = L4_3.addEventListener
              L6_3 = "touch"
              L7_3 = L8_2
              L7_3 = L7_3.disobj_dimOverlay
              L4_3(L5_3, L6_3, L7_3)
              L4_3 = L1_1
              if L4_3 then
                L4_3 = log
                L4_3 = L4_3.show
                L5_3 = "drawing big close button"
                L4_3(L5_3)
              end
              L4_3 = L8_2
              L5_3 = display
              L5_3 = L5_3.newImageRect
              L6_3 = "images/_close_ad_422x128.png"
              L7_3 = 105.5
              L8_3 = 32
              L5_3 = L5_3(L6_3, L7_3, L8_3)
              L4_3.disobj_alexCloseText = L5_3
              L4_3 = L8_2
              L4_3 = L4_3.disobj_alexCloseText
              L5_3 = L8_2
              L5_3 = L5_3.disobj_alexCloseText
              L6_3 = 0.5
              L5_3.anchorY = 0
              L4_3.anchorX = L6_3
              L4_3 = L8_2
              L4_3 = L4_3.disobj_alexCloseText
              L5_3 = L8_2
              L5_3 = L5_3.disobj_alexCloseText
              L6_3 = _W2
              L7_3 = screenTop
              L7_3 = L7_3 + 3
              L5_3.y = L7_3
              L4_3.x = L6_3
              L4_3 = L8_2
              L4_3 = L4_3.disobj_alexCloseText
              L4_3.alpha = 0
              L4_3 = L8_2
              L4_3 = L4_3.disobj_alexCloseText
              L5_3 = transition
              L5_3 = L5_3.to
              L6_3 = L8_2
              L6_3 = L6_3.disobj_alexCloseText
              L7_3 = {}
              L7_3.delay = 1500
              L7_3.time = 2000
              L7_3.alpha = 0.8
              L5_3 = L5_3(L6_3, L7_3)
              L4_3.fadeInTransition = L5_3
              L4_3 = L8_2
              L5_3 = L8_2
              L6_3 = _W2
              L7_3 = _H2
              L7_3 = L7_3 + 36
              L5_3.y = L7_3
              L4_3.x = L6_3
              L4_3 = L8_2
              L4_3.xScale = 0.925
              L4_3 = L8_2
              L4_3.yScale = 0.925
              
              function L4_3()
                local L0_4, L1_4
                L0_4 = L8_2
                if L0_4 then
                  L0_4 = L8_2
                  L0_4 = L0_4.disobj_dimOverlay
                  if L0_4 then
                    L0_4 = L8_2
                    L0_4 = L0_4.disobj_dimOverlay
                    L1_4 = L0_4
                    L0_4 = L0_4.toFront
                    L0_4(L1_4)
                  end
                end
                L0_4 = L8_2
                if L0_4 then
                  L0_4 = L8_2
                  L0_4 = L0_4.disobj_alexCloseText
                  if L0_4 then
                    L0_4 = L8_2
                    L0_4 = L0_4.disobj_alexCloseText
                    L1_4 = L0_4
                    L0_4 = L0_4.toFront
                    L0_4(L1_4)
                  end
                end
              end
              
              L5_3 = L8_2
              L6_3 = timer
              L6_3 = L6_3.performWithDelay
              L7_3 = 300
              L8_3 = L4_3
              L9_3 = -1
              L6_3 = L6_3(L7_3, L8_3, L9_3)
              L5_3.frontTimer = L6_3
            end
          end
        end
        L1_3 = A0_2
        if L1_3 == "BANNER" then
          L1_3 = L8_2
          L1_3.alpha = 1
          L1_3 = L8_2
          L2_3 = L1_3
          L1_3 = L1_3.request
          L3_3 = L8_2
          L3_3 = L3_3.cached_file
          L4_3 = system
          L4_3 = L4_3.TemporaryDirectory
          L1_3(L2_3, L3_3, L4_3)
        end
      end
    end
  end
  
  L8_2.cacheAdHTML = L9_2
  
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = A0_3.url
    if not L1_3 then
      L1_3 = "nil"
    end
    L2_3 = L1_1
    if L2_3 then
      L2_3 = log
      L2_3 = L2_3.show
      L3_3 = "webview.webviewListener()"
      L2_3(L3_3)
    end
    L2_3 = L1_1
    if L2_3 then
      L2_3 = log
      L2_3 = L2_3.show
      L4_3 = L1_3
      L3_3 = L1_3.sub
      L5_3 = 1
      L6_3 = 35
      L2_3(L3_3(L4_3, L5_3, L6_3))
    end
    L2_3 = A0_3.errorCode
    if L2_3 then
      L2_3 = L1_1
      if L2_3 then
        L2_3 = log
        L2_3 = L2_3.show
        L3_3 = "errorCode "
        L4_3 = A0_3.errorCode
        L3_3 = L3_3 .. L4_3
        L2_3(L3_3)
      end
      L2_3 = L1_1
      if L2_3 then
        L2_3 = log
        L2_3 = L2_3.show
        L3_3 = "errorMessage "
        L4_3 = A0_3.errorMessage
        L3_3 = L3_3 .. L4_3
        L2_3(L3_3)
      end
      L2_3 = L8_2
      L2_3 = L2_3.applovin_size
      if L2_3 == "INTER" then
        L2_3 = L8_2
        L2_3 = L2_3.remove
        L2_3()
      end
      return
    end
    L2_3 = string
    L2_3 = L2_3.find
    L3_3 = A0_3.url
    L4_3 = "applovin://com.applovin.sdk/adservice/close_ad"
    L2_3 = L2_3(L3_3, L4_3)
    if L2_3 then
      L2_3 = L8_2
      L2_3 = L2_3.applovin_size
      if L2_3 == "INTER" then
        L2_3 = L1_1
        if L2_3 then
          L2_3 = log
          L2_3 = L2_3.show
          L3_3 = "native: user hit close"
          L2_3(L3_3)
        end
        L2_3 = Runtime
        L3_3 = L2_3
        L2_3 = L2_3.dispatchEvent
        L4_3 = {}
        L4_3.name = "adEvent"
        L4_3.type = "interstitial"
        L4_3.phase = "closed"
        L2_3(L3_3, L4_3)
        L2_3 = L8_2
        L2_3 = L2_3.remove
        L2_3()
        return
    end
    else
      L2_3 = L8_2
      L2_3 = L2_3.adURL
      L3_3 = A0_3.url
      if L2_3 ~= L3_3 then
        L2_3 = string
        L2_3 = L2_3.find
        L3_3 = A0_3.url
        L4_3 = "file://"
        L2_3 = L2_3(L3_3, L4_3)
        if not L2_3 then
          L2_3 = print
          L3_3 = "webview.adURL, event.url"
          L4_3 = L8_2
          L4_3 = L4_3.adURL
          L5_3 = A0_3.url
          L2_3(L3_3, L4_3, L5_3)
          L2_3 = L1_1
          if L2_3 then
            L2_3 = log
            L2_3 = L2_3.show
            L3_3 = "native: user clicked ad"
            L2_3(L3_3)
          end
          L2_3 = L0_1
          L2_3 = L2_3.safeOpenUrl
          L3_3 = A0_3.url
          L4_3 = L8_2
          L2_3(L3_3, L4_3)
          L2_3 = L8_2
          L2_3 = L2_3.applovin_size
          if L2_3 == "INTER" then
            L2_3 = L8_2
            L2_3 = L2_3.remove
            L2_3()
          end
          return
        end
      end
    end
    L2_3 = L8_2
    if L2_3 then
      L2_3 = string
      L2_3 = L2_3.find
      L3_3 = A0_3.url
      L4_3 = "applovin://com.applovin.sdk/adservice/close_ad"
      L2_3 = L2_3(L3_3, L4_3)
      if not L2_3 then
        L2_3 = L1_1
        if L2_3 then
          L2_3 = log
          L2_3 = L2_3.show
          L3_3 = "native: ad shown"
          L2_3(L3_3)
        end
        L2_3 = Runtime
        L3_3 = L2_3
        L2_3 = L2_3.dispatchEvent
        L4_3 = {}
        L4_3.name = "adEvent"
        L4_3.type = "interstitial"
        L4_3.phase = "opened"
        L2_3(L3_3, L4_3)
        L2_3 = _SIMULATOR
        if L2_3 then
          L2_3 = L8_2
          L2_3 = L2_3.remove
          L2_3()
        end
      end
    end
  end
  
  L8_2.webviewListener = L9_2
  
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3
    L1_3 = L0_1
    L1_3 = L1_3.handleAdResponse
    L2_3 = A0_3
    L3_3 = L8_2
    L3_3 = L3_3.cached_file
    L4_3 = L8_2
    L5_3 = A0_2
    L1_3(L2_3, L3_3, L4_3, L5_3)
  end
  
  L8_2.adResponseListener = L9_2
  L10_2 = L8_2
  L9_2 = L8_2.addEventListener
  L11_2 = "urlRequest"
  L12_2 = L8_2.webviewListener
  L9_2(L10_2, L11_2, L12_2)
  
  function L9_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = L0_1
    L1_3 = L1_3.log
    L2_3 = "Loading next ad of size "
    L3_3 = A0_3.applovin_size
    L2_3 = L2_3 .. L3_3
    L1_3(L2_3)
    L1_3 = network
    L1_3 = L1_3.request
    L2_3 = L0_1
    L2_3 = L2_3.buildAdUrl
    L3_3 = A0_3.applovin_size
    L2_3 = L2_3(L3_3)
    L3_3 = "GET"
    L4_3 = A0_3.adResponseListener
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = L0_1
    L1_3 = L1_3.log
    L2_3 = "Sending GET request to "
    L3_3 = L0_1
    L3_3 = L3_3.buildAdUrl
    L4_3 = A0_3.applovin_size
    L3_3 = L3_3(L4_3)
    L4_3 = "."
    L2_3 = L2_3 .. L3_3 .. L4_3
    L1_3(L2_3)
  end
  
  L8_2.loadNextAd = L9_2
  
  function L9_2(A0_3)
    local L1_3, L2_3
    L1_3 = L8_2
    L2_3 = L1_3
    L1_3 = L1_3.loadNextAd
    L1_3(L2_3)
  end
  
  timeTrigger = L9_2
  L9_2 = L8_2.applovin_size
  if L9_2 == "BANNER" then
    L9_2 = timer
    L9_2 = L9_2.performWithDelay
    L10_2 = 60000
    L11_2 = timerTrigger
    L12_2 = 0
    L9_2(L10_2, L11_2, L12_2)
  end
  return L8_2
end

L3_1.init = L4_1
AppLovinAdView = L3_1
L3_1 = applovin_adviewCount
if not L3_1 then
  L3_1 = 0
  applovin_adviewCount = L3_1
end
return L0_1
