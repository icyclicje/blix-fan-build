local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1, L22_1, L23_1, L24_1, L25_1, L26_1, L27_1, L28_1, L29_1, L30_1, L31_1, L32_1, L33_1
L0_1 = {}
L1_1 = require
L2_1 = "facebook"
L1_1 = L1_1(L2_1)
L2_1 = require
L3_1 = "json"
L2_1 = L2_1(L3_1)
L3_1 = false
if L3_1 then
  L4_1 = log
  L4_1 = L4_1.show
  L5_1 = "_fb_utils.lua DEBUGGING"
  L4_1(L5_1)
end
L4_1 = {}
L5_1 = "publish_actions"
L6_1 = "read_friendlists"
L4_1[1] = L5_1
L4_1[2] = L6_1
L5_1 = {}
L6_1 = "publish_actions"
L5_1[1] = L6_1
L4_1 = L5_1
L5_1 = {}
L4_1 = L5_1
L5_1 = "http://bonfiremedia.com/"
L6_1 = APP_ID
L7_1 = "_fb_fan_page.jsp"
L5_1 = L5_1 .. L6_1 .. L7_1
_FB_FAN_PAGE_URL = L5_1
L5_1 = "http://bonfiremedia.com/universal_download.jsp?id="
L6_1 = APP_ID
L5_1 = L5_1 .. L6_1
L6_1 = APP_ONLINE_ICON
L7_1 = APP_NAME
L8_1 = sharing
L8_1 = L8_1.title
L9_1 = "Try the new hit game "
L10_1 = APP_NAME
L9_1 = L9_1 .. L10_1
L10_1 = sharing
L10_1 = L10_1.message
L11_1 = nil
L12_1 = false
L13_1 = false
L14_1 = 0
L15_1 = 0
L16_1 = 1
L17_1 = 2
L18_1 = 3
L19_1 = 4
L20_1 = 5

function L21_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2
  L3_2 = L11_1
  L3_2.fbCurrentCommand = A0_2
  L3_2 = L11_1
  L3_2.fbCurrentParams = A1_2
  L3_2 = L11_1
  L4_2 = A2_2 or L4_2
  if not A2_2 then
    L4_2 = "feed"
  end
  L3_2.fbCurrentDialogMethod = L4_2
  L3_2 = L11_1
  L4_2 = os
  L4_2 = L4_2.time
  L4_2 = L4_2()
  L3_2.fbLastCommandSetTime = L4_2
  L3_2 = saver
  L3_2 = L3_2.Save
  L4_2 = L11_1
  L5_2 = "fb.txt"
  L3_2(L4_2, L5_2)
end

L22_1 = nil
L23_1 = nil
L24_1 = saver
L24_1 = L24_1.Load
L25_1 = "fb.txt"
L24_1 = L24_1(L25_1)
L11_1 = L24_1 or L11_1
if not L24_1 then
  L24_1 = {}
  L11_1 = L24_1
end
L24_1 = L11_1.fbCurrentCommand
if not L24_1 then
  L11_1.fbCurrentCommand = L15_1
end
L24_1 = L11_1.fbCurrentDialogMethod
if not L24_1 then
  L11_1.fbCurrentDialogMethod = "feed"
end
L24_1 = L11_1.fbCurrentParams
if not L24_1 then
  L24_1 = {}
  L11_1.fbCurrentParams = L24_1
end
L24_1 = L11_1.fbNumStartup
if not L24_1 then
  L11_1.fbNumStartup = 0
end
L24_1 = L11_1.fbNumLogin
if not L24_1 then
  L11_1.fbNumLogin = 0
end
L24_1 = L11_1.fbNumDialogFeed
if not L24_1 then
  L11_1.fbNumDialogFeed = 0
end
L24_1 = L11_1.fbNumPostInstant
if not L24_1 then
  L11_1.fbNumPostInstant = 0
end
L24_1 = L11_1.fbNumPhotoUpload
if not L24_1 then
  L11_1.fbNumPhotoUpload = 0
end
L24_1 = L11_1.fbUploadedToServer
if not L24_1 then
  L11_1.fbUploadedToServer = false
end
L24_1 = L11_1.friends_with_app
if not L24_1 then
  L11_1.friends_with_app = 0
end
L24_1 = L11_1.fb_id
if L24_1 then
  L24_1 = string
  L24_1 = L24_1.format
  L25_1 = "%.0f"
  L26_1 = L11_1.fb_id
  L24_1 = L24_1(L25_1, L26_1)
  L11_1.fb_id = L24_1
end
L24_1 = L11_1.fbNumStartup
L24_1 = L24_1 + 1
L11_1.fbNumStartup = L24_1
L24_1 = saver
L24_1 = L24_1.Save
L25_1 = L11_1
L26_1 = "fb.txt"
L24_1(L25_1, L26_1)
L24_1 = L11_1.fbLastCommandSetTime
if L24_1 then
  L24_1 = os
  L24_1 = L24_1.time
  L24_1 = L24_1()
  L25_1 = L11_1.fbLastCommandSetTime
  L24_1 = L24_1 - L25_1
  if 180 < L24_1 then
    L24_1 = L11_1.fbCurrentCommand
    if L24_1 then
      L24_1 = L11_1.fbCurrentCommand
      if L24_1 ~= L15_1 then
        L24_1 = L21_1
        L25_1 = L15_1
        L26_1 = {}
        L24_1(L25_1, L26_1)
      end
    end
  end
end

function L24_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = A0_2.isError
  if L1_2 then
    L1_2 = L3_1
    if L1_2 then
      L1_2 = print
      L2_2 = "uploadInfoToServerListener: Network error"
      L1_2(L2_2)
    end
    L1_2 = L3_1
    if L1_2 then
      L1_2 = log
      L1_2 = L1_2.show
      L2_2 = "uploadInfoToServerListener isError"
      L3_2 = {}
      L4_2 = red
      L3_2.textColor = L4_2
      L1_2(L2_2, L3_2)
    end
  else
    L1_2 = L2_1
    L1_2 = L1_2.decode
    L2_2 = A0_2.response
    L1_2 = L1_2(L2_2)
    if L1_2 then
      L2_2 = L1_2.status
      if L2_2 == 0 then
        L2_2 = L11_1
        L2_2.fbUploadedToServer = true
        L2_2 = L11_1
        L3_2 = L1_2.friends_with_app
        L2_2.friends_with_app = L3_2
        L2_2 = saver
        L2_2 = L2_2.Save
        L3_2 = L11_1
        L4_2 = "fb.txt"
        L2_2(L3_2, L4_2)
        L2_2 = L3_1
        if L2_2 then
          L2_2 = print
          L3_2 = "uploadInfoToServerListener: status = "
          L4_2 = L1_2.status
          L3_2 = L3_2 .. L4_2
          L2_2(L3_2)
        end
        L2_2 = L3_1
        if L2_2 then
          L2_2 = log
          L2_2 = L2_2.show
          L3_2 = "uploadInfoToServerListener status = 0, friends_with_app = "
          L4_2 = L11_1
          L4_2 = L4_2.friends_with_app
          L3_2 = L3_2 .. L4_2
          L4_2 = {}
          L5_2 = green
          L4_2.textColor = L5_2
          L2_2(L3_2, L4_2)
        end
    end
    else
      L2_2 = L3_1
      if L2_2 then
        L2_2 = log
        L2_2 = L2_2.show
        L3_2 = "uploadInfoToServerListener status = "
        L4_2 = L1_2.status
        L3_2 = L3_2 .. L4_2
        L4_2 = {}
        L5_2 = red
        L4_2.textColor = L5_2
        L2_2(L3_2, L4_2)
      end
    end
  end
end

function L25_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = ""
  L1_2 = L0_2
  L2_2 = "&faid="
  L3_2 = globals
  L3_2 = L3_2.FB_API_KEY
  L0_2 = L1_2 .. L2_2 .. L3_2
  L1_2 = L0_1
  L1_2 = L1_2.GetUserId
  L1_2 = L1_2()
  if L1_2 then
    L1_2 = L0_2
    L2_2 = "&fid="
    L3_2 = L0_1
    L3_2 = L3_2.GetUserId
    L3_2 = L3_2()
    L0_2 = L1_2 .. L2_2 .. L3_2
  end
  L1_2 = L11_1
  L1_2 = L1_2.fb_name
  if L1_2 then
    L1_2 = L0_2
    L2_2 = "&fn="
    L3_2 = utils
    L3_2 = L3_2.url_encode
    L4_2 = L11_1
    L4_2 = L4_2.fb_name
    L3_2 = L3_2(L4_2)
    L0_2 = L1_2 .. L2_2 .. L3_2
  end
  L1_2 = L11_1
  L1_2 = L1_2.fb_username
  if L1_2 then
    L1_2 = L0_2
    L2_2 = "&fun="
    L3_2 = utils
    L3_2 = L3_2.url_encode
    L4_2 = L11_1
    L4_2 = L4_2.fb_username
    L3_2 = L3_2(L4_2)
    L0_2 = L1_2 .. L2_2 .. L3_2
  end
  L1_2 = L11_1
  L1_2 = L1_2.fb_locale
  if L1_2 then
    L1_2 = L0_2
    L2_2 = "&floc="
    L3_2 = utils
    L3_2 = L3_2.url_encode
    L4_2 = L11_1
    L4_2 = L4_2.fb_locale
    L3_2 = L3_2(L4_2)
    L0_2 = L1_2 .. L2_2 .. L3_2
  end
  L1_2 = L11_1
  L1_2 = L1_2.fb_gender
  if L1_2 then
    L1_2 = L0_2
    L2_2 = "&fgen="
    L3_2 = utils
    L3_2 = L3_2.url_encode
    L4_2 = L11_1
    L4_2 = L4_2.fb_gender
    L3_2 = L3_2(L4_2)
    L0_2 = L1_2 .. L2_2 .. L3_2
  end
  L1_2 = L11_1
  L1_2 = L1_2.fb_access_token
  if L1_2 then
    L1_2 = L0_2
    L2_2 = "&ftok="
    L3_2 = utils
    L3_2 = L3_2.url_encode
    L4_2 = L11_1
    L4_2 = L4_2.fb_access_token
    L3_2 = L3_2(L4_2)
    L0_2 = L1_2 .. L2_2 .. L3_2
  end
  return L0_2
end

L0_1.generateFbParams = L25_1

function L25_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = L3_1
  if L0_2 then
    L0_2 = log
    L0_2 = L0_2.show
    L1_2 = "uploadInfoToServer() "
    L2_2 = L11_1
    L2_2 = L2_2.fb_id
    L1_2 = L1_2 .. L2_2
    L2_2 = {}
    L3_2 = yellow
    L2_2.textColor = L3_2
    L0_2(L1_2, L2_2)
  end
  L0_2 = {}
  L0_2["Accept-Language"] = "en-US"
  L0_2["Content-Type"] = "application/x-www-form-urlencoded"
  L1_2 = {}
  L1_2.headers = L0_2
  L1_2.body = "Command=Games_NewUser"
  L2_2 = L1_2.body
  L3_2 = L0_1
  L3_2 = L3_2.generateFbParams
  L3_2 = L3_2()
  L2_2 = L2_2 .. L3_2
  L1_2.body = L2_2
  L2_2 = L1_2.body
  L3_2 = "&"
  L4_2 = utils
  L4_2 = L4_2.getParametersForServer
  L4_2 = L4_2()
  L2_2 = L2_2 .. L3_2 .. L4_2
  L1_2.body = L2_2
  L2_2 = L3_1
  if L2_2 then
    L2_2 = print
    L3_2 = L1_2.body
    L2_2(L3_2)
  end
  L2_2 = network
  L2_2 = L2_2.request
  L3_2 = utils
  L3_2 = L3_2.getURL
  L4_2 = "POST"
  L3_2 = L3_2(L4_2)
  L4_2 = "POST"
  L5_2 = L24_1
  L6_2 = L1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
end

function L26_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = "https://graph.facebook.com/"
  L2_2 = L0_1
  L2_2 = L2_2.GetUserId
  L2_2 = L2_2()
  L3_2 = "/picture?width=300&height=300"
  L1_2 = L1_2 .. L2_2 .. L3_2
  L2_2 = L11_1
  L2_2 = L2_2.fb_access_token
  if L2_2 then
    L2_2 = L1_2
    L3_2 = "&access_token="
    L4_2 = L11_1
    L4_2 = L4_2.fb_access_token
    L1_2 = L2_2 .. L3_2 .. L4_2
  end
  L2_2 = network
  L2_2 = L2_2.download
  L3_2 = L1_2
  L4_2 = "GET"
  
  function L5_2(A0_3)
    local L1_3, L2_3
    L1_3 = L3_1
    if L1_3 then
      L1_3 = print
      L2_3 = A0_3
      L1_3(L2_3)
    end
    L1_3 = A0_2
    if L1_3 then
      L1_3 = A0_2
      L1_3()
    end
  end
  
  L6_2 = "me.jpg"
  L7_2 = system
  L7_2 = L7_2.DocumentsDirectory
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
end

function L27_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = L3_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "listener: event.type = "
    L3_2 = A0_2.type
    L2_2 = L2_2 .. L3_2
    L3_2 = {}
    L4_2 = yellow
    L3_2.textColor = L4_2
    L1_2(L2_2, L3_2)
  end
  L1_2 = A0_2.type
  if "session" == L1_2 then
    L1_2 = A0_2.phase
    if "login" == L1_2 then
      L1_2 = L3_1
      if L1_2 then
        L1_2 = log
        L1_2 = L1_2.show
        L2_2 = "Login succeeded with event.phase = "
        L3_2 = A0_2.phase
        L2_2 = L2_2 .. L3_2
        L3_2 = {}
        L4_2 = green
        L3_2.textColor = L4_2
        L1_2(L2_2, L3_2)
      end
      L1_2 = L12_1
      if not L1_2 then
        L1_2 = L3_1
        if L1_2 then
          L1_2 = log
          L1_2 = L1_2.show
          L2_2 = "First successful login this session"
          L3_2 = {}
          L4_2 = green
          L3_2.textColor = L4_2
          L1_2(L2_2, L3_2)
        end
        L1_2 = L11_1
        L1_2 = L1_2.fb_first_name
        if L1_2 then
          L1_2 = toast
          L1_2 = L1_2.show
          L2_2 = "Logged into FB as "
          L3_2 = L11_1
          L3_2 = L3_2.fb_first_name
          L2_2 = L2_2 .. L3_2
          L3_2 = {}
          L3_2.time = 3000
          L4_2 = blue
          L3_2.textColor = L4_2
          L1_2(L2_2, L3_2)
        else
          L1_2 = toast
          L1_2 = L1_2.show
          L2_2 = "Logged into FB"
          L3_2 = {}
          L3_2.time = 3000
          L4_2 = blue
          L3_2.textColor = L4_2
          L1_2(L2_2, L3_2)
        end
        L1_2 = L11_1
        L1_2 = L1_2.friends_with_app
        if 2 <= L1_2 then
          L1_2 = timer
          L1_2 = L1_2.performWithDelay
          L2_2 = 1000
          
          function L3_2()
            local L0_3, L1_3, L2_3, L3_3
            L0_3 = toast
            L0_3 = L0_3.show
            L1_3 = "You have "
            L2_3 = L11_1
            L2_3 = L2_3.friends_with_app
            L3_3 = " friends currently playing."
            L1_3 = L1_3 .. L2_3 .. L3_3
            L2_3 = {}
            L2_3.time = 3000
            L3_3 = blue
            L2_3.textColor = L3_3
            L0_3(L1_3, L2_3)
          end
          
          L1_2(L2_2, L3_2)
        end
        L1_2 = analytics
        L1_2 = L1_2.logEvent
        L2_2 = "FB login successful"
        L1_2(L2_2)
        L1_2 = L11_1
        L2_2 = L11_1
        L2_2 = L2_2.fbNumLogin
        L2_2 = L2_2 + 1
        L1_2.fbNumLogin = L2_2
        L1_2 = saver
        L1_2 = L1_2.Save
        L2_2 = L11_1
        L3_2 = "fb.txt"
        L1_2(L2_2, L3_2)
        L1_2 = L0_1
        L1_2 = L1_2.GetUserId
        L1_2 = L1_2()
        if L1_2 then
          L1_2 = fb_friends
          L1_2 = L1_2.possiblyFetchAndSaveFriends
          L2_2 = nil
          L1_2(L2_2)
        end
        
        function L1_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3
          L0_3 = gamenetwork_utils
          L0_3 = L0_3.sendAchievementProgress
          L1_3 = globals
          L1_3 = L1_3.ACH_ID_FB_LOGIN
          L2_3 = 100
          L0_3(L1_3, L2_3)
          L0_3 = gamenetwork_utils
          L0_3 = L0_3.sendAchievementProgress
          L1_3 = globals
          L1_3 = L1_3.ACH_ID_FB_FRIENDS
          L2_3 = math
          L2_3 = L2_3.ceil
          L3_3 = L11_1
          L3_3 = L3_3.friends_with_app
          L3_3 = L3_3 * 100
          L4_3 = globals
          L4_3 = L4_3.ACH_FB_FRIENDS_NUMBER
          L3_3 = L3_3 / L4_3
          L0_3(L1_3, L2_3(L3_3))
        end
        
        L2_2 = timer
        L2_2 = L2_2.performWithDelay
        L3_2 = 3000
        L4_2 = L1_2
        L2_2(L3_2, L4_2)
      end
      L1_2 = true
      L12_1 = L1_2
      L1_2 = A0_2.token
      if L1_2 then
        L1_2 = L11_1
        L2_2 = A0_2.token
        L1_2.fb_access_token = L2_2
        L1_2 = saver
        L1_2 = L1_2.Save
        L2_2 = L11_1
        L3_2 = "fb.txt"
        L1_2(L2_2, L3_2)
        L1_2 = L3_1
        if L1_2 then
          L1_2 = log
          L1_2 = L1_2.show
          L2_2 = "Got event.token = "
          L3_2 = A0_2.token
          L2_2 = L2_2 .. L3_2
          L3_2 = {}
          L4_2 = green
          L3_2.textColor = L4_2
          L1_2(L2_2, L3_2)
        end
      end
      L1_2 = L11_1
      L1_2 = L1_2.fb_id
      if L1_2 then
        L1_2 = L22_1
        if L1_2 then
          L1_2 = L22_1
          L1_2()
          L1_2 = nil
          L22_1 = L1_2
        end
      end
      L1_2 = L11_1
      L1_2 = L1_2.fb_id
      if not L1_2 then
        L1_2 = L3_1
        if L1_2 then
          L1_2 = log
          L1_2 = L1_2.show
          L2_2 = "Executing me after login to get user info..."
          L3_2 = {}
          L4_2 = yellow
          L3_2.textColor = L4_2
          L1_2(L2_2, L3_2)
        end
        L1_2 = true
        L13_1 = L1_2
        L1_2 = L1_1
        L1_2 = L1_2.request
        L2_2 = "me"
        L3_2 = "GET"
        L4_2 = {}
        L4_2.fields = "id,name,first_name,last_name,username,locale,gender"
        L1_2(L2_2, L3_2, L4_2)
        return
      else
        L1_2 = L25_1
        L1_2()
      end
      L1_2 = L11_1
      L1_2 = L1_2.fbCurrentCommand
      L2_2 = L16_1
      if L1_2 == L2_2 then
        L1_2 = L3_1
        if L1_2 then
          L1_2 = log
          L1_2 = L1_2.show
          L2_2 = "Executing PHOTO_UPLOAD after login..."
          L3_2 = {}
          L4_2 = yellow
          L3_2.textColor = L4_2
          L1_2(L2_2, L3_2)
        end
        L1_2 = utils
        L1_2 = L1_2.simple_message_show
        L2_2 = "Saving picture to Facebook..."
        L3_2 = 30000
        L1_2(L2_2, L3_2)
        L1_2 = L1_1
        L1_2 = L1_2.request
        L2_2 = "me/photos"
        L3_2 = "POST"
        L4_2 = L11_1
        L4_2 = L4_2.fbCurrentParams
        L1_2(L2_2, L3_2, L4_2)
      else
        L1_2 = L11_1
        L1_2 = L1_2.fbCurrentCommand
        L2_2 = L17_1
        if L1_2 == L2_2 then
          L1_2 = L3_1
          if L1_2 then
            L1_2 = log
            L1_2 = L1_2.show
            L2_2 = "Executing SHOW_DIALOG after login..."
            L3_2 = {}
            L4_2 = yellow
            L3_2.textColor = L4_2
            L1_2(L2_2, L3_2)
          end
          L1_2 = toast
          L1_2 = L1_2.hide
          L1_2()
          L1_2 = L1_1
          L1_2 = L1_2.showDialog
          L2_2 = L11_1
          L2_2 = L2_2.fbCurrentDialogMethod
          L3_2 = L11_1
          L3_2 = L3_2.fbCurrentParams
          L1_2(L2_2, L3_2)
        else
          L1_2 = L11_1
          L1_2 = L1_2.fbCurrentCommand
          L2_2 = L19_1
          if L1_2 == L2_2 then
            L1_2 = L3_1
            if L1_2 then
              L1_2 = log
              L1_2 = L1_2.show
              L2_2 = "Executing INVITE_FRIENDS after login..."
              L3_2 = {}
              L4_2 = yellow
              L3_2.textColor = L4_2
              L1_2(L2_2, L3_2)
            end
            L1_2 = toast
            L1_2 = L1_2.hide
            L1_2()
            L1_2 = L1_1
            L1_2 = L1_2.showDialog
            L2_2 = L11_1
            L2_2 = L2_2.fbCurrentDialogMethod
            L3_2 = L11_1
            L3_2 = L3_2.fbCurrentParams
            L1_2(L2_2, L3_2)
          else
            L1_2 = L11_1
            L1_2 = L1_2.fbCurrentCommand
            L2_2 = L18_1
            if L1_2 == L2_2 then
              L1_2 = L3_1
              if L1_2 then
                L1_2 = log
                L1_2 = L1_2.show
                L2_2 = "Executing POST_INSTANT after login..."
                L3_2 = {}
                L4_2 = yellow
                L3_2.textColor = L4_2
                L1_2(L2_2, L3_2)
              end
              L1_2 = L1_1
              L1_2 = L1_2.request
              L2_2 = "me/feed"
              L3_2 = "POST"
              L4_2 = L11_1
              L4_2 = L4_2.fbCurrentParams
              L1_2(L2_2, L3_2, L4_2)
            else
              L1_2 = L11_1
              L1_2 = L1_2.fbCurrentCommand
              L2_2 = L20_1
              if L1_2 == L2_2 then
                L1_2 = L3_1
                if L1_2 then
                  L1_2 = log
                  L1_2 = L1_2.show
                  L2_2 = "Executing DELETE after login..."
                  L3_2 = {}
                  L4_2 = yellow
                  L3_2.textColor = L4_2
                  L1_2(L2_2, L3_2)
                end
                L1_2 = L1_1
                L1_2 = L1_2.request
                L2_2 = L11_1
                L2_2 = L2_2.fbCurrentParams
                L2_2 = L2_2.id
                L3_2 = "DELETE"
                L4_2 = {}
                L1_2(L2_2, L3_2, L4_2)
              else
                L1_2 = L3_1
                if L1_2 then
                  L1_2 = log
                  L1_2 = L1_2.show
                  L2_2 = "Nothing to do after login. fbCurrentCommand = "
                  L3_2 = L11_1
                  L3_2 = L3_2.fbCurrentCommand
                  L2_2 = L2_2 .. L3_2
                  L3_2 = {}
                  L4_2 = green
                  L3_2.textColor = L4_2
                  L1_2(L2_2, L3_2)
                end
              end
            end
          end
        end
      end
    else
      L1_2 = A0_2.phase
      if "logout" == L1_2 then
      else
        L1_2 = L3_1
        if L1_2 then
          L1_2 = log
          L1_2 = L1_2.show
          L2_2 = "event.phase = "
          L3_2 = A0_2.phase
          L4_2 = " and event.response = "
          L5_2 = A0_2.response
          L2_2 = L2_2 .. L3_2 .. L4_2 .. L5_2
          L3_2 = {}
          L4_2 = red
          L3_2.textColor = L4_2
          L1_2(L2_2, L3_2)
        end
        L1_2 = analytics
        L1_2 = L1_2.logEvent
        L2_2 = "FB login failed or canceled"
        L1_2(L2_2)
      end
    end
  else
    L1_2 = A0_2.type
    if "request" == L1_2 then
      L1_2 = A0_2.response
      L2_2 = A0_2.isError
      if not L2_2 then
        L2_2 = L2_1
        L2_2 = L2_2.decode
        L3_2 = A0_2.response
        L2_2 = L2_2(L3_2)
        L1_2 = L2_2
        L2_2 = L13_1
        if L2_2 then
          L2_2 = false
          L13_1 = L2_2
          L2_2 = L11_1
          L3_2 = string
          L3_2 = L3_2.format
          L4_2 = "%.0f"
          L5_2 = L1_2.id
          L3_2 = L3_2(L4_2, L5_2)
          L2_2.fb_id = L3_2
          L2_2 = L11_1
          L3_2 = L1_2.name
          L2_2.fb_name = L3_2
          L2_2 = L11_1
          L3_2 = L1_2.first_name
          L2_2.fb_first_name = L3_2
          L2_2 = L11_1
          L3_2 = L1_2.last_name
          L2_2.fb_last_name = L3_2
          L2_2 = L11_1
          L3_2 = L1_2.username
          L2_2.fb_username = L3_2
          L2_2 = L11_1
          L3_2 = L1_2.locale
          L2_2.fb_locale = L3_2
          L2_2 = L11_1
          L3_2 = L1_2.gender
          L2_2.fb_gender = L3_2
          L2_2 = saver
          L2_2 = L2_2.Save
          L3_2 = L11_1
          L4_2 = "fb.txt"
          L2_2(L3_2, L4_2)
          L2_2 = L3_1
          if L2_2 then
            L2_2 = log
            L2_2 = L2_2.show
            L3_2 = "Got request response to GET_USER_INFO: fb_id = "
            L4_2 = L11_1
            L4_2 = L4_2.fb_id
            L3_2 = L3_2 .. L4_2
            L4_2 = {}
            L5_2 = green
            L4_2.textColor = L5_2
            L2_2(L3_2, L4_2)
          end
          L2_2 = L25_1
          L2_2()
          L2_2 = L26_1
          L3_2 = nil
          L2_2(L3_2)
          L2_2 = analytics
          L2_2 = L2_2.logEvent
          L3_2 = "fbCalledMe successful"
          L2_2(L3_2)
          L2_2 = L11_1
          L2_2 = L2_2.fbCurrentCommand
          L3_2 = L15_1
          if L2_2 ~= L3_2 then
            L2_2 = L3_1
            if L2_2 then
              L2_2 = log
              L2_2 = L2_2.show
              L3_2 = "Calling login again to do fbCurrentCommand = "
              L4_2 = L11_1
              L4_2 = L4_2.fbCurrentCommand
              L3_2 = L3_2 .. L4_2
              L4_2 = {}
              L5_2 = yellow
              L4_2.textColor = L5_2
              L2_2(L3_2, L4_2)
            end
            L2_2 = L1_1
            L2_2 = L2_2.login
            L3_2 = globals
            L3_2 = L3_2.FB_API_KEY
            L4_2 = L27_1
            L5_2 = L4_1
            L2_2(L3_2, L4_2, L5_2)
          end
          L2_2 = L11_1
          L2_2 = L2_2.fb_id
          if L2_2 then
            L2_2 = L22_1
            if L2_2 then
              L2_2 = L22_1
              L2_2()
              L2_2 = nil
              L22_1 = L2_2
            end
          end
          return
        end
        L2_2 = L11_1
        L2_2 = L2_2.fbCurrentCommand
        L3_2 = L16_1
        if L2_2 == L3_2 then
          L2_2 = L3_1
          if L2_2 then
            L2_2 = log
            L2_2 = L2_2.show
            L3_2 = "Got request response to PHOTO_UPLOAD: event.response = "
            L4_2 = A0_2.response
            L3_2 = L3_2 .. L4_2
            L4_2 = {}
            L5_2 = green
            L4_2.textColor = L5_2
            L2_2(L3_2, L4_2)
          end
          L2_2 = toast
          L2_2 = L2_2.hide
          L2_2()
          L2_2 = A0_2.response
          L3_2 = L2_2
          L2_2 = L2_2.find
          L4_2 = "post_id"
          L2_2 = L2_2(L3_2, L4_2)
          if L2_2 then
            L2_2 = toast
            L2_2 = L2_2.show
            L3_2 = "Picture saved to Facebook"
            L4_2 = {}
            L4_2.time = 3000
            L5_2 = blue
            L4_2.textColor = L5_2
            L2_2(L3_2, L4_2)
            L2_2 = analytics
            L2_2 = L2_2.logEvent
            L3_2 = "FB PHOTO_UPLOAD successful"
            L2_2(L3_2)
            L2_2 = L11_1
            L3_2 = L11_1
            L3_2 = L3_2.fbNumPhotoUpload
            L3_2 = L3_2 + 1
            L2_2.fbNumPhotoUpload = L3_2
            L2_2 = saver
            L2_2 = L2_2.Save
            L3_2 = L11_1
            L4_2 = "fb.txt"
            L2_2(L3_2, L4_2)
          else
            L2_2 = analytics
            L2_2 = L2_2.logEvent
            L3_2 = "FB PHOTO_UPLOAD failed"
            L2_2(L3_2)
          end
        else
          L2_2 = L11_1
          L2_2 = L2_2.fbCurrentCommand
          L3_2 = L17_1
          if L2_2 == L3_2 then
            L2_2 = L3_1
            if L2_2 then
              L2_2 = log
              L2_2 = L2_2.show
              L3_2 = "Got request response to SHOW_DIALOG: event.response = "
              L4_2 = A0_2.response
              L3_2 = L3_2 .. L4_2
              L4_2 = {}
              L5_2 = green
              L4_2.textColor = L5_2
              L2_2(L3_2, L4_2)
            end
          else
            L2_2 = L11_1
            L2_2 = L2_2.fbCurrentCommand
            L3_2 = L19_1
            if L2_2 == L3_2 then
              L2_2 = L3_1
              if L2_2 then
                L2_2 = log
                L2_2 = L2_2.show
                L3_2 = "Got request response to INVITE_FRIENDS: event.response = "
                L4_2 = A0_2.response
                L3_2 = L3_2 .. L4_2
                L4_2 = {}
                L5_2 = green
                L4_2.textColor = L5_2
                L2_2(L3_2, L4_2)
              end
            else
              L2_2 = L11_1
              L2_2 = L2_2.fbCurrentCommand
              L3_2 = L18_1
              if L2_2 == L3_2 then
                L2_2 = L3_1
                if L2_2 then
                  L2_2 = log
                  L2_2 = L2_2.show
                  L3_2 = "Got request response to POST_INSTANT: event.response = "
                  L4_2 = A0_2.response
                  L3_2 = L3_2 .. L4_2
                  L4_2 = {}
                  L5_2 = green
                  L4_2.textColor = L5_2
                  L2_2(L3_2, L4_2)
                end
                L2_2 = A0_2.response
                L3_2 = L2_2
                L2_2 = L2_2.find
                L4_2 = "post_id"
                L2_2 = L2_2(L3_2, L4_2)
                if L2_2 then
                  L2_2 = analytics
                  L2_2 = L2_2.logEvent
                  L3_2 = "FB POST_INSTANT successful"
                  L2_2(L3_2)
                  L2_2 = L11_1
                  L3_2 = L11_1
                  L3_2 = L3_2.fbNumPostInstant
                  L3_2 = L3_2 + 1
                  L2_2.fbNumPostInstant = L3_2
                  L2_2 = saver
                  L2_2 = L2_2.Save
                  L3_2 = L11_1
                  L4_2 = "fb.txt"
                  L2_2(L3_2, L4_2)
                else
                  L2_2 = analytics
                  L2_2 = L2_2.logEvent
                  L3_2 = "FB POST_INSTANT failed"
                  L2_2(L3_2)
                end
              else
                L2_2 = L11_1
                L2_2 = L2_2.fbCurrentCommand
                L3_2 = L20_1
                if L2_2 == L3_2 then
                  L2_2 = L3_1
                  if L2_2 then
                    L2_2 = log
                    L2_2 = L2_2.show
                    L3_2 = "Got request response to DELETE: event.response = "
                    L4_2 = A0_2.response
                    L3_2 = L3_2 .. L4_2
                    L4_2 = {}
                    L5_2 = green
                    L4_2.textColor = L5_2
                    L2_2(L3_2, L4_2)
                  end
                else
                  L2_2 = L3_1
                  if L2_2 then
                    L2_2 = log
                    L2_2 = L2_2.show
                    L3_2 = "Unknown command response. fbCurrentCommand = "
                    L4_2 = L11_1
                    L4_2 = L4_2.fbCurrentCommand
                    L5_2 = ". event.response = "
                    L6_2 = A0_2.response
                    L3_2 = L3_2 .. L4_2 .. L5_2 .. L6_2
                    L4_2 = {}
                    L5_2 = red
                    L4_2.textColor = L5_2
                    L2_2(L3_2, L4_2)
                  end
                end
              end
            end
          end
        end
      else
        L2_2 = false
        L13_1 = L2_2
        L2_2 = L3_1
        if L2_2 then
          L2_2 = log
          L2_2 = L2_2.show
          L3_2 = "Request failed; got event.isError. fbCurrentCommand = "
          L4_2 = L11_1
          L4_2 = L4_2.fbCurrentCommand
          L3_2 = L3_2 .. L4_2
          L4_2 = {}
          L5_2 = red
          L4_2.textColor = L5_2
          L2_2(L3_2, L4_2)
        end
        L2_2 = L11_1
        L2_2 = L2_2.fbCurrentCommand
        L3_2 = L16_1
        if L2_2 == L3_2 then
          L2_2 = toast
          L2_2 = L2_2.hide
          L2_2()
        end
        L2_2 = analytics
        L2_2 = L2_2.logEvent
        L3_2 = "FB API call failure. fbCurrentCommand = "
        L4_2 = L11_1
        L4_2 = L4_2.fbCurrentCommand
        L3_2 = L3_2 .. L4_2
        L2_2(L3_2)
      end
      L2_2 = L21_1
      L3_2 = L15_1
      L4_2 = {}
      L2_2(L3_2, L4_2)
    else
      L1_2 = A0_2.type
      if "dialog" == L1_2 then
        L1_2 = L3_1
        if L1_2 then
          L1_2 = log
          L1_2 = L1_2.show
          L2_2 = "Got dialog response: event.response = "
          L3_2 = A0_2.response
          L2_2 = L2_2 .. L3_2
          L3_2 = {}
          L4_2 = green
          L3_2.textColor = L4_2
          L1_2(L2_2, L3_2)
        end
        L1_2 = L11_1
        L1_2 = L1_2.fbCurrentCommand
        L2_2 = L17_1
        if L1_2 == L2_2 then
          L1_2 = A0_2.response
          L2_2 = L1_2
          L1_2 = L1_2.find
          L3_2 = "post_id"
          L1_2 = L1_2(L2_2, L3_2)
          if L1_2 then
            L1_2 = toast
            L1_2 = L1_2.show
            L2_2 = "Posted successfully to Facebook"
            L3_2 = {}
            L3_2.time = 3000
            L4_2 = blue
            L3_2.textColor = L4_2
            L1_2(L2_2, L3_2)
            L1_2 = analytics
            L1_2 = L1_2.logEvent
            L2_2 = "FB SHOW_DIALOG successful"
            L1_2(L2_2)
            L1_2 = L11_1
            L2_2 = L11_1
            L2_2 = L2_2.fbNumDialogFeed
            L2_2 = L2_2 + 1
            L1_2.fbNumDialogFeed = L2_2
            L1_2 = saver
            L1_2 = L1_2.Save
            L2_2 = L11_1
            L3_2 = "fb.txt"
            L1_2(L2_2, L3_2)
          else
            L1_2 = A0_2.response
            L2_2 = L1_2
            L1_2 = L1_2.find
            L3_2 = "cancelled"
            L1_2 = L1_2(L2_2, L3_2)
            if L1_2 then
              L1_2 = toast
              L1_2 = L1_2.show
              L2_2 = "Post not made"
              L3_2 = {}
              L3_2.time = 2000
              L4_2 = red
              L3_2.textColor = L4_2
              L1_2(L2_2, L3_2)
            else
            end
          end
        end
        L1_2 = L11_1
        L1_2 = L1_2.fbCurrentCommand
        L2_2 = L19_1
        if L1_2 == L2_2 then
          L1_2 = 0
          L2_2 = L3_1
          if L2_2 then
            L2_2 = log
            L2_2 = L2_2.show
            L3_2 = A0_2.response
            L4_2 = {}
            L5_2 = yellow
            L4_2.textColor = L5_2
            L2_2(L3_2, L4_2)
          end
          L2_2 = A0_2.response
          L3_2 = L2_2
          L2_2 = L2_2.find
          L4_2 = "&to"
          L2_2 = L2_2(L3_2, L4_2)
          if not L2_2 then
            L2_2 = A0_2.response
            L3_2 = L2_2
            L2_2 = L2_2.find
            L4_2 = "?to"
            L2_2 = L2_2(L3_2, L4_2)
            if not L2_2 then
              goto lbl_805
            end
          end
          L2_2 = utils
          L2_2 = L2_2.split
          L3_2 = A0_2.response
          L4_2 = "&to"
          L2_2 = L2_2(L3_2, L4_2)
          L3_2 = utils
          L3_2 = L3_2.split
          L4_2 = A0_2.response
          L5_2 = "?to"
          L3_2 = L3_2(L4_2, L5_2)
          L4_2 = #L2_2
          L4_2 = L4_2 - 1
          L5_2 = #L3_2
          L4_2 = L4_2 + L5_2
          L1_2 = L4_2 - 1
          L4_2 = L3_1
          if L4_2 then
            if L1_2 == 1 then
              L4_2 = toast
              L4_2 = L4_2.show
              L5_2 = "Sent request"
              L6_2 = {}
              L6_2.time = 3000
              L7_2 = green
              L6_2.textColor = L7_2
              L4_2(L5_2, L6_2)
            else
              L4_2 = toast
              L4_2 = L4_2.show
              L5_2 = "Sent "
              L6_2 = L1_2
              L7_2 = " requests"
              L5_2 = L5_2 .. L6_2 .. L7_2
              L6_2 = {}
              L6_2.time = 3000
              L7_2 = green
              L6_2.textColor = L7_2
              L4_2(L5_2, L6_2)
            end
          else
            L4_2 = toast
            L4_2 = L4_2.show
            L5_2 = "Sent"
            L6_2 = {}
            L6_2.time = 3000
            L7_2 = green
            L6_2.textColor = L7_2
            L4_2(L5_2, L6_2)
          end
          if 0 < L1_2 then
            L4_2 = L11_1
            L4_2 = L4_2.fbCurrentParams
            if L4_2 then
              L4_2 = L11_1
              L4_2 = L4_2.fbCurrentParams
              L4_2 = L4_2.data
              L5_2 = L4_2
              L4_2 = L4_2.startsWith
              L6_2 = "send."
              L4_2 = L4_2(L5_2, L6_2)
              if L4_2 then
                L4_2 = gamenetwork_utils
                L4_2 = L4_2.sendAchievementProgress
                L5_2 = globals
                L5_2 = L5_2.ACH_ID_FB_SEND_GIFT
                L6_2 = 100
                L4_2(L5_2, L6_2)
              else
              end
            end
          end
          ::lbl_805::
          L2_2 = L23_1
          if L2_2 then
            L2_2 = L23_1
            L3_2 = L1_2
            L2_2(L3_2)
            L2_2 = nil
            L23_1 = L2_2
          end
        end
        L1_2 = A0_2.response
        L2_2 = L1_2
        L1_2 = L1_2.find
        L3_2 = "NSURLErrorDomain"
        L1_2 = L1_2(L2_2, L3_2)
        if L1_2 then
          L1_2 = A0_2.response
          L2_2 = L1_2
          L1_2 = L1_2.find
          L3_2 = "-999"
          L1_2 = L1_2(L2_2, L3_2)
          if L1_2 then
            L1_2 = L14_1
            L1_2 = L1_2 + 1
            L14_1 = L1_2
            L1_2 = L14_1
            if L1_2 <= 2 then
              L1_2 = L3_1
              if L1_2 then
                L1_2 = log
                L1_2 = L1_2.show
                L2_2 = "Retrying dialog command..."
                L3_2 = yellowT
                L1_2(L2_2, L3_2)
              end
              L1_2 = L1_1
              L1_2 = L1_2.showDialog
              L2_2 = L11_1
              L2_2 = L2_2.fbCurrentDialogMethod
              L3_2 = L11_1
              L3_2 = L3_2.fbCurrentParams
              L1_2(L2_2, L3_2)
            else
              L1_2 = toast
              L1_2 = L1_2.show
              L2_2 = "Post error; please try again"
              L3_2 = {}
              L3_2.time = 3000
              L4_2 = red
              L3_2.textColor = L4_2
              L1_2(L2_2, L3_2)
            end
        end
        else
          L1_2 = L21_1
          L2_2 = L15_1
          L3_2 = {}
          L1_2(L2_2, L3_2)
        end
      end
    end
  end
end

function L28_1()
  local L0_2, L1_2
  L0_2 = globals
  L0_2 = L0_2.FB_API_KEY
  return L0_2
end

L0_1.GetAppId = L28_1

function L28_1()
  local L0_2, L1_2
  L0_2 = _SIMULATOR
  if L0_2 then
    L0_2 = "213193"
    return L0_2
  end
  L0_2 = L11_1
  if not L0_2 then
    L0_2 = nil
    return L0_2
  end
  L0_2 = L11_1
  L0_2 = L0_2.fb_id
  return L0_2
end

L0_1.GetUserId = L28_1

function L28_1()
  local L0_2, L1_2
  L0_2 = L11_1
  return L0_2
end

L0_1.GetfbSavedData = L28_1

function L28_1()
  local L0_2, L1_2
  L0_2 = L11_1
  L0_2 = L0_2.friends_with_app
  return L0_2
end

L0_1.NumFriendsWithAppInstalled = L28_1

function L28_1()
  local L0_2, L1_2, L2_2
  L0_2 = L3_1
  if L0_2 then
    L0_2 = print
    L1_2 = L11_1
    L1_2 = L1_2.fb_access_token
    L2_2 = L11_1
    L2_2 = L2_2.fbNumLogin
    L0_2(L1_2, L2_2)
  end
  L0_2 = _SIMULATOR
  if L0_2 then
    L0_2 = true
    return L0_2
  end
  L0_2 = L11_1
  L0_2 = L0_2.fb_access_token
  if L0_2 then
    L0_2 = L11_1
    L0_2 = L0_2.fb_id
    if L0_2 then
      L0_2 = L11_1
      L0_2 = L0_2.fbNumLogin
      if 0 < L0_2 then
        L0_2 = true
        return L0_2
    end
  end
  else
    L0_2 = false
    return L0_2
  end
end

L0_1.IsLoggedIn = L28_1

function L28_1()
  local L0_2, L1_2
  L0_2 = L1_1
  L0_2 = L0_2.publishInstall
  L1_2 = globals
  L1_2 = L1_2.FB_API_KEY
  L0_2(L1_2)
end

L0_1.PublishInstall = L28_1

function L28_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = L11_1
  L0_2 = L0_2.fb_access_token
  if L0_2 then
    L0_2 = L12_1
    if not L0_2 then
      L0_2 = L3_1
      if L0_2 then
        L0_2 = log
        L0_2 = L0_2.show
        L1_2 = "Calling startup facebook.login() with fbCurrentCommand = "
        L2_2 = L11_1
        L2_2 = L2_2.fbCurrentCommand
        L1_2 = L1_2 .. L2_2
        L2_2 = {}
        L3_2 = yellow
        L2_2.textColor = L3_2
        L2_2.pos = 1
        L0_2(L1_2, L2_2)
      end
      L0_2 = analytics
      L0_2 = L0_2.logEvent
      L1_2 = "Called fb_utils.StartupLogin()"
      L0_2(L1_2)
      L0_2 = L1_1
      L0_2 = L0_2.login
      L1_2 = globals
      L1_2 = L1_2.FB_API_KEY
      L2_2 = L27_1
      L3_2 = L4_1
      L0_2(L1_2, L2_2, L3_2)
    end
  end
end

L0_1.StartupLogin = L28_1

function L28_1()
  local L0_2, L1_2, L2_2, L3_2
  L0_2 = L3_1
  if L0_2 then
    L0_2 = log
    L0_2 = L0_2.show
    L1_2 = "LoginOnly()"
    L2_2 = {}
    L3_2 = yellow
    L2_2.textColor = L3_2
    L2_2.pos = 1
    L0_2(L1_2, L2_2)
  end
  L0_2 = analytics
  L0_2 = L0_2.logEvent
  L1_2 = "Called fb_utils.LoginOnly()"
  L0_2(L1_2)
  L0_2 = L21_1
  L1_2 = L15_1
  L2_2 = {}
  L0_2(L1_2, L2_2)
  L0_2 = L1_1
  L0_2 = L0_2.login
  L1_2 = globals
  L1_2 = L1_2.FB_API_KEY
  L2_2 = L27_1
  L3_2 = L4_1
  L0_2(L1_2, L2_2, L3_2)
end

L0_1.LoginOnly = L28_1

function L28_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L3_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "LoginThenRunFunction()"
    L3_2 = {}
    L4_2 = yellow
    L3_2.textColor = L4_2
    L3_2.pos = 1
    L1_2(L2_2, L3_2)
  end
  L1_2 = analytics
  L1_2 = L1_2.logEvent
  L2_2 = "Called fb_utils.LoginThenRunFunction()"
  L1_2(L2_2)
  L1_2 = L21_1
  L2_2 = L15_1
  L3_2 = {}
  L1_2(L2_2, L3_2)
  L22_1 = A0_2
  L1_2 = L1_1
  L1_2 = L1_2.login
  L2_2 = globals
  L2_2 = L2_2.FB_API_KEY
  L3_2 = L27_1
  L4_2 = L4_1
  L1_2(L2_2, L3_2, L4_2)
end

L0_1.LoginThenRunFunction = L28_1

function L28_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = L3_1
  if L2_2 then
    L2_2 = log
    L2_2 = L2_2.show
    L3_2 = "UploadScreenShot()"
    L4_2 = {}
    L5_2 = yellow
    L4_2.textColor = L5_2
    L4_2.pos = 1
    L2_2(L3_2, L4_2)
  end
  L2_2 = analytics
  L2_2 = L2_2.logEvent
  L3_2 = "Called fb_utils.UploadScreenShot()"
  L2_2(L3_2)
  L2_2 = display
  L2_2 = L2_2.save
  L3_2 = A0_2
  L4_2 = "fb_upload.jpg"
  L5_2 = system
  L5_2 = L5_2.DocumentsDirectory
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = L21_1
  L3_2 = L16_1
  L4_2 = {}
  L4_2.message = A1_2
  L5_2 = {}
  L6_2 = system
  L6_2 = L6_2.DocumentsDirectory
  L5_2.baseDir = L6_2
  L5_2.filename = "fb_upload.jpg"
  L5_2.type = "image"
  L4_2.source = L5_2
  L2_2(L3_2, L4_2)
  L2_2 = L1_1
  L2_2 = L2_2.login
  L3_2 = globals
  L3_2 = L3_2.FB_API_KEY
  L4_2 = L27_1
  L5_2 = L4_1
  L2_2(L3_2, L4_2, L5_2)
end

L0_1.UploadScreenShot = L28_1

function L28_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L3_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "PostToFeedViaDialog()"
    L3_2 = {}
    L4_2 = yellow
    L3_2.textColor = L4_2
    L3_2.pos = 1
    L1_2(L2_2, L3_2)
  end
  L1_2 = analytics
  L1_2 = L1_2.logEvent
  L2_2 = "Called fb_utils.PostToFeedViaDialog()"
  L1_2(L2_2)
  L1_2 = utils
  L1_2 = L1_2.simple_message_show
  L2_2 = "Connecting to Facebook..."
  L3_2 = 3000
  L1_2(L2_2, L3_2)
  if not A0_2 then
    L1_2 = {}
    A0_2 = L1_2
  end
  L1_2 = L21_1
  L2_2 = L17_1
  L3_2 = {}
  L4_2 = A0_2.link
  if not L4_2 then
    L4_2 = L5_1
  end
  L3_2.link = L4_2
  L4_2 = A0_2.picture
  if not L4_2 then
    L4_2 = L6_1
  end
  L3_2.picture = L4_2
  L4_2 = A0_2.name
  if not L4_2 then
    L4_2 = L7_1
  end
  L3_2.name = L4_2
  L4_2 = A0_2.caption
  if not L4_2 then
    L4_2 = L8_1
  end
  L3_2.caption = L4_2
  L4_2 = A0_2.description
  if not L4_2 then
    L4_2 = L9_1
  end
  L3_2.description = L4_2
  L4_2 = "feed"
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = L1_1
  L1_2 = L1_2.login
  L2_2 = globals
  L2_2 = L2_2.FB_API_KEY
  L3_2 = L27_1
  L4_2 = L4_1
  L1_2(L2_2, L3_2, L4_2)
end

L0_1.PostToFeedViaDialog = L28_1

function L28_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L3_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "PostToFeedInstantly()"
    L3_2 = {}
    L4_2 = yellow
    L3_2.textColor = L4_2
    L3_2.pos = 1
    L1_2(L2_2, L3_2)
  end
  L1_2 = analytics
  L1_2 = L1_2.logEvent
  L2_2 = "Called fb_utils.PostToFeedInstantly()"
  L1_2(L2_2)
  L1_2 = L21_1
  L2_2 = L18_1
  L3_2 = {}
  L4_2 = A0_2.message
  L3_2.message = L4_2
  L4_2 = A0_2.link
  if not L4_2 then
    L4_2 = L5_1
  end
  L3_2.link = L4_2
  L4_2 = A0_2.picture
  if not L4_2 then
    L4_2 = L6_1
  end
  L3_2.picture = L4_2
  L4_2 = A0_2.name
  if not L4_2 then
    L4_2 = L7_1
  end
  L3_2.name = L4_2
  L4_2 = A0_2.caption
  if not L4_2 then
    L4_2 = L8_1
  end
  L3_2.caption = L4_2
  L4_2 = A0_2.description
  if not L4_2 then
    L4_2 = L9_1
  end
  L3_2.description = L4_2
  L1_2(L2_2, L3_2)
  L1_2 = L1_1
  L1_2 = L1_2.login
  L2_2 = globals
  L2_2 = L2_2.FB_API_KEY
  L3_2 = L27_1
  L4_2 = L4_1
  L1_2(L2_2, L3_2, L4_2)
end

L0_1.PostToFeedInstantly = L28_1

function L28_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = L3_1
  if L2_2 then
    L2_2 = log
    L2_2 = L2_2.show
    L3_2 = "RequestsDialog()"
    L4_2 = {}
    L5_2 = yellow
    L4_2.textColor = L5_2
    L4_2.pos = 1
    L2_2(L3_2, L4_2)
  end
  L2_2 = analytics
  L2_2 = L2_2.logEvent
  L3_2 = "Called fb_utils.RequestsDialog()"
  L2_2(L3_2)
  L2_2 = utils
  L2_2 = L2_2.simple_message_show
  L3_2 = "Connecting to Facebook..."
  L4_2 = 3000
  L2_2(L3_2, L4_2)
  if not A0_2 then
    L2_2 = {}
    A0_2 = L2_2
  end
  L2_2 = A0_2.message
  if not L2_2 then
    L2_2 = L10_1
    A0_2.message = L2_2
  end
  L2_2 = A0_2.frictionless
  if L2_2 == nil then
    A0_2.frictionless = "1"
  end
  L2_2 = L21_1
  L3_2 = L19_1
  L4_2 = A0_2
  L5_2 = "apprequests"
  L2_2(L3_2, L4_2, L5_2)
  L23_1 = A1_2
  L2_2 = L1_1
  L2_2 = L2_2.login
  L3_2 = globals
  L3_2 = L3_2.FB_API_KEY
  L4_2 = L27_1
  L5_2 = L4_1
  L2_2(L3_2, L4_2, L5_2)
end

L0_1.RequestsDialog = L28_1

function L28_1()
  local L0_2, L1_2, L2_2
  L0_2 = display
  L0_2 = L0_2.newImage
  L1_2 = "me.jpg"
  L2_2 = system
  L2_2 = L2_2.DocumentsDirectory
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    return L0_2
  end
  L1_2 = L26_1
  L2_2 = nil
  L1_2(L2_2)
  L1_2 = nil
  return L1_2
end

L0_1.getProfilePicAsDisplayObject = L28_1

function L28_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = L3_1
  if L1_2 then
    L1_2 = log
    L1_2 = L1_2.show
    L2_2 = "Delete()"
    L3_2 = {}
    L4_2 = yellow
    L3_2.textColor = L4_2
    L3_2.pos = 1
    L1_2(L2_2, L3_2)
  end
  L1_2 = analytics
  L1_2 = L1_2.logEvent
  L2_2 = "Called fb_utils.Delete()"
  L1_2(L2_2)
  L1_2 = L21_1
  L2_2 = L20_1
  L3_2 = {}
  L3_2.id = A0_2
  L1_2(L2_2, L3_2)
  L1_2 = L1_1
  L1_2 = L1_2.login
  L2_2 = globals
  L2_2 = L2_2.FB_API_KEY
  L3_2 = L27_1
  L4_2 = L4_1
  L1_2(L2_2, L3_2, L4_2)
end

L0_1.Delete = L28_1
L28_1 = {}
L29_1 = {}
L30_1 = {}
L31_1 = {}

function L32_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = A0_2.isError
  if L1_2 then
    L1_2 = print
    L2_2 = "fbPicListener(): Network error - download failed"
    L1_2(L2_2)
    return
  end
  L1_2 = A0_2.url
  if L1_2 == nil then
    L1_2 = print
    L2_2 = "fbPicListener(): event.url was nil"
    L1_2(L2_2)
    return
  end
  L1_2 = A0_2.url
  L2_2 = L1_2
  L1_2 = L1_2.match
  L3_2 = "%d+"
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 == nil then
    L2_2 = print
    L3_2 = "fbPicListener(): fid not found in url"
    L2_2(L3_2)
    return
  end
  L2_2 = L29_1
  L2_2 = L2_2[L1_2]
  if L2_2 == nil then
    L2_2 = print
    L3_2 = "fbPicListener(): fbTempPics[fid] was nil"
    L2_2(L3_2)
    return
  end
  L2_2 = L28_1
  L2_2 = L2_2[L1_2]
  if L2_2 == nil then
    L2_2 = print
    L3_2 = "fbPicListener(): fbPicGroups[fid] was nil"
    L2_2(L3_2)
    return
  end
  L2_2 = display
  L2_2 = L2_2.newImage
  L3_2 = "fb"
  L4_2 = L1_2
  L5_2 = ".jpg"
  L3_2 = L3_2 .. L4_2 .. L5_2
  L4_2 = system
  L4_2 = L4_2.DocumentsDirectory
  L5_2 = L30_1
  L5_2 = L5_2[L1_2]
  L6_2 = L31_1
  L6_2 = L6_2[L1_2]
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
  if L2_2 == nil then
    L3_2 = print
    L4_2 = "fbPicListener(): fbImage was nil"
    L3_2(L4_2)
    return
  end
  L3_2 = L29_1
  L3_2 = L3_2[L1_2]
  L3_2 = L3_2.removeSelf
  if L3_2 then
    L3_2 = L29_1
    L3_2 = L3_2[L1_2]
    L4_2 = L3_2
    L3_2 = L3_2.removeSelf
    L3_2(L4_2)
    L3_2 = L28_1
    L3_2 = L3_2[L1_2]
    L4_2 = L3_2
    L3_2 = L3_2.insert
    L5_2 = L2_2
    L3_2(L4_2, L5_2)
    L3_2 = 0
    L2_2.y = 0
    L2_2.x = L3_2
    L4_2 = L2_2
    L3_2 = L2_2.toBack
    L3_2(L4_2)
  else
    L3_2 = print
    L4_2 = "fbPicListener() fbTempPics[fid].removeSelf was nil for "
    L5_2 = L1_2
    L4_2 = L4_2 .. L5_2
    L3_2(L4_2)
    L4_2 = L2_2
    L3_2 = L2_2.removeSelf
    L3_2(L4_2)
  end
  L3_2 = L29_1
  L3_2[L1_2] = nil
  L3_2 = L28_1
  L3_2[L1_2] = nil
end

function L33_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L2_2 = display
  L2_2 = L2_2.newGroup
  L2_2 = L2_2()
  L3_2 = 50
  L4_2 = 50
  L5_2 = display
  L5_2 = L5_2.newImage
  L6_2 = "fb"
  L7_2 = A0_2
  L8_2 = ".jpg"
  L6_2 = L6_2 .. L7_2 .. L8_2
  L7_2 = system
  L7_2 = L7_2.DocumentsDirectory
  L8_2 = L3_2
  L9_2 = L4_2
  L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2)
  if L5_2 then
    L7_2 = L2_2
    L6_2 = L2_2.insert
    L8_2 = L5_2
    L6_2(L7_2, L8_2)
    L6_2 = 0
    L5_2.y = 0
    L5_2.x = L6_2
  else
    L6_2 = "https://graph.facebook.com/"
    L7_2 = A0_2
    L8_2 = "/picture"
    L6_2 = L6_2 .. L7_2 .. L8_2
    L7_2 = network
    L7_2 = L7_2.download
    L8_2 = L6_2
    L9_2 = "GET"
    L10_2 = L32_1
    L11_2 = "fb"
    L12_2 = A0_2
    L13_2 = ".jpg"
    L11_2 = L11_2 .. L12_2 .. L13_2
    L12_2 = system
    L12_2 = L12_2.DocumentsDirectory
    L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
    L7_2 = L28_1
    L8_2 = tostring
    L9_2 = A0_2
    L8_2 = L8_2(L9_2)
    L7_2[L8_2] = L2_2
    L7_2 = L29_1
    L8_2 = tostring
    L9_2 = A0_2
    L8_2 = L8_2(L9_2)
    L9_2 = display
    L9_2 = L9_2.newRect
    L10_2 = 0
    L11_2 = 0
    L12_2 = L3_2
    L13_2 = L4_2
    L9_2 = L9_2(L10_2, L11_2, L12_2, L13_2)
    L7_2[L8_2] = L9_2
    L7_2 = L29_1
    L8_2 = tostring
    L9_2 = A0_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2[L8_2]
    L8_2 = L7_2
    L7_2 = L7_2.setFillColor
    L9_2 = gray
    L7_2(L8_2, L9_2())
    L8_2 = L2_2
    L7_2 = L2_2.insert
    L9_2 = L29_1
    L10_2 = tostring
    L11_2 = A0_2
    L10_2 = L10_2(L11_2)
    L9_2 = L9_2[L10_2]
    L7_2(L8_2, L9_2)
    L7_2 = L29_1
    L8_2 = tostring
    L9_2 = A0_2
    L8_2 = L8_2(L9_2)
    L7_2 = L7_2[L8_2]
    L8_2 = L29_1
    L9_2 = tostring
    L10_2 = A0_2
    L9_2 = L9_2(L10_2)
    L8_2 = L8_2[L9_2]
    L9_2 = 0
    L8_2.y = 0
    L7_2.x = L9_2
  end
  if A1_2 then
    L6_2 = display
    L6_2 = L6_2.newRoundedRect
    L7_2 = L2_2
    L8_2 = 0
    L9_2 = 0
    L10_2 = L3_2
    L11_2 = L4_2
    L12_2 = 3
    L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    L8_2 = L6_2
    L7_2 = L6_2.setFillColor
    L9_2 = 0
    L10_2 = 0
    L11_2 = 0
    L12_2 = 0
    L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
    L8_2 = L6_2
    L7_2 = L6_2.setStrokeColor
    L9_2 = A1_2
    L7_2(L8_2, L9_2())
    L6_2.strokeWidth = 3
    L7_2 = 0
    L6_2.y = 0
    L6_2.x = L7_2
  end
  L6_2 = L30_1
  L7_2 = tostring
  L8_2 = A0_2
  L7_2 = L7_2(L8_2)
  L6_2[L7_2] = L3_2
  L6_2 = L31_1
  L7_2 = tostring
  L8_2 = A0_2
  L7_2 = L7_2(L8_2)
  L6_2[L7_2] = L4_2
  return L2_2
end

L0_1.getFacebookPicAsDisplayObject = L33_1
L33_1 = L0_1.PublishInstall
L33_1()
L33_1 = L0_1.StartupLogin
L33_1()
return L0_1
