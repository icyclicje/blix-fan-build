# Blix (browser port, private copy)

Blix 1.03 for iPhone, running in a desktop browser. The game's own Lua scripts
run unchanged on a small re-implementation of the Corona SDK engine.

This folder holds Bonfire Media's game code, art, sounds and fonts, extracted
from your own `.ipa`. Keep it for personal use and don't upload it anywhere.

## Play

1. Double-click `index.html`. It runs from disk and needs no server or internet.
2. Press **Play** on the title screen. Play also turns on sound and fullscreen.
3. Press **F** to toggle fullscreen.

On a 1920×1080 screen in fullscreen, the game fills the display exactly.
Windows with other proportions get black bars. Progress (high scores, the
sound setting) is saved in the browser's local storage for this file.

## Blix! 1.0 additions

These all live in `mods/` and hook into the original scripts without editing
them, so rebuilding from the .ipa keeps them.

- **Title screen**: "Blix!" with Play and who's playing. It starts in fullscreen.
- **Profiles**: tap the player name on the title screens. Each player has their
  own high scores and achievements. Your old saves went to "Player 1".
- **Achievements and high scores**: the Game Center button opens them. There
  are 24 achievements, tracked per player.
- **Classic Mode levels 51-999**: 16 new formations, then harder mixes, faster
  spins, smaller dots and drifting formations. You get an extra life every
  50 levels, and clearing 999 beats Blix.
- **Copy Cat** (Mini Games): the developers left this mode unfinished. Copy the
  squiggle the hand draws. You have 3 lives.
- **Tutorial**: a "skip tutorial" button at the bottom right. Once a player has
  skipped or finished it, the game opens on the title screen for them.
- **Pause menu**: the pause button in the game's header (or Esc / P) pauses any
  mode. From there you can resume, restart, quit, and turn sound and music on
  or off. The game also pauses itself when you switch to another tab.
- **Colour keys**: while playing, 1-6 pick a squiggle colour (each palette
  square shows its number) and the up / down arrows step through them.
- **Create**: make maps of fixed levels or endless waves. The Create screen
  lists your maps with a preview, your best score or progress, and play, edit,
  export, copy and delete.
- **The editor**:
  - The object menu at the bottom has tabs:
    - dots: sizes, 2/3/5 hits, any-colour, shifting
    - blocks: walls, jails, grids
    - shapes: every formation from the game
    - zones: shaded "no squiggles" circles you can't squiggle in, and dashed
      "squiggle here" circles. While one of those is on the paper, you can
      only squiggle inside it. A squiggle that runs into a zone stops there.
  - Move tab: slide (across, up-down, diagonal), circle, wave, square,
    figure 8 or pulse, in small/medium/large amounts and slow/normal/fast
    speeds. Drag the blue handles to fine-tune a path.
  - Spin tab: make one object or a group spin at any speed in either direction.
    Drag the blue cross to change the point it spins around.
  - Level tab: add, copy, reorder and delete levels.
  - Tools: select (tap, shift-click, or drag a box), group select (draw a loop
    around things like a squiggle; tap to add or drop one), erase, snap to the
    paper's grid, and mirror placing.
  - Selecting things opens a details card with:
    - colour, size, hits, and colour-shift speed
    - movement distance and loop time, and spin
    - copy / delete / group / turn / flip / line up / spread
    Sizes go from a speck to most of the paper (also [ and ]).
  - Dots and blocks always stay on the paper: they never go over the colour
    palette or the header, in the editor or in the game, even when moving.
  - The header has:
    - preview, to watch everything move
    - hitboxes, which shows what the squiggle actually collides with
    - noclip
    - undo/redo, settings, save and playtest
    Hitboxes and noclip also work in playtests (H and N keys).
  - Noclip: in a playtest, nothing costs a life. Squiggles pass through blocks
    and wrong-colour dots, and running out of time or squiggles doesn't end the
    level. Each of those is counted as a death instead: the screen flashes red,
    and the deaths and your accuracy (good hits / good hits + deaths) show at
    the bottom right.
  - Settings:
    - map: title, description, author
    - rules: levels or endless, goal (high score or "just finish it", with no
      score), lives, time limit, blocks cost a life, how fast shifting dots
      change colour
    - squiggles: a squiggle limit per level or wave, one at a time, one per
      colour, speed
    - endless: wave options
    - level: name, and its own time limit and squiggle limit
    - editor: options, and keyboard shortcuts
  - With a squiggle limit, the header counts down the squiggles left. Running
    out with dots still on the paper costs a life and restarts the level.
  - Snap-to-grid, mirror placing, copy/paste between levels and keyboard
    shortcuts (listed under Settings > keys) are also available.
- **.blix files**: use "export" in Create to save one, and "load file" or drop
  a .blix file on the window to load one. Maps from earlier versions of the
  editor still load.

## What's different from the phone

- Ads, Facebook, Kiip and the "rate this app" prompts are switched off. The
  Share button still shows but can't post anywhere.
- Startup's call to the game's old server always fails, the same way it would
  on a phone with no internet.

## Rebuilding from the .ipa

```
python tools/build.py "../Blix 1.03.ipa"
python tools/build.py --scripts        # after editing engine/ or mods/ only
```

This needs Python 3 (with Pillow and numpy) and Java. It extracts the app,
decompiles the scripts with unluac and repairs a decompiler artifact
(`tools/fix_multret.py`). It also converts Apple's iOS-only PNGs and regenerates
`game-data.js` and `engine/engine-lua.js`.

## Layout

| Path | What it is |
| --- | --- |
| `index.html` | Page, start screen, alert styling |
| `engine/corona.js` | Engine: display objects, rendering, touch, audio, storage, system APIs |
| `engine/lua/corona_init.lua` | Lua 5.1 compatibility, event system, stubs for phone-only services |
| `engine/lua/*.lua` (others) | Solar2D's open-source timer, transition, easing, composer and json (MIT) |
| `engine/fengari-web.js` | Fengari Lua VM (MIT), patched to print numbers like Lua 5.1 |
| `game/lua/` | Decompiled game scripts (generated) |
| `game/res/` | Converted images and sounds (generated) |
| `game-data.js` | Everything the page loads, bundled (generated) |
| `mods/*.lua` | Blix! 1.0 additions (bundled into `mods/mods-lua.js`) |

Debugging: open `index.html?debug` to see Lua errors on screen.
