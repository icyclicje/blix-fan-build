------------------------------------------------------------------------------
-- mod_copycat.lua
-- Finishes Copy Cat ("See how far you can get by copying what I do."), which
-- shipped unfinished and hidden. Each level the hand taps a colour and draws a
-- squiggle; dots sit where that squiggle's replays will pass. Copy it to clear
-- them. Three lives; a miss costs one and shows the squiggle again.
------------------------------------------------------------------------------

local ui = mods.ui
local ach = mods.achievements

local state = {}

local function clearDemo()
	if state.demo then
		display.remove( state.demo.ghost )
		display.remove( state.demo.hand )
		state.demo = nil
	end
	if state.fade then transition.cancel( state.fade ); state.fade = nil end
end

-- Catmull-Rom through the control points, sampled every few units
local function spline( pts )
	local out = {}
	local function at( i ) return pts[math.max( 1, math.min( #pts, i ) )] end
	for i = 1, #pts - 1 do
		local p0, p1, p2, p3 = at( i - 1 ), at( i ), at( i + 1 ), at( i + 2 )
		local len = math.sqrt( ( p2.x - p1.x ) ^ 2 + ( p2.y - p1.y ) ^ 2 )
		local steps = math.max( 4, math.floor( len / 4 ) )
		for s = 0, steps - 1 do
			local t = s / steps
			local t2, t3 = t * t, t * t * t
			local function f( a, b, c, d )
				return 0.5 * ( 2 * b + ( -a + c ) * t + ( 2 * a - 5 * b + 4 * c - d ) * t2 + ( -a + 3 * b - 3 * c + d ) * t3 )
			end
			out[#out + 1] = { x = f( p0.x, p1.x, p2.x, p3.x ), y = f( p0.y, p1.y, p2.y, p3.y ) }
		end
	end
	out[#out + 1] = { x = pts[#pts].x, y = pts[#pts].y }
	return out
end

local function inside( x, y, m )
	return x > _canvasLeft + m and x < _canvasRight - m and y > _canvasTop + m and y < _canvasBottom - m
end

-- build a squiggle and the dots its replays will cross
local function makeLevel( level )
	local dotR = math.max( 7, 12 - math.floor( level / 4 ) )
	local nDots = math.min( 8, 2 + math.floor( level / 2 ) )
	local nCtrl = 3 + math.min( 4, math.floor( level / 3 ) )
	local span = 70 + math.min( 110, level * 8 )
	for attempt = 1, 40 do
		local heading = math.rad( math.random( -50, 50 ) + ( math.random() < 0.25 and 180 or 0 ) )
		local sx = heading > math.pi / 2 and math.random( math.floor( _canvasW2 ), math.floor( _canvasRight - 40 ) )
			or math.random( math.floor( _canvasLeft + 30 ), math.floor( _canvasW2 ) )
		local sy = math.random( math.floor( _canvasTop + 50 ), math.floor( _canvasBottom - 50 ) )
		local ctrl = { { x = sx, y = sy } }
		local step = span / ( nCtrl - 1 )
		local hx, hy = math.cos( heading ), math.sin( heading )
		local ok = true
		for i = 2, nCtrl do
			local side = ( i % 2 == 0 and 1 or -1 ) * math.random( 18, 40 )
			local base = ctrl[1]
			local d = step * ( i - 1 )
			local x = base.x + hx * d - hy * side
			local y = base.y + hy * d + hx * side
			if not inside( x, y, 15 ) then ok = false; break end
			ctrl[#ctrl + 1] = { x = x, y = y }
		end
		if ok then
			local path = spline( ctrl )
			local first, last = path[1], path[#path]
			local ox, oy = last.x - first.x, last.y - first.y
			local olen = math.sqrt( ox * ox + oy * oy )
			if olen >= 45 then
				local dots = {}
				for k = 1, 7 do
					if #dots >= nDots then break end
					for _ = 1, 2 do
						if #dots >= nDots then break end
						local p = path[math.random( 1, #path )]
						local x, y = p.x + ox * k, p.y + oy * k
						local free = inside( x, y, dotR + 4 )
						for _, d in ipairs( dots ) do
							if ( d.x - x ) ^ 2 + ( d.y - y ) ^ 2 < ( 2 * dotR + 8 ) ^ 2 then free = false end
						end
						if free then dots[#dots + 1] = { x = x, y = y } end
					end
				end
				if #dots >= math.min( 2, nDots ) then
					return { path = path, dots = dots, r = dotR, color = gameutils.getRandomColor() }
				end
			end
		end
	end
	return nil
end

-- hand taps the colour, then draws the squiggle
local function playDemo()
	clearDemo()
	local lvl = state.level
	if not lvl or _game_ended then return end
	local ghost = display.newGroup()
	_group:insert( ghost )
	local hand = display.newImageRect( _group, "images/hand_pointer_bw_194x246.png", 24.5, 30.75 )
	hand.anchorX, hand.anchorY = 0.37, 0.04
	local ci = ui.colorIndex( lvl.color ) or 1
	local size = screenHeight / 6
	local px, py = screenLeft + size / 2, screenTop + size * ( ci - 0.5 )
	hand.x, hand.y = _canvasW2, _canvasBottom
	hand.alpha = 0
	state.demo = { ghost = ghost, hand = hand, phase = "toPalette", t = 0, drawn = 1 }
	transition.to( hand, { time = 200, alpha = 1 } )
	transition.to( hand, { time = 450, x = px, y = py, transition = easing.inOutQuad, onComplete = function()
		if not state.demo or state.demo.hand ~= hand then return end
		sounds.play( sounds.palette and sounds.palette[ci] or sounds.hits[1], 0.5 )
		utils.pop( hand, 120, 0.85 )
		transition.to( hand, { delay = 250, time = 450, x = lvl.path[1].x, y = lvl.path[1].y, transition = easing.inOutQuad, onComplete = function()
			if state.demo and state.demo.hand == hand then state.demo.phase = "draw" end
		end } )
	end } )
end

local function finishDemo()
	local d = state.demo
	if not d then return end
	d.phase = "done"
	transition.to( d.hand, { time = 300, alpha = 0 } )
	local lvl = state.level.number
	if lvl > 9 then
		state.fade = transition.to( d.ghost, { time = 400, alpha = 0 } )
	elseif lvl > 3 then
		state.fade = transition.to( d.ghost, { delay = 1200, time = 1500, alpha = 0 } )
	end
end

mods.afterRequire( "game_copycat", function( cc )
	cc.lives = 3

	cc.onSetupGame = function( self )
		clearDemo()
		state = {}
	end

	cc.onLevelUp = function( self, level )
		clearDemo()
		state.cleared = false
		local lvl = makeLevel( level )
		if not lvl then timer.performWithDelay( 100, function() _levelUp( 0 ) end ); return end
		lvl.number = level
		state.level = lvl
		for i, d in ipairs( lvl.dots ) do
			target.new( _group, { x = d.x, y = d.y, radius = lvl.r, color = lvl.color, delay = 100 + i * 80 } )
		end
		sounds.play( sounds.bbAppear, 0.75 )
		timerStash["copycat demo"] = timer.performWithDelay( 300 + #lvl.dots * 80, playDemo )
	end

	cc.onEnterFrame = function( self, frame )
		local d = state.demo
		if not d or d.phase ~= "draw" or _game_paused then return end
		local path = state.level.path
		d.t = d.t + 1 / ( _FPS or 60 )
		local dur = 0.8 + #path / 120
		local upto = math.min( #path, math.floor( #path * d.t / dur ) + 1 )
		while d.drawn < upto do
			local a, b = path[d.drawn], path[d.drawn + 1]
			local seg = display.newLine( d.ghost, a.x, a.y, b.x, b.y )
			seg.strokeWidth = 3
			seg:setStrokeColor( state.level.color() )
			seg.alpha = 0.35
			d.drawn = d.drawn + 1
		end
		d.hand.x, d.hand.y = path[upto].x, path[upto].y
		if upto >= #path then finishDemo() end
	end

	cc.onCorrectTargetHit = function( self, s, t )
		local x, y = t.parent:localToContent( t.x, t.y )
		_addToScore( 1, 1 )
		gameutils.showPopupScore( x, y, 1, t.color, 14 )
		t:remove( 200 )
		if target.numInPlay == 0 and not state.cleared then
			state.cleared = true
			if _level >= 5 then ach.unlock( "COPYCAT_5" ) end
			if _level >= 20 then ach.unlock( "COPYCAT_20" ) end
			timerStash["copycat next"] = timer.performWithDelay( 600, function()
				if not _game_ended then _levelUp( 500 ) end
			end )
		end
	end

	cc.onStrokeLost = function( self, s )
		if state.cleared or _game_ended or target.numInPlay == 0 then return end
		_loseLife()
		if _lives > 0 then
			timerStash["copycat again"] = timer.performWithDelay( 500, function()
				if not _game_ended then playDemo() end
			end )
		end
	end

	local cleanup = cc.onCleanUp
	cc.onCleanUp = function( self )
		clearDemo()
		if cleanup then cleanup( self ) end
	end
end )

return {}
