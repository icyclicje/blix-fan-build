------------------------------------------------------------------------------
-- game_custom.lua
-- Plays a Create-mode map inside the normal game scene, like the built-in
-- modes do (game_main, game_swarm, ...). Supports fixed levels or endless
-- waves, groups that move / pulse / spin together, moving dots and blocks,
-- multi-hit / any-colour / colour-shifting dots, time limits, custom lives,
-- squiggle zones (shaded circles you can't squiggle in, dashed ones you can
-- only squiggle in), squiggle limits, maps played for completion instead of
-- score,
-- playtesting from the editor, a hitbox view and noclip (nothing costs a
-- life; deaths and accuracy are counted instead).
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui
local motion = require "mod_motion"
local ach = mods.achievements
local levelfile = mods.levelfile

local M = {}

local function colorFor( c, phase )
	if c == "any" or c == "shift" then return ui.palette[( phase % 6 ) + 1] end
	return ui.palette[c] or red
end

function M.new( map, opts )
	opts = opts or {}
	local rules = map.rules
	local g = {
		map = map,
		playtest = opts.playtest,
		name = opts.playtest and "__playtest" or ( "custom:" .. map.id ),
		displayName = map.title,
		instructions = ( map.description and map.description ~= "" ) and map.description or "Clear all the dots!",
		scoring = rules.goal ~= "complete",
		leveling = true,
		lives = ( rules.lives or 0 ) > 0 and rules.lives or nil,
		oneStrokeAtOnce = rules.oneStroke,
		oneStrokePerColorAtOnce = rules.onePerColor,
		multitouch = false,
		replaySpeedMultiplier = rules.speed or 1,
		hitboxes = opts.hitboxes and true or false,
		noclip = opts.noclip and true or false,
	}
	-- scene_game only starts straight away for modes without an instructions card
	if opts.playtest then g.instructions = nil end

	local S = {}           -- per-game state
	local instances = {}   -- placed copies of a level (several per wave in endless)
	local byTarget = {}    -- target display object -> runtime record
	local boundsCache = setmetatable( {}, { __mode = "k" } )

	local function canvas() return ui.canvas() end

	local function eachRuntime( fn )
		for _, inst in ipairs( instances ) do
			for _, rt in ipairs( inst.list ) do fn( rt, inst ) end
		end
	end

	local function clearLevel()
		eachRuntime( function( rt )
			display.remove( rt.ring )
			display.remove( rt.box )
			if rt.obj and not rt.obj.removed and rt.obj.remove then rt.obj:remove( 0 ) end
		end )
		for _, inst in ipairs( instances ) do
			for _, z in ipairs( inst.zones or {} ) do display.remove( z.obj ) end
		end
		S.blocked, S.last = {}, {}
		instances, byTarget = {}, {}
		display.remove( S.lines )
		S.lines = nil
		S.levelDone = false
		S.t = 0
	end

	local function currentLevel()
		return map.mode == "levels" and map.levels[S.level] or nil
	end

	local function setTimerText()
		if not S.timerText then return end
		if S.timeLimit and S.timeLimit > 0 then
			S.timerText.isVisible = true
			S.timerText.text = ui.fmtSeconds( S.timeLeft )
			S.timerText:setFillColor( ( S.timeLeft <= 5 and red or darkgray )() )
		else
			S.timerText.isVisible = false
		end
	end

	local function setSquiggleText()
		local t = S.squiggleText
		if not t then return end
		if not S.limit or S.limit <= 0 then t.isVisible = false; return end
		t.isVisible = true
		local n = math.max( 0, S.left )
		t.text = n == 0 and "No squiggles" or ( n == 1 and "1 Squiggle" or ( n .. " Squiggles" ) )
		t:setFillColor( ( n == 0 and red or darkgray )() )
	end

	local function note( text, color )
		display.remove( S.note )
		-- playtests have buttons along the bottom, so notes go at the top of the paper
		local y = g.playtest and ( _canvasTop + 14 ) or ( _canvasBottom - 15 )
		local t = display.newText( _group, text, _canvasW2, y + ui.offset( 14 ), ui.font(), 14 )
		t:setFillColor( ( color or darkgray )() )
		S.note = t
		transition.to( t, { delay = 3000, time = 800, alpha = 0 } )
	end

	local function bringHudToFront()
		for _, b in ipairs( S.buttons or {} ) do b:toFront() end
		if S.timerText then S.timerText:toFront() end
		if S.noclipText then S.noclipText:toFront() end
		if S.squiggleText then S.squiggleText:toFront() end
	end

	-- hitbox view ------------------------------------------------------------------

	local function makeBox( rt )
		if rt.box or not rt.obj then return end
		local o = rt.obj
		local box = display.newCircle( _group, o.x, o.y, math.max( 1, rt.r ) )
		box:setFillColor( 0, 0, 0, 0 )
		box.strokeWidth = 1.2
		if rt.def.kind == "block" then box:setStrokeColor( 0.85, 0.15, 0.15 ) else box:setStrokeColor( 0.1, 0.55, 0.2 ) end
		rt.box = box
	end

	local function setHitboxes( on )
		g.hitboxes = on
		eachRuntime( function( rt )
			if on and rt.obj and not rt.obj.removed then makeBox( rt )
			elseif not on then display.remove( rt.box ); rt.box = nil end
		end )
		if not on then display.remove( S.lines ); S.lines = nil end
	end

	-- the line a squiggle actually collides with (its centre line)
	local function drawStrokeLines()
		display.remove( S.lines )
		S.lines = display.newGroup()
		_group:insert( S.lines )
		for _, s in ipairs( stroke.list ) do
			if not s.removed and s.visibleLines then
				for _, l in ipairs( s.visibleLines ) do
					if not l.removed and l.x1 then
						local seg = display.newLine( S.lines, l.x1, l.y1, l.x2, l.y2 )
						seg.strokeWidth = 1
						seg:setStrokeColor( 0, 0, 0, 0.7 )
					end
				end
			end
		end
	end

	-- noclip ----------------------------------------------------------------------------
	-- Squiggles pass through blocks and wrong-colour dots, and running out of time or
	-- squiggles doesn't end the level. Each of those counts as a death instead, and
	-- accuracy is good hits / (good hits + deaths), shown at the bottom right.

	local function setNoclipText()
		local t = S.noclipText
		if not t then return end
		t.isVisible = g.noclip
		if not g.noclip then return end
		local total = S.good + S.deaths
		local pct = total == 0 and 100 or math.floor( 100 * S.good / total + 0.5 )
		t.text = "Deaths " .. S.deaths .. "    Accuracy " .. pct .. "%"
		t:setFillColor( ( S.deaths > 0 and red or darkgray )() )
	end

	-- the whole screen flushes red while you're "dead", then fades back
	local function noclipTint()
		local t = S.tint
		if not t or not t.removeSelf then
			t = display.newRect( _group, _W2, _H2, screenWidth * 1.2, screenHeight * 1.2 )
			local r, gg, b = red()
			t:setFillColor( r, gg * 0.6, b * 0.6 )
			t.alpha = 0
			S.tint = t
		end
		t:toFront()
		if S.tintFade then transition.cancel( S.tintFade ) end
		t.alpha = 0.28
		S.tintFade = transition.to( t, { delay = 150, time = 400, alpha = 0 } )
	end

	local function noclipDeath( obj )
		noclipTint()
		S.deaths = S.deaths + 1
		setNoclipText()
		if S.noclipText then utils.pop( S.noclipText, 100, 1.12 ) end
		if obj and not obj.removed then utils.pop( obj ) end
		sounds.play( sounds.die, 0.12 )
	end

	-- a squiggle touching the same thing again straight away is the same death
	local function newContact( st, obj )
		local now = system.getTimer()
		local c = S.contacts[st]
		if not c then c = {}; S.contacts[st] = c end
		local last = c[obj]
		c[obj] = now
		return not last or now - last > 300
	end

	-- dots and blocks -----------------------------------------------------------------

	local function ringRadius( rt ) return rt.r + 2.5 * ( rt.hitsLeft - 1 ) end

	local function updateRing( rt )
		if not rt.ring then return end
		if rt.hitsLeft <= 1 then
			display.remove( rt.ring )
			rt.ring = nil
			return
		end
		local d = ringRadius( rt ) * 2
		rt.ring.width, rt.ring.height = d, d
	end

	-- where a dot or block is drawn: on the paper, never over the palette or header
	local function placeOf( inst, it, p, c )
		local px, py = motion.inside( inst.dx + p.x, inst.dy + p.y, motion.outer( it, p.r ), c.w, c.h )
		return c.left + px, c.top + py
	end

	local function spawnItem( inst, it, delay )
		local c = canvas()
		local p = inst.pos[it]
		local x, y = placeOf( inst, it, p, c )
		local rt = { def = it, r = p.r, phase = math.random( 0, 5 ) }
		if it.kind == "block" then
			rt.obj = obstacle.new( _group, { x = x, y = y, radius = p.r, delay = delay } )
		else
			local color = it.color
			if type( color ) == "number" and inst.recolor then color = inst.recolor[color] end
			rt.color = color
			rt.shiftMs = levelfile.shiftMs( map, it )
			rt.hitsLeft = it.hits or 1
			if rt.hitsLeft > 1 then
				rt.ring = display.newImageRect( _group, "images/circle_256.png", ringRadius( rt ) * 2, ringRadius( rt ) * 2 )
				rt.ring:setFillColor( colors.getDarker( colorFor( color, 0 ), 1.6 ) )
				rt.ring.x, rt.ring.y = x, y
				rt.ring.alpha = 0
				transition.to( rt.ring, { delay = delay, time = 300, alpha = 0.55 } )
			end
			local t = target.new( _group, { x = x, y = y, radius = p.r, color = colorFor( color, rt.phase ), delay = delay } )
			rt.obj = t
			byTarget[t] = rt
			-- multi-hit dots: every hit before the last one only shrinks the ring
			local hit = t.hit
			t.hit = function( self )
				if rt.hitsLeft > 1 then
					rt.hitsLeft = rt.hitsLeft - 1
					self.whenHit = system.getTimer()
					utils.pop( self, 120, 1.35 )
					updateRing( rt )
					timer.performWithDelay( 450, function() if not self.removed then self.whenHit = nil end end )
					return
				end
				rt.cleared = true
				return hit( self )
			end
		end
		if g.hitboxes then makeBox( rt ) end
		inst.list[#inst.list + 1] = rt
		return rt
	end

	-- squiggle zones live on their own layer just above the paper
	local function spawnZone( inst, it, delay )
		local c = canvas()
		local p = inst.pos[it]
		local z = { def = it, kind = it.kind, r = p.r }
		z.obj = ui.zone( S.zoneLayer, it.kind, c.left + inst.dx + p.x, c.top + inst.dy + p.y, p.r )
		z.obj.alpha = 0
		transition.to( z.obj, { delay = delay, time = 300, alpha = 1 } )
		inst.zones[#inst.zones + 1] = z
	end

	local function spawnInstance( level, dx, dy, recolor, delayBase )
		local inst = { level = level, dx = dx or 0, dy = dy or 0, recolor = recolor, list = {}, pos = {}, zones = {} }
		motion.positions( level, 0, inst.pos )
		for i, it in ipairs( level.items ) do
			if levelfile.isZone( it ) then spawnZone( inst, it, ( delayBase or 0 ) + 30 )
			else spawnItem( inst, it, ( delayBase or 0 ) + 60 + i * 20 ) end
		end
		instances[#instances + 1] = inst
		return inst
	end

	local function remainingDots()
		local n = 0
		eachRuntime( function( rt ) if rt.def.kind == "dot" and not rt.cleared then n = n + 1 end end )
		return n
	end

	-- levels / waves ---------------------------------------------------------------------

	local function levelBounds( level )
		local b = boundsCache[level]
		if not b then
			b = { motion.bounds( level ) }
			boundsCache[level] = b
		end
		return b[1], b[2], b[3], b[4]
	end

	local function shuffledColors()
		local p = { 1, 2, 3, 4, 5, 6 }
		for i = 6, 2, -1 do local j = math.random( i ); p[i], p[j] = p[j], p[i] end
		return p
	end

	local function spawnWave( wave )
		local e = map.endless
		local count = math.min( e.start + math.floor( ( wave - 1 ) / math.max( 1, e.every ) ), e.max )
		local pool = {}
		for _, lv in ipairs( map.levels ) do if #lv.items > 0 then pool[#pool + 1] = lv end end
		if #pool == 0 then return end
		local c = canvas()
		local placed = {}
		for n = 1, count do
			local lv = pool[math.random( #pool )]
			local bx0, by0, bx1, by1 = levelBounds( lv )
			local w, h = bx1 - bx0, by1 - by0
			for _ = 1, 40 do
				local nx = math.random() * math.max( 0, c.w - w - 8 ) + 4
				local ny = math.random() * math.max( 0, c.h - h - 8 ) + 4
				local free = true
				for _, r in ipairs( placed ) do
					if nx < r[3] + 6 and nx + w + 6 > r[1] and ny < r[4] + 6 and ny + h + 6 > r[2] then free = false; break end
				end
				if free then
					placed[#placed + 1] = { nx, ny, nx + w, ny + h }
					spawnInstance( lv, nx - bx0, ny - by0, e.recolor and shuffledColors() or nil, ( n - 1 ) * 300 )
					break
				end
			end
		end
	end

	local function finishMap()
		S.complete = true
		-- the header already moved on to a level that doesn't exist; put it back
		for i = 1, _group.numChildren do
			local child = _group[i]
			if child and child.size and type( child.text ) == "string" and child.text:match( "^Level %d+$" ) then
				child.text = "Level " .. #map.levels
			end
		end
		_level = #map.levels
		if not g.playtest then ach.unlock( "CREATE_CLEAR" ) end
		sounds.play( sounds.levelup, 1 )
		_endGame( 600 )
	end

	local function startTimer( seconds )
		S.timeLimit = seconds
		S.timeFull = seconds
		S.timeLeft = seconds
		S.lastWhole = math.ceil( seconds )
		setTimerText()
	end

	local function spawnCurrent()
		clearLevel()
		S.failing = false
		S.strokes, S.lastClear, S.lastStroke = {}, nil, nil
		S.limit = levelfile.squiggleLimit( map, currentLevel() )
		S.left = S.limit
		S.toldOut = false
		setSquiggleText()
		if map.mode == "endless" then
			spawnWave( S.level )
			startTimer( rules.time or 0 )
		else
			local lv = map.levels[S.level]
			spawnInstance( lv, 0, 0, nil, 0 )
			startTimer( ( lv.time and lv.time >= 0 ) and lv.time or ( rules.time or 0 ) )
		end
		bringHudToFront()
	end

	local function levelCleared()
		S.levelDone = true
		timerStash["custom next level"] = timer.performWithDelay( 700, function()
			if not _game_ended then _levelUp( 800 ) end
		end )
	end

	local function failLevel( message )
		if S.levelDone or _game_ended or S.failing then return end
		if g.noclip then
			-- no restart: count it, then carry on with a fresh clock / squiggles
			noclipDeath()
			note( message .. "  (noclip)", red )
			if S.timeLimit and S.timeLimit > 0 and S.timeLeft <= 0 then
				S.timeLeft = S.timeFull or S.timeLimit
				S.lastWhole = math.ceil( S.timeLeft )
				setTimerText()
			end
			if S.limit and S.limit > 0 and S.left <= 0 then
				S.left = S.limit
				S.strokes = {}
				setSquiggleText()
			end
			return
		end
		S.failing = true
		sounds.play( sounds.die, 0.3 )
		note( message, red )
		local lv = currentLevel()
		if g.lives and not ( lv and lv.bonus ) then _loseLife() end
		if not _game_ended then
			stroke.removeAll()
			timerStash["custom retry level"] = timer.performWithDelay( 600, function()
				if not _game_ended then spawnCurrent() end
			end )
			S.timeLimit = 0
			setTimerText()
		end
	end

	local function timeUp() failLevel( "Time's up!" ) end

	-- out of squiggles: none left to draw, and the last ones are gone or have
	-- stopped clearing dots (a closed loop can circle forever)
	local OUT_IDLE_MS = 5000
	local function checkSquiggles()
		if not S.limit or S.limit <= 0 or S.left > 0 or S.levelDone or S.failing then return end
		if next( S.last ) ~= nil then return end            -- still drawing the last one
		if remainingDots() == 0 then return end
		local alive = false
		for _, st in ipairs( S.strokes ) do if not st.removed then alive = true end end
		if not alive or S.t - math.max( S.lastClear or 0, S.lastStroke or 0 ) > OUT_IDLE_MS then
			failLevel( "Out of squiggles!" )
		end
	end

	-- squiggle zones ---------------------------------------------------------------------------
	-- The game draws squiggles from Runtime touches; this listener runs just before
	-- it and edits the event: a touch that starts where you can't squiggle is turned
	-- into one the game ignores, and a squiggle that runs into a zone ends there.

	-- is (x, y) off limits? (and which zones to show)
	local function zoneCheck( x, y )
		local drawZones, inDraw = nil, false
		for _, inst in ipairs( instances ) do
			for _, z in ipairs( inst.zones or {} ) do
				local dx, dy = x - z.obj.x, y - z.obj.y
				local inside = dx * dx + dy * dy < z.r * z.r
				if z.kind == "nodraw" then
					if inside then return true, { z } end
				else
					drawZones = drawZones or {}
					drawZones[#drawZones + 1] = z
					if inside then inDraw = true end
				end
			end
		end
		if drawZones and not inDraw then return true, drawZones end
		return false
	end

	-- the last free point on the way from (x0, y0) to (x1, y1), if the way is blocked
	local function cutPoint( x0, y0, x1, y1 )
		local len = math.sqrt( ( x1 - x0 ) ^ 2 + ( y1 - y0 ) ^ 2 )
		local steps = math.max( 1, math.ceil( len / 3 ) )
		local px, py = x0, y0
		for i = 1, steps do
			local f = i / steps
			local qx, qy = x0 + ( x1 - x0 ) * f, y0 + ( y1 - y0 ) * f
			local blocked, zones = zoneCheck( qx, qy )
			if blocked then
				local ax, ay, bx, by = px, py, qx, qy
				for _ = 1, 6 do
					local mx, my = ( ax + bx ) / 2, ( ay + by ) / 2
					if zoneCheck( mx, my ) then bx, by = mx, my else ax, ay = mx, my end
				end
				return ax, ay, zones
			end
			px, py = qx, qy
		end
		return nil
	end

	-- a little pencil cross where the squiggle was stopped, and the zone blinks
	local function refuse( x, y, zones, message )
		local mark = display.newGroup()
		_group:insert( mark )
		mark.x, mark.y = x, y
		for i = -1, 1, 2 do
			local l = display.newLine( mark, -4, -4 * i, 4, 4 * i )
			l.strokeWidth = 1.6
			l:setStrokeColor( darkgray() )
		end
		transition.to( mark, { delay = 250, time = 450, alpha = 0, onComplete = function() display.remove( mark ) end } )
		for _, z in ipairs( zones or {} ) do
			if not z.flashing then
				z.flashing = true
				transition.to( z.obj, { time = 90, alpha = 0.35, onComplete = function()
					transition.to( z.obj, { time = 220, alpha = 1, onComplete = function() z.flashing = false end } )
				end } )
			end
		end
		sounds.play( sounds.die, 0.12 )
		local kind = zones and zones[1] and zones[1].kind
		if message then
			note( message, red )
			if S.squiggleText then utils.pop( S.squiggleText ) end
		elseif kind == "nodraw" and not S.toldNo then
			S.toldNo = true
			note( "You can't squiggle in the shaded circles." )
		elseif kind == "drawzone" and not S.toldIn then
			S.toldIn = true
			note( "Squiggle inside the dashed circles." )
		end
	end

	local function zoneFilter( event )
		if not _inPlay or _game_paused or not S.blocked then return false end
		local id = event.id
		local phase = event.phase
		if phase == "began" then
			local blocked, zones = zoneCheck( event.x, event.y )
			if not blocked and S.limit and S.limit > 0 and S.left <= 0 then
				S.blocked[id] = true
				event.phase = "blocked"
				refuse( event.x, event.y, nil, "No squiggles left!" )
				return false
			end
			if blocked then
				S.blocked[id] = true
				event.phase = "blocked"   -- the game ignores this
				refuse( event.x, event.y, zones )
			else
				S.blocked[id] = nil
				S.last[id] = { x = event.x, y = event.y }
			end
		elseif phase == "moved" then
			if S.blocked[id] then
				event.phase = "blocked"
				return false
			end
			local last = S.last[id]
			if last then
				local cx, cy, zones = cutPoint( last.x, last.y, event.x, event.y )
				if cx then
					-- the squiggle ends where it ran into the zone
					event.x, event.y = cx, cy
					event.phase = "ended"
					S.blocked[id] = true
					refuse( cx, cy, zones )
				else
					last.x, last.y = event.x, event.y
				end
			end
		elseif phase == "ended" or phase == "cancelled" then
			if S.blocked[id] then event.phase = "blocked" end
			S.blocked[id], S.last[id] = nil, nil
		end
		return false
	end

	-- game hooks ---------------------------------------------------------------------------

	function g:onSetupGame()
		S = { buttons = {}, t = 0, blocked = {}, last = {}, deaths = 0, good = 0,
			contacts = setmetatable( {}, { __mode = "k" } ) }
		instances, byTarget = {}, {}
		-- zones go just above the paper (the scene's first two children)
		S.zoneLayer = display.newGroup()
		_group:insert( math.min( 3, _group.numChildren + 1 ), S.zoneLayer )
		-- added before the game adds its own touch listener in _startGame, so it runs first
		Runtime:removeEventListener( "touch", zoneFilter )
		Runtime:addEventListener( "touch", zoneFilter )
		_level = ( opts.startLevel or 1 ) - 1
		S.timerText = display.newText( _group, "", ( _canvasW2 + _canvasRight ) / 2 - 10,
			screenTop + ui.HEADER_HEIGHT / 2 + ui.offset( 15 ), ui.font(), 15 )
		S.timerText:setFillColor( darkgray() )
		S.timerText.isVisible = false
		S.squiggleText = display.newText( _group, "", ( _canvasLeft + _canvasW2 ) / 2 + 10,
			screenTop + ui.HEADER_HEIGHT / 2 + ui.offset( 15 ), ui.font(), 15 )
		S.squiggleText:setFillColor( darkgray() )
		S.squiggleText.isVisible = false
		-- noclip stats, bottom right (above the playtest buttons)
		S.noclipText = display.newText( _group, "", screenRight - 8, screenBottom - 37 + ui.offset( 14 ), ui.font(), 14 )
		S.noclipText.anchorX = 1
		setNoclipText()
		local exitLabel = g.playtest and "< edit" or "< quit"
		S.buttons[1] = ui.button( _group, exitLabel, _canvasLeft + 6, screenBottom - 15, function() g:onQuit() end,
			{ color = gray, size = 14, align = "left" } )
		if g.playtest then
			local hb, nb
			local function toggleHitboxes()
				setHitboxes( not g.hitboxes )
				ui.relabel( hb, nil, g.hitboxes and blue or gray )
			end
			local function toggleNoclip()
				g.noclip = not g.noclip
				if g.noclip then S.deaths, S.good = 0, 0 end   -- a fresh count each time it's turned on
				ui.relabel( nb, nil, g.noclip and blue or gray )
				setNoclipText()
			end
			hb = ui.button( _group, "hitboxes", _canvasLeft + 58, screenBottom - 15, toggleHitboxes,
				{ color = g.hitboxes and blue or gray, size = 14, align = "left" } )
			S.buttons[#S.buttons + 1] = hb
			nb = ui.button( _group, "noclip", hb.textObj.contentBounds.xMax + 14, screenBottom - 15, toggleNoclip,
				{ color = g.noclip and blue or gray, size = 14, align = "left" } )
			S.buttons[#S.buttons + 1] = nb
			-- H and N switch them from the keyboard too
			S.keys = function( event )
				if event.phase ~= "down" or event.isCtrlDown or event.isCommandDown or _game_paused then return false end
				if event.keyName == "h" then toggleHitboxes(); return true end
				if event.keyName == "n" then toggleNoclip(); return true end
				return false
			end
			Runtime:addEventListener( "key", S.keys )
			if map.mode == "levels" then
				S.buttons[#S.buttons + 1] = ui.button( _group, "next >", screenRight - 30, screenBottom - 15, function()
					if not _game_ended and _inPlay then _levelUp( 0 ) end
				end, { color = gray, size = 14, align = "right" } )
			end
		end
	end

	function g:onStrokeStarted( st )
		if S.limit and S.limit > 0 then
			S.left = S.left - 1
			S.strokes[#S.strokes + 1] = st
			setSquiggleText()
		end
	end

	function g:onStrokeFinished( st )
		S.lastStroke = S.t
	end

	function g:onQuit()
		if g.playtest and opts.onExit then opts.onExit() else composer.gotoScene( "scene_create" ) end
	end

	function g:onLevelUp( level )
		S.level = level
		if map.mode ~= "endless" and level > #map.levels then
			clearLevel()
			finishMap()
			return
		end
		spawnCurrent()
		if map.mode ~= "endless" then
			local lv = map.levels[level]
			note( lv.bonus and ( lv.name .. "  (no lives lost)" ) or lv.name, lv.bonus and blue or darkgray )
		elseif level > 1 then
			note( "Wave " .. level, darkgray )
		end
		if remainingDots() == 0 then levelCleared() end
	end

	function g:onEnterFrame( frame )
		if S.levelDone or _game_ended or not _inPlay then return end
		local dt = 1000 / ( _FPS or 60 )
		local speed = 1
		if map.mode == "endless" and map.endless.speedUp then speed = math.min( 2, 1 + 0.05 * ( ( S.level or 1 ) - 1 ) ) end
		S.t = ( S.t or 0 ) + dt * speed
		local c = canvas()
		for _, inst in ipairs( instances ) do
			motion.positions( inst.level, S.t, inst.pos )
			for _, rt in ipairs( inst.list ) do
				local obj = rt.obj
				if obj and not obj.removed and not ( rt.cleared and obj.whenHit ) then
					local p = inst.pos[rt.def]
					local x, y = placeOf( inst, rt.def, p, c )
					obj.x, obj.y = x, y
					if math.abs( p.r - rt.r ) > 0.01 then
						rt.r = p.r
						obj.radius = p.r
						obj.width, obj.height = p.r * 2, p.r * 2
						updateRing( rt )
						if rt.box then rt.box.width, rt.box.height = p.r * 2, p.r * 2 end
					end
					if rt.ring then rt.ring.x, rt.ring.y = x, y end
					if rt.box then rt.box.x, rt.box.y = x, y end
					if rt.def.kind == "dot" and not rt.cleared then
						if rt.color == "any" then
							-- glides through every colour
							local f = ( S.t / 900 + rt.phase ) % 6
							local a, b = ui.palette[math.floor( f ) + 1], ui.palette[( math.floor( f ) + 1 ) % 6 + 1]
							local k = f - math.floor( f )
							local r1, g1, b1 = a()
							local r2, g2, b2 = b()
							obj:setFillColor( r1 + ( r2 - r1 ) * k, g1 + ( g2 - g1 ) * k, b1 + ( b2 - b1 ) * k )
						elseif rt.color == "shift" then
							local ph = math.floor( S.t / rt.shiftMs ) + rt.phase
							if ph ~= rt.lastPhase then
								rt.lastPhase = ph
								obj.color = colorFor( "shift", ph )
								obj:setFillColor( obj.color() )
								if S.t > 100 then utils.pop( obj, 100, 1.15 ) end
							end
						end
					end
				elseif rt.box and obj and obj.removed then
					display.remove( rt.box )
					rt.box = nil
				end
			end
		end
		for _, inst in ipairs( instances ) do
			for _, z in ipairs( inst.zones ) do
				local p = inst.pos[z.def]
				z.obj.x, z.obj.y = c.left + inst.dx + p.x, c.top + inst.dy + p.y
				if math.abs( p.r - z.r ) > 0.01 then
					z.r = p.r
					local k = p.r / z.obj.r0
					z.obj.xScale, z.obj.yScale = k, k
				end
			end
		end
		if g.hitboxes and frame % 2 == 0 then drawStrokeLines() end
		if frame % 10 == 0 then checkSquiggles() end
		if S.timeLimit and S.timeLimit > 0 then
			S.timeLeft = S.timeLeft - dt / 1000
			local whole = math.ceil( S.timeLeft )
			if whole ~= S.lastWhole then
				S.lastWhole = whole
				setTimerText()
				if whole <= 5 and whole > 0 then
					utils.pop( S.timerText )
					sounds.play( sounds.hits[1], 0.4 )
				end
			end
			if S.timeLeft <= 0 then timeUp() end
		end
	end

	function g:onCorrectTargetHit( s, t )
		local rt = byTarget[t]
		if rt then
			S.good = S.good + 1    -- every hit counts towards accuracy, tough dots too
			setNoclipText()
		end
		if not rt or not rt.cleared or rt.scored then return end
		rt.scored = true
		S.lastClear = S.t
		if g.scoring then
			local x, y = t.parent:localToContent( t.x, t.y )
			_addToScore( 1, 1 )
			gameutils.showPopupScore( x, y, 1, rt.color == "any" and yellow or t.color, 14 )
		end
		display.remove( rt.ring )
		rt.ring = nil
		display.remove( rt.box )
		rt.box = nil
		if remainingDots() == 0 and not S.levelDone then levelCleared() end
	end

	function g:onWrongTargetHit( s, t )
		local rt = byTarget[t]
		if rt and rt.color == "any" and not t.whenHit then
			t:hit()
			sounds.play( sounds.hits[math.min( 9, #s.targetsHit + 1 )], 1 )
			s.targetsHit[#s.targetsHit + 1] = t
			return self:onCorrectTargetHit( s, t )
		end
		if g.noclip then
			noclipTint()   -- stays red while the squiggle is still in it
			if newContact( s, t ) then noclipDeath( t ) end
			return
		end
		s:lost( 100 )
		utils.pop( t )
		local lv = currentLevel()
		if not ( lv and lv.bonus ) then _loseLife() end
	end

	function g:onObstacleHit( s, o )
		if g.noclip then
			noclipTint()
			if newContact( s, o ) then noclipDeath( o ) end
			return
		end
		s:lost( 100 )
		utils.pop( o )
		local lv = currentLevel()
		if rules.blocksCostLife and not ( lv and lv.bonus ) then _loseLife() end
	end

	function g:onCleanUp()
		Runtime:removeEventListener( "touch", zoneFilter )
		if S.keys then Runtime:removeEventListener( "key", S.keys ) end
		display.remove( S.noclipText )
		if S.tintFade then transition.cancel( S.tintFade ) end
		display.remove( S.tint )
		clearLevel()
		display.remove( S.zoneLayer )
		for _, b in ipairs( S.buttons or {} ) do display.remove( b ) end
		display.remove( S.timerText )
		display.remove( S.squiggleText )
		display.remove( S.note )
		S = {}
	end

	-- the start card shows the high score; maps played to finish show progress instead
	function g:onPopup( options )
		local p = options and options.params
		if g.scoring or not p or type( p.title ) ~= "string" or not p.title:match( "^High Score" ) then return end
		local rec = not g.playtest and mods.library.progressFor( map.id ) or nil
		local best = rec and tonumber( rec.best ) or 0
		if map.mode == "endless" then
			p.title = best > 0 and ( "Best: wave " .. best ) or map.title
		elseif rec and rec.done then
			p.title = "Completed!"
		elseif best > 0 then
			p.title = "Cleared " .. best .. " of " .. #map.levels
		else
			p.title = map.title
		end
	end

	-- our own end card instead of the standard results pop-up
	function g:onResultOverlay( options )
		local p = options.params or {}
		local best = progress.getHighScore( g.name )
		local title = S.complete and "Map complete!" or "Game over"
		local text
		local n = #map.levels
		local endless = map.mode == "endless"
		-- how far you got: levels cleared, or the wave you reached
		local reached = endless and ( S.level or 1 ) or ( S.complete and n or math.max( 0, ( S.level or 1 ) - 1 ) )
		local record = not g.playtest and mods.library.recordProgress( map.id, reached, S.complete ) or nil
		if g.scoring then
			text = "Score " .. ui.commas( _score )
			if not g.playtest then text = text .. "   Best " .. ui.commas( math.max( best, _score ) ) end
		elseif endless then
			text = "You reached wave " .. reached
			if record then text = text .. "   Best " .. record.best end
		elseif S.complete then
			text = n == 1 and "Level cleared!" or ( "All " .. n .. " levels cleared!" )
		else
			text = "You cleared " .. reached .. " of " .. n .. ( n == 1 and " level" or " levels" )
		end
		local popup = {
			title = title, text = text,
			bgStrokeWidth = 2, bgStrokeColor = darkgray, bgColor = white, bgAlpha = 1, dimAlpha = 0.1,
			lineSpacingAdjust = 6, titleColor = gray, textWidth = 220, fontSize = 22, textColor = darkgray,
		}
		if g.playtest then
			popup.okText, popup.okTextColor = "Edit", blue
			popup.okCallBackFn = function() if opts.onExit then opts.onExit() end end
			popup.cancelText, popup.cancelTextColor = "Retry", green
			popup.cancelCallBackFn = p.retryFn
		else
			popup.okText, popup.okTextColor = "Retry", green
			popup.okCallBackFn = p.retryFn
			popup.cancelText, popup.cancelTextColor = "Back", black
			popup.cancelCallBackFn = function() composer.gotoScene( "scene_create" ) end
		end
		composer.showOverlay( "_scene_popup", { isModal = true, effect = "zoomOutIn", time = 100, params = popup } )
		return true
	end

	return g
end

return M
