------------------------------------------------------------------------------
-- mod_prefabs.lua
-- Everything you can place in the editor, sorted into the object menu's tabs:
-- dots, blocks, shapes (every formation from the game, built from the game's
-- own pattern data at the size Classic Mode draws them) and squiggle zones.
--
-- build( color ) returns items relative to (0, 0); grouped prefabs are placed
-- as one group so they move and spin together.
------------------------------------------------------------------------------

local M = {}

local SCALE = 1.3   -- Classic Mode draws formations 1.3x (ring jails another 1.25x)

local function dot( x, y, r, color, hits ) return { kind = "dot", x = x, y = y, r = r, color = color, hits = hits or 1 } end
local function block( x, y, r ) return { kind = "block", x = x, y = y, r = r } end
local function zone( kind, x, y, r ) return { kind = kind, x = x, y = y, r = r } end

local function single( make ) return function( color ) return { make( color ) } end end

M.dots = {
	{ id = "dot", label = "dot", build = single( function( c ) return dot( 0, 0, 10, c ) end ) },
	{ id = "small dot", label = "small", build = single( function( c ) return dot( 0, 0, 7, c ) end ) },
	{ id = "big dot", label = "big", build = single( function( c ) return dot( 0, 0, 14, c ) end ) },
	{ id = "huge dot", label = "huge", build = single( function( c ) return dot( 0, 0, 20, c ) end ) },
	{ id = "2 hits", label = "2 hits", build = single( function( c ) return dot( 0, 0, 11, c, 2 ) end ) },
	{ id = "3 hits", label = "3 hits", build = single( function( c ) return dot( 0, 0, 12, c, 3 ) end ) },
	{ id = "5 hits", label = "5 hits", build = single( function( c ) return dot( 0, 0, 13, c, 5 ) end ) },
	{ id = "any colour", label = "any colour", build = single( function() return dot( 0, 0, 10, "any" ) end ) },
	{ id = "shifting", label = "shifting", build = single( function() return dot( 0, 0, 10, "shift" ) end ) },
	{ id = "dot pair", label = "pair", grouped = true, build = function( c ) return { dot( -16, 0, 9, c ), dot( 16, 0, 9, c ) } end },
	{ id = "dot trio", label = "trio", grouped = true, build = function( c ) return { dot( -26, 0, 8, c ), dot( 0, 0, 8, c ), dot( 26, 0, 8, c ) } end },
}

local function row( n, step, r, vertical )
	local out = {}
	for i = 1, n do
		local d = ( i - ( n + 1 ) / 2 ) * step
		out[#out + 1] = vertical and block( 0, d, r ) or block( d, 0, r )
	end
	return out
end

-- the game's own jail and grid layouts (building_block.lua)
local function starJail( s, r )
	return { block( 0, -s * 1.1, r ), block( s * 1.05, -s * 0.35, r ), block( s * 0.65, s * 0.9, r ),
		block( -s * 0.65, s * 0.9, r ), block( -s * 1.05, -s * 0.35, r ) }
end
local function ringJail( s, r )
	local d = s / math.sqrt( 2 )
	return { block( 0, -s, r ), block( 0, s, r ), block( -s, 0, r ), block( s, 0, r ),
		block( -d, -d, r ), block( d, -d, r ), block( -d, d, r ), block( d, d, r ) }
end
local function grid( cols, rows, spacing, r, hollow )
	local out = {}
	local x0 = -spacing * ( ( cols - 2 ) / 2 + 0.5 )
	local y0 = -spacing * ( ( rows - 2 ) / 2 + 0.5 )
	for j = 1, rows do
		for i = 1, cols do
			if not hollow or i == 1 or i == cols or j == 1 or j == rows then
				out[#out + 1] = block( x0 + ( i - 1 ) * spacing, y0 + ( j - 1 ) * spacing, r )
			end
		end
	end
	return out
end

M.blocks = {
	{ id = "block", label = "block", build = single( function() return block( 0, 0, 6 ) end ) },
	{ id = "small block", label = "small", build = single( function() return block( 0, 0, 4 ) end ) },
	{ id = "big block", label = "big", build = single( function() return block( 0, 0, 10 ) end ) },
	{ id = "boulder", label = "boulder", build = single( function() return block( 0, 0, 16 ) end ) },
	{ id = "wall", label = "wall", grouped = true, build = function() return row( 3, 15, 6 ) end },
	{ id = "long wall", label = "long wall", grouped = true, build = function() return row( 6, 13, 5 ) end },
	{ id = "pillar", label = "pillar", grouped = true, build = function() return row( 3, 15, 6, true ) end },
	{ id = "corner", label = "corner", grouped = true, build = function()
		return { block( -15, -15, 5 ), block( -15, 0, 5 ), block( -15, 15, 5 ), block( 0, 15, 5 ), block( 15, 15, 5 ) }
	end },
	{ id = "cross", label = "cross", grouped = true, build = function()
		return { block( 0, 0, 6 ), block( -15, 0, 6 ), block( 15, 0, 6 ), block( 0, -15, 6 ), block( 0, 15, 6 ) }
	end },
	{ id = "box", label = "box", grouped = true, build = function() return grid( 5, 5, 13, 4, true ) end },
	{ id = "ring jail", label = "ring jail", grouped = true, build = function() return ringJail( 35 * SCALE * 1.25, 4 * SCALE ) end },
	{ id = "star jail", label = "star jail", grouped = true, build = function() return starJail( 35 * SCALE, 5 * SCALE ) end },
	{ id = "grid", label = "grid", grouped = true, build = function() return grid( 3, 3, 30, 4 * SCALE ) end },
	{ id = "hollow grid", label = "hollow grid", grouped = true, build = function() return grid( 4, 4, 30, 4 * SCALE, true ) end },
}

-- shaded circles you can't squiggle in, and clean ones you can only squiggle in
M.zones = {
	{ id = "no squiggles", label = "no squiggles", build = single( function() return zone( "nodraw", 0, 0, 40 ) end ) },
	{ id = "small no squiggles", label = "small", build = single( function() return zone( "nodraw", 0, 0, 24 ) end ) },
	{ id = "big no squiggles", label = "big", build = single( function() return zone( "nodraw", 0, 0, 64 ) end ) },
	{ id = "huge no squiggles", label = "huge", build = single( function() return zone( "nodraw", 0, 0, 100 ) end ) },
	{ id = "squiggle here", label = "squiggle here", build = single( function() return zone( "drawzone", 0, 0, 60 ) end ) },
	{ id = "small squiggle here", label = "small", build = single( function() return zone( "drawzone", 0, 0, 40 ) end ) },
	{ id = "big squiggle here", label = "big", build = single( function() return zone( "drawzone", 0, 0, 90 ) end ) },
	{ id = "huge squiggle here", label = "huge", build = single( function() return zone( "drawzone", 0, 0, 130 ) end ) },
}

-- a formation from building_block.types -> items
local function fromFormation( bt, color )
	local k = SCALE
	if bt.name and bt.name:match( "in ring jail" ) then k = SCALE * 1.25 end
	local items = {}
	for _, t in ipairs( bt.targets or {} ) do items[#items + 1] = dot( t.x * k, t.y * k, t.r * k, color ) end
	for _, o in ipairs( bt.obstacles or {} ) do items[#items + 1] = block( o.x * k, o.y * k, o.r * k ) end
	local function add( list ) for _, b in ipairs( list ) do b.x, b.y, b.r = b.x * k, b.y * k, b.r * k; items[#items + 1] = b end end
	if bt.star_jail then add( starJail( bt.star_jail.size, bt.star_jail.r ) ) end
	if bt.octagon_jail then add( ringJail( bt.octagon_jail.size, bt.octagon_jail.r ) ) end
	if bt.grid then add( grid( bt.grid.cols, bt.grid.rows, bt.grid.spacing, bt.grid.r ) ) end
	if bt.hollow_grid then add( grid( bt.hollow_grid.cols, bt.hollow_grid.rows, bt.hollow_grid.spacing, bt.hollow_grid.r, true ) ) end
	return items
end

local SHORT = {
	["two dots"] = "2 dots", ["three dots"] = "3 dots", ["five dots"] = "5 dots",
	["1 in ring jail"] = "1 jailed", ["2 in ring jail"] = "2 jailed", ["3 in ring jail"] = "3 jailed",
	["grid three dots"] = "grid 3", ["triangle jail"] = "tri jail", ["walled off"] = "walled",
	["simple hop"] = "hop", ["square corner obstacle"] = "sq corner", ["triangle with center"] = "tri + 1",
	["square with center"] = "sq + 1", ["4 o 3 t in line"] = "in line", ["tombstone"] = "tomb",
	["grid horse"] = "horse", ["grid square"] = "grid sq", ["grid pyramid"] = "grid pyr",
	["grid zig"] = "grid zig", ["perpendicular 3-2 lines"] = "3-2 lines", ["hollow grid H"] = "grid H",
	["grid stairs"] = "stairs", ["double paw"] = "2 paws", ["four corners"] = "corners",
	["ring of six"] = "ring of 6", ["checkerboard"] = "checkers", ["double ring"] = "2 rings",
	["constellation"] = "stars",
}

-- built on first use, once the game's pattern data has loaded
local shapes
function M.shapes()
	if shapes then return shapes end
	shapes = {}
	local seen = {}
	local list = {}
	if building_block and building_block.types_array then
		for _, bt in ipairs( building_block.types_array ) do list[#list + 1] = bt end
	end
	local ok, levels = pcall( require, "mod_levels" )
	if ok and levels and levels.types then
		for _, bt in ipairs( levels.types ) do list[#list + 1] = bt end
	end
	for _, bt in ipairs( list ) do
		if not seen[bt.name] then
			seen[bt.name] = true
			shapes[#shapes + 1] = {
				id = bt.name, label = SHORT[bt.name] or bt.name, grouped = true,
				build = function( color ) return fromFormation( bt, color ) end,
			}
		end
	end
	return shapes
end

function M.tab( name )
	if name == "dots" then return M.dots end
	if name == "blocks" then return M.blocks end
	if name == "shapes" then return M.shapes() end
	if name == "zones" then return M.zones end
	return {}
end

-- size of a prefab (for fitting previews)
function M.extent( items )
	local e = 1
	for _, it in ipairs( items ) do
		local r = it.r + 2.5 * ( ( it.hits or 1 ) - 1 )
		e = math.max( e, math.abs( it.x ) + r, math.abs( it.y ) + r )
	end
	return e
end

return M
