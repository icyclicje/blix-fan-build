------------------------------------------------------------------------------
-- mod_init.lua
-- Blix! 1.0 additions: title screen, local profiles, local achievements,
-- Classic levels 51-999, Copy Cat and Create mode.
-- Runs after config.lua and before main.lua; main.lua is started from the
-- title screen (scene_splash) once a player presses Play.
------------------------------------------------------------------------------

mods = {}
mods.VERSION_LABEL = "Blix! 1.0"

-- Run hooks the first time a module is required, so additions can patch
-- the original game modules without editing them.
local hooks = {}
function mods.afterRequire( name, fn )
	hooks[name] = hooks[name] or {}
	table.insert( hooks[name], fn )
	if package.loaded[name] ~= nil then fn( package.loaded[name] ) end
end

local _require = require
require = function( name, ... )
	local fresh = package.loaded[name] == nil
	local m = _require( name, ... )
	if fresh and hooks[name] then
		for _, fn in ipairs( hooks[name] ) do fn( m ) end
	end
	return m
end

-- Add a table listener that runs after the scene's own handler.
function mods.onScene( scene, eventName, fn )
	local listener = {}
	listener[eventName] = function( self, event ) return fn( scene, event ) end
	scene:addEventListener( eventName, listener )
end

-- Profiles first: they decide which save files the game reads.
mods.profiles = require "mod_profiles"

-- Achievements and Game Center replacement must be in place before __all loads.
package.preload["_gamenetwork_utils"] = function() return require( "mod_achievements" ).gamenetwork end

globals = require "globals"
require "__all"

mods.ui = require "mod_ui"
mods.achievements = require "mod_achievements"
mods.levelfile = require "mod_levelfile"
require "mod_title"
require "mod_levels"
require "mod_copycat"
require "mod_create"
require "mod_pause"
require "mod_keys"

-- results for custom maps and playtests use their own pop-up
local composer = require "composer"
local _showOverlay = composer.showOverlay
composer.showOverlay = function( sceneName, options )
	if sceneName == "_scene_result" and _game and _game.onResultOverlay then
		if _game:onResultOverlay( options ) then return end
	end
	-- lets a mode reword the start card (custom maps played for completion)
	if sceneName == "_scene_popup" and _game and _game.onPopup then _game:onPopup( options ) end
	return _showOverlay( sceneName, options )
end

composer.gotoScene( "scene_splash" )
