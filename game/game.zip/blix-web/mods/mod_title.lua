------------------------------------------------------------------------------
-- mod_title.lua
-- Additions to existing screens: title (version label, Create, player badge),
-- Mini Games menu (Copy Cat), tutorial (skip tutorial).
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui

local function findChild( group, label )
	for i = 1, group.numChildren do
		local c = group[i]
		if c and c.text == label then return c end
	end
	return nil
end

-- title screen --------------------------------------------------------------

local badgeName

local function refreshBadge()
	local p = mods.profiles.current()
	if badgeName and p then
		ui.relabel( badgeName, p.name, ui.palette[p.color] or darkgray )
	end
end

mods.afterRequire( "scene_title", function( scene )
	mods.onScene( scene, "create", function( scene, event )
		local g = scene.view

		local version = findChild( g, "v" .. string.format( "%.2f", APP_VERSION / 100 ) )
		if version then version.text = mods.VERSION_LABEL end

		-- Mini Games and Create share the second row
		local mini = findChild( g, "Mini Games" )
		if mini then mini.x = _W2 - 78 end
		ui.button( g, "Create", _W2 + 86, _H2 + 50, function()
			analytics.logEvent( "Create button" )
			composer.gotoScene( "scene_create" )
		end, { color = green, size = 30 } )

		-- who's playing (top left)
		ui.text( g, "playing as", screenLeft + 12, screenTop + 14, 10, gray, 0 )
		badgeName = ui.button( g, " ", screenLeft + 12, screenTop + 31, function()
			composer.showOverlay( "scene_profiles", { isModal = true, effect = "zoomOutIn", time = 100,
				params = { onChange = refreshBadge } } )
		end, { size = 18, align = "left" } )
		refreshBadge()
	end )
	mods.onScene( scene, "show", function( scene, event )
		if event.phase == "did" then refreshBadge() end
	end )
end )

-- Mini Games: Copy Cat takes the "More Coming" slot -------------------------------

mods.afterRequire( "scene_minigames_menu", function( scene )
	mods.onScene( scene, "create", function( scene, event )
		local g = scene.view
		local slot = findChild( g, "More Coming" )
		if not slot then return end
		local x, y = slot.x, slot.y
		display.remove( slot )
		-- the original game never loaded Copy Cat; load it here
		game_copycat = game_copycat or require( "game_copycat" )
		ui.button( g, game_copycat.displayName, x, y, function()
			composer.gotoScene( "scene_game", { params = { game = game_copycat } } )
		end, { color = green, size = 24 } )
	end )
end )

-- Tutorial: skip the whole thing -------------------------------------------------

-- The game starts on the tutorial until you've scored in Classic Mode. Once a
-- player has finished or skipped it, start them on the title screen instead.
do
	local gotoScene = composer.gotoScene
	composer.gotoScene = function( sceneName, options )
		if sceneName == "scene_game" and options and options.params and game_tutorial
			and options.params.game == game_tutorial and mods.profiles.flag( "tutorialDone" ) then
			return gotoScene( "scene_title" )
		end
		return gotoScene( sceneName, options )
	end
end

mods.afterRequire( "game_tutorial", function( tut )
	local skipButton
	local setup, cleanup = tut.onSetupGame, tut.onCleanUp
	tut.onSetupGame = function( self, ... )
		if setup then setup( self, ... ) end
		local right = screenRight - 30
		for i = 1, _group.numChildren do
			local child = _group[i]
			if child and child.text == "skip >" and child.textObj then right = child.textObj.contentBounds.xMax end
		end
		skipButton = ui.button( _group, "skip tutorial", right, screenBottom - 37, function()
			analytics.logEvent( "Tutorial Skipped" )
			mods.profiles.setFlag( "tutorialDone", true )
			composer.gotoScene( "scene_title" )
		end, { color = gray, size = 14, align = "right" } )
	end

	tut.onCleanUp = function( self, ... )
		display.remove( skipButton )
		skipButton = nil
		if cleanup then cleanup( self, ... ) end
	end
end )
