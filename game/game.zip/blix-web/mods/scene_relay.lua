------------------------------------------------------------------------------
-- scene_relay.lua
-- Passes straight back into the game scene, so a game can be restarted from
-- the pause menu with a fresh scene (composer won't re-enter the scene that
-- is already showing).
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui

local scene = composer.newScene()

function scene:create( event )
	ui.paper( self.view, 0.15 )
end

function scene:show( event )
	if event.phase == "did" then
		local p = event.params or {}
		composer.gotoScene( "scene_game", { params = { game = p.game, skip_instructions = true } } )
	end
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
return scene
