------------------------------------------------------------------------------
-- scene_profiles.lua
-- "Who's playing?" card: switch, add, rename and delete local players.
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui
local profiles = mods.profiles

local scene = composer.newScene()

local W, H = 280, 250
local MAX_PLAYERS = 6
local params = {}
local panel, field

local function clearPanel()
	if field then field:removeSelf(); field = nil end
	display.remove( panel )
	panel = display.newGroup()
	scene.view:insert( panel )
end

local function close()
	if field then field:removeSelf(); field = nil end
	composer.hideOverlay( false, "zoomOutIn", 100 )
end

local function changed()
	if params.onChange then params.onChange() end
end

local showList, showNameEntry, showConfirmDelete

-- list of players
function showList( editing )
	clearPanel()
	local top = _H2 - H / 2
	ui.text( panel, editing and "Tap a player to edit" or "Who's playing?", _W2, top + 28, editing and 18 or 22, gray )
	local list = profiles.list()
	local current = profiles.current()
	local rowH = 25
	local y0 = top + 64
	for i, p in ipairs( list ) do
		local y = y0 + ( i - 1 ) * rowH
		local b = ui.button( panel, p.name, _W2, y, function()
			if editing then
				showNameEntry( p )
			else
				profiles.switch( p.id )
				changed()
				close()
			end
		end, { color = ui.palette[p.color] or darkgray, size = 20 } )
		if not editing and current and p.id == current.id then
			ui.dot( panel, b.textObj.contentBounds.xMin - 10, y - 1, 4, ui.palette[p.color] )
		end
	end
	local fy = top + H - 26
	if editing then
		ui.button( panel, "done", _W2, fy, function() showList( false ) end, { color = black, alpha = 0.6, size = 16 } )
	else
		if #list < MAX_PLAYERS then
			ui.button( panel, "+ new player", _W2 - 80, fy, function() showNameEntry( nil ) end, { color = green, size = 16 } )
		end
		ui.button( panel, "edit", _W2 + 10, fy, function() showList( true ) end, { color = gray, size = 16 } )
		ui.button( panel, "back", _W2 + 80, fy, close, { color = black, alpha = 0.6, size = 16 } )
	end
end

-- new player / rename
function showNameEntry( p )
	clearPanel()
	local top = _H2 - H / 2
	ui.text( panel, p and "Rename player" or "New player", _W2, top + 28, 22, gray )
	local line = display.newRect( panel, _W2, _H2 - 8, 180, 1.5 )
	line:setFillColor( lightgray() )
	field = native.newTextField( _W2, _H2 - 22, 180, 28 )
	field.font = ui.font()
	field.size = 20
	field.maxLength = 16
	field.align = "center"
	field.placeholder = "name"
	field:setTextColor( 0.25, 0.25, 0.25 )
	field.text = p and p.name or ""

	local function submit()
		local name = ( field.text or "" ):gsub( "^%s+", "" ):gsub( "%s+$", "" )
		if name == "" then
			toast.show( "Type a name first.", { time = 1200, textColor = white } )
			return
		end
		if p then
			profiles.rename( p.id, name )
			changed()
			showList( true )
		else
			local np = profiles.create( name )
			profiles.switch( np.id )
			changed()
			close()
		end
	end
	field:addEventListener( "userInput", function( event )
		if event.phase == "submitted" then submit() end
	end )
	native.setKeyboardFocus( field )

	local fy = top + H - 26
	ui.button( panel, p and "save" or "create", _W2 - 70, fy, submit, { color = green, size = 18 } )
	if p and #profiles.list() > 1 then
		ui.button( panel, "delete", _W2, fy, function() showConfirmDelete( p ) end, { color = red, size = 18 } )
	end
	ui.button( panel, "cancel", _W2 + 70, fy, function() showList( p ~= nil ) end, { color = black, alpha = 0.6, size = 18 } )
end

function showConfirmDelete( p )
	clearPanel()
	local top = _H2 - H / 2
	ui.text( panel, "Delete " .. p.name .. "?", _W2, top + 40, 22, darkgray )
	local msg = display.newText( { parent = panel, text = "Their scores and achievements will be erased.",
		x = _W2, y = _H2 - 6 + ui.offset( 15 ), width = 220, font = ui.font(), fontSize = 15, align = "center" } )
	msg:setFillColor( gray() )
	local fy = top + H - 26
	ui.button( panel, "delete", _W2 - 50, fy, function()
		profiles.remove( p.id )
		changed()
		showList( true )
	end, { color = red, size = 18 } )
	ui.button( panel, "cancel", _W2 + 50, fy, function() showList( true ) end, { color = black, alpha = 0.6, size = 18 } )
end

function scene:create( event )
	local g = self.view
	ui.dim( g, 0.1 )
	ui.card( g, _W2, _H2, W, H )
end

function scene:show( event )
	if event.phase == "will" then
		params = event.params or {}
		showList( false )
	end
end

function scene:hide( event )
	if event.phase == "will" and field then field:removeSelf(); field = nil end
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
return scene
