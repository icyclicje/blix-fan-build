------------------------------------------------------------------------------
-- mod_achievements.lua
-- Achievements tracked locally per profile (they used to go to Game Center),
-- plus a local high-score table across profiles.
------------------------------------------------------------------------------

local M = {}

local saver = require "_saver"

M.defs = {
	{ id = "TUTORIAL", name = "Back to School", desc = "Finish the tutorial." },
	{ id = "LEVEL_05", name = "Warming Up", desc = "Clear level 5 in Classic Mode." },
	{ id = "LEVEL_10", name = "Double Digits", desc = "Clear level 10 in Classic Mode." },
	{ id = "LEVEL_20", name = "Squiggle Sense", desc = "Clear level 20 in Classic Mode." },
	{ id = "LEVEL_30", name = "Dot Collector", desc = "Clear level 30 in Classic Mode." },
	{ id = "LEVEL_40", name = "Steady Hand", desc = "Clear level 40 in Classic Mode." },
	{ id = "LEVEL_50", name = "Fifty Up", desc = "Clear level 50 in Classic Mode." },
	{ id = "LEVEL_75", name = "Off the Map", desc = "Clear level 75 in Classic Mode." },
	{ id = "LEVEL_100", name = "Century", desc = "Clear level 100 in Classic Mode." },
	{ id = "LEVEL_150", name = "Paper Trail", desc = "Clear level 150 in Classic Mode." },
	{ id = "LEVEL_200", name = "Drifter", desc = "Clear level 200 in Classic Mode." },
	{ id = "LEVEL_250", name = "Quarter Way There", desc = "Clear level 250 in Classic Mode." },
	{ id = "LEVEL_300", name = "Spin Doctor", desc = "Clear level 300 in Classic Mode." },
	{ id = "LEVEL_400", name = "Ink to Spare", desc = "Clear level 400 in Classic Mode." },
	{ id = "LEVEL_500", name = "Halfway There", desc = "Clear level 500 in Classic Mode." },
	{ id = "LEVEL_600", name = "Unstoppable", desc = "Clear level 600 in Classic Mode." },
	{ id = "LEVEL_700", name = "Graph Paper Legend", desc = "Clear level 700 in Classic Mode." },
	{ id = "LEVEL_800", name = "Almost Famous", desc = "Clear level 800 in Classic Mode." },
	{ id = "LEVEL_900", name = "So Close", desc = "Clear level 900 in Classic Mode." },
	{ id = "LEVEL_999", name = "Blix Master", desc = "Beat Blix! Clear all 999 levels." },
	{ id = "COPYCAT_5", name = "Copy That", desc = "Clear 5 levels of Copy Cat." },
	{ id = "COPYCAT_20", name = "Perfect Copy", desc = "Clear 20 levels of Copy Cat." },
	{ id = "CREATE_SAVE", name = "Level Designer", desc = "Save your first map in Create." },
	{ id = "CREATE_CLEAR", name = "Map Maker", desc = "Clear every level of a map." },
}
M.byId = {}
for i, d in ipairs( M.defs ) do d.index = i; M.byId[d.id] = d end

-- Classic level milestones: level -> achievement id
M.levelMilestones = {}
for _, d in ipairs( M.defs ) do
	local n = d.id:match( "^LEVEL_(%d+)$" )
	if n then M.levelMilestones[#M.levelMilestones + 1] = { level = tonumber( n ), id = d.id } end
end

M.data = { unlocked = {} }

function M.reload()
	local d = saver.Load( "achievements.txt" )
	if type( d ) ~= "table" or type( d.unlocked ) ~= "table" then d = { unlocked = {} } end
	M.data = d
end

local function save() saver.Save( M.data, "achievements.txt" ) end

function M.isUnlocked( id ) return M.data.unlocked[id] ~= nil end

function M.count()
	local n = 0
	for _, d in ipairs( M.defs ) do if M.data.unlocked[d.id] then n = n + 1 end end
	return n, #M.defs
end

function M.unlock( id )
	local d = M.byId[id]
	if not d or M.data.unlocked[id] then return false end
	M.data.unlocked[id] = os.time()
	save()
	-- finishing the tutorial means it no longer opens the game
	if id == "TUTORIAL" and mods.profiles then mods.profiles.setFlag( "tutorialDone", true ) end
	mods.ui.banner( "Achievement unlocked", d.name, yellow )
	analytics.logEvent( "Achievement " .. id )
	return true
end

-- Classic Mode: unlock every milestone below the level just reached.
function M.checkLevel( level )
	for _, m in ipairs( M.levelMilestones ) do
		if level > m.level then M.unlock( m.id ) end
	end
end

-- "ach_blix_level_05" / "LEVEL_05" / "CgkI..." -> local id
local androidIds = {}
local function normalize( id )
	if type( id ) ~= "string" then return nil end
	if M.byId[id] then return id end
	local short = id:gsub( "^ach_blix_", "" ):upper()
	if M.byId[short] then return short end
	return androidIds[id]
end

-- Drop-in replacement for the game's gamenetwork_utils (Game Center / Google Play).
M.gamenetwork = {
	initGC = function() end,
	sendAchievementProgress = function( id, percent )
		local local_id = normalize( id )
		if local_id and ( percent or 0 ) >= 100 then M.unlock( local_id ) end
	end,
	sendHighScore = function() end,   -- scores are already kept by progress.lua
	showAchievements = function()
		require( "composer" ).showOverlay( "scene_achievements", { isModal = true, effect = "zoomOutIn", time = 100, params = { tab = "achievements" } } )
	end,
	showLeaderboards = function()
		require( "composer" ).showOverlay( "scene_achievements", { isModal = true, effect = "zoomOutIn", time = 100, params = { tab = "scores" } } )
	end,
}

-- modes shown in the High Scores table
M.boards = {
	{ name = "Main", title = "Classic Mode", color = red, showLevel = true },
	{ name = "PointAndShoot", title = "Point and Shoot", color = blue },
	{ name = "Swarm", title = "Swarm", color = purple },
	{ name = "CopyCat", title = "Copy Cat", color = green, showLevel = true },
}

-- { {profile, score, level}, ... } sorted best first
function M.board( gameName )
	local rows = {}
	for _, p in ipairs( mods.profiles.list() ) do
		local s = mods.profiles.scoresFor( p.id )[gameName]
		if s and ( s.highScore or 0 ) > 0 then
			rows[#rows + 1] = { profile = p, score = s.highScore or 0, level = s.highestLevel or 0 }
		end
	end
	table.sort( rows, function( a, b ) return a.score > b.score end )
	return rows
end

M.reload()
return M
