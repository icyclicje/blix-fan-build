------------------------------------------------------------------------------
-- scene_splash.lua
-- Title screen shown before the game starts: "Blix!", Play, and who's playing.
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui

local scene = composer.newScene()

local title, playButton, whoButton
local started = false

local function refreshPlayer()
	local p = mods.profiles.current()
	if not p or not whoButton then return end
	ui.relabel( whoButton, p.name, ui.palette[p.color] or darkgray )
end

local function play()
	if started then return end
	started = true
	native.resumeAudio()
	native.setFullscreen( true )
	transition.to( playButton, { time = 200, alpha = 0.2 } )
	native.runMain()
end

local function choosePlayer()
	composer.showOverlay( "scene_profiles", { isModal = true, effect = "zoomOutIn", time = 100,
		params = { onChange = refreshPlayer } } )
end

function scene:create( event )
	local g = self.view
	ui.paper( g, 0.1 )

	title = display.newText( g, "Blix!", 0, 0, ui.font(), 92 )
	title:setFillColor( black() )
	title.x, title.y = _W2, _H2 - 62 + ui.offset( 92 )

	playButton = ui.button( g, "Play", _W2, _H2 + 38, play, { color = red, size = 46 } )

	ui.text( g, "playing as", _W2, _H2 + 92, 12, gray )
	whoButton = ui.button( g, " ", _W2, _H2 + 112, choosePlayer, { size = 22 } )
	refreshPlayer()
end

function scene:show( event )
	if event.phase == "did" then
		refreshPlayer()
		local letters = #title.text
		utils.typeOutTextObject( title, 0, 160, false, nil )
		local n = 0
		timerStash["splash beeps"] = timer.performWithDelay( 160, function()
			n = n + 1
			sounds.play( sounds.hits[n] )
		end, letters )
	end
end

function scene:hide( event )
	if event.phase == "will" then utils.cancelAllTimersAndTransitions() end
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
return scene
