------------------------------------------------------------------------------
-- mod_pause.lua
-- A pause menu for every game mode: a pause button in the game's header,
-- Esc or P on a keyboard, and an automatic pause when the game's tab is
-- hidden. It uses the game's own (unused) pause switch: _game_paused stops
-- touches and the frame loop, and timers / transitions are held as well,
-- so squiggles, formations, moving maps and time limits all freeze.
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui

local M = {}

local S = { paused = false }
local touches = {}            -- squiggles being drawn (touch id -> true)

local function inGame()
	return composer.getSceneName( "current" ) == "scene_game"
end

local function canPause()
	return inGame() and _inPlay and not _game_ended and _game ~= game_tutorial
		and not composer.getSceneName( "overlay" )
end

local function drawing()
	return next( touches ) ~= nil
end

local function onOff( v ) return v and "on" or "off" end

------------------------------------------------------------------------------
-- header button
------------------------------------------------------------------------------

local function removeButton()
	display.remove( S.button )
	S.button = nil
end

local function makeButton()
	removeButton()
	if not _group or _game == game_tutorial then return end
	local g = display.newGroup()
	_group:insert( g )
	local x, y = _canvasRight - 80, screenTop + ui.HEADER_HEIGHT / 2
	for i = -1, 1, 2 do
		local bar = display.newRoundedRect( g, x + i * 3, y, 2.6, 10, 1.2 )
		bar:setFillColor( darkgray() )
	end
	g.alpha = 0.75
	local hit = display.newRect( g, x, y, 28, ui.HEADER_HEIGHT )
	hit.isVisible = false
	hit.isHitTestable = true
	ui.onTap( hit, function()
		-- tapping the button means no squiggle is being drawn
		touches = {}
		M.pause()
	end )
	g.isVisible = false
	S.button = g
end

local function showButton( on )
	if S.button and S.button.removeSelf then S.button.isVisible = on end
end

------------------------------------------------------------------------------
-- the pause card
------------------------------------------------------------------------------

local function closeMenu()
	display.remove( S.menu )
	S.menu = nil
end

local function infoLine()
	local parts = { _game and _game.displayName or "Blix!" }
	if _game and _game.leveling and ( _level or 0 ) > 0 then parts[#parts + 1] = "Level " .. _level end
	if _game and _game.scoring then parts[#parts + 1] = "Score " .. ui.commas( _score or 0 ) end
	if _game and _game.lives and ( _lives or 0 ) > 0 then parts[#parts + 1] = _lives .. ( _lives == 1 and " life" or " lives" ) end
	return table.concat( parts, "   " )
end

local function openMenu()
	closeMenu()
	local g = display.newGroup()
	display.getCurrentStage():insert( g )
	S.menu = g
	ui.dim( g, 0.12 )
	local W, H = 250, 242
	local top = _H2 - H / 2
	ui.card( g, _W2, _H2, W, H )
	ui.text( g, "Paused", _W2, top + 30, 32, gray )
	local info = ui.text( g, infoLine(), _W2, top + 60, 12, gray )
	-- keep it inside the card
	local iw = info.contentBounds.xMax - info.contentBounds.xMin
	if iw > W - 30 then info.xScale = ( W - 30 ) / iw; info.yScale = info.xScale end

	ui.button( g, "resume", _W2, top + 96, function() M.resume() end, { color = green, size = 28 } )
	ui.button( g, "restart", _W2, top + 130, function() M.restart() end, { color = orange, size = 22 } )
	local quitLabel = ( _game and _game.playtest ) and "back to editor" or "quit"
	ui.button( g, quitLabel, _W2, top + 160, function() M.quit() end, { color = red, size = 22 } )

	local line = display.newRect( g, _W2, top + 182, W - 50, 1 )
	line:setFillColor( 0.9, 0.9, 0.9 )
	local soundB, musicB
	soundB = ui.button( g, "sound " .. onOff( sounds.savedData.soundOn ), _W2 - 52, top + 200, function()
		sounds.toggleSoundSetting()
		ui.relabel( soundB, "sound " .. onOff( sounds.savedData.soundOn ) )
	end, { color = darkgray, size = 15 } )
	musicB = ui.button( g, "music " .. onOff( sounds.savedData.musicOn ), _W2 + 52, top + 200, function()
		sounds.toggleMusicSetting()
		ui.relabel( musicB, "music " .. onOff( sounds.savedData.musicOn ) )
	end, { color = darkgray, size = 15 } )
	ui.text( g, "keys:  1 - 6 pick a colour,  esc pause", _W2, top + 224, 11, lightgray )

	g.alpha = 0
	transition.to( g, { time = 120, alpha = 1 } )
end

------------------------------------------------------------------------------
-- pause / resume / restart / quit
------------------------------------------------------------------------------

function M.isPaused() return S.paused end

function M.pause()
	if S.paused or not canPause() then return end
	if drawing() then
		-- let the squiggle being drawn finish first (it pauses as soon as it's let go)
		S.pending = system.getTimer()
		return
	end
	S.pending = nil
	S.paused = true
	_game_paused = true
	timer.pauseAll()
	transition.pauseAll()
	if _game and _game.onPauseGame then _game:onPauseGame() end
	sounds.playFast( sounds._button_click_fast )
	openMenu()
end

function M.resume()
	if not S.paused then return end
	S.paused = false
	closeMenu()
	timer.resumeAll()
	transition.resumeAll()
	_game_paused = false
	if _game and _game.onContinueGame then _game:onContinueGame() end
end

function M.restart()
	local game = _game
	M.resume()
	if game then
		-- scene_game only starts straight away for modes without an instructions
		-- card; hide the card until the restarted game is under way
		S.instructions = { game = game, text = game.instructions }
		game.instructions = nil
	end
	composer.gotoScene( "scene_relay", { params = { game = game } } )
end

local function restoreInstructions()
	if S.instructions then
		S.instructions.game.instructions = S.instructions.text
		S.instructions = nil
	end
end

function M.quit()
	local game = _game
	M.resume()
	if game and game.onQuit then game:onQuit() else composer.gotoScene( "scene_title" ) end
end

------------------------------------------------------------------------------
-- hooks into the game scene
------------------------------------------------------------------------------

mods.afterRequire( "scene_game", function( scene )
	local setupGame, startGame, endGame = _setupGame, _startGame, _endGame
	_setupGame = function( ... )
		S.paused, S.pending = false, nil
		closeMenu()
		touches = {}
		local r = setupGame( ... )
		makeButton()
		return r
	end
	_startGame = function( ... )
		restoreInstructions()
		local r = startGame( ... )
		showButton( true )
		return r
	end
	_endGame = function( ... )
		showButton( false )
		return endGame( ... )
	end
	mods.onScene( scene, "hide", function( _, event )
		if event.phase == "will" then
			if S.paused then M.resume() end
			closeMenu()
			removeButton()
		end
	end )
end )

-- squiggles in progress (the game draws them from Runtime touches)
Runtime:addEventListener( "touch", function( event )
	if not inGame() then return false end
	if event.phase == "began" then
		touches = {}          -- one pointer at a time: anything older has ended
		touches[event.id] = true
	elseif event.phase == "ended" or event.phase == "cancelled" then
		touches[event.id] = nil
		if S.pending and not drawing() then
			-- after the game has finished this squiggle
			timer.performWithDelay( 1, function() S.pending = nil; M.pause() end )
		end
	end
	return false
end )

Runtime:addEventListener( "enterFrame", function()
	-- don't wait forever for a squiggle whose end went somewhere else
	if S.pending and system.getTimer() - S.pending > 1500 then
		touches = {}
		S.pending = nil
		M.pause()
	end
end )

Runtime:addEventListener( "key", function( event )
	if event.phase ~= "down" or not inGame() then return false end
	local k = event.keyName
	if k == "escape" or k == "p" then
		if S.paused then M.resume() else M.pause() end
		return S.paused or canPause()
	end
	if S.paused and ( k == "enter" or k == "space" ) then M.resume(); return true end
	return false
end )

Runtime:addEventListener( "system", function( event )
	if event.type == "applicationSuspend" then
		touches = {}
		M.pause()
	end
end )

mods.pause = M
return M
