------------------------------------------------------------------------------
-- scene_create.lua
-- Create mode: your maps on the left, the chosen map on the right
-- (preview, details, play / edit / export / copy / delete), plus
-- new map and load file.
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui
local library = mods.library
local levelfile = mods.levelfile

local scene = composer.newScene()

local PER_PAGE = 5
local ROW_H = 40
local title, listGroup, detailGroup, footer, modal
local selectedId, page, previewLevel = nil, 1, 1

-- the palette minus yellow (too pale for text on white)
local TITLE_COLORS = { red, orange, green, blue, purple }
local function mapColor( i ) return TITLE_COLORS[( ( i - 1 ) % #TITLE_COLORS ) + 1] end

local render

local function closeModal()
	display.remove( modal )
	modal = nil
end

local function confirmDelete( map )
	closeModal()
	modal = display.newGroup()
	scene.view:insert( modal )
	ui.dim( modal, 0.1 )
	ui.card( modal, _W2, _H2, 270, 150 )
	ui.text( modal, "Delete this map?", _W2, _H2 - 44, 22, darkgray )
	ui.text( modal, map.title, _W2, _H2 - 12, 18, gray )
	ui.button( modal, "delete", _W2 - 55, _H2 + 40, function()
		library.remove( map.id )
		sounds.play( sounds.bbCleared, 0.5 )
		closeModal()
		selectedId = nil
		render()
	end, { color = red, size = 20 } )
	ui.button( modal, "cancel", _W2 + 55, _H2 + 40, closeModal, { color = black, alpha = 0.6, size = 20 } )
end

-- "best 1,234", "completed", "cleared 2 of 5", "best wave 7" or nil
local function record( m )
	if m.rules.goal ~= "complete" then
		local best = progress.getHighScore( "custom:" .. m.id )
		return best > 0 and ( "best " .. ui.commas( best ) ) or nil
	end
	local p = library.progressFor( m.id )
	if not p then return nil end
	if m.mode == "endless" then return ( p.best or 0 ) > 0 and ( "best wave " .. p.best ) or nil end
	if p.done then return "completed" end
	return ( p.best or 0 ) > 0 and ( "cleared " .. p.best .. " of " .. #m.levels ) or nil
end

local function stats( m )
	local parts = {}
	parts[#parts + 1] = m.mode == "endless" and "endless" or "levels"
	parts[#parts + 1] = m.rules.goal == "complete" and "play to finish" or "play for score"
	local lives = m.rules.lives or 0
	parts[#parts + 1] = lives == 0 and "unlimited lives" or ( lives .. ( lives == 1 and " life" or " lives" ) )
	local t = m.rules.time or 0
	if t > 0 then parts[#parts + 1] = ui.fmtSeconds( t ) .. " each" end
	local sq = m.rules.squiggles or 0
	if sq > 0 then parts[#parts + 1] = sq .. ( sq == 1 and " squiggle" or " squiggles" ) end
	return table.concat( parts, "  /  " )
end

local function shorten( s, max )
	s = ( s or "" ):gsub( "%s+", " " )
	if #s <= max then return s end
	return s:sub( 1, max - 3 ):gsub( "%s+%S*$", "" ) .. "..."
end

local function drawList( maps, selected )
	local x0 = screenLeft + 30
	local w = _W2 + 10 - x0
	if #maps == 0 then
		ui.text( listGroup, "Nothing here yet.", x0, 112, 22, gray, 0 )
		ui.text( listGroup, "Tap \"+ new map\" to make your first one,", x0, 140, 14, lightgray, 0 )
		ui.text( listGroup, "or load a .blix file (you can drop one", x0, 158, 14, lightgray, 0 )
		ui.text( listGroup, "anywhere on the game, too).", x0, 176, 14, lightgray, 0 )
		return
	end
	local pages = math.max( 1, math.ceil( #maps / PER_PAGE ) )
	local first = ( page - 1 ) * PER_PAGE + 1
	for i = first, math.min( first + PER_PAGE - 1, #maps ) do
		local m = maps[i]
		local y = 92 + ( i - first ) * ROW_H
		local isSel = selected and m.id == selected.id
		local bg = display.newRoundedRect( listGroup, x0 + w / 2 - 6, y, w + 4, ROW_H - 4, 7 )
		if isSel then
			bg:setFillColor( 0.39, 0.5, 1, 0.12 )
			bg.strokeWidth = 1.2
			bg:setStrokeColor( blue() )
		else
			bg:setFillColor( 1, 1, 1, 0.01 )
		end
		ui.onTap( bg, function()
			if selectedId == m.id then return end
			selectedId, previewLevel = m.id, 1
			sounds.play( sounds.palette and sounds.palette[( ( i - 1 ) % 6 ) + 1] or sounds.hits[1], 0.4 )
			render()
		end, false )
		ui.thumbnail( listGroup, m.levels[1], x0 + 20, y, 44, 27 )
		ui.text( listGroup, shorten( m.title, 26 ), x0 + 50, y - 7, 17, mapColor( i ), 0 )
		local info = levelfile.summary( m ) .. ( m.author ~= "" and ( "   by " .. m.author ) or "" )
		local t = ui.text( listGroup, info, x0 + 50, y + 10, 10, gray, 0 )
		local rec = record( m )
		if rec then
			ui.text( listGroup, rec, t.contentBounds.xMax + 9, y + 10, 10, rec == "completed" and darkgreen or gray, 0 )
		end
	end
	if pages > 1 then
		local px = x0 + w - 40
		ui.button( listGroup, "<", px - 30, 50, function() page = ( page - 2 ) % pages + 1; render() end, { size = 20, color = darkgray } )
		ui.text( listGroup, page .. "/" .. pages, px, 50, 13, gray )
		ui.button( listGroup, ">", px + 30, 50, function() page = page % pages + 1; render() end, { size = 20, color = darkgray } )
	end
end

local function drawDetail( m )
	local rx = ( _W2 + 30 + screenRight - 20 ) / 2
	if not m then
		ui.text( detailGroup, "Your maps show up here.", rx, 140, 16, lightgray )
		return
	end
	local n = #m.levels
	previewLevel = math.max( 1, math.min( previewLevel, n ) )
	local lv = m.levels[previewLevel]
	ui.thumbnail( detailGroup, lv, rx, 68, 168, 96 )
	if n > 1 then
		-- tap the preview to look through the levels
		local hit = display.newRect( detailGroup, rx, 68, 168, 96 )
		hit.isVisible = false
		hit.isHitTestable = true
		ui.onTap( hit, function()
			previewLevel = previewLevel % n + 1
			render()
		end )
		local word = m.mode == "endless" and "pattern " or "level "
		ui.text( detailGroup, word .. previewLevel .. " of " .. n .. ":  " .. shorten( lv.name, 20 ) .. "   (tap to see more)", rx, 125, 10, lightgray )
	end
	local tsize = #m.title > 18 and 17 or 22
	ui.text( detailGroup, shorten( m.title, 32 ), rx, 141, tsize, black )
	ui.text( detailGroup, ( m.author ~= "" and ( "by " .. m.author ) or "" ), rx, 167, 11, gray )
	local desc = m.description ~= "" and shorten( m.description, 120 ) or "No description."
	local d = display.newText( {
		parent = detailGroup, text = desc, x = rx, y = 177, width = 220,
		font = ui.font(), fontSize = 12, align = "center",
	} )
	d.anchorY = 0
	d:setFillColor( ( m.description ~= "" and darkgray or lightgray )() )
	ui.text( detailGroup, stats( m ), rx, 229, 10, gray )

	ui.button( detailGroup, "play", rx - 40, 250, function()
		if levelfile.countDots( m ) == 0 then
			toast.show( "This map has no dots yet.", { time = 1500 } )
			return
		end
		library.play( m )
	end, { color = red, size = 24 } )
	ui.button( detailGroup, "edit", rx + 40, 250, function()
		composer.gotoScene( "scene_editor", { params = { mapId = m.id } } )
	end, { color = blue, size = 20 } )
	ui.button( detailGroup, "export", rx - 66, 281, function()
		library.export( m )
		toast.show( "Saved " .. levelfile.filename( m ), { time = 1600 } )
	end, { color = purple, size = 14 } )
	ui.button( detailGroup, "copy", rx - 4, 281, function()
		local copy = ui.deepcopy( m )
		copy.id = levelfile.newId()
		copy.title = ( m.title .. " copy" ):sub( 1, 40 )
		copy.created, copy.modified = os.time(), os.time()
		library.put( copy )
		selectedId, page, previewLevel = copy.id, 1, 1
		sounds.play( sounds.bbAppear, 0.5 )
		render()
	end, { color = orange, size = 14 } )
	ui.button( detailGroup, "delete", rx + 56, 281, function() confirmDelete( m ) end, { color = gray, size = 14 } )
end

function render()
	display.remove( listGroup )
	display.remove( detailGroup )
	display.remove( footer )
	listGroup, detailGroup, footer = display.newGroup(), display.newGroup(), display.newGroup()
	scene.view:insert( listGroup )
	scene.view:insert( detailGroup )
	scene.view:insert( footer )

	local maps = library.list()
	local pages = math.max( 1, math.ceil( #maps / PER_PAGE ) )
	page = math.max( 1, math.min( page, pages ) )
	local selected = selectedId and library.get( selectedId )
	if not selected and #maps > 0 then
		selected = maps[( page - 1 ) * PER_PAGE + 1] or maps[1]
		selectedId = selected.id
	end
	if selected then
		-- keep the chosen map on the page being shown
		local _, i = library.get( selected.id )
		page = math.ceil( i / PER_PAGE )
	end

	drawList( maps, selected )
	local divider = display.newRect( detailGroup, _W2 + 24, 160, 1, 230 )
	divider:setFillColor( 0.88, 0.88, 0.88 )
	drawDetail( selected )

	local x0 = screenLeft + 30
	ui.button( footer, "+ new map", x0, 300, function()
		composer.gotoScene( "scene_editor", { params = { newMap = true } } )
	end, { color = green, size = 22, align = "left" } )
	ui.button( footer, "load file", x0 + 128, 300, function()
		library.pickFile( function( map ) selectedId, page, previewLevel = map.id, 1, 1; render() end )
	end, { color = orange, size = 22, align = "left" } )
	ui.button( footer, "back", screenRight - 34, 300, function()
		composer.gotoScene( "scene_title" )
	end, { color = black, alpha = 0.6, size = 18 } )
end

function scene:refresh( id )
	if id then selectedId, page, previewLevel = id, 1, 1 end
	render()
end

function scene:create( event )
	local g = self.view
	ui.paper( g, 0.1 )
	title = display.newText( g, "Create", 0, 0, ui.font(), 46 )
	title:setFillColor( black() )
	title.anchorX = 0
	title.x, title.y = screenLeft + 30, 40 + ui.offset( 46 )
end

function scene:show( event )
	if event.phase == "will" then
		closeModal()
		render()
	elseif event.phase == "did" then
		local letters = #title.text
		utils.typeOutTextObject( title, 0, 120, false, nil )
		local n = 0
		timerStash["create beeps"] = timer.performWithDelay( 120, function()
			n = n + 1
			sounds.play( sounds.hits[n] )
		end, letters )
	end
end

function scene:hide( event )
	if event.phase == "will" then
		utils.cancelAllTimersAndTransitions()
		closeModal()
	end
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
return scene
