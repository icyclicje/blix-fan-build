------------------------------------------------------------------------------
-- mod_levelfile.lua
-- Blix map files (.blix): JSON with a title, description, rules and a list of
-- levels. A level holds dots and blocks ("items") and optional groups; a
-- group's members move, pulse and spin together around its pivot.
-- Coordinates are relative to the top-left corner of the paper.
--
-- Version 2 adds groups and more movements; version 3 adds squiggle zones
-- (no-squiggle and squiggle-only areas), colour-shift speeds and maps played
-- for completion instead of score. Older files still load.
------------------------------------------------------------------------------

local json = require "json"

local M = {}

M.FORMAT = "blix-map"
M.VERSION = 3
M.EXT = ".blix"
M.MAX_LEVELS = 99
M.MAX_ITEMS = 200
M.MAX_GROUPS = 100

local KEY_ORDER = { "format", "version", "id", "title", "description", "author", "created", "modified",
	"mode", "rules", "endless", "levels", "name", "time", "squiggles", "bonus", "items", "groups",
	"kind", "x", "y", "r", "color", "hits", "shiftMs", "group", "move", "spin", "pivot",
	"type", "dx", "dy", "cx", "cy", "w", "h", "amp", "waves", "scale", "ms", "dir", "speed",
	"goal", "lives", "oneStroke", "onePerColor", "blocksCostLife", "shiftMs", "speedUp",
	"start", "max", "every", "recolor" }

function M.newId()
	return string.format( "%x%04x", os.time(), math.random( 0, 65535 ) )
end

M.SHIFT_MS = 1600          -- how often shifting dots change colour, by default

-- the kinds of thing a level can hold
M.KINDS = { dot = true, block = true, nodraw = true, drawzone = true }
function M.isZone( it ) return it.kind == "nodraw" or it.kind == "drawzone" end

function M.defaultRules()
	return { goal = "score", lives = 5, time = 0, squiggles = 0, oneStroke = false, onePerColor = true, speed = 1,
		blocksCostLife = true, shiftMs = M.SHIFT_MS }
end

function M.defaultEndless()
	return { start = 1, max = 4, every = 3, recolor = true, speedUp = true }
end

function M.newLevel( n )
	-- time / squiggles: -1 = use the map's rule
	return { name = "Level " .. n, time = -1, squiggles = -1, bonus = false, items = {}, groups = {} }
end

function M.newMap( author )
	return {
		format = M.FORMAT, version = M.VERSION, id = M.newId(),
		title = "Untitled Map", description = "", author = author or "",
		created = os.time(), modified = os.time(),
		mode = "levels", rules = M.defaultRules(), endless = M.defaultEndless(),
		levels = { M.newLevel( 1 ) },
	}
end

local function num( v, lo, hi, default )
	v = tonumber( v )
	if not v or v ~= v then return default end
	return math.max( lo, math.min( hi, v ) )
end
local function str( v, max, default )
	if type( v ) ~= "string" then return default end
	return v:sub( 1, max )
end
local function bool( v, default )
	if type( v ) == "boolean" then return v end
	return default
end
local function dir( v ) return v == -1 and -1 or 1 end

-- movement, accepting version 1 names (patrol -> slide, orbit -> circle)
function M.sanitizeMove( m, x, y )
	if type( m ) ~= "table" then return nil end
	local c = mods.ui.canvas()
	local W, H = c.w, c.h
	local kind = m.type
	if kind == "patrol" then kind = "slide" elseif kind == "orbit" then kind = "circle" end
	if kind == "slide" then
		return { type = "slide", dx = num( m.dx, -W, W, 60 ), dy = num( m.dy, -H, H, 0 ), ms = num( m.ms, 200, 30000, 2000 ) }
	elseif kind == "circle" then
		return { type = "circle", cx = num( m.cx, -W, 2 * W, ( x or 0 ) - 30 ), cy = num( m.cy, -H, 2 * H, y or 0 ),
			ms = num( m.ms, 300, 60000, 3000 ), dir = dir( m.dir ) }
	elseif kind == "wave" then
		return { type = "wave", dx = num( m.dx, -W, W, 120 ), dy = num( m.dy, -H, H, 0 ), amp = num( m.amp, 0, 150, 20 ),
			waves = math.floor( num( m.waves, 1, 8, 2 ) ), ms = num( m.ms, 300, 30000, 3000 ) }
	elseif kind == "square" then
		return { type = "square", w = num( m.w, -W, W, 60 ), h = num( m.h, -H, H, 60 ), ms = num( m.ms, 400, 60000, 4000 ) }
	elseif kind == "figure8" then
		return { type = "figure8", w = num( m.w, -W, W, 80 ), h = num( m.h, -H, H, 50 ), ms = num( m.ms, 400, 60000, 3600 ), dir = dir( m.dir ) }
	elseif kind == "pulse" then
		return { type = "pulse", scale = num( m.scale, 0.2, 4, 1.6 ), ms = num( m.ms, 200, 30000, 2400 ) }
	end
	return nil
end

function M.sanitizeItem( it )
	if type( it ) ~= "table" then return nil end
	local kind = M.KINDS[it.kind] and it.kind or nil
	if not kind then return nil end
	local c = mods.ui.canvas()
	local zone = kind == "nodraw" or kind == "drawzone"
	local out = {
		kind = kind,
		x = num( it.x, -c.w, 2 * c.w, c.w / 2 ),
		y = num( it.y, -c.h, 2 * c.h, c.h / 2 ),
		r = num( it.r, zone and 2 or 0.25, zone and 400 or 160, zone and 50 or ( kind == "dot" and 10 or 6 ) ),
	}
	if kind == "dot" then
		if it.color == "any" or it.color == "shift" then out.color = it.color
		else out.color = math.floor( num( it.color, 1, 6, 1 ) ) end
		out.hits = math.floor( num( it.hits, 1, 9, 1 ) )
		if out.color == "shift" and it.shiftMs ~= nil then out.shiftMs = math.floor( num( it.shiftMs, 200, 6000, M.SHIFT_MS ) ) end
	end
	if it.group ~= nil then out.group = math.floor( num( it.group, 1, 9999, 1 ) ) end
	out.move = M.sanitizeMove( it.move, out.x, out.y )
	return out
end

function M.sanitizeGroup( g )
	if type( g ) ~= "table" or tonumber( g.id ) == nil then return nil end
	local out = { id = math.floor( num( g.id, 1, 9999, 1 ) ) }
	if type( g.spin ) == "table" and num( g.spin.speed, 0, 1440, 0 ) > 0 then
		out.spin = { speed = num( g.spin.speed, 0, 1440, 90 ), dir = dir( g.spin.dir ) }
	end
	if type( g.pivot ) == "table" then
		out.pivot = { x = num( g.pivot.x, -2000, 2000, 0 ), y = num( g.pivot.y, -2000, 2000, 0 ) }
	end
	local px, py = out.pivot and out.pivot.x or 0, out.pivot and out.pivot.y or 0
	out.move = M.sanitizeMove( g.move, px, py )
	return out
end

function M.sanitizeLevel( lv, i )
	if type( lv ) ~= "table" then return nil end
	local out = {
		name = str( lv.name, 30, "Level " .. i ),
		time = math.floor( num( lv.time, -1, 600, -1 ) ),
		squiggles = math.floor( num( lv.squiggles, -1, 99, -1 ) ),
		bonus = bool( lv.bonus, false ),
		items = {}, groups = {},
	}
	if type( lv.items ) == "table" then
		for j = 1, math.min( #lv.items, M.MAX_ITEMS ) do
			local item = M.sanitizeItem( lv.items[j] )
			if item then out.items[#out.items + 1] = item end
		end
	end
	local used = {}
	for _, it in ipairs( out.items ) do if it.group then used[it.group] = true end end
	local known = {}
	if type( lv.groups ) == "table" then
		for j = 1, math.min( #lv.groups, M.MAX_GROUPS ) do
			local g = M.sanitizeGroup( lv.groups[j] )
			if g and used[g.id] and not known[g.id] then
				known[g.id] = true
				out.groups[#out.groups + 1] = g
			end
		end
	end
	-- a member of a group that wasn't saved becomes a plain item; a group named
	-- by items but missing from the list gets created
	for _, it in ipairs( out.items ) do
		if it.group and not known[it.group] then
			known[it.group] = true
			out.groups[#out.groups + 1] = { id = it.group }
		end
	end
	return out
end

function M.sanitize( t )
	if type( t ) ~= "table" then return nil, "That isn't a Blix map." end
	if t.format ~= M.FORMAT then return nil, "That isn't a Blix map file." end
	if ( tonumber( t.version ) or 1 ) > M.VERSION then return nil, "This map needs a newer Blix." end
	local map = {
		format = M.FORMAT, version = M.VERSION,
		id = str( t.id, 40, nil ) or M.newId(),
		title = str( t.title, 40, "Untitled Map" ),
		description = str( t.description, 300, "" ),
		author = str( t.author, 24, "" ),
		created = num( t.created, 0, 4e9, os.time() ),
		modified = num( t.modified, 0, 4e9, os.time() ),
		mode = ( t.mode == "endless" ) and "endless" or "levels",
		levels = {},
	}
	local r = type( t.rules ) == "table" and t.rules or {}
	local d = M.defaultRules()
	map.rules = {
		goal = ( r.goal == "complete" ) and "complete" or "score",
		lives = math.floor( num( r.lives, 0, 99, d.lives ) ),
		time = math.floor( num( r.time, 0, 600, d.time ) ),
		squiggles = math.floor( num( r.squiggles, 0, 99, d.squiggles ) ),
		oneStroke = bool( r.oneStroke, d.oneStroke ),
		onePerColor = bool( r.onePerColor, d.onePerColor ),
		speed = num( r.speed, 0.5, 2, d.speed ),
		blocksCostLife = bool( r.blocksCostLife, d.blocksCostLife ),
		shiftMs = math.floor( num( r.shiftMs, 200, 6000, d.shiftMs ) ),
	}
	local e = type( t.endless ) == "table" and t.endless or {}
	local de = M.defaultEndless()
	map.endless = {
		start = math.floor( num( e.start, 1, 8, de.start ) ),
		max = math.floor( num( e.max, 1, 8, de.max ) ),
		every = math.floor( num( e.every, 1, 20, de.every ) ),
		recolor = bool( e.recolor, de.recolor ),
		speedUp = bool( e.speedUp, de.speedUp ),
	}
	if map.endless.max < map.endless.start then map.endless.max = map.endless.start end
	if type( t.levels ) == "table" then
		for i = 1, math.min( #t.levels, M.MAX_LEVELS ) do
			local lv = M.sanitizeLevel( t.levels[i], i )
			if lv then map.levels[#map.levels + 1] = lv end
		end
	end
	if #map.levels == 0 then map.levels[1] = M.newLevel( 1 ) end
	return map
end

function M.encode( map )
	return json.encode( map, { indent = true, keyorder = KEY_ORDER } )
end

function M.decode( text )
	if type( text ) ~= "string" or text == "" then return nil, "That file is empty." end
	local ok, t = pcall( json.decode, text )
	if not ok or type( t ) ~= "table" then return nil, "That isn't a Blix map file." end
	return M.sanitize( t )
end

function M.filename( map )
	local base = ( map.title or "map" ):gsub( "[^%w%s%-_]", "" ):gsub( "%s+", " " ):gsub( "^%s+", "" ):gsub( "%s+$", "" )
	if base == "" then base = "map" end
	return base .. M.EXT
end

-- how many squiggles you get for a level (0 = as many as you like)
function M.squiggleLimit( map, lv )
	if lv and lv.squiggles and lv.squiggles >= 0 then return lv.squiggles end
	return map.rules.squiggles or 0
end

-- how often a shifting dot changes colour (ms)
function M.shiftMs( map, it )
	return ( it and it.shiftMs ) or ( map and map.rules and map.rules.shiftMs ) or M.SHIFT_MS
end

function M.countDots( map )
	local n = 0
	for _, lv in ipairs( map.levels ) do
		for _, it in ipairs( lv.items ) do if it.kind == "dot" then n = n + 1 end end
	end
	return n
end

function M.summary( map )
	local n = #map.levels
	if map.mode == "endless" then
		return "endless, " .. n .. ( n == 1 and " pattern" or " patterns" )
	end
	return n .. ( n == 1 and " level" or " levels" )
end

-- next free group id in a level
function M.newGroupId( level )
	local top = 0
	for _, g in ipairs( level.groups or {} ) do top = math.max( top, g.id ) end
	for _, it in ipairs( level.items ) do if it.group then top = math.max( top, it.group ) end end
	return top + 1
end

-- drop groups nobody belongs to (after deleting/ungrouping)
function M.pruneGroups( level )
	local used = {}
	for _, it in ipairs( level.items ) do if it.group then used[it.group] = true end end
	for i = #( level.groups or {} ), 1, -1 do
		if not used[level.groups[i].id] then table.remove( level.groups, i ) end
	end
end

return M
