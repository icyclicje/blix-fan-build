------------------------------------------------------------------------------
-- mod_keys.lua
-- Keyboard shortcuts while playing: 1-6 pick a squiggle colour (red, orange,
-- yellow, green, blue, purple) and up / down step through them. Each palette
-- square shows its number in the corner. (Esc / P pause: see mod_pause.)
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui

local M = {}

local squares = {}   -- the game's palette squares, top to bottom

-- number the squares when the game builds its palette
mods.afterRequire( "palette", function( palette )
	local new = palette.new
	palette.new = function( parent, ... )
		local group = new( parent, ... )
		squares = {}
		for i = 1, group.numChildren do
			local child = group[i]
			if child and type( child.color ) == "function" then squares[#squares + 1] = child end
		end
		for i, sq in ipairs( squares ) do ui.paletteKey( group, i, sq.x, sq.y, palette.size ) end
		return group
	end
end )

-- choose a colour the same way tapping its square does (same sound and marker)
function M.pick( i )
	local sq = squares[i]
	if not sq or not sq.removeSelf or not _inPlay or _game_paused then return false end
	sq:dispatchEvent( { name = "touch", phase = "began", target = sq, x = sq.x, y = sq.y, id = "key" } )
	return true
end

Runtime:addEventListener( "key", function( event )
	if event.phase ~= "down" or composer.getSceneName( "current" ) ~= "scene_game" then return false end
	if event.isCtrlDown or event.isCommandDown or event.isAltDown then return false end
	local k = event.keyName
	local n = tonumber( k )
	if n and n >= 1 and n <= #squares then return M.pick( n ) end
	if ( k == "up" or k == "down" ) and #squares > 0 then
		local cur = 1
		for i, sq in ipairs( squares ) do if sq.color == palette.selectedColor then cur = i end end
		return M.pick( ( cur - 1 + ( k == "down" and 1 or -1 ) ) % #squares + 1 )
	end
	return false
end )

mods.keys = M
return M
