------------------------------------------------------------------------------
-- mod_ui.lua
-- Small helpers so every addition uses Blix's own look: graph paper,
-- the handwritten font, frameless plain-text buttons and white cards.
------------------------------------------------------------------------------

local M = {}

M.HEADER_HEIGHT = 20

function M.font() return _ttf_font[globals.defaultFont] end
function M.offset( size ) return _ttf_font_offset[globals.defaultFont] * size end

M.palette = { red, orange, yellow, green, blue, purple }
M.paletteNames = { "red", "orange", "yellow", "green", "blue", "purple" }

function M.colorIndex( fn )
	for i, c in ipairs( M.palette ) do if c == fn then return i end end
	return nil
end

-- The play area used by scene_game (right of the palette, under the header).
function M.canvas()
	local left = screenLeft + screenHeight / 6
	local top = screenTop + M.HEADER_HEIGHT
	return {
		left = left, top = top, right = screenRight, bottom = screenBottom,
		w = screenRight - left, h = screenBottom - top,
		cx = ( left + screenRight ) / 2, cy = ( top + screenBottom ) / 2,
	}
end

function M.text( group, str, x, y, size, color, anchorX, anchorY )
	local t = display.newText( group, str or "", 0, 0, M.font(), size )
	t:setFillColor( ( color or darkgray )() )
	t.anchorX = anchorX or 0.5
	t.anchorY = anchorY or 0.5
	t.x, t.y = x, y + M.offset( size )
	return t
end

-- Plain-text button in the game's style (buttons.newPlainText).
function M.button( group, label, x, y, fn, opts )
	opts = opts or {}
	local b = buttons.newPlainText( label, fn, {
		group = group,
		textColor = opts.color or darkgray,
		frameless = true,
		fontSize = opts.size or 18,
		fontNum = globals.defaultFont,
		textAnchorX = opts.textAnchorX,
		alphaWhenEnabled = opts.alpha,
		disabled = opts.disabled,
		sound = opts.sound,
	} )
	b.x, b.y = x, y
	if opts.align then
		b._align, b._alignX = opts.align, x
		M.align( b )
	end
	return b
end

-- Line the button's visible text up on its left or right edge
-- (its invisible tap frame is centred on the text, so anchors alone are off).
local function alive( b ) return b and b.removeSelf ~= nil end

function M.align( b )
	if not alive( b ) or not b._align or not alive( b.textObj ) then return end
	local tb = b.textObj.contentBounds
	local edge = b._align == "left" and tb.xMin or tb.xMax
	b.x = b.x + ( b._alignX - edge )
end

-- Change a plain-text button's label/colour in place.
function M.relabel( b, label, color )
	if not alive( b ) then return end   -- its card may have been rebuilt meanwhile
	if label then b.text = label end
	if color then b.textColor = color end
	b:render()
	M.align( b )
end

function M.paper( group, alpha )
	local bg = display.newRect( group, _W2, _H2, screenWidth, screenHeight )
	bg:setFillColor( white() )
	local paper = display.newImageRect( group, "images/graph_paper_1230x919.jpg", screenWidth, screenWidth * 919 / 1230 )
	paper.alpha = alpha or 0.1
	paper.x, paper.y = _W2, _H2
	return bg, paper
end

-- Dim background that swallows touches (like the game's modal pop-ups).
function M.dim( group, alpha )
	local r = display.newRect( group, _W2, _H2, screenWidth * 1.2, screenHeight * 1.2 )
	r:setFillColor( black() )
	r.alpha = alpha or 0.1
	r.isHitTestable = true
	r:addEventListener( "touch", function() return true end )
	return r
end

function M.card( group, x, y, w, h, strokeColor )
	local c = display.newRoundedRect( group, x, y, w, h, 20 )
	c:setFillColor( white() )
	c.strokeWidth = 2
	c:setStrokeColor( ( strokeColor or gray )() )
	c:addEventListener( "touch", function() return true end )
	return c
end

function M.dot( group, x, y, r, color )
	local d = display.newImageRect( group, "images/circle_256.png", r * 2, r * 2 )
	d:setFillColor( ( color or kindadarkgray )() )
	d.x, d.y = x, y
	return d
end

-- "label    -   value   +" row; returns a refresh function.
function M.stepper( group, x, y, w, label, get, change, format, size, valueW )
	size, valueW = size or 14, valueW or 56
	local right = x + w / 2
	local row = {}
	row.label = M.text( group, label, x - w / 2, y, size, gray, 0 )
	row.value = M.text( group, "", right - 18 - valueW / 2, y, size, black )
	local function refresh() row.value.text = format and format( get() ) or tostring( get() ) end
	row.minus = M.button( group, "-", right - 30 - valueW, y, function() change( -1 ); refresh() end, { size = size + 4, color = darkgray } )
	row.plus = M.button( group, "+", right - 6, y, function() change( 1 ); refresh() end, { size = size + 4, color = darkgray } )
	refresh()
	row.refresh = refresh
	return row
end

-- "label    value" row where tapping the value cycles/toggles it.
function M.toggle( group, x, y, w, label, get, change, format, size )
	size = size or 14
	local row = {}
	row.label = M.text( group, label, x - w / 2, y, size, gray, 0 )
	local function text() return format and format( get() ) or tostring( get() ) end
	row.value = M.button( group, text(), x + w / 2, y, function()
		change()
		M.relabel( row.value, text() )
	end, { size = size, color = blue, align = "right" } )
	row.refresh = function() M.relabel( row.value, text() ) end
	return row
end

function M.deepcopy( t )
	if type( t ) ~= "table" then return t end
	local out = {}
	for k, v in pairs( t ) do out[k] = M.deepcopy( v ) end
	return out
end

function M.fmtSeconds( s )
	s = math.max( 0, math.ceil( s ) )
	return string.format( "%d:%02d", math.floor( s / 60 ), s % 60 )
end

function M.commas( n )
	local s = tostring( math.floor( n or 0 ) )
	local out = s:reverse():gsub( "(%d%d%d)", "%1," ):reverse()
	return ( out:gsub( "^,", "" ) )
end

-- Tap on a plain display object: press and release inside it.
function M.onTap( obj, fn, sound )
	obj:addEventListener( "touch", function( event )
		if event.phase == "began" then
			display.getCurrentStage():setFocus( obj, event.id )
			obj._pressed = true
			if sound ~= false then sounds.playFast( sounds._button_click_fast ) end
		elseif event.phase == "ended" or event.phase == "cancelled" then
			display.getCurrentStage():setFocus( nil )
			local inside = false
			if obj._pressed and event.phase == "ended" and obj.contentBounds then
				local b = obj.contentBounds
				inside = event.x >= b.xMin and event.x <= b.xMax and event.y >= b.yMin and event.y <= b.yMax
			end
			obj._pressed = false
			if inside then fn( event ) end
		end
		return true
	end )
end

-- Light panel used by the editor (white, thin grey border, swallows touches).
function M.panel( group, x, y, w, h, radius, alpha )
	local p = display.newRoundedRect( group, x, y, w, h, radius or 10 )
	p:setFillColor( 1, 1, 1, alpha or 1 )
	p.strokeWidth = 1.5
	p:setStrokeColor( 0.84, 0.84, 0.84 )
	p:addEventListener( "touch", function() return true end )
	return p
end

-- Menu cell: highlight box, a preview group to draw into, and a label.
function M.cell( group, x, y, w, h, label, selected, onTap, dimmed )
	local g = display.newGroup()
	group:insert( g )
	local bg = display.newRoundedRect( g, x, y, w, h, 6 )
	if selected then
		bg:setFillColor( 0.39, 0.5, 1, 0.14 )
		bg.strokeWidth = 1.2
		bg:setStrokeColor( blue() )
	else
		bg:setFillColor( 1, 1, 1, 0.01 )
	end
	g.preview = display.newGroup()
	g:insert( g.preview )
	if label and label ~= "" then
		g.label = M.text( g, label, x, y + h / 2 - 6, 9, selected and blue or ( dimmed and lightgray or gray ) )
	end
	if onTap then M.onTap( bg, onTap ) end
	g.bg = bg
	return g
end

-- Row of options; the chosen one is blue and underlined.
function M.segmented( group, x, y, labels, index, onChange, size, gap )
	size, gap = size or 12, gap or 9
	local g = display.newGroup()
	group:insert( g )
	local widths, total = {}, 0
	for i, l in ipairs( labels ) do
		local t = display.newText( l, 0, 0, M.font(), size )
		widths[i] = t.width
		total = total + t.width
		t:removeSelf()
	end
	total = total + gap * ( #labels - 1 )
	local cx = x - total / 2
	for i, l in ipairs( labels ) do
		local bx = cx + widths[i] / 2
		local on = i == index
		M.text( g, l, bx, y, size, on and blue or gray )
		if on then
			local u = display.newRect( g, bx, y + size * 0.62, widths[i], 1.2 )
			u:setFillColor( blue() )
		end
		local hit = display.newRect( g, bx, y, widths[i] + gap, size + 8 )
		hit.isVisible = false
		hit.isHitTestable = true
		M.onTap( hit, function() onChange( i ) end )
		cx = cx + widths[i] + gap
	end
	g.width_ = total
	return g
end

-- Plain-text buttons laid out left to right, wrapping onto new lines.
-- list = { { label, color, fn }, ... }; returns the y of the last line.
function M.flow( group, x, y, w, list, size, lineH, gap )
	gap, lineH = gap or 10, lineH or 16
	local cx, cy = x, y
	for _, a in ipairs( list ) do
		local b = M.button( group, a[1], cx, cy, a[3], { color = a[2], size = size or 12, align = "left" } )
		local tb = b.textObj.contentBounds
		local bw = tb.xMax - tb.xMin
		if cx > x and cx + bw > x + w then
			cx, cy = x, cy + lineH
			b.y = cy
			b._alignX = cx
			M.align( b )
		end
		cx = cx + bw + gap
	end
	return cy
end

-- The keyboard number of a palette colour, faint in its square's corner.
function M.paletteKey( group, i, x, y, size )
	local t = M.text( group, tostring( i ), x + size / 2 - 7, y + size / 2 - 10, 12, black )
	t.alpha = 0.3
	return t
end

-- small hand-drawn icons (the game's fonts have no arrow glyphs)
local function poly( g, pts, w, color )
	local l = display.newLine( g, unpack( pts ) )
	l.strokeWidth = w or 1.5
	l:setStrokeColor( ( color or gray )() )
	return l
end
local function arrowHead( g, x, y, ang, s, color )
	local a1, a2 = ang + 2.6, ang - 2.6
	poly( g, { x + s * math.cos( a1 ), y + s * math.sin( a1 ), x, y, x + s * math.cos( a2 ), y + s * math.sin( a2 ) }, 1.5, color )
end
local function ring( g, x, y, r, color, w )
	local c = display.newCircle( g, x, y, r )
	c:setFillColor( 0, 0, 0, 0 )
	c.strokeWidth = w or 1.5
	c:setStrokeColor( ( color or gray )() )
	return c
end
M.ring = ring

function M.icon( group, kind, x, y, s, color )
	local g = display.newGroup()
	group:insert( g )
	color = color or darkgray
	s = s or 11
	local dotR = s * 0.28
	if kind == "still" then
		M.dot( g, x, y, s * 0.35, color )
	elseif kind == "slide-h" or kind == "slide-v" or kind == "slide-d" then
		local ax, ay = 1, 0
		if kind == "slide-v" then ax, ay = 0, 1 elseif kind == "slide-d" then ax, ay = 0.71, 0.71 end
		poly( g, { x - ax * s, y - ay * s, x + ax * s, y + ay * s } )
		local ang = math.atan2( ay, ax )
		arrowHead( g, x + ax * s, y + ay * s, ang, s * 0.35 )
		arrowHead( g, x - ax * s, y - ay * s, ang + math.pi, s * 0.35 )
		M.dot( g, x - ax * s * 0.45, y - ay * s * 0.45, dotR, color )
	elseif kind == "circle" then
		ring( g, x, y, s * 0.8 )
		arrowHead( g, x, y - s * 0.8, 0, s * 0.3 )
		M.dot( g, x + s * 0.8, y, dotR, color )
	elseif kind == "wave" then
		local pts = {}
		for i = 0, 16 do
			local f = i / 16
			pts[#pts + 1] = x - s + 2 * s * f
			pts[#pts + 1] = y + math.sin( f * math.pi * 4 ) * s * 0.4
		end
		poly( g, pts )
		M.dot( g, x - s, y, dotR, color )
	elseif kind == "square" then
		local r = display.newRect( g, x, y, s * 1.5, s * 1.5 )
		r:setFillColor( 0, 0, 0, 0 )
		r.strokeWidth = 1.5
		r:setStrokeColor( gray() )
		M.dot( g, x - s * 0.75, y - s * 0.75, dotR, color )
	elseif kind == "figure8" then
		local pts = {}
		for i = 0, 32 do
			local a = i / 32 * math.pi * 2
			pts[#pts + 1] = x + s * math.sin( a )
			pts[#pts + 1] = y + s * 0.45 * math.sin( 2 * a )
		end
		poly( g, pts )
		M.dot( g, x, y, dotR, color )
	elseif kind == "pulse" then
		ring( g, x, y, s * 0.85, lightgray )
		ring( g, x, y, s * 0.55 )
		M.dot( g, x, y, s * 0.25, color )
	elseif kind:match( "^spin" ) then
		local level = tonumber( kind:match( "%d" ) ) or 1
		if level == 0 then
			ring( g, x, y, s * 0.75 )
			poly( g, { x - s * 0.55, y + s * 0.55, x + s * 0.55, y - s * 0.55 } )
		else
			local pts = {}
			for i = 0, 20 do
				local a = math.rad( -60 + i * 15 )
				pts[#pts + 1] = x + s * 0.75 * math.cos( a )
				pts[#pts + 1] = y + s * 0.75 * math.sin( a )
			end
			poly( g, pts )
			local a = math.rad( 240 )
			arrowHead( g, x + s * 0.75 * math.cos( a ), y + s * 0.75 * math.sin( a ), a + math.pi / 2, s * 0.35 )
			for i = 1, level do
				M.dot( g, x - ( level - 1 ) * s * 0.18 + ( i - 1 ) * s * 0.36, y, s * 0.13, color )
			end
		end
	end
	return g
end

-- A squiggle zone, drawn around (0, 0) in a group placed at (x, y) so it can
-- move and grow. "nodraw" is pencil-shaded paper you can't squiggle on;
-- "drawzone" is a clean patch of paper with a dashed edge, the only place
-- you can squiggle while one is on the paper.
function M.zone( group, kind, x, y, r, thin )
	local g = display.newGroup()
	group:insert( g )
	g.x, g.y = x, y
	g.r0 = r
	local fill = display.newCircle( g, 0, 0, r )
	local k = 0.70711
	if kind == "nodraw" then
		fill:setFillColor( 0.3, 0.3, 0.3, 0.06 )
		-- pencil shading, corner to corner
		local step = math.max( 2.4, math.min( 6, r / 5 ) )
		for d = -r + step / 2, r - step / 2, step do
			local h = math.sqrt( r * r - d * d ) - 0.8
			if h > 0.6 then
				local l = display.newLine( g, k * ( d - h ), k * ( d + h ), k * ( d + h ), k * ( d - h ) )
				l.strokeWidth = thin and 0.45 or 0.8
				l:setStrokeColor( 0.4, 0.4, 0.4, 0.5 )
			end
		end
	else
		fill:setFillColor( 1, 1, 1, 0.8 )
		local tint = display.newCircle( g, 0, 0, r )
		tint:setFillColor( 0.39, 0.5, 1, 0.05 )
	end
	-- dashed pencil edge
	local n = math.max( 10, math.floor( 2 * math.pi * r / 7 ) )
	local ink = kind == "nodraw" and { 0.45, 0.45, 0.45, 0.9 } or { 0.39, 0.5, 1, 0.85 }
	for i = 0, n - 1 do
		local a1 = 2 * math.pi * i / n
		local a2 = a1 + 2 * math.pi / n * 0.55
		local l = display.newLine( g, r * math.cos( a1 ), r * math.sin( a1 ), r * math.cos( a2 ), r * math.sin( a2 ) )
		l.strokeWidth = thin and 0.6 or 1.3
		l:setStrokeColor( unpack( ink ) )
	end
	return g
end

-- A level drawn small (for lists and the Level tab).
function M.thumbnail( group, level, x, y, w, h, framed )
	local g = display.newGroup()
	group:insert( g )
	local c = M.canvas()
	if framed ~= false then
		local bg = display.newRect( g, x, y, w, h )
		bg:setFillColor( white() )
		bg.strokeWidth = 1
		bg:setStrokeColor( 0.84, 0.84, 0.84 )
	end
	local k = math.min( w / c.w, h / c.h )
	local ox, oy = x - c.w * k / 2, y - c.h * k / 2
	for _, it in ipairs( level.items or {} ) do
		if it.kind == "nodraw" or it.kind == "drawzone" then
			local z = display.newCircle( g, ox + it.x * k, oy + it.y * k, math.max( 1, it.r * k ) )
			if it.kind == "nodraw" then z:setFillColor( 0.3, 0.3, 0.3, 0.18 )
			else
				z:setFillColor( 0.39, 0.5, 1, 0.08 )
				z.strokeWidth = 0.5
				z:setStrokeColor( 0.39, 0.5, 1, 0.7 )
			end
		end
	end
	for _, it in ipairs( level.items or {} ) do
		if it.kind ~= "nodraw" and it.kind ~= "drawzone" then
		local col = kindadarkgray
		if it.kind == "dot" then col = type( it.color ) == "number" and M.palette[it.color] or gray end
		M.dot( g, ox + it.x * k, oy + it.y * k, math.max( 0.9, it.r * k ), col )
		end
	end
	return g
end

-- Achievement-style banner that drops in from the top of the screen.
local bannerQueue, bannerShowing = {}, false
local function nextBanner()
	if bannerShowing or #bannerQueue == 0 then return end
	bannerShowing = true
	local item = table.remove( bannerQueue, 1 )
	local g = display.newGroup()
	local w = 250
	local bg = display.newRoundedRect( g, 0, 0, w, 38, 10 )
	bg:setFillColor( white() )
	bg.strokeWidth = 1.5
	bg:setStrokeColor( lightgray() )
	M.dot( g, -w / 2 + 20, 0, 9, item.color or yellow )
	M.text( g, item.title, -w / 2 + 36, -8, 11, gray, 0 )
	M.text( g, item.text, -w / 2 + 36, 7, 16, black, 0 )
	g.x, g.y = _W2, screenTop - 30
	display.getCurrentStage():insert( g )
	if item.sound ~= false then sounds.play( sounds.targetReappear, 0.6, true ) end
	transition.to( g, { time = 350, y = screenTop + 26, transition = easing.outBack } )
	transition.to( g, { delay = 2600, time = 300, y = screenTop - 30, onComplete = function()
		display.remove( g )
		bannerShowing = false
		nextBanner()
	end } )
end
function M.banner( title, text, color, sound )
	bannerQueue[#bannerQueue + 1] = { title = title, text = text, color = color, sound = sound }
	nextBanner()
end

return M
