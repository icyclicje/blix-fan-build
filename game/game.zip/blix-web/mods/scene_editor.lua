------------------------------------------------------------------------------
-- scene_editor.lua
-- Create mode's map editor.
--
--   header      back | level < n of m > | preview hitboxes undo redo settings save play
--   canvas      the game's paper, palette and grid; place, select, group select,
--               drag, erase
--   object menu dots / blocks / shapes / zones / move / spin / level  (+ tools)
--   details     properties of the selection (size, hits, type, movement, spin, ...)
--   settings    map, rules, endless, this level, editor, keyboard shortcuts
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui
local motion = require "mod_motion"
local prefabs = require "mod_prefabs"
local library = mods.library
local levelfile = mods.levelfile
local ach = mods.achievements

local scene = composer.newScene()

local TAB_H, BODY_H = 18, 52
local CELL_W, CELL_H = 42, 44
local DETAILS_W = 176
local MIRRORS = { "off", "x", "y", "xy" }
local MIRROR_LABEL = { off = "mirror", x = "mirror x", y = "mirror y", xy = "mirror xy" }
local TIME_STEPS = { -1, 0, 5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240, 300, 450, 600 }
local GRID = { x0 = 13, dx = 22.727, y0 = 16, dy = 22.818 }   -- the paper's printed lines
local TABS = { "dots", "blocks", "shapes", "zones", "move", "spin", "level" }
local SHIFT_STEPS = { 300, 400, 600, 800, 1000, 1200, 1600, 2000, 2500, 3000, 4000, 5000, 6000 }

local E = {
	tab = "dots", tool = "select", brush = nil, color = 1,
	snap = true, mirror = "off", hitboxes = false, showPaths = true,
	preview = false, t = 0, dockOpen = true, detailsOpen = true,
	amount = 2, speed = 2, spinDir = 1, pages = {},
	selection = {}, undo = {}, redo = {}, levelIndex = 1, dirty = false,
	keys = {}, handles = {},
}
local G = {}
local c                                          -- paper geometry (mods.ui.canvas)
local disp = setmetatable( {}, { __mode = "k" } )  -- item -> { circle, ring, box }
local animated = {}                              -- any-colour / shifting dots on screen
local fields = {}                                -- text fields of the open card

------------------------------------------------------------------------------
-- small helpers
------------------------------------------------------------------------------

local function clamp( v, lo, hi ) return math.max( lo, math.min( hi, v ) ) end
local function level() return E.map.levels[E.levelIndex] end
local function items() return level().items end
local function groups()
	local lv = level()
	lv.groups = lv.groups or {}
	return lv.groups
end
local function groupById( id )
	for _, g in ipairs( groups() ) do if g.id == id then return g end end
end
local function isEndless() return E.map.mode == "endless" end
local function levelWord() return isEndless() and "Pattern" or "Level" end
local function dockTop() return screenBottom - TAB_H - ( E.dockOpen and BODY_H or 0 ) end

local function hint( text, quiet )
	toast.show( text, { time = 1500 } )
	if not quiet then sounds.play( sounds.die, 0.15 ) end
end

local function selectedList()
	local out = {}
	for _, it in ipairs( items() ) do if E.selection[it] then out[#out + 1] = it end end
	return out
end

-- the group, if the selection is exactly one whole group
local function selectionGroup()
	local sel = selectedList()
	if #sel == 0 then return nil end
	local gid = sel[1].group
	if not gid then return nil end
	for _, it in ipairs( sel ) do if it.group ~= gid then return nil end end
	for _, it in ipairs( items() ) do if it.group == gid and not E.selection[it] then return nil end end
	return groupById( gid )
end

local function selectItem( it, add, onlyThis )
	if not add then E.selection = {} end
	if it.group and not onlyThis then
		for _, m in ipairs( items() ) do if m.group == it.group then E.selection[m] = true end end
	else
		E.selection[it] = true
	end
end

local function centroid( list )
	local sx, sy = 0, 0
	for _, it in ipairs( list ) do sx, sy = sx + it.x, sy + it.y end
	return sx / #list, sy / #list
end

local function snapValue( v, isX )
	if not E.snap then return v end
	local s = screenWidth / 1230
	if isX then
		local left = c.cx - screenWidth / 2 - c.left
		local k = math.floor( ( ( v - left ) / s - GRID.x0 ) / GRID.dx + 0.5 )
		return left + s * ( GRID.x0 + GRID.dx * k )
	end
	local top = c.cy - ( screenWidth * 919 / 1230 ) / 2 - c.top
	local k = math.floor( ( ( v - top ) / s - GRID.y0 ) / GRID.dy + 0.5 )
	return top + s * ( GRID.y0 + GRID.dy * k )
end
local function snapPoint( x, y ) return clamp( snapValue( x, true ), 0, c.w ), clamp( snapValue( y, false ), 0, c.h ) end
local function gridStep() return E.snap and ( screenWidth / 1230 * GRID.dx ) or 1 end

local function isZone( it ) return levelfile.isZone( it ) end
local function fmtShift( ms ) return string.format( "%.1fs", ms / 1000 ) end

-- the step after ms in SHIFT_STEPS (d = -1 / +1)
local function stepShift( ms, d )
	local i = 1
	for k, v in ipairs( SHIFT_STEPS ) do if v <= ms then i = k end end
	if SHIFT_STEPS[i] < ms and d < 0 then d = 0 end
	return SHIFT_STEPS[clamp( i + d, 1, #SHIFT_STEPS )]
end

-- sizes: from a speck to most of the paper (zones can be bigger still)
local function sizeLimits( it ) if isZone( it ) then return 2, 400 end return 0.25, 160 end

-- a size step that suits the size: fine when small, coarse when big
local function sizeStep( it, d )
	local r = d < 0 and it.r - 0.001 or it.r   -- going down uses the step below
	if isZone( it ) then
		if r < 10 then return 1 elseif r < 100 then return 4 end
		return 10
	end
	if r < 2 then return 0.25 elseif r < 5 then return 0.5 elseif r < 40 then return 1 elseif r < 100 then return 5 end
	return 10
end

local function grow( it, d )
	local lo, hi = sizeLimits( it )
	it.r = clamp( it.r + d * sizeStep( it, d ), lo, hi )
end

local function fmtSize( v )
	if v >= 10 or v == math.floor( v ) then return tostring( math.floor( v + 0.5 ) ) end
	return ( string.format( "%.2f", v ):gsub( "0+$", "" ):gsub( "%.$", "" ) )
end

-- Dots and blocks stay wholly on the paper, never over the colour palette,
-- the header or the edge of the screen. Zones may run under those (they're
-- drawn beneath them), but their centres stay on the paper.
local function fit( it )
	if isZone( it ) then
		it.x, it.y = clamp( it.x, 0, c.w ), clamp( it.y, 0, c.h )
	else
		it.x, it.y = motion.inside( it.x, it.y, motion.outer( it ), c.w, c.h )
	end
end

local function fitAll()
	for _, lv in ipairs( E.map.levels ) do
		for _, it in ipairs( lv.items ) do fit( it ) end
	end
end

-- how far a set of things can move together (from their start positions)
-- and all stay on the paper
local function fitDelta( list, dx, dy, from )
	local lox, hix, loy, hiy = -math.huge, math.huge, -math.huge, math.huge
	for _, it in ipairs( list ) do
		local x, y = it.x, it.y
		if from and from[it] then x, y = from[it].x, from[it].y end
		local R = isZone( it ) and 0 or motion.outer( it )
		lox, hix = math.max( lox, R - x ), math.min( hix, c.w - R - x )
		loy, hiy = math.max( loy, R - y ), math.min( hiy, c.h - R - y )
	end
	dx = lox <= hix and clamp( dx, lox, hix ) or 0
	dy = loy <= hiy and clamp( dy, loy, hiy ) or 0
	return dx, dy
end

-- move things (and their circle centres and groups) together
local function shiftAll( list, dx, dy, groupList )
	if dx == 0 and dy == 0 then return end
	for _, it in ipairs( list ) do
		it.x, it.y = it.x + dx, it.y + dy
		if it.move and it.move.type == "circle" then it.move.cx, it.move.cy = it.move.cx + dx, it.move.cy + dy end
	end
	for _, g in ipairs( groupList or {} ) do
		if g.pivot then g.pivot.x, g.pivot.y = g.pivot.x + dx, g.pivot.y + dy end
		if g.move and g.move.type == "circle" then g.move.cx, g.move.cy = g.move.cx + dx, g.move.cy + dy end
	end
end

local function colorFn( it )
	if it.kind == "block" then return kindadarkgray end
	if type( it.color ) == "number" then return ui.palette[it.color] or red end
	return ui.palette[1]
end

------------------------------------------------------------------------------
-- undo / redo
------------------------------------------------------------------------------

local function snapshot() return { levels = ui.deepcopy( E.map.levels ), index = E.levelIndex } end

local renderAll, renderItems, renderOverlay, renderHeader, renderDock, renderDetails, renderStatus

local function pushUndo()
	E.undo[#E.undo + 1] = snapshot()
	if #E.undo > 80 then table.remove( E.undo, 1 ) end
	E.redo = {}
	E.dirty = true
end

local function restore( s )
	E.map.levels = s.levels
	E.levelIndex = clamp( s.index, 1, #E.map.levels )
	E.selection = {}
	E.dirty = true
	renderAll()
end

local function undo()
	if #E.undo == 0 then return end
	E.redo[#E.redo + 1] = snapshot()
	restore( table.remove( E.undo ) )
end

local function redo()
	if #E.redo == 0 then return end
	E.undo[#E.undo + 1] = snapshot()
	restore( table.remove( E.redo ) )
end

------------------------------------------------------------------------------
-- drawing the level
------------------------------------------------------------------------------

local function drawItem( group, it, x, y, r, small )
	local d = {}
	if isZone( it ) then
		d.zone = ui.zone( group, it.kind, x, y, r, small )
		return d
	end
	if it.kind == "dot" and ( it.hits or 1 ) > 1 then
		d.ring = ui.dot( group, x, y, r + 2.5 * ( it.hits - 1 ), colorFn( it ) )
		d.ring:setFillColor( colors.getDarker( colorFn( it ), 1.6 ) )
		d.ring.alpha = 0.55
	end
	d.circle = ui.dot( group, x, y, r, colorFn( it ) )
	if it.kind == "dot" and type( it.color ) ~= "number" then
		animated[#animated + 1] = { obj = d.circle, kind = it.color, ms = levelfile.shiftMs( E.map, it ) }
	end
	return d
end

-- where everything is during the preview (kept on the paper like in the game)
local function currentPositions()
	if not E.preview then return nil end
	local pos = motion.positions( level(), E.t )
	for it, p in pairs( pos ) do
		if not isZone( it ) then p.x, p.y = motion.inside( p.x, p.y, motion.outer( it, p.r ), c.w, c.h ) end
	end
	return pos
end

function renderItems()
	display.remove( G.items )
	G.items = display.newGroup()
	G.itemsHost:insert( G.items )
	animated = {}
	local pos = currentPositions()
	-- zones first: they lie on the paper under everything else
	for pass = 1, 2 do
		for _, it in ipairs( items() ) do
			if ( pass == 1 ) == isZone( it ) then
				local p = pos and pos[it]
				local x, y, r = c.left + ( p and p.x or it.x ), c.top + ( p and p.y or it.y ), p and p.r or it.r
				disp[it] = drawItem( G.items, it, x, y, r )
			end
		end
	end
	if #items() == 0 then
		local msg = E.brush and "Tap the paper to place it" or "Pick something from the menu below, then tap the paper"
		local t = ui.text( G.items, msg, c.cx, ( c.top + dockTop() ) / 2, 16, lightgray )
		t.alpha = 0.9
	end
end

-- dashed-looking trail (a run of short segments)
local function trail( group, pts, alpha, color )
	for i = 1, #pts - 1, 2 do
		local a, b = pts[i], pts[i + 1]
		local l = display.newLine( group, c.left + a.x, c.top + a.y, c.left + b.x, c.top + b.y )
		l.strokeWidth = 1.2
		l:setStrokeColor( ( color or gray )() )
		l.alpha = alpha
	end
end

-- a draggable point (movement end, circle centre, spin pivot); the canvas
-- touch handler picks these up first, so they keep working while redrawn
local function handle( x, y, onMove, kind )
	local h = display.newGroup()
	G.overlay:insert( h )
	if kind == "pivot" then
		local a = display.newRect( h, x, y, 12, 1.5 ); a:setFillColor( blue() )
		local b = display.newRect( h, x, y, 1.5, 12 ); b:setFillColor( blue() )
		ui.ring( h, x, y, 4, blue, 1.5 )
	else
		local dotH = display.newCircle( h, x, y, 4 )
		dotH:setFillColor( white() )
		dotH.strokeWidth = 1.5
		dotH:setStrokeColor( blue() )
	end
	E.handles[#E.handles + 1] = { x = x, y = y, move = onMove }
	return h
end

-- handles for a movement based at (bx, by)
local function moveHandles( mv, bx, by, owner )
	if mv.type == "slide" or mv.type == "wave" then
		handle( c.left + bx + mv.dx, c.top + by + mv.dy, function( px, py ) owner.move.dx, owner.move.dy = px - bx, py - by end )
	elseif mv.type == "circle" then
		handle( c.left + mv.cx, c.top + mv.cy, function( px, py ) owner.move.cx, owner.move.cy = px, py end )
	elseif mv.type == "square" then
		handle( c.left + bx + mv.w, c.top + by + mv.h, function( px, py ) owner.move.w, owner.move.h = px - bx, py - by end )
	elseif mv.type == "figure8" then
		handle( c.left + bx + mv.w / 2, c.top + by + mv.h / 2, function( px, py ) owner.move.w, owner.move.h = ( px - bx ) * 2, ( py - by ) * 2 end )
	end
end

function renderOverlay()
	display.remove( G.overlay )
	G.overlay = display.newGroup()
	G.overlayHost:insert( G.overlay )
	E.handles = {}
	local lv = level()
	local pos = currentPositions()

	if E.hitboxes then
		for _, it in ipairs( items() ) do
			local p = pos and pos[it]
			local x, y, r = c.left + ( p and p.x or it.x ), c.top + ( p and p.y or it.y ), p and p.r or it.r
			local ink = it.kind == "block" and red or ( isZone( it ) and blue or darkgreen )
			local box = ui.ring( G.overlay, x, y, math.max( 1, r ), ink, 1.2 )
			local mark = display.newRect( G.overlay, x, y, 2, 2 )
			mark:setFillColor( black() )
			disp[it] = disp[it] or {}
			disp[it].box, disp[it].mark = box, mark
		end
	end
	if E.preview then return end

	-- movement paths and spin circles
	for _, it in ipairs( items() ) do
		if it.move and ( E.showPaths or E.selection[it] ) then
			local pts = motion.trail( it.move, it.x, it.y, 28 )
			if not isZone( it ) then
				for _, q in ipairs( pts ) do q.x, q.y = motion.inside( q.x, q.y, motion.outer( it ), c.w, c.h ) end
			end
			trail( G.overlay, pts, E.selection[it] and 0.75 or 0.3 )
		end
	end
	for _, g in ipairs( groups() ) do
		local selected = false
		for _, it in ipairs( items() ) do if it.group == g.id and E.selection[it] then selected = true end end
		if E.showPaths or selected then
			local px, py = motion.pivot( lv, g )
			if g.move then trail( G.overlay, motion.trail( g.move, px, py, 28 ), selected and 0.75 or 0.3, blue ) end
			if g.spin then
				local rmax = 0
				for _, it in ipairs( items() ) do
					if it.group == g.id then rmax = math.max( rmax, math.sqrt( ( it.x - px ) ^ 2 + ( it.y - py ) ^ 2 ) + it.r ) end
				end
				local circ = ui.ring( G.overlay, c.left + px, c.top + py, math.max( 2, rmax ), blue, 1 )
				circ.alpha = selected and 0.5 or 0.2
			end
		end
	end

	-- selection
	local sel = selectedList()
	for _, it in ipairs( sel ) do
		ui.ring( G.overlay, c.left + it.x, c.top + it.y, it.r + 3.5, darkgray, 1.4 )
	end
	local g = selectionGroup()
	if g then
		local x0, y0, x1, y1 = math.huge, math.huge, -math.huge, -math.huge
		for _, it in ipairs( sel ) do
			x0, y0 = math.min( x0, it.x - it.r ), math.min( y0, it.y - it.r )
			x1, y1 = math.max( x1, it.x + it.r ), math.max( y1, it.y + it.r )
		end
		local box = display.newRoundedRect( G.overlay, c.left + ( x0 + x1 ) / 2, c.top + ( y0 + y1 ) / 2, x1 - x0 + 14, y1 - y0 + 14, 6 )
		box:setFillColor( 0, 0, 0, 0 )
		box.strokeWidth = 1
		box:setStrokeColor( blue() )
		box.alpha = 0.6
		local px, py = motion.pivot( lv, g )
		if g.move then moveHandles( g.move, px, py, g ) end
		handle( c.left + px, c.top + py, function( nx, ny ) g.pivot = { x = nx, y = ny } end, "pivot" )
	elseif #sel == 1 and sel[1].move then
		moveHandles( sel[1].move, sel[1].x, sel[1].y, sel[1] )
	end

	if E.band then
		local b = E.band
		local r = display.newRect( G.overlay, c.left + ( b.x0 + b.x1 ) / 2, c.top + ( b.y0 + b.y1 ) / 2,
			math.abs( b.x1 - b.x0 ), math.abs( b.y1 - b.y0 ) )
		r:setFillColor( 0.39, 0.5, 1, 0.08 )
		r.strokeWidth = 1
		r:setStrokeColor( blue() )
	end
end

------------------------------------------------------------------------------
-- editing actions
------------------------------------------------------------------------------

local function setLevel( i )
	E.levelIndex = clamp( i, 1, #E.map.levels )
	E.selection = {}
	E.t = 0
	sounds.play( sounds.bbAppear, 0.5 )
	renderAll()
end

local function makeGroup( list )
	local lv = level()
	local id = levelfile.newGroupId( lv )
	for _, it in ipairs( list ) do it.group = id end
	levelfile.pruneGroups( lv )
	local g = { id = id }
	table.insert( groups(), g )
	return g
end

local function groupSelection()
	local sel = selectedList()
	if #sel < 2 then return hint( "Select two or more things to group." ) end
	pushUndo()
	makeGroup( sel )
	sounds.play( sounds.targetReappear, 0.4 )
	renderAll()
end

local function ungroupSelection()
	local sel = selectedList()
	local any = false
	for _, it in ipairs( sel ) do if it.group then any = true end end
	if not any then return hint( "That isn't a group." ) end
	pushUndo()
	for _, it in ipairs( sel ) do it.group = nil end
	levelfile.pruneGroups( level() )
	renderAll()
end

local function deleteSelection()
	local sel = selectedList()
	if #sel == 0 then return end
	pushUndo()
	for i = #items(), 1, -1 do
		if E.selection[items()[i]] then table.remove( items(), i ) end
	end
	levelfile.pruneGroups( level() )
	E.selection = {}
	sounds.play( sounds.die, 0.25 )
	renderAll()
end

local function duplicateSelection()
	local sel = selectedList()
	if #sel == 0 then return end
	pushUndo()
	local lv = level()
	local whole = {}
	for _, it in ipairs( sel ) do
		if it.group and whole[it.group] == nil then
			local all = true
			for _, m in ipairs( items() ) do if m.group == it.group and not E.selection[m] then all = false end end
			whole[it.group] = all
		end
	end
	local newIds = {}
	local function offsetMove( mv )
		if mv and mv.type == "circle" then mv.cx, mv.cy = mv.cx + 16, mv.cy + 16 end
	end
	for gid, all in pairs( whole ) do
		if all then
			local src = groupById( gid )
			local copy = ui.deepcopy( src )
			copy.id = levelfile.newGroupId( lv )
			if copy.pivot then copy.pivot.x, copy.pivot.y = copy.pivot.x + 16, copy.pivot.y + 16 end
			offsetMove( copy.move )
			table.insert( groups(), copy )
			newIds[gid] = copy.id
		end
	end
	E.selection = {}
	local copies = {}
	for _, it in ipairs( sel ) do
		local copy = ui.deepcopy( it )
		copy.x, copy.y = it.x + 16, it.y + 16
		offsetMove( copy.move )
		copy.group = it.group and newIds[it.group] or nil
		table.insert( items(), copy )
		E.selection[copy] = true
		copies[#copies + 1] = copy
	end
	local newGroups = {}
	for _, id in pairs( newIds ) do newGroups[#newGroups + 1] = groupById( id ) end
	local dxs, dys = fitDelta( copies, 0, 0 )
	shiftAll( copies, dxs, dys, newGroups )
	sounds.play( sounds.bbAppear, 0.5 )
	renderAll()
end

local function flipMove( mv, axis, m )
	if not mv then return end
	local k = mv.type
	if axis == "x" then
		if k == "slide" then mv.dx = -mv.dx
		elseif k == "wave" then mv.dx, mv.amp = -mv.dx, -mv.amp
		elseif k == "circle" then mv.cx, mv.dir = 2 * m - mv.cx, -mv.dir
		elseif k == "square" or k == "figure8" then mv.w = -mv.w end
	else
		if k == "slide" then mv.dy = -mv.dy
		elseif k == "wave" then mv.dy, mv.amp = -mv.dy, -mv.amp
		elseif k == "circle" then mv.cy, mv.dir = 2 * m - mv.cy, -mv.dir
		elseif k == "square" or k == "figure8" then mv.h = -mv.h end
	end
end

local function flipSelection( axis )
	local sel = selectedList()
	if #sel == 0 then return end
	pushUndo()
	local mx, my = centroid( sel )
	local touched = {}
	for _, it in ipairs( sel ) do
		if axis == "x" then it.x = clamp( 2 * mx - it.x, 0, c.w ) else it.y = clamp( 2 * my - it.y, 0, c.h ) end
		flipMove( it.move, axis, axis == "x" and mx or my )
		if it.group then touched[it.group] = true end
	end
	for gid in pairs( touched ) do
		local g = groupById( gid )
		if g then
			if g.pivot then
				if axis == "x" then g.pivot.x = 2 * mx - g.pivot.x else g.pivot.y = 2 * my - g.pivot.y end
			end
			flipMove( g.move, axis, axis == "x" and mx or my )
			if g.spin then g.spin.dir = -g.spin.dir end
		end
	end
	renderAll()
end

-- put the selection in a row (or column) / space it evenly
local function lineUp()
	local sel = selectedList()
	if #sel < 2 then return hint( "Select two or more things first." ) end
	pushUndo()
	local x0, x1, y0, y1 = math.huge, -math.huge, math.huge, -math.huge
	for _, it in ipairs( sel ) do x0, x1, y0, y1 = math.min( x0, it.x ), math.max( x1, it.x ), math.min( y0, it.y ), math.max( y1, it.y ) end
	local mx, my = centroid( sel )
	for _, it in ipairs( sel ) do
		if x1 - x0 >= y1 - y0 then it.y = my else it.x = mx end
	end
	renderAll()
end

local function spread()
	local sel = selectedList()
	if #sel < 3 then return hint( "Select three or more things to spread out." ) end
	pushUndo()
	local x0, x1, y0, y1 = math.huge, -math.huge, math.huge, -math.huge
	for _, it in ipairs( sel ) do x0, x1, y0, y1 = math.min( x0, it.x ), math.max( x1, it.x ), math.min( y0, it.y ), math.max( y1, it.y ) end
	local horizontal = x1 - x0 >= y1 - y0
	table.sort( sel, function( a, b ) if horizontal then return a.x < b.x end return a.y < b.y end )
	for i, it in ipairs( sel ) do
		local f = ( i - 1 ) / ( #sel - 1 )
		if horizontal then it.x = x0 + ( x1 - x0 ) * f else it.y = y0 + ( y1 - y0 ) * f end
	end
	renderAll()
end

-- turn the selection around its middle (a whole group turns around its pivot)
local function rotateVec( x, y, a ) return x * math.cos( a ) - y * math.sin( a ), x * math.sin( a ) + y * math.cos( a ) end

local function rotateSelection( deg )
	local sel = selectedList()
	if #sel == 0 then return end
	pushUndo()
	local g = selectionGroup()
	local mx, my
	if g then mx, my = motion.pivot( level(), g ) else mx, my = centroid( sel ) end
	local a = math.rad( deg )
	local function turnMove( mv )
		if not mv then return end
		if mv.type == "slide" or mv.type == "wave" then mv.dx, mv.dy = rotateVec( mv.dx, mv.dy, a )
		elseif mv.type == "circle" then
			local rx, ry = rotateVec( mv.cx - mx, mv.cy - my, a )
			mv.cx, mv.cy = mx + rx, my + ry
		end
	end
	for _, it in ipairs( sel ) do
		local rx, ry = rotateVec( it.x - mx, it.y - my, a )
		it.x, it.y = clamp( mx + rx, 0, c.w ), clamp( my + ry, 0, c.h )
		turnMove( it.move )
	end
	if g then turnMove( g.move ) end
	sounds.playFast( sounds._button_click_low_volume_fast )
	renderAll()
end

-- clipboard (works across levels of the map)
local function copySelection()
	local sel = selectedList()
	if #sel == 0 then return end
	local clip = { items = {}, groups = {} }
	local seen = {}
	for _, it in ipairs( sel ) do
		clip.items[#clip.items + 1] = ui.deepcopy( it )
		if it.group and not seen[it.group] then
			seen[it.group] = true
			local g = groupById( it.group )
			if g then clip.groups[#clip.groups + 1] = ui.deepcopy( g ) end
		end
	end
	clip.level = level()
	E.clipboard = clip
	toast.show( #sel == 1 and "Copied 1 thing" or ( "Copied " .. #sel .. " things" ), { time = 900 } )
	sounds.playFast( sounds._button_click_low_volume_fast )
end

local function shiftClip( clip, d )
	for _, it in ipairs( clip.items ) do
		it.x, it.y = it.x + d, it.y + d
		if it.move and it.move.type == "circle" then it.move.cx, it.move.cy = it.move.cx + d, it.move.cy + d end
	end
	for _, g in ipairs( clip.groups ) do
		if g.pivot then g.pivot.x, g.pivot.y = g.pivot.x + d, g.pivot.y + d end
		if g.move and g.move.type == "circle" then g.move.cx, g.move.cy = g.move.cx + d, g.move.cy + d end
	end
end

local function pasteClipboard()
	local clip = E.clipboard
	if not clip or #clip.items == 0 then return hint( "Nothing copied yet. Select something and press ctrl + c." ) end
	if #items() + #clip.items > levelfile.MAX_ITEMS then return hint( "That would be too many things for one level." ) end
	pushUndo()
	local lv = level()
	if clip.level == lv then shiftClip( clip, 16 ) end   -- pasting again lands a little further on
	clip.level = lv
	local ids = {}
	for _, src in ipairs( clip.groups ) do
		local g = ui.deepcopy( src )
		g.id = levelfile.newGroupId( lv )
		table.insert( groups(), g )
		ids[src.id] = g.id
	end
	E.selection = {}
	local pasted, newGroups = {}, {}
	for _, src in ipairs( clip.items ) do
		local it = ui.deepcopy( src )
		it.group = src.group and ids[src.group] or nil
		table.insert( items(), it )
		E.selection[it] = true
		pasted[#pasted + 1] = it
	end
	for _, id in pairs( ids ) do newGroups[#newGroups + 1] = groupById( id ) end
	local dxs, dys = fitDelta( pasted, 0, 0 )
	shiftAll( pasted, dxs, dys, newGroups )
	E.tool, E.brush = "select", nil
	sounds.play( sounds.bbAppear, 0.5 )
	renderAll()
end

local function applyMove( kind, variant )
	local sel = selectedList()
	if #sel == 0 then return hint( "Select something to move first." ) end
	pushUndo()
	local extra = { dir = E.spinDir }
	if variant == "h" then extra.ax, extra.ay = 1, 0
	elseif variant == "v" then extra.ax, extra.ay = 0, 1
	elseif variant == "d" then extra.ax, extra.ay = 1, 1 end
	local g = selectionGroup()
	if g then
		local px, py = motion.pivot( level(), g )
		g.move = kind ~= "still" and motion.preset( kind, E.amount, E.speed, px, py, extra ) or nil
	else
		for _, it in ipairs( sel ) do
			it.move = kind ~= "still" and motion.preset( kind, E.amount, E.speed, it.x, it.y, extra ) or nil
		end
	end
	sounds.play( sounds.targetReappear, 0.35 )
	renderAll()
end

local function applySpin( index )
	local sel = selectedList()
	if #sel == 0 then return hint( "Select a shape or some objects first." ) end
	local speed = motion.SPIN_SPEEDS[index]
	pushUndo()
	local g = selectionGroup()
	if not g and speed > 0 then
		g = makeGroup( sel )
		-- a single object swings around a point next to it
		if #sel == 1 then g.pivot = { x = clamp( sel[1].x - 32, 0, c.w ), y = sel[1].y } end
	end
	if g then g.spin = speed > 0 and { speed = speed, dir = E.spinDir } or nil end
	sounds.play( sounds.targetReappear, 0.35 )
	renderAll()
end

local function scaleMove( mv, f, x, y )
	local k = mv.type
	if k == "slide" then mv.dx, mv.dy = mv.dx * f, mv.dy * f
	elseif k == "circle" then mv.cx, mv.cy = x + ( mv.cx - x ) * f, y + ( mv.cy - y ) * f
	elseif k == "wave" then mv.dx, mv.dy, mv.amp = mv.dx * f, mv.dy * f, mv.amp * f
	elseif k == "square" or k == "figure8" then mv.w, mv.h = mv.w * f, mv.h * f
	elseif k == "pulse" then mv.scale = clamp( 1 + ( mv.scale - 1 ) * f, 0.3, 4 ) end
end

-- the thing under (x, y): dots and blocks come before the zones under them
local function itemAt( x, y )
	local list = items()
	for pass = 1, 2 do
		for i = #list, 1, -1 do
			local it = list[i]
			local zone = isZone( it )
			if ( pass == 2 ) == zone and ( it.x - x ) ^ 2 + ( it.y - y ) ^ 2 <= ( it.r + ( zone and 0 or 5 ) ) ^ 2 then
				return it
			end
		end
	end
	return nil
end

local function eraseAt( x, y, drag )
	local it = itemAt( x, y )
	if not it then return end
	if not drag.pushed then pushUndo(); drag.pushed = true end   -- one undo step per stroke
	for i, v in ipairs( items() ) do
		if v == it then table.remove( items(), i ); break end
	end
	E.selection[it] = nil
	levelfile.pruneGroups( level() )
	sounds.play( sounds.die, 0.2, true )
	renderItems()
	renderOverlay()
end

-- copies of a placement for mirror mode: { { ax, ay, flipX, flipY }, ... }
local function mirrorAnchors( ax, ay )
	local out = { { ax, ay, false, false } }
	local function add( x, y, fx, fy )
		for _, p in ipairs( out ) do if ( p[1] - x ) ^ 2 + ( p[2] - y ) ^ 2 < 4 then return end end
		out[#out + 1] = { x, y, fx, fy }
	end
	if E.mirror == "x" or E.mirror == "xy" then add( c.w - ax, ay, true, false ) end
	if E.mirror == "y" or E.mirror == "xy" then add( ax, c.h - ay, false, true ) end
	if E.mirror == "xy" then add( c.w - ax, c.h - ay, true, true ) end
	return out
end

-- push each placed copy (a whole shape) back onto the paper if it hangs off
local function fitPlaced( placed )
	local byAnchor, order = {}, {}
	for _, p in ipairs( placed ) do
		if not byAnchor[p.anchor] then byAnchor[p.anchor] = {}; order[#order + 1] = p.anchor end
		table.insert( byAnchor[p.anchor], p.item )
	end
	for _, a in ipairs( order ) do
		local list = byAnchor[a]
		local dx, dy = fitDelta( list, 0, 0 )
		for _, it in ipairs( list ) do it.x, it.y = it.x + dx, it.y + dy end
	end
end

local function placeBrush( ax, ay )
	local placed = {}
	for _, a in ipairs( mirrorAnchors( ax, ay ) ) do
		local built = E.brush.build( E.color )
		local gid = ( E.brush.grouped or #built > 1 ) and levelfile.newGroupId( level() ) or nil
		if gid then table.insert( groups(), { id = gid } ) end
		for _, b in ipairs( built ) do
			local it = ui.deepcopy( b )
			it.ox, it.oy = ( a[3] and -b.x or b.x ), ( a[4] and -b.y or b.y )
			it.x, it.y = a[1] + it.ox, a[2] + it.oy
			it.group = gid
			table.insert( items(), it )
			placed[#placed + 1] = { item = it, anchor = a }
		end
	end
	fitPlaced( placed )
	return placed
end

local function movePlaced( placed, ax, ay )
	local anchors = mirrorAnchors( ax, ay )
	local index = {}
	for i, p in ipairs( placed ) do
		local a = p.anchor
		-- find which mirror copy this item belongs to
		local k = 1
		for j, b in ipairs( anchors ) do if b[3] == a[3] and b[4] == a[4] then k = j end end
		local b = anchors[k]
		p.item.x, p.item.y = b[1] + p.item.ox, b[2] + p.item.oy
	end
	fitPlaced( placed )
end

local function finishPlacement( placed )
	for _, p in ipairs( placed ) do p.item.ox, p.item.oy = nil, nil end
end

------------------------------------------------------------------------------
-- group select: draw a loop around things, like a squiggle, to select them all
------------------------------------------------------------------------------

local function lassoPoint( d, x, y )
	local last = d.pts[#d.pts]
	if last and ( x - last.x ) ^ 2 + ( y - last.y ) ^ 2 < 6 then return end
	d.pts[#d.pts + 1] = { x = x, y = y }
	if last then
		local l = display.newLine( d.line, c.left + last.x, c.top + last.y, c.left + x, c.top + y )
		l.strokeWidth = 3
		l:setStrokeColor( ui.palette[E.color]() )
	end
end

local function insidePolygon( pts, x, y )
	local inside, j = false, #pts
	for i = 1, #pts do
		local a, b = pts[i], pts[j]
		if ( a.y > y ) ~= ( b.y > y ) and x < ( b.x - a.x ) * ( y - a.y ) / ( b.y - a.y ) + a.x then inside = not inside end
		j = i
	end
	return inside
end

local function selectionCount()
	local n = 0
	for _ in pairs( E.selection ) do n = n + 1 end
	return n
end

-- rising beeps, like a squiggle clearing dots
local function beeps( n )
	for i = 1, math.min( n, 9 ) do
		timer.performWithDelay( ( i - 1 ) * 60 + 1, function() sounds.play( sounds.hits[i], 0.45, true ) end )
	end
end

local function finishLasso( d, shift, ctrl )
	local len = 0
	for i = 2, #d.pts do
		len = len + math.sqrt( ( d.pts[i].x - d.pts[i - 1].x ) ^ 2 + ( d.pts[i].y - d.pts[i - 1].y ) ^ 2 )
	end
	local before = selectionCount()
	if len < 8 then
		-- a tap adds one thing (or its group); a tap on empty paper starts over
		if d.tapItem then selectItem( d.tapItem, true, ctrl )
		elseif not shift then E.selection = {} end
	else
		for _, it in ipairs( items() ) do
			if insidePolygon( d.pts, it.x, it.y ) then selectItem( it, true, ctrl ) end
		end
		-- close the loop before it fades
		local a, b = d.pts[#d.pts], d.pts[1]
		local l = display.newLine( d.line, c.left + a.x, c.top + a.y, c.left + b.x, c.top + b.y )
		l.strokeWidth = 3
		l:setStrokeColor( ui.palette[E.color]() )
		l.alpha = 0.5
	end
	local added = selectionCount() - before
	if added > 0 then beeps( added ) end
	local line = d.line
	transition.to( line, { time = 450, alpha = 0, onComplete = function() display.remove( line ) end } )
end

-- start dragging the selection by the thing under the pointer
local function startMove( x, y, anchor, extra )
	local start = {}
	for _, it in ipairs( selectedList() ) do
		start[it] = { x = it.x, y = it.y, cx = it.move and it.move.cx, cy = it.move and it.move.cy }
	end
	local gstart = {}
	for _, g in ipairs( groups() ) do
		local whole, any = true, false
		for _, it in ipairs( items() ) do
			if it.group == g.id then
				if E.selection[it] then any = true else whole = false end
			end
		end
		if any and whole then
			gstart[g] = { px = g.pivot and g.pivot.x, py = g.pivot and g.pivot.y, cx = g.move and g.move.cx, cy = g.move and g.move.cy }
		end
	end
	E.drag = { mode = "move", x0 = x, y0 = y, anchor = anchor, start = start, gstart = gstart, moved = false }
	for k, v in pairs( extra or {} ) do E.drag[k] = v end
end

------------------------------------------------------------------------------
-- canvas touches
------------------------------------------------------------------------------

local function canvasTouch( event )
	if E.modal then return true end
	local x, y = event.x - c.left, event.y - c.top
	local stage = display.getCurrentStage()
	local shift = event.isShiftDown or E.keys.shift
	local ctrl = event.isCtrlDown or E.keys.ctrl
	if event.phase == "began" then
		stage:setFocus( G.touch, event.id )
		E.drag = nil
		if E.preview then
			-- a tap just stops the preview
			E.preview = false
			renderAll()
			return true
		end
		if E.tool == "select" or E.tool == "lasso" then
			for i = #E.handles, 1, -1 do
				local h = E.handles[i]
				if ( event.x - h.x ) ^ 2 + ( event.y - h.y ) ^ 2 <= 81 then
					pushUndo()
					E.drag = { mode = "handle", move = h.move }
					sounds.playFast( sounds._button_click_low_volume_fast, true )
					return true
				end
			end
		end
		if E.tool == "place" and E.brush then
			pushUndo()
			local ax, ay = snapPoint( x, y )
			local placed = placeBrush( ax, ay )
			E.drag = { mode = "place", placed = placed }
			local built = #placed
			if E.tab == "dots" and built == 1 then
				sounds.play( sounds.hits[( #items() - 1 ) % 9 + 1], 0.5, true )
			else
				sounds.play( sounds.bbAppear, 0.5, true )
			end
			renderItems()
			renderOverlay()
		elseif E.tool == "erase" then
			E.drag = { mode = "erase" }
			eraseAt( x, y, E.drag )
		elseif E.tool == "lasso" then
			local hit = itemAt( x, y )
			if hit and E.selection[hit] then
				-- drag the selection along, or tap it to take it back out
				startMove( x, y, hit, { untap = hit, ctrl = ctrl } )
				sounds.playFast( sounds._button_click_low_volume_fast, true )
			else
				local line = display.newGroup()
				G.lassoHost:insert( line )
				E.drag = { mode = "lasso", pts = {}, line = line, tapItem = hit }
				lassoPoint( E.drag, x, y )
			end
		else
			local hit = itemAt( x, y )
			if hit and shift and E.selection[hit] then
				-- shift-click a selected thing: take it (or its group) out of the selection
				if hit.group and not ctrl then
					for _, m in ipairs( items() ) do if m.group == hit.group then E.selection[m] = nil end end
				else
					E.selection[hit] = nil
				end
				sounds.playFast( sounds._button_click_low_volume_fast, true )
				renderOverlay()
				renderDetails()
				renderStatus()
				return true
			end
			if hit then
				if shift then
					selectItem( hit, true, ctrl )
				elseif not E.selection[hit] or ctrl then
					selectItem( hit, false, ctrl )
				end
				startMove( x, y, hit )
				sounds.playFast( sounds._button_click_low_volume_fast, true )
			else
				if not shift then E.selection = {} end
				E.drag = { mode = "band" }
				E.band = { x0 = x, y0 = y, x1 = x, y1 = y }
			end
			renderOverlay()
			renderDetails()
			renderStatus()
		end
	elseif event.phase == "moved" and E.drag then
		local d = E.drag
		if d.mode == "handle" then
			local px, py = x, y
			if E.snap then px, py = snapValue( px, true ), snapValue( py, false ) end
			d.move( px, py )
			renderItems()
			renderOverlay()
		elseif d.mode == "place" then
			local ax, ay = snapPoint( x, y )
			movePlaced( d.placed, ax, ay )
			renderItems()
			renderOverlay()
		elseif d.mode == "move" then
			if not d.moved and ( ( x - d.x0 ) ^ 2 + ( y - d.y0 ) ^ 2 ) > 9 then
				pushUndo()
				d.moved = true
			end
			if d.moved then
				local s0 = d.start[d.anchor]
				local nx, ny = snapPoint( s0.x + x - d.x0, s0.y + y - d.y0 )
				local list = {}
				for it in pairs( d.start ) do list[#list + 1] = it end
				local dx, dy = fitDelta( list, nx - s0.x, ny - s0.y, d.start )
				for it, s in pairs( d.start ) do
					it.x, it.y = s.x + dx, s.y + dy
					if it.move and it.move.type == "circle" and s.cx then it.move.cx, it.move.cy = s.cx + dx, s.cy + dy end
				end
				for g, s in pairs( d.gstart ) do
					if s.px then g.pivot = { x = s.px + dx, y = s.py + dy } end
					if g.move and g.move.type == "circle" and s.cx then g.move.cx, g.move.cy = s.cx + dx, s.cy + dy end
				end
				renderItems()
				renderOverlay()
			end
		elseif d.mode == "band" then
			E.band.x1, E.band.y1 = x, y
			renderOverlay()
		elseif d.mode == "erase" then
			eraseAt( x, y, d )
		elseif d.mode == "lasso" then
			lassoPoint( d, x, y )
		end
	elseif event.phase == "ended" or event.phase == "cancelled" then
		stage:setFocus( nil )
		local d = E.drag
		E.drag = nil
		if d and d.mode == "place" then finishPlacement( d.placed ) end
		if d and d.mode == "lasso" then finishLasso( d, shift, ctrl ) end
		if d and d.mode == "move" and not d.moved and d.untap then
			local it = d.untap
			if it.group and not d.ctrl then
				for _, m in ipairs( items() ) do if m.group == it.group then E.selection[m] = nil end end
			else
				E.selection[it] = nil
			end
			sounds.playFast( sounds._button_click_low_volume_fast )
		end
		if d and d.mode == "band" and E.band then
			local b = E.band
			local x0, x1 = math.min( b.x0, b.x1 ), math.max( b.x0, b.x1 )
			local y0, y1 = math.min( b.y0, b.y1 ), math.max( b.y0, b.y1 )
			if x1 - x0 > 3 or y1 - y0 > 3 then
				for _, it in ipairs( items() ) do
					if it.x >= x0 and it.x <= x1 and it.y >= y0 and it.y <= y1 then selectItem( it, true, true ) end
				end
				if next( E.selection ) then sounds.playFast( sounds._button_click_low_volume_fast ) end
			end
			E.band = nil
		end
		renderAll()
	end
	return true
end

------------------------------------------------------------------------------
-- header
------------------------------------------------------------------------------

local function headerButton( label, color, fn, size )
	return ui.button( G.header, label, 0, screenTop + ui.HEADER_HEIGHT / 2, fn, { color = color, size = size or 14 } )
end

function renderHeader()
	display.remove( G.header )
	G.header = display.newGroup()
	G.ui:insert( G.header )
	local y = screenTop + ui.HEADER_HEIGHT / 2
	local back = ui.button( G.header, "< back", c.left + 4, y, function() scene:leave() end, { color = gray, size = 14, align = "left" } )

	local right = {
		{ "preview", E.preview and blue or darkgray, function()
			E.preview = not E.preview
			E.t = 0
			if E.preview then E.selection = {} end
			renderAll()
		end },
		{ "hitboxes", E.hitboxes and blue or darkgray, function() E.hitboxes = not E.hitboxes; renderAll() end },
		{ "noclip", E.noclip and blue or darkgray, function()
			E.noclip = not E.noclip
			hint( E.noclip and "Noclip on: playtests count deaths instead of losing lives." or "Noclip off.", true )
			renderHeader()
		end },
		{ "undo", #E.undo > 0 and darkgray or lightgray, undo },
		{ "redo", #E.redo > 0 and darkgray or lightgray, redo },
		{ "settings", darkgray, function() scene:openSettings() end },
		{ "save", E.dirty and green or lightgray, function() scene:save() end },
		{ "play >", red, function() scene:playtest() end },
	}
	local x = c.right - 4
	for i = #right, 1, -1 do
		local r = right[i]
		local b = ui.button( G.header, r[1], x, y, r[3], { color = r[2], size = 13, align = "right" } )
		x = b.textObj.contentBounds.xMin - 8
	end

	-- "< Level 2 of 5 >" in the space that's left, smaller if it's a squeeze
	local n = #E.map.levels
	local lo, hi = back.textObj.contentBounds.xMax + 12, x - 4
	local function nav( size )
		local g = display.newGroup()
		G.header:insert( g )
		local label = ui.button( g, levelWord() .. " " .. E.levelIndex .. " of " .. n, ( lo + hi ) / 2, y, function()
			E.tab = "level"
			E.dockOpen = true
			renderAll()
		end, { color = black, size = size } )
		local lb = label.textObj.contentBounds
		local prev = ui.button( g, "<", lb.xMin - 11, y, function()
			if E.levelIndex > 1 then setLevel( E.levelIndex - 1 ) end
		end, { color = E.levelIndex > 1 and darkgray or lightgray, size = size + 2 } )
		local nxt = ui.button( g, ">", lb.xMax + 11, y, function()
			if E.levelIndex < n then setLevel( E.levelIndex + 1 ) end
		end, { color = E.levelIndex < n and darkgray or lightgray, size = size + 2 } )
		return g, prev.textObj.contentBounds.xMin, nxt.textObj.contentBounds.xMax
	end
	for _, size in ipairs( { 14, 12, 10 } ) do
		local g, x0, x1 = nav( size )
		if ( x0 >= lo and x1 <= hi ) or size == 10 then break end
		display.remove( g )
	end
end

------------------------------------------------------------------------------
-- palette (left), same as the game's
------------------------------------------------------------------------------

local function choosePalette( i )
	E.color = i
	sounds.play( sounds.palette and sounds.palette[i] or sounds.hits[i], 0.5 )
	local size = screenHeight / 6
	transition.to( G.paletteMark, { time = 300, x = screenLeft + size / 2, y = screenTop + size * ( i - 0.5 ), transition = easing.outExpo } )
	local sel = selectedList()
	local dots = false
	for _, it in ipairs( sel ) do if it.kind == "dot" then dots = true end end
	if dots then
		pushUndo()
		for _, it in ipairs( sel ) do if it.kind == "dot" then it.color = i end end
		renderAll()
	else
		renderDock()
	end
end

local function buildPalette( g )
	local size = screenHeight / 6
	for i, col in ipairs( ui.palette ) do
		local sq = display.newRect( g, screenLeft + size / 2, screenTop + size * ( i - 0.5 ), size, size )
		sq:setFillColor( col() )
		sq:addEventListener( "touch", function( event )
			if event.phase == "began" and not E.modal then choosePalette( i ) end
			return true
		end )
		ui.paletteKey( g, i, screenLeft + size / 2, screenTop + size * ( i - 0.5 ), size )
	end
	G.paletteMark = display.newImageRect( g, "images/palette_selection_square_240.png", size, size )
	G.paletteMark:setFillColor( black() )
	G.paletteMark.alpha = 0.25
	G.paletteMark.x, G.paletteMark.y = screenLeft + size / 2, screenTop + size * ( E.color - 0.5 )
end

------------------------------------------------------------------------------
-- object menu (bottom dock)
------------------------------------------------------------------------------

local function drawPrefabPreview( group, prefab, x, y )
	local built = prefab.build( E.color )
	local k = math.min( 1, 12.5 / prefabs.extent( built ) )
	for _, it in ipairs( built ) do
		local d = drawItem( group, it, x + it.x * k, y + it.y * k, math.max( 1, it.r * k ), true )
		if d.ring then d.ring.width, d.ring.height = ( it.r + 2.5 * ( it.hits - 1 ) ) * k * 2, ( it.r + 2.5 * ( it.hits - 1 ) ) * k * 2 end
	end
end

local function pageControls( body, key, pages, x0, x1, y )
	if pages <= 1 then return end
	local page = E.pages[key] or 1
	ui.button( body, "<", x0, y - 6, function()
		E.pages[key] = ( page - 2 ) % pages + 1
		renderDock()
	end, { color = darkgray, size = 18 } )
	ui.button( body, ">", x1, y - 6, function()
		E.pages[key] = page % pages + 1
		renderDock()
	end, { color = darkgray, size = 18 } )
	ui.text( body, page .. "/" .. pages, ( x0 + x1 ) / 2 > c.cx and x1 or x0, y + 12, 9, lightgray )
end

local function cellsTab( body, list, key, y, cellW )
	local CELL_W = cellW or CELL_W
	local left, right = c.left + 18, c.right - 18
	local perPage = math.floor( ( right - left ) / CELL_W )
	local pages = math.max( 1, math.ceil( #list / perPage ) )
	E.pages[key] = clamp( E.pages[key] or 1, 1, pages )
	local first = ( E.pages[key] - 1 ) * perPage + 1
	local used = math.min( perPage, #list - first + 1 )
	local x0 = c.cx - used * CELL_W / 2 + CELL_W / 2
	for i = first, math.min( first + perPage - 1, #list ) do
		local p = list[i]
		local x = x0 + ( i - first ) * CELL_W
		local selected = E.tool == "place" and E.brush == p
		local cell = ui.cell( body, x, y, CELL_W - 3, CELL_H, p.label, selected, function()
			if E.tool == "place" and E.brush == p then
				E.tool, E.brush = "select", nil
			else
				E.tool, E.brush = "place", p
				E.selection = {}
			end
			renderAll()
		end )
		drawPrefabPreview( cell.preview, p, x, y - 6 )
	end
	pageControls( body, key, pages, c.left + 8, c.right - 8, y )
end

local MOVE_CELLS = {
	{ "still", "still", "still" }, { "slide", "slide-h", "across", "h" }, { "slide", "slide-v", "up-down", "v" },
	{ "slide", "slide-d", "diagonal", "d" }, { "circle", "circle", "circle" }, { "wave", "wave", "wave" },
	{ "square", "square", "square" }, { "figure8", "figure8", "figure 8" }, { "pulse", "pulse", "pulse" },
}

local function slideVariant( mv )
	if math.abs( mv.dy ) < 0.5 then return "h" end
	if math.abs( mv.dx ) < 0.5 then return "v" end
	return "d"
end

-- the selection's movement kind (and slide direction), if they all share one
local function currentMoveKind()
	local g = selectionGroup()
	local mv
	if g then
		mv = g.move
	else
		local sel = selectedList()
		if #sel == 0 then return nil end
		mv = sel[1].move
		local k = mv and mv.type or "still"
		for _, it in ipairs( sel ) do if ( it.move and it.move.type or "still" ) ~= k then return nil end end
	end
	if not mv then return "still" end
	return mv.type, mv.type == "slide" and slideVariant( mv ) or nil
end

local function moveTab( body, y )
	local current, variant = currentMoveKind()
	local x0 = c.left + 26
	for i, m in ipairs( MOVE_CELLS ) do
		local x = x0 + ( i - 1 ) * CELL_W
		local cell = ui.cell( body, x, y, CELL_W - 3, CELL_H, m[3], current == m[1] and ( m[1] ~= "slide" or variant == m[4] ), function()
			applyMove( m[1], m[4] )
		end )
		ui.icon( cell.preview, m[2], x, y - 6, 11, ui.palette[E.color] )
	end
	local rx = c.right - 62
	ui.segmented( body, rx, y - 10, motion.AMOUNT, E.amount, function( i ) E.amount = i; renderDock() end, 11 )
	ui.segmented( body, rx, y + 10, motion.SPEED, E.speed, function( i ) E.speed = i; renderDock() end, 11 )
end

local function spinTab( body, y )
	local g = selectionGroup()
	local current = g and g.spin and g.spin.speed or 0
	local x0 = c.left + 26
	for i = 1, #motion.SPIN_SPEEDS do
		local x = x0 + ( i - 1 ) * CELL_W
		local on = selectedList()[1] ~= nil and current == motion.SPIN_SPEEDS[i] and ( g ~= nil or i == 1 )
		local cell = ui.cell( body, x, y, CELL_W - 3, CELL_H, motion.SPIN_LABEL[i], on, function() applySpin( i ) end )
		ui.icon( cell.preview, "spin" .. ( i - 1 ), x, y - 6, 11, ui.palette[E.color] )
	end
	local ax = x0 + #motion.SPIN_SPEEDS * CELL_W + 12
	local actions = {
		{ "group", groupSelection }, { "ungroup", ungroupSelection },
		{ "centre pivot", function()
			local gg = selectionGroup()
			if not gg then return hint( "Select a group first." ) end
			pushUndo()
			gg.pivot = nil
			renderAll()
		end },
	}
	for i, a in ipairs( actions ) do
		ui.button( body, a[1], ax, y - 16 + ( i - 1 ) * 15, a[2], { color = darkgray, size = 12, align = "left" } )
	end
	local rx = c.right - 66
	ui.text( body, "direction", rx, y - 15, 9, lightgray )
	ui.segmented( body, rx, y - 3, { "clockwise", "anti" }, E.spinDir == 1 and 1 or 2, function( i )
		E.spinDir = i == 1 and 1 or -1
		local gg = selectionGroup()
		if gg and gg.spin then pushUndo(); gg.spin.dir = E.spinDir; renderAll() else renderDock() end
	end, 11 )
	ui.text( body, g and g.spin and ( "one turn every " .. string.format( "%.1f", 360 / g.spin.speed ) .. "s" ) or "pick how fast it spins", rx, y + 16, 9, gray )
end

local function levelTab( body, y )
	local n = #E.map.levels
	local left, right = c.left + 18, c.right - 170
	local w = 52
	local perPage = math.floor( ( right - left ) / w )
	local pages = math.max( 1, math.ceil( ( n + 1 ) / perPage ) )
	E.pages.levels = clamp( E.pages.levels or math.ceil( E.levelIndex / perPage ), 1, pages )
	local first = ( E.pages.levels - 1 ) * perPage + 1
	for slot = 0, perPage - 1 do
		local i = first + slot
		local x = left + slot * w + w / 2
		if i <= n then
			local lv = E.map.levels[i]
			local cell = ui.cell( body, x, y, w - 4, CELL_H, lv.name, i == E.levelIndex, function() setLevel( i ) end )
			ui.thumbnail( cell.preview, lv, x, y - 6, w - 10, 26 )
		elseif i == n + 1 then
			local cell = ui.cell( body, x, y, w - 4, CELL_H, "new", false, function()
				if n >= levelfile.MAX_LEVELS then return end
				pushUndo()
				local lv = levelfile.newLevel( n + 1 )
				lv.name = levelWord() .. " " .. ( n + 1 )
				table.insert( E.map.levels, lv )
				setLevel( n + 1 )
			end )
			ui.text( cell.preview, "+", x, y - 7, 24, green )
		end
	end
	pageControls( body, "levels", pages, c.left + 8, right + 4, y )
	local ax = c.right - 150
	local acts = {
		{ "copy", blue, function()
			if n >= levelfile.MAX_LEVELS then return end
			pushUndo()
			local copy = ui.deepcopy( level() )
			copy.name = level().name .. " copy"
			table.insert( E.map.levels, E.levelIndex + 1, copy )
			setLevel( E.levelIndex + 1 )
		end },
		{ "delete", red, function()
			pushUndo()
			if n == 1 then E.map.levels[1] = levelfile.newLevel( 1 )
			else table.remove( E.map.levels, E.levelIndex ) end
			E.levelIndex = clamp( E.levelIndex, 1, #E.map.levels )
			sounds.play( sounds.bbCleared, 0.5 )
			E.selection = {}
			renderAll()
		end },
		{ "< move", darkgray, function()
			if E.levelIndex <= 1 then return end
			pushUndo()
			local l = E.map.levels
			l[E.levelIndex], l[E.levelIndex - 1] = l[E.levelIndex - 1], l[E.levelIndex]
			E.levelIndex = E.levelIndex - 1
			renderAll()
		end },
		{ "move >", darkgray, function()
			if E.levelIndex >= n then return end
			pushUndo()
			local l = E.map.levels
			l[E.levelIndex], l[E.levelIndex + 1] = l[E.levelIndex + 1], l[E.levelIndex]
			E.levelIndex = E.levelIndex + 1
			renderAll()
		end },
		{ "level settings", darkgray, function() scene:openSettings( "level" ) end },
	}
	for i, a in ipairs( acts ) do
		local col, rowI = ( i - 1 ) % 2, math.floor( ( i - 1 ) / 2 )
		ui.button( body, a[1], ax + col * 72, y - 15 + rowI * 15, a[3], { color = a[2], size = 12, align = "left" } )
	end
end

function renderDock()
	display.remove( G.dock )
	G.dock = display.newGroup()
	G.ui:insert( G.dock )
	local top = dockTop()
	local full = TAB_H + ( E.dockOpen and BODY_H or 0 )
	local bg = display.newRect( G.dock, c.cx, top + full / 2, c.w, full )
	bg:setFillColor( 1, 1, 1, 0.96 )
	bg:addEventListener( "touch", function() return true end )
	local strip = display.newRect( G.dock, c.cx, top + TAB_H / 2, c.w, TAB_H )
	strip:setFillColor( verylightgray() )
	local line = display.newRect( G.dock, c.cx, top, c.w, 1 )
	line:setFillColor( 0.8, 0.8, 0.8 )

	-- tabs
	local ty = top + TAB_H / 2
	local x = c.left + 8
	for _, name in ipairs( TABS ) do
		local on = E.tab == name and E.dockOpen
		local b = ui.button( G.dock, name, x, ty, function()
			if E.tab == name and E.dockOpen then E.dockOpen = false else E.tab, E.dockOpen = name, true end
			renderAll()
		end, { color = on and blue or darkgray, size = 13, align = "left" } )
		local tb = b.textObj.contentBounds
		if on then
			local u = display.newRect( G.dock, ( tb.xMin + tb.xMax ) / 2, top + TAB_H - 1.5, tb.xMax - tb.xMin + 6, 2 )
			u:setFillColor( blue() )
		end
		x = tb.xMax + 9
	end

	-- tools (right)
	local tools = {
		{ "select", E.tool == "select" and blue or darkgray, function() E.tool, E.brush = "select", nil; renderAll() end },
		{ "group select", E.tool == "lasso" and blue or darkgray, function() E.tool, E.brush = "lasso", nil; renderAll() end },
		{ "erase", E.tool == "erase" and blue or darkgray, function() E.tool, E.brush = "erase", nil; E.selection = {}; renderAll() end },
		{ "snap", E.snap and blue or lightgray, function() E.snap = not E.snap; renderDock() end },
		{ MIRROR_LABEL[E.mirror], E.mirror ~= "off" and blue or lightgray, function()
			for i, m in ipairs( MIRRORS ) do if m == E.mirror then E.mirror = MIRRORS[i % #MIRRORS + 1]; break end end
			renderAll()
		end },
	}
	local rx = c.right - 8
	for i = #tools, 1, -1 do
		local t = tools[i]
		local b = ui.button( G.dock, t[1], rx, ty, t[3], { color = t[2], size = 12, align = "right" } )
		rx = b.textObj.contentBounds.xMin - 9
		if i == 4 then
			local sep = display.newRect( G.dock, rx + 6, ty, 1, TAB_H - 6 )
			sep:setFillColor( 0.8, 0.8, 0.8 )
			rx = rx - 4
		end
	end

	if not E.dockOpen then return end
	local body = display.newGroup()
	G.dock:insert( body )
	local y = top + TAB_H + BODY_H / 2 + 1
	if E.tab == "dots" or E.tab == "blocks" or E.tab == "shapes" or E.tab == "zones" then
		cellsTab( body, prefabs.tab( E.tab ), E.tab, y, E.tab == "zones" and 54 or nil )
	elseif E.tab == "move" then
		moveTab( body, y )
	elseif E.tab == "spin" then
		spinTab( body, y )
	elseif E.tab == "level" then
		levelTab( body, y )
	end
end

------------------------------------------------------------------------------
-- details card (right)
------------------------------------------------------------------------------

local SPIN_STEPS = { 0, 15, 30, 45, 60, 90, 120, 180, 240, 300, 360, 480, 720 }

local function moveSize( mv, x, y )
	local k = mv.type
	if k == "slide" or k == "wave" then return math.sqrt( mv.dx ^ 2 + mv.dy ^ 2 ) end
	if k == "circle" then return math.sqrt( ( x - mv.cx ) ^ 2 + ( y - mv.cy ) ^ 2 ) end
	if k == "square" or k == "figure8" then return math.max( math.abs( mv.w ), math.abs( mv.h ) ) end
	return 0
end

local function turnTime( speed ) return string.format( "%.1fs", 360 / speed ) end

-- the card goes on whichever side hides less (the selection counts most)
local function detailsOnLeft( h )
	local W = DETAILS_W
	local top = c.top + 6
	local function covered( cx )
		local x0, x1, y0, y1 = cx - W / 2 - 4, cx + W / 2 + 4, top - 4, top + h + 4
		local n = 0
		for _, it in ipairs( items() ) do
			local px, py = c.left + it.x, c.top + it.y
			if px + it.r > x0 and px - it.r < x1 and py + it.r > y0 and py - it.r < y1 then
				n = n + ( E.selection[it] and 10 or 1 )
			end
		end
		return n
	end
	return covered( c.left + W / 2 + 6 ) < covered( c.right - W / 2 - 6 )
end

function renderDetails()
	display.remove( G.details )
	G.details = display.newGroup()
	G.ui:insert( G.details )
	local sel = selectedList()
	if #sel == 0 or E.preview or ( E.tool ~= "select" and E.tool ~= "lasso" ) then return end
	local W = DETAILS_W
	local top = c.top + 6
	if not E.detailsOpen then
		local tx = detailsOnLeft( 22 ) and ( c.left + 36 ) or ( c.right - 36 )
		ui.panel( G.details, tx, top + 11, 60, 22, 8 )
		ui.button( G.details, "details", tx, top + 11, function() E.detailsOpen = true; renderDetails() end, { color = gray, size = 12 } )
		return
	end

	local first = sel[1]
	local g = selectionGroup()
	local firstDot
	for _, it in ipairs( sel ) do if it.kind == "dot" then firstDot = it; break end end
	local mv, mx, my
	if g then
		mv = g.move
		mx, my = motion.pivot( level(), g )
	else
		mv = first.move
		for _, it in ipairs( sel ) do
			if ( it.move and it.move.type ) ~= ( mv and mv.type ) then mv = nil; break end
		end
		mx, my = first.x, first.y
	end
	local function eachMove( fn )
		if g then
			if g.move then fn( g.move, mx, my ) end
		else
			for _, it in ipairs( sel ) do if it.move then fn( it.move, it.x, it.y ) end end
		end
	end

	local rows = {}
	local function add( r ) rows[#rows + 1] = r end
	if firstDot then add( { kind = "colour" } ) end
	if g and #sel > 1 then
		add( { kind = "stepper", label = "size", get = function() return first.r end,
			change = function( d )
				-- the whole shape grows or shrinks, spacing and all
				local lo, hi = sizeLimits( first )
				local f = clamp( first.r + d * sizeStep( first, d ), lo, hi ) / first.r
				for _, it in ipairs( sel ) do
					it.x, it.y = clamp( mx + ( it.x - mx ) * f, 0, c.w ), clamp( my + ( it.y - my ) * f, 0, c.h )
					local ilo, ihi = sizeLimits( it )
					it.r = clamp( it.r * f, ilo, ihi )
					if it.move then
						if it.move.type == "circle" then
							it.move.cx, it.move.cy = mx + ( it.move.cx - mx ) * f, my + ( it.move.cy - my ) * f
						else
							scaleMove( it.move, f, it.x, it.y )
						end
					end
				end
				if g.move then scaleMove( g.move, f, mx, my ) end
			end, format = fmtSize } )
	else
		add( { kind = "stepper", label = "size", get = function() return first.r end,
			change = function( d ) for _, it in ipairs( sel ) do grow( it, d ) end end, format = fmtSize } )
	end
	if firstDot then
		add( { kind = "stepper", label = "hits", get = function() return firstDot.hits or 1 end,
			change = function( d )
				for _, it in ipairs( sel ) do if it.kind == "dot" then it.hits = clamp( ( it.hits or 1 ) + d, 1, 9 ) end end
			end } )
	end
	local firstShift
	for _, it in ipairs( sel ) do if it.kind == "dot" and it.color == "shift" then firstShift = it; break end end
	if firstShift then
		-- this dot's own colour-shift speed ("map" = the speed in Settings > rules)
		add( { kind = "stepper", label = "shift every", get = function() return firstShift.shiftMs or 0 end,
			change = function( d )
				local cur = firstShift.shiftMs
				local v
				if not cur then v = d > 0 and stepShift( E.map.rules.shiftMs, 1 ) or stepShift( E.map.rules.shiftMs, -1 )
				else v = stepShift( cur, d ) end
				for _, it in ipairs( sel ) do
					if it.kind == "dot" and it.color == "shift" then it.shiftMs = v end
				end
			end, format = function( v ) return v == 0 and "map's" or fmtShift( v ) end } )
	end
	add( { kind = "move" } )
	if mv then
		if mv.type == "pulse" then
			add( { kind = "stepper", label = "grows to", get = function() return mv.scale end,
				change = function( d ) eachMove( function( m ) m.scale = clamp( m.scale + d * 0.1, 0.3, 4 ) end ) end,
				format = function( v ) return string.format( "x%.1f", v ) end } )
		else
			add( { kind = "stepper", label = "distance", get = function() return moveSize( mv, mx, my ) end,
				change = function( d )
					eachMove( function( m, ix, iy ) scaleMove( m, d > 0 and 1.2 or 1 / 1.2, ix, iy ) end )
				end } )
		end
		add( { kind = "stepper", label = "one loop", get = function() return motion.period( mv ) end,
			change = function( d )
				eachMove( function( m ) m.ms = clamp( m.ms + d * ( m.ms < 2000 and 200 or 500 ), 200, 30000 ) end )
			end, format = function( v ) return string.format( "%.1fs", v / 1000 ) end } )
		if mv.type == "circle" or mv.type == "figure8" then
			add( { kind = "dir", get = function() return mv.dir or 1 end,
				set = function( v ) eachMove( function( m ) m.dir = v end ) end } )
		end
	end
	if g then
		add( { kind = "stepper", label = "spin", get = function() return g.spin and g.spin.speed or 0 end,
			change = function( d )
				local cur = g.spin and g.spin.speed or 0
				local i = 1
				for k, s in ipairs( SPIN_STEPS ) do if s <= cur then i = k end end
				local s = SPIN_STEPS[clamp( i + d, 1, #SPIN_STEPS )]
				g.spin = s > 0 and { speed = s, dir = g.spin and g.spin.dir or E.spinDir } or nil
			end, format = function( v ) return v == 0 and "off" or turnTime( v ) end } )
		if g.spin then
			add( { kind = "dir", get = function() return g.spin.dir end, set = function( v ) g.spin.dir = v end } )
		end
	end

	local rowH = 16
	local onLeft = detailsOnLeft( #rows * rowH + 75 )
	local x = onLeft and ( c.left + W / 2 + 6 ) or ( c.right - W / 2 - 6 )
	local panel = ui.panel( G.details, x, top + 60, W, 120, 10 )
	local title
	if g then title = "group of " .. #sel
	elseif #sel == 1 then
		if first.kind == "nodraw" then title = "no squiggles"
		elseif first.kind == "drawzone" then title = "squiggle here"
		else title = first.kind == "dot" and ( ( first.hits or 1 ) > 1 and "tough dot" or "dot" ) or "block" end
	else title = #sel .. " selected" end
	ui.text( G.details, title, x - W / 2 + 10, top + 13, 14, black, 0 )
	ui.button( G.details, "hide", x + W / 2 - 8, top + 13, function() E.detailsOpen = false; renderDetails() end,
		{ color = lightgray, size = 11, align = "right" } )
	local y = top + 31
	local lx, rx = x - W / 2 + 10, x + W / 2 - 10

	local function change( fn )
		pushUndo()
		fn()
		renderItems()
		renderOverlay()
		renderDetails()
	end

	for _, r in ipairs( rows ) do
		if r.kind == "colour" then
			local cur = firstDot.color
			for i, col in ipairs( ui.palette ) do
				local dx = lx + 5 + ( i - 1 ) * 13
				ui.dot( G.details, dx, y, 4.5, col )
				if cur == i then ui.ring( G.details, dx, y, 6.8, darkgray, 1.2 ) end
				local hit = display.newRect( G.details, dx, y, 13, 16 )
				hit.isVisible = false
				hit.isHitTestable = true
				ui.onTap( hit, function()
					sounds.play( sounds.palette and sounds.palette[i] or sounds.hits[i], 0.4 )
					change( function() for _, it in ipairs( sel ) do if it.kind == "dot" then it.color = i end end end )
				end, false )
			end
			ui.segmented( G.details, rx - 22, y, { "any", "shift" }, cur == "any" and 1 or ( cur == "shift" and 2 or 0 ), function( i )
				change( function()
					for _, it in ipairs( sel ) do if it.kind == "dot" then it.color = i == 1 and "any" or "shift" end end
				end )
			end, 11, 7 )
		elseif r.kind == "stepper" then
			ui.text( G.details, r.label, lx, y, 12, gray, 0 )
			local v = r.get()
			ui.text( G.details, r.format and r.format( v ) or tostring( math.floor( v + 0.5 ) ), rx - 28, y, 12, black )
			ui.button( G.details, "-", rx - 54, y - 1, function() change( function() r.change( -1 ) end ) end, { size = 16, color = darkgray } )
			ui.button( G.details, "+", rx - 2, y - 1, function() change( function() r.change( 1 ) end ) end, { size = 16, color = darkgray } )
		elseif r.kind == "move" then
			ui.text( G.details, "move", lx, y, 12, gray, 0 )
			if mv then
				ui.text( G.details, motion.LABEL[mv.type], lx + 44, y, 12, blue, 0 )
				ui.button( G.details, "stop", rx, y, function()
					change( function()
						if g then g.move = nil else for _, it in ipairs( sel ) do it.move = nil end end
					end )
				end, { color = red, size = 11, align = "right" } )
			else
				ui.button( G.details, "add movement", rx, y, function()
					E.tab, E.dockOpen = "move", true
					renderDock()
				end, { color = blue, size = 11, align = "right" } )
			end
		elseif r.kind == "dir" then
			ui.text( G.details, "direction", lx, y, 12, gray, 0 )
			ui.segmented( G.details, rx - 34, y, { "clockwise", "anti" }, r.get() == 1 and 1 or 2, function( i )
				change( function() r.set( i == 1 and 1 or -1 ) end )
			end, 11, 7 )
		end
		y = y + rowH
	end

	local line = display.newRect( G.details, x, y - rowH / 2 + 3, W - 20, 1 )
	line:setFillColor( 0.9, 0.9, 0.9 )
	local anyGrouped = false
	for _, it in ipairs( sel ) do if it.group then anyGrouped = true end end
	local acts = { { "copy", blue, duplicateSelection }, { "delete", red, deleteSelection } }
	if g or anyGrouped then acts[#acts + 1] = { "ungroup", darkgray, ungroupSelection } end
	if not g and #sel > 1 then acts[#acts + 1] = { "group", darkgray, groupSelection } end
	if #sel > 1 then acts[#acts + 1] = { "turn", darkgray, function() rotateSelection( 45 ) end } end
	acts[#acts + 1] = { "flip x", darkgray, function() flipSelection( "x" ) end }
	acts[#acts + 1] = { "flip y", darkgray, function() flipSelection( "y" ) end }
	if #sel > 1 and not g then acts[#acts + 1] = { "line up", darkgray, lineUp } end
	if #sel > 2 and not g then acts[#acts + 1] = { "spread", darkgray, spread } end
	local lastY = ui.flow( G.details, lx, y + 2, W - 20, acts, 11, 15, 8 )
	local h = lastY - top + 12
	panel.height = h
	panel.y = top + h / 2
end

------------------------------------------------------------------------------
-- hint line (what you can do right now) and item count
------------------------------------------------------------------------------

function renderStatus()
	display.remove( G.status )
	G.status = display.newGroup()
	G.ui:insert( G.status )
	local y = dockTop() - 8
	local sel = selectedList()
	local msg
	if E.preview then msg = "Previewing the movement. Press space or tap the paper to stop."
	elseif E.tool == "place" and E.brush then
		msg = "Tap the paper to place: " .. E.brush.label .. ( E.mirror ~= "off" and " (mirrored)" or "" ) .. ".  Esc stops placing."
	elseif E.tool == "erase" then msg = "Tap or drag across things to erase them."
	elseif E.tool == "lasso" then
		msg = #sel == 0 and "Draw a loop around things to select them all, or tap them one by one."
			or "Loop or tap to add more. Tap a selected thing to drop it; drag to move."
	elseif #sel == 0 then msg = "Tap something to select it, or drag a box around a few things."
	elseif selectionGroup() then msg = "Drag to move the group. Drag the blue cross to change what it spins around."
	elseif #sel == 1 then msg = "Drag to move it. Arrows nudge it. Ctrl-click picks one thing from a group."
	else msg = "Drag to move them together. Group them (ctrl + g) so they can spin as one." end
	local hintText = ui.text( G.status, msg, c.left + 8, y, 10, gray, 0 )
	local dots, blocks, zones = 0, 0, 0
	for _, it in ipairs( items() ) do
		if it.kind == "dot" then dots = dots + 1 elseif isZone( it ) then zones = zones + 1 else blocks = blocks + 1 end
	end
	local info = dots .. ( dots == 1 and " dot   " or " dots   " ) .. blocks .. ( blocks == 1 and " block" or " blocks" )
	if zones > 0 then info = info .. "   " .. zones .. ( zones == 1 and " zone" or " zones" ) end
	local counts = ui.text( G.status, info, c.right - 8, y, 10, #items() > levelfile.MAX_ITEMS - 20 and red or gray, 1 )
	if hintText.contentBounds.xMax > counts.contentBounds.xMin - 10 then
		hintText.xScale = ( counts.contentBounds.xMin - 10 - hintText.contentBounds.xMin ) / ( hintText.contentBounds.xMax - hintText.contentBounds.xMin )
		hintText.yScale = hintText.xScale
	end
end

------------------------------------------------------------------------------
-- whole screen
------------------------------------------------------------------------------

function renderAll()
	if not E.map then return end
	fitAll()
	renderItems()
	renderOverlay()
	renderHeader()
	renderDock()
	renderDetails()
	renderStatus()
end

------------------------------------------------------------------------------
-- settings
------------------------------------------------------------------------------

local function removeFields()
	for _, f in ipairs( fields ) do f:removeSelf() end
	fields = {}
end

local function closeModal()
	removeFields()
	display.remove( G.modal )
	G.modal = nil
	E.modal = false
	renderAll()
end

local function textField( group, x, y, w, h, value, multiline, size, onChange )
	local f = multiline and native.newTextBox( x, y, w, h ) or native.newTextField( x, y, w, h )
	f.font = ui.font()
	f.size = size or 16
	f:setTextColor( 0.25, 0.25, 0.25 )
	f.text = value or ""
	f:addEventListener( "userInput", function( event )
		if event.phase == "editing" or event.phase == "ended" or event.phase == "submitted" then
			onChange( f.text )
			E.dirty = true
		end
	end )
	fields[#fields + 1] = f
	if multiline then
		local frame = display.newRoundedRect( group, x, y, w + 8, h + 4, 5 )
		frame:setFillColor( 0, 0, 0, 0 )
		frame.strokeWidth = 1.2
		frame:setStrokeColor( 0.8, 0.8, 0.8 )
	else
		local under = display.newRect( group, x, y + h / 2, w, 1.2 )
		under:setFillColor( 0.8, 0.8, 0.8 )
	end
	return f
end

local function timeIndex( v )
	for i, s in ipairs( TIME_STEPS ) do if s == v then return i end end
	for i, s in ipairs( TIME_STEPS ) do if s > v then return i end end
	return #TIME_STEPS
end
local function fmtTime( v )
	if v < 0 then return "default" end
	if v == 0 then return "none" end
	return ui.fmtSeconds( v )
end
local function yesNo( v ) return v and "yes" or "no" end

local SECTIONS = { "map", "rules", "squiggles", "endless", "level", "editor", "keys" }

function scene:openSettings( section )
	removeFields()
	display.remove( G.modal )
	G.modal = display.newGroup()
	self.view:insert( G.modal )
	E.modal = true
	E.section = section or E.section or "map"
	local W, H = 440, 278
	local g = G.modal
	ui.dim( g, 0.12 )
	ui.card( g, _W2, _H2, W, H )
	local top, left = _H2 - H / 2, _W2 - W / 2
	ui.text( g, "Settings", left + 22, top + 24, 22, gray, 0 )

	-- section list
	for i, name in ipairs( SECTIONS ) do
		local on = E.section == name
		ui.button( g, name, left + 24, top + 60 + ( i - 1 ) * 24, function() scene:openSettings( name ) end,
			{ color = on and blue or darkgray, size = 16, align = "left" } )
		if on then ui.dot( g, left + 16, top + 59 + ( i - 1 ) * 24, 2.5, blue ) end
	end
	local divider = display.newRect( g, left + 104, _H2 + 10, 1, H - 70 )
	divider:setFillColor( 0.88, 0.88, 0.88 )

	local cx, cw = left + 104 + ( W - 104 ) / 2, W - 140
	local y = top + 60
	local m, rules = E.map, E.map.rules
	local function row( kind, label, get, change, fmt )
		local r
		if kind == "stepper" then
			r = ui.stepper( g, cx, y, cw, label, get, function( d ) change( d ); E.dirty = true end, fmt, 14 )
		else
			r = ui.toggle( g, cx, y, cw, label, get, function() change(); E.dirty = true end, fmt, 14 )
		end
		y = y + 23
		return r
	end

	if E.section == "map" then
		ui.text( g, "title", cx - cw / 2, y, 13, gray, 0 )
		textField( g, cx + 30, y - 2, cw - 60, 22, m.title, false, 17, function( t ) m.title = t:sub( 1, 40 ) end )
		y = y + 32
		ui.text( g, "description", cx - cw / 2, y, 13, gray, 0 )
		textField( g, cx + 4, y + 46, cw - 8, 58, m.description, true, 14, function( t ) m.description = t:sub( 1, 300 ) end )
		y = y + 96
		ui.text( g, "made by", cx - cw / 2, y, 13, gray, 0 )
		textField( g, cx + 30, y - 2, cw - 60, 22, m.author, false, 16, function( t ) m.author = t:sub( 1, 24 ) end )
	elseif E.section == "rules" then
		ui.text( g, "mode", cx - cw / 2, y, 14, gray, 0 )
		ui.segmented( g, cx + 60, y, { "levels in order", "endless waves" }, m.mode == "levels" and 1 or 2, function( i )
			local want = i == 1 and "levels" or "endless"
			if m.mode ~= want then
				pushUndo()
				m.mode = want
				E.dirty = true
				-- keep default names in step: "Level 3" <-> "Pattern 3"
				for _, lv in ipairs( m.levels ) do
					local n = lv.name:match( "^Level (%d+)$" ) or lv.name:match( "^Pattern (%d+)$" )
					if n then lv.name = levelWord() .. " " .. n end
				end
			end
			scene:openSettings( "rules" )
		end, 14 )
		y = y + 24
		ui.text( g, "goal", cx - cw / 2, y, 14, gray, 0 )
		ui.segmented( g, cx + 60, y, { "high score", "just finish it" }, rules.goal == "complete" and 2 or 1, function( i )
			local want = i == 2 and "complete" or "score"
			if rules.goal ~= want then pushUndo(); rules.goal = want; E.dirty = true end
			scene:openSettings( "rules" )
		end, 14 )
		y = y + 25
		row( "stepper", "lives", function() return rules.lives end, function( d ) rules.lives = clamp( rules.lives + d, 0, 20 ) end,
			function( v ) return v == 0 and "unlimited" or tostring( v ) end )
		row( "stepper", "time limit", function() return rules.time end, function( d )
			rules.time = TIME_STEPS[clamp( timeIndex( rules.time ) + d, 2, #TIME_STEPS )]
		end, fmtTime )
		row( "toggle", "blocks cost a life", function() return rules.blocksCostLife end, function() rules.blocksCostLife = not rules.blocksCostLife end, yesNo )
		row( "stepper", "shifting dots change", function() return rules.shiftMs end, function( d )
			rules.shiftMs = stepShift( rules.shiftMs, d )
			renderItems()
		end, function( v ) return "every " .. fmtShift( v ) end )
		y = y + 2
		ui.text( g, rules.goal == "complete" and "No score: clear every level to complete the map."
			or "Every dot cleared scores a point.", cx, y, 11, lightgray )
	elseif E.section == "squiggles" then
		row( "stepper", isEndless() and "squiggles each wave" or "squiggles each level", function() return rules.squiggles end,
			function( d ) rules.squiggles = clamp( rules.squiggles + d, 0, 30 ) end,
			function( v ) return v == 0 and "unlimited" or tostring( v ) end )
		row( "toggle", "one squiggle at a time", function() return rules.oneStroke end, function() rules.oneStroke = not rules.oneStroke end, yesNo )
		row( "toggle", "one squiggle per colour", function() return rules.onePerColor end, function() rules.onePerColor = not rules.onePerColor end, yesNo )
		row( "stepper", "squiggle speed", function() return rules.speed end, function( d ) rules.speed = clamp( rules.speed + d * 0.25, 0.5, 2 ) end,
			function( v ) return "x" .. string.format( "%.2g", v ) end )
		y = y + 6
		ui.text( g, "Zones (in the zones tab) change where you can squiggle:", cx, y, 11, lightgray )
		ui.text( g, "nobody can squiggle in a shaded circle, and while a dashed", cx, y + 14, 11, lightgray )
		ui.text( g, "circle is on the paper you can only squiggle inside one.", cx, y + 28, 11, lightgray )
	elseif E.section == "endless" then
		local e = m.endless
		if m.mode ~= "endless" then
			ui.text( g, "These apply when Rules > mode is endless waves.", cx, y, 12, lightgray )
			y = y + 22
		end
		row( "stepper", "patterns in the first wave", function() return e.start end, function( d ) e.start = clamp( e.start + d, 1, 8 ); e.max = math.max( e.max, e.start ) end )
		row( "stepper", "most patterns at once", function() return e.max end, function( d ) e.max = clamp( e.max + d, e.start, 8 ) end )
		row( "stepper", "add a pattern every", function() return e.every end, function( d ) e.every = clamp( e.every + d, 1, 20 ) end,
			function( v ) return v .. ( v == 1 and " wave" or " waves" ) end )
		row( "toggle", "random colours", function() return e.recolor end, function() e.recolor = not e.recolor end, yesNo )
		row( "toggle", "speed up every wave", function() return e.speedUp end, function() e.speedUp = not e.speedUp end, yesNo )
	elseif E.section == "level" then
		local lv = level()
		ui.text( g, levelWord() .. " " .. E.levelIndex .. " of " .. #m.levels, cx, y, 14, black )
		y = y + 26
		ui.text( g, "name", cx - cw / 2, y, 13, gray, 0 )
		textField( g, cx + 30, y - 2, cw - 60, 22, lv.name, false, 17, function( t ) lv.name = t:sub( 1, 30 ) end )
		y = y + 32
		if not isEndless() then
			row( "stepper", "time limit", function() return lv.time end, function( d ) lv.time = TIME_STEPS[clamp( timeIndex( lv.time ) + d, 1, #TIME_STEPS )] end, fmtTime )
			row( "stepper", "squiggles", function() return lv.squiggles or -1 end,
				function( d ) lv.squiggles = clamp( ( lv.squiggles or -1 ) + d, -1, 30 ) end,
				function( v ) return v < 0 and "default" or ( v == 0 and "unlimited" or tostring( v ) ) end )
			row( "toggle", "lose lives on this level", function() return not lv.bonus end, function() lv.bonus = not lv.bonus end,
				function( v ) return v and "yes" or "no (bonus)" end )
			y = y + 4
			ui.text( g, "\"default\" uses the map's own time limit and squiggles.", cx, y, 11, lightgray )
		else
			ui.text( g, "In endless mode each level is a pattern; waves mix them.", cx, y, 12, lightgray )
		end
	elseif E.section == "editor" then
		row( "toggle", "snap to the paper's grid", function() return E.snap end, function() E.snap = not E.snap end, yesNo )
		row( "toggle", "mirror placing", function() return E.mirror end, function()
			for i, mm in ipairs( MIRRORS ) do if mm == E.mirror then E.mirror = MIRRORS[i % #MIRRORS + 1]; break end end
		end, function( v ) return v == "off" and "off" or ( v == "xy" and "both ways" or ( "across " .. v ) ) end )
		row( "toggle", "show movement paths", function() return E.showPaths end, function() E.showPaths = not E.showPaths end, yesNo )
		row( "toggle", "show hitboxes", function() return E.hitboxes end, function() E.hitboxes = not E.hitboxes end, yesNo )
		row( "toggle", "noclip in playtests", function() return E.noclip end, function() E.noclip = not E.noclip end, yesNo )
		y = y + 4
		ui.text( g, "Noclip: nothing costs a life. Deaths and accuracy", cx, y, 11, lightgray )
		ui.text( g, "show at the bottom right while you playtest.", cx, y + 14, 11, lightgray )
	elseif E.section == "keys" then
		local keys = {
			{ "ctrl + z / y", "undo / redo" }, { "delete", "delete the selection" },
			{ "ctrl + c / x / v", "copy / cut / paste" }, { "ctrl + d", "duplicate" },
			{ "ctrl + g", "group (shift: ungroup)" }, { "ctrl + a", "select everything" },
			{ "arrows", "nudge (shift: a square)" }, { "r", "turn (shift: other way)" },
			{ "[  /  ]", "smaller / bigger" },
			{ "space", "preview movement" }, { "h / n / g", "hitboxes / noclip / snap" },
			{ "1 - 6", "pick a colour" }, { "v / l / e", "select / group select / erase" },
			{ "shift + click", "add to the selection" }, { "ctrl + click", "one thing in a group" },
			{ "open tab", "tap it again to hide the menu" },
		}
		for i, k in ipairs( keys ) do
			local col, rowI = ( i - 1 ) % 2, math.floor( ( i - 1 ) / 2 )
			local kx = cx - cw / 2 + col * ( cw / 2 + 6 )
			ui.text( g, k[1], kx, y + rowI * 24.5 - 6, 12, black, 0 )
			ui.text( g, k[2], kx, y + rowI * 24.5 + 6, 10, gray, 0 )
		end
	end

	ui.button( g, "done", left + W - 40, top + H - 22, closeModal, { color = black, alpha = 0.6, size = 18 } )
end

function scene:confirmLeave()
	removeFields()
	display.remove( G.modal )
	G.modal = display.newGroup()
	self.view:insert( G.modal )
	E.modal = true
	local g = G.modal
	ui.dim( g, 0.12 )
	ui.card( g, _W2, _H2, 280, 150 )
	ui.text( g, "Save your changes?", _W2, _H2 - 40, 22, darkgray )
	ui.button( g, "save", _W2 - 85, _H2 + 36, function()
		closeModal()
		scene:save()
		composer.gotoScene( "scene_create" )
	end, { color = green, size = 20 } )
	ui.button( g, "don't save", _W2, _H2 + 36, function()
		closeModal()
		E.dirty = false
		composer.gotoScene( "scene_create" )
	end, { color = red, size = 20 } )
	ui.button( g, "cancel", _W2 + 90, _H2 + 36, closeModal, { color = black, alpha = 0.6, size = 20 } )
end

------------------------------------------------------------------------------
-- save, leave, playtest
------------------------------------------------------------------------------

function scene:save()
	local m = E.map
	m.modified = os.time()
	m.version = levelfile.VERSION
	if not m.author or m.author == "" then m.author = mods.profiles.currentName() end
	if not m.title or m.title:gsub( "%s", "" ) == "" then m.title = "Untitled Map" end
	for _, lv in ipairs( m.levels ) do levelfile.pruneGroups( lv ) end
	library.put( ui.deepcopy( m ) )
	E.dirty = false
	sounds.play( sounds.levelup, 0.6 )
	toast.show( "Saved!", { time = 1200 } )
	ach.unlock( "CREATE_SAVE" )
	renderHeader()
end

function scene:leave()
	if E.modal then return end
	if E.dirty then scene:confirmLeave() else composer.gotoScene( "scene_create" ) end
end

function scene:playtest()
	if E.modal then return end
	local check = isEndless() and E.map.levels or { level() }
	local hasDots = false
	for _, lv in ipairs( check ) do
		for _, it in ipairs( lv.items ) do if it.kind == "dot" then hasDots = true end end
	end
	if not hasDots then return hint( isEndless() and "Add some dots to a pattern first." or "Add some dots to this level first." ) end
	E.preview = false
	library.playtest( ui.deepcopy( E.map ), isEndless() and 1 or E.levelIndex, function()
		composer.gotoScene( "scene_editor", { params = { resume = true } } )
	end, E.hitboxes, E.noclip )
end

------------------------------------------------------------------------------
-- keyboard
------------------------------------------------------------------------------

local function nudge( dx, dy )
	local sel = selectedList()
	if #sel == 0 then return end
	pushUndo()
	dx, dy = fitDelta( sel, dx, dy )
	for _, it in ipairs( sel ) do
		it.x, it.y = it.x + dx, it.y + dy
		if it.move and it.move.type == "circle" then it.move.cx, it.move.cy = it.move.cx + dx, it.move.cy + dy end
	end
	local g = selectionGroup()
	if g then
		if g.pivot then g.pivot.x, g.pivot.y = g.pivot.x + dx, g.pivot.y + dy end
		if g.move and g.move.type == "circle" then g.move.cx, g.move.cy = g.move.cx + dx, g.move.cy + dy end
	end
	renderItems()
	renderOverlay()
end

local function onKey( event )
	if not E.visible then return false end
	local k = event.keyName
	if k == "leftShift" or k == "rightShift" then E.keys.shift = event.phase == "down"; return false end
	if k == "leftCtrl" or k == "rightCtrl" or k == "leftCommand" then E.keys.ctrl = event.phase == "down"; return false end
	if event.phase ~= "down" then return false end
	local ctrl = event.isCtrlDown or event.isCommandDown
	if E.modal then
		if k == "escape" then closeModal(); return true end
		return false
	end
	if ctrl and k == "z" then if event.isShiftDown then redo() else undo() end return true end
	if ctrl and k == "y" then redo(); return true end
	if ctrl and k == "d" then duplicateSelection(); return true end
	if ctrl and k == "c" then copySelection(); return true end
	if ctrl and k == "x" then copySelection(); deleteSelection(); return true end
	if ctrl and k == "v" then pasteClipboard(); return true end
	if ctrl and k == "g" then if event.isShiftDown then ungroupSelection() else groupSelection() end return true end
	if ctrl and k == "s" then scene:save(); return true end
	if ctrl and k == "a" then
		E.tool, E.brush = "select", nil
		for _, it in ipairs( items() ) do E.selection[it] = true end
		renderAll()
		return true
	end
	if k == "deleteBack" or k == "deleteForward" then deleteSelection(); return true end
	if k == "escape" then
		if E.brush then E.tool, E.brush = "select", nil else E.selection = {} end
		renderAll()
		return true
	end
	local step = event.isShiftDown and gridStep() or 1
	if k == "left" then nudge( -step, 0 ); return true end
	if k == "right" then nudge( step, 0 ); return true end
	if k == "up" then nudge( 0, -step ); return true end
	if k == "down" then nudge( 0, step ); return true end
	if k == "space" then E.preview = not E.preview; E.t = 0; if E.preview then E.selection = {} end; renderAll(); return true end
	if k == "h" then E.hitboxes = not E.hitboxes; renderAll(); return true end
	if k == "n" then E.noclip = not E.noclip; renderHeader(); return true end
	if k == "r" then rotateSelection( event.isShiftDown and -45 or 45 ); return true end
	if k == "[" or k == "]" then
		local sel = selectedList()
		if #sel == 0 then return true end
		pushUndo()
		for _, it in ipairs( sel ) do grow( it, k == "]" and 1 or -1 ) end
		renderAll()
		return true
	end
	if k == "g" then E.snap = not E.snap; renderDock(); renderStatus(); return true end
	if k == "v" then E.tool, E.brush = "select", nil; renderAll(); return true end
	if k == "l" then E.tool, E.brush = "lasso", nil; renderAll(); return true end
	if k == "e" then E.tool, E.brush = "erase", nil; E.selection = {}; renderAll(); return true end
	local n = tonumber( k )
	if n and n >= 1 and n <= 6 then choosePalette( n ); return true end
	return false
end

------------------------------------------------------------------------------
-- animation: preview movement, any-colour and shifting dots
------------------------------------------------------------------------------

local function animate()
	if not E.visible then return end
	E.anim = ( E.anim or 0 ) + 1 / ( _FPS or 60 ) / 0.9
	local f = E.anim % 6
	local i = math.floor( f )
	local k = f - i
	local r1, g1, b1 = ui.palette[i + 1]()
	local r2, g2, b2 = ui.palette[( i + 1 ) % 6 + 1]()
	local ms = E.anim * 0.9 * 1000
	for _, a in ipairs( animated ) do
		if a.obj and a.obj.setFillColor then
			if a.kind == "any" then a.obj:setFillColor( r1 + ( r2 - r1 ) * k, g1 + ( g2 - g1 ) * k, b1 + ( b2 - b1 ) * k )
			else a.obj:setFillColor( ui.palette[( math.floor( ms / a.ms ) % 6 ) + 1]() ) end
		end
	end
	if E.preview and not E.modal then
		E.t = E.t + 1000 / ( _FPS or 60 )
		local pos = currentPositions()
		for it, p in pairs( pos ) do
			local d = disp[it]
			if d then
				local x, y = c.left + p.x, c.top + p.y
				if d.circle and d.circle.setFillColor then
					d.circle.x, d.circle.y = x, y
					d.circle.width, d.circle.height = p.r * 2, p.r * 2
				end
				if d.ring and d.ring.setFillColor then
					d.ring.x, d.ring.y = x, y
					local rr = ( p.r + 2.5 * ( ( it.hits or 1 ) - 1 ) ) * 2
					d.ring.width, d.ring.height = rr, rr
				end
				if d.box and d.box.setFillColor then
					d.box.x, d.box.y = x, y
					d.box.width, d.box.height = p.r * 2, p.r * 2
				end
				if d.mark and d.mark.setFillColor then d.mark.x, d.mark.y = x, y end
				if d.zone and d.zone.removeSelf then
					d.zone.x, d.zone.y = x, y
					local zk = p.r / d.zone.r0
					d.zone.xScale, d.zone.yScale = zk, zk
				end
			end
		end
	end
end

------------------------------------------------------------------------------
-- scene
------------------------------------------------------------------------------

function scene:create( event )
	c = ui.canvas()
	local g = self.view
	local bg = display.newRect( g, _W2, _H2, screenWidth, screenHeight )
	bg:setFillColor( white() )
	local paper = display.newImageRect( g, "images/graph_paper_1230x919.jpg", screenWidth, screenWidth * 919 / 1230 )
	paper.alpha = 0.15
	paper.x, paper.y = c.cx, c.cy

	G.touch = display.newRect( g, c.cx, c.cy, c.w, c.h )
	G.touch.isVisible = false
	G.touch.isHitTestable = true
	G.touch:addEventListener( "touch", canvasTouch )

	G.itemsHost = display.newGroup(); g:insert( G.itemsHost )
	G.overlayHost = display.newGroup(); g:insert( G.overlayHost )
	G.lassoHost = display.newGroup(); g:insert( G.lassoHost )
	G.ui = display.newGroup(); g:insert( G.ui )

	local header = display.newRect( G.ui, _W2, screenTop + ui.HEADER_HEIGHT / 2, screenWidth, ui.HEADER_HEIGHT )
	header:setFillColor( verylightgray() )
	header:addEventListener( "touch", function() return true end )
	local paletteGroup = display.newGroup()
	G.ui:insert( paletteGroup )
	buildPalette( paletteGroup )
end

function scene:show( event )
	if event.phase == "will" then
		local p = event.params or {}
		if p.mapId then
			local m = library.get( p.mapId )
			E.map = m and levelfile.sanitize( ui.deepcopy( m ) ) or levelfile.newMap( mods.profiles.currentName() )
			E.levelIndex, E.selection, E.undo, E.redo, E.dirty = 1, {}, {}, {}, false
			E.tool, E.brush, E.preview = "select", nil, false
		elseif p.newMap or not E.map then
			E.map = levelfile.newMap( mods.profiles.currentName() )
			E.levelIndex, E.selection, E.undo, E.redo, E.dirty = 1, {}, {}, {}, true
			E.tool, E.brush, E.preview, E.tab, E.dockOpen = "place", prefabs.dots[1], false, "dots", true
		end
		E.visible = true
		E.keys = {}
		renderAll()
	elseif event.phase == "did" then
		Runtime:addEventListener( "enterFrame", animate )
		Runtime:addEventListener( "key", onKey )
	end
end

function scene:hide( event )
	if event.phase == "will" then
		E.visible = false
		Runtime:removeEventListener( "enterFrame", animate )
		Runtime:removeEventListener( "key", onKey )
		removeFields()
		display.remove( G.modal )
		G.modal = nil
		E.modal = false
	end
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
return scene
