------------------------------------------------------------------------------
-- mod_create.lua
-- The map library behind Create mode: saving, importing and exporting .blix
-- files, and starting a map (normally or as a playtest).
------------------------------------------------------------------------------

local composer = require "composer"
local levelfile = mods.levelfile

local M = {}

local saver = require "_saver"
M.data = saver.Load( "maps.txt" )
if type( M.data ) ~= "table" or type( M.data.maps ) ~= "table" then M.data = { maps = {} } end
-- bring maps from older versions up to date (and drop anything unreadable)
do
	local maps = {}
	for _, m in ipairs( M.data.maps ) do
		local ok, fixed = pcall( levelfile.sanitize, m )
		if ok and fixed then maps[#maps + 1] = fixed end
	end
	M.data.maps = maps
end

local function save() saver.Save( M.data, "maps.txt" ) end

function M.list() return M.data.maps end

function M.get( id )
	for i, m in ipairs( M.data.maps ) do if m.id == id then return m, i end end
	return nil
end

-- store a map (newest first); returns true if it replaced an older copy
function M.put( map )
	local _, i = M.get( map.id )
	if i then table.remove( M.data.maps, i ) end
	table.insert( M.data.maps, 1, map )
	save()
	return i ~= nil
end

function M.remove( id )
	local _, i = M.get( id )
	if i then table.remove( M.data.maps, i ); save() end
end

-- each player's progress on custom maps: { [id] = { best = levels cleared or
-- best wave, done = finished every level } } (completion maps show this)
local PROGRESS = "custom_progress.txt"

function M.progressFor( id )
	local d = saver.Load( PROGRESS )
	return type( d ) == "table" and d[id] or nil
end

function M.recordProgress( id, reached, completed )
	local d = saver.Load( PROGRESS )
	if type( d ) ~= "table" then d = {} end
	local p = type( d[id] ) == "table" and d[id] or {}
	p.best = math.max( tonumber( p.best ) or 0, reached or 0 )
	if completed then p.done = true end
	d[id] = p
	saver.Save( d, PROGRESS )
	return p
end

function M.export( map )
	return native.saveTextFile( levelfile.filename( map ), levelfile.encode( map ) )
end

-- load a .blix file's text into the library
function M.import( text )
	local map, err = levelfile.decode( text )
	if not map then return nil, err end
	local replaced = M.put( map )
	return map, replaced
end

function M.pickFile( onDone )
	native.openTextFile( function( event )
		if event.isError then
			if not event.cancelled then toast.show( "Couldn't open that file.", { time = 1600 } ) end
			return
		end
		local map, replacedOrErr = M.import( event.text )
		if not map then
			toast.show( replacedOrErr, { time = 1800 } )
			sounds.play( sounds.die, 0.3 )
			return
		end
		sounds.play( sounds.bbCleared, 0.6 )
		toast.show( ( replacedOrErr and "Updated: " or "Loaded: " ) .. map.title, { time = 1600 } )
		if onDone then onDone( map ) end
	end, ".blix,.json,application/json" )
end

-- ignore a second tap while the game scene is already on its way in
local lastStart = -10000
local function startGame( params )
	local now = system.getTimer()
	if now - lastStart < 1500 then return end
	lastStart = now
	composer.gotoScene( "scene_game", { params = params } )
end

function M.play( map )
	startGame( { game = require( "game_custom" ).new( map ), skip_instructions = false } )
end

function M.playtest( map, startLevel, onExit, hitboxes, noclip )
	startGame( { game = require( "game_custom" ).new( map, {
		playtest = true, startLevel = startLevel, onExit = onExit, hitboxes = hitboxes, noclip = noclip,
	} ), skip_instructions = true } )
end

-- dropping a .blix file anywhere on the game loads it
Runtime:addEventListener( "fileDropped", function( event )
	local name = ( event.filename or "" ):lower()
	if not ( name:match( "%.blix$" ) or name:match( "%.json$" ) ) then return end
	local map, replacedOrErr = M.import( event.text )
	if not map then
		toast.show( replacedOrErr, { time = 1800 } )
		return
	end
	sounds.play( sounds.bbCleared, 0.6 )
	toast.show( ( replacedOrErr and "Updated: " or "Loaded: " ) .. map.title, { time = 1600 } )
	local scene = composer.getScene( "scene_create" )
	if scene and scene.refresh and composer.getSceneName( "current" ) == "scene_create" then scene:refresh( map.id ) end
end )

mods.library = M
return M
