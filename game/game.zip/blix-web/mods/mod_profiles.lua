------------------------------------------------------------------------------
-- mod_profiles.lua
-- Local player profiles. Each profile keeps its own high scores and
-- achievements; device settings (sound, etc.) stay shared.
------------------------------------------------------------------------------

local M = {}

local saver = require "_saver"

local json = require "json"

-- files that belong to a profile rather than the device
local PER_PROFILE = {
	["progress.txt"] = true, ["__progress.txt"] = true,
	["achievements.txt"] = true, ["__achievements.txt"] = true,
	["custom_progress.txt"] = true, ["__custom_progress.txt"] = true,
}

local _pathForFile = system.pathForFile
local function rawPath( name ) return _pathForFile( name, system.DocumentsDirectory ) end

local function profileDir( id ) return "profiles/p" .. tostring( id ) .. "/" end

system.pathForFile = function( name, base )
	if name and base == system.DocumentsDirectory and PER_PROFILE[name] and M.data and M.data.current then
		return _pathForFile( profileDir( M.data.current ) .. name, base )
	end
	return _pathForFile( name, base )
end

local function readRaw( path )
	local f = io.open( path, "r" )
	if not f then return nil end
	local s = f:read( "*a" )
	f:close()
	return s
end
local function writeRaw( path, s )
	local f = io.open( path, "w" )
	if f then f:write( s ); f:close() end
end

function M.pathFor( id, name ) return rawPath( profileDir( id ) .. name ) end

local function save() saver.Save( M.data, "profiles.txt" ) end

M.data = saver.Load( "profiles.txt" )
if type( M.data ) ~= "table" or type( M.data.list ) ~= "table" then
	M.data = { list = {}, current = nil, nextId = 1 }
end

function M.list() return M.data.list end
function M.get( id )
	for _, p in ipairs( M.data.list ) do if p.id == id then return p end end
	return nil
end
function M.current() return M.get( M.data.current ) end
function M.currentName() local p = M.current(); return p and p.name or "" end

local function nextColor()
	local used = {}
	for _, p in ipairs( M.data.list ) do used[p.color] = true end
	for i = 1, 6 do if not used[i] then return i end end
	return ( #M.data.list % 6 ) + 1
end

function M.create( name )
	local id = M.data.nextId or ( #M.data.list + 1 )
	M.data.nextId = id + 1
	local p = { id = id, name = name, color = nextColor(), created = os.time() }
	table.insert( M.data.list, p )
	save()
	return p
end

function M.rename( id, name )
	local p = M.get( id )
	if p then p.name = name; save() end
end

-- small per-player flags (e.g. "tutorialDone"), kept with the profile list
function M.flag( key )
	local p = M.current()
	return p and p.flags and p.flags[key] or nil
end
function M.setFlag( key, value )
	local p = M.current()
	if not p then return end
	p.flags = p.flags or {}
	if p.flags[key] ~= value then p.flags[key] = value; save() end
end

-- reload everything that was read from the previous profile's files
local function reloadProfileData()
	if package.loaded["progress"] then
		package.loaded["progress"] = nil
		progress = require "progress"
	end
	if mods.achievements then mods.achievements.reload() end
end

function M.switch( id )
	if not M.get( id ) or M.data.current == id then return end
	M.data.current = id
	save()
	reloadProfileData()
end

function M.remove( id )
	if #M.data.list <= 1 then return false end
	for name in pairs( PER_PROFILE ) do os.remove( M.pathFor( id, name ) ) end
	for i, p in ipairs( M.data.list ) do
		if p.id == id then table.remove( M.data.list, i ); break end
	end
	if M.data.current == id then
		M.data.current = M.data.list[1].id
		save()
		reloadProfileData()
	else
		save()
	end
	return true
end

-- Best scores of every profile, read straight from their files.
function M.scoresFor( id )
	local s = readRaw( M.pathFor( id, "progress.txt" ) )
	local t = s and json.decode( s )
	return ( type( t ) == "table" and t.gameScores ) or {}
end

-- First run: create "Player 1" and move any existing saves into it.
if #M.data.list == 0 then
	local p = M.create( "Player 1" )
	M.data.current = p.id
	for name in pairs( PER_PROFILE ) do
		local s = readRaw( rawPath( name ) )
		if s then writeRaw( M.pathFor( p.id, name ), s ) end
	end
	save()
elseif not M.get( M.data.current ) then
	M.data.current = M.data.list[1].id
	save()
end

return M
