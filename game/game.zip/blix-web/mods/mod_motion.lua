------------------------------------------------------------------------------
-- mod_motion.lua
-- Movement and spin for Create-mode objects. The editor preview and the game
-- use the same maths, so what you see while editing is what you play.
--
-- Positions are in "paper" coordinates (0,0 = top-left of the play area).
-- A movement gives an offset (dx, dy) and a size factor at time t (ms).
-- A group can spin around its pivot, and move/pulse as one piece.
------------------------------------------------------------------------------

local M = {}

local pi, sin, cos, sqrt, floor = math.pi, math.sin, math.cos, math.sqrt, math.floor

M.TYPES = { "slide", "circle", "wave", "square", "figure8", "pulse" }
M.LABEL = { slide = "slide", circle = "circle", wave = "wave", square = "square", figure8 = "figure 8", pulse = "pulse" }

-- offset of one movement at time t for something based at (x, y)
function M.offset( mv, t, x, y )
	if not mv then return 0, 0, 1 end
	local ms = math.max( 100, mv.ms or 2000 )
	local kind = mv.type
	if kind == "slide" then
		local p = ( 1 - cos( pi * t / ms ) ) / 2          -- there and back again
		return mv.dx * p, mv.dy * p, 1
	elseif kind == "circle" then
		local rx, ry = x - mv.cx, y - mv.cy
		local a = ( mv.dir or 1 ) * 2 * pi * t / ms
		local c, s = cos( a ), sin( a )
		return mv.cx + rx * c - ry * s - x, mv.cy + rx * s + ry * c - y, 1
	elseif kind == "wave" then
		local p = ( 1 - cos( pi * t / ms ) ) / 2
		local len = sqrt( mv.dx * mv.dx + mv.dy * mv.dy )
		if len < 0.001 then len = 1 end
		local nx, ny = -mv.dy / len, mv.dx / len
		local w = sin( p * 2 * pi * ( mv.waves or 2 ) ) * ( mv.amp or 20 )
		return mv.dx * p + nx * w, mv.dy * p + ny * w, 1
	elseif kind == "square" then
		local f = ( t / ms ) % 1
		local seg = floor( f * 4 )
		local k = f * 4 - seg
		local w, h = mv.w or 60, mv.h or 60
		if seg == 0 then return w * k, 0, 1
		elseif seg == 1 then return w, h * k, 1
		elseif seg == 2 then return w * ( 1 - k ), h, 1
		else return 0, h * ( 1 - k ), 1 end
	elseif kind == "figure8" then
		local a = ( mv.dir or 1 ) * 2 * pi * t / ms
		return ( mv.w or 60 ) / 2 * sin( a ), ( mv.h or 40 ) / 2 * sin( 2 * a ), 1
	elseif kind == "pulse" then
		local p = ( 1 - cos( 2 * pi * t / ms ) ) / 2
		return 0, 0, 1 + ( ( mv.scale or 1.6 ) - 1 ) * p
	end
	return 0, 0, 1
end

-- how long until a movement repeats (ms)
function M.period( mv )
	if not mv then return 0 end
	local ms = mv.ms or 2000
	if mv.type == "slide" or mv.type == "wave" then return 2 * ms end
	return ms
end

function M.groupsById( level )
	local out = {}
	for _, g in ipairs( level.groups or {} ) do out[g.id] = g end
	return out
end

function M.members( level, gid )
	local out = {}
	for _, it in ipairs( level.items ) do if it.group == gid then out[#out + 1] = it end end
	return out
end

function M.pivot( level, g )
	if g.pivot then return g.pivot.x, g.pivot.y end
	local sx, sy, n = 0, 0, 0
	for _, it in ipairs( level.items ) do
		if it.group == g.id then sx, sy, n = sx + it.x, sy + it.y, n + 1 end
	end
	if n == 0 then return 0, 0 end
	return sx / n, sy / n
end

-- where everything is at time t: item -> { x, y, r }
function M.positions( level, t, out )
	out = out or {}
	local transforms = {}
	for _, g in ipairs( level.groups or {} ) do
		local px, py = M.pivot( level, g )
		local ox, oy, s = M.offset( g.move, t, px, py )
		local a = 0
		if g.spin and ( g.spin.speed or 0 ) ~= 0 then a = math.rad( g.spin.speed * ( g.spin.dir or 1 ) * t / 1000 ) end
		transforms[g.id] = { px = px, py = py, ox = ox, oy = oy, s = s, c = cos( a ), sn = sin( a ) }
	end
	for _, it in ipairs( level.items ) do
		local dx, dy, s = M.offset( it.move, t, it.x, it.y )
		local x, y, r = it.x + dx, it.y + dy, it.r * s
		local tr = it.group and transforms[it.group]
		if tr then
			local rx, ry = ( x - tr.px ) * tr.s, ( y - tr.py ) * tr.s
			x = tr.px + tr.ox + rx * tr.c - ry * tr.sn
			y = tr.py + tr.oy + rx * tr.sn + ry * tr.c
			r = r * tr.s
		end
		local p = out[it]
		if p then p.x, p.y, p.r = x, y, r else out[it] = { x = x, y = y, r = r } end
	end
	return out
end

function M.isAnimated( level )
	for _, g in ipairs( level.groups or {} ) do
		if g.move or ( g.spin and ( g.spin.speed or 0 ) ~= 0 ) then return true end
	end
	for _, it in ipairs( level.items ) do if it.move then return true end end
	return false
end

-- longest repeat time in the level
function M.levelPeriod( level )
	local p = 0
	for _, g in ipairs( level.groups or {} ) do
		p = math.max( p, M.period( g.move ) )
		if g.spin and ( g.spin.speed or 0 ) ~= 0 then p = math.max( p, 360000 / math.abs( g.spin.speed ) ) end
	end
	for _, it in ipairs( level.items ) do p = math.max( p, M.period( it.move ) ) end
	return p
end

-- area covered over a full cycle (x0, y0, x1, y1), including sizes
function M.bounds( level, samples )
	local x0, y0, x1, y1 = math.huge, math.huge, -math.huge, -math.huge
	local period = M.levelPeriod( level )
	samples = period > 0 and ( samples or 48 ) or 1
	local pos = {}
	for i = 0, samples - 1 do
		M.positions( level, period * i / samples, pos )
		for _, p in pairs( pos ) do
			x0, y0 = math.min( x0, p.x - p.r ), math.min( y0, p.y - p.r )
			x1, y1 = math.max( x1, p.x + p.r ), math.max( y1, p.y + p.r )
		end
	end
	return x0, y0, x1, y1
end

-- Keep a circle of radius r on the paper (w x h, 0,0 = top-left) so dots and
-- blocks never cover the colour palette, the header or the screen's edge.
function M.inside( x, y, r, w, h )
	if w < 2 * r then x = w / 2 else x = math.max( r, math.min( w - r, x ) ) end
	if h < 2 * r then y = h / 2 else y = math.max( r, math.min( h - r, y ) ) end
	return x, y
end

-- the outer radius of a dot or block (a tough dot's ring is bigger)
function M.outer( it, r )
	return ( r or it.r ) + 2.5 * ( ( it.hits or 1 ) - 1 )
end

-- a few points along a movement's path, for drawing guides
function M.trail( mv, x, y, n )
	local pts = {}
	-- slides and waves come back the way they went: draw the way there once
	local period = ( mv.type == "slide" or mv.type == "wave" ) and ( mv.ms or 2000 ) or M.period( mv )
	n = n or 24
	for i = 0, n do
		local dx, dy = M.offset( mv, period * i / n, x, y )
		pts[#pts + 1] = { x = x + dx, y = y + dy }
	end
	return pts
end

-- presets used by the editor's Move tab: amount 1..3, speed 1..3
M.AMOUNT = { "small", "medium", "large" }
M.SPEED = { "slow", "normal", "fast" }
local SPEED_MS = { 4000, 2400, 1300 }

function M.preset( kind, amount, speed, x, y, extra )
	amount, speed = amount or 2, speed or 2
	local ms = SPEED_MS[speed]
	extra = extra or {}
	if kind == "slide" then
		local d = ( { 40, 80, 140 } )[amount]
		local ax, ay = extra.ax or 1, extra.ay or 0
		local l = sqrt( ax * ax + ay * ay )
		return { type = "slide", dx = d * ax / l, dy = d * ay / l, ms = ms }
	elseif kind == "circle" then
		local r = ( { 20, 35, 55 } )[amount]
		return { type = "circle", cx = x - r, cy = y, ms = ms * 1.3, dir = extra.dir or 1 }
	elseif kind == "wave" then
		local d = ( { 80, 120, 180 } )[amount]
		return { type = "wave", dx = d, dy = 0, amp = ( { 12, 20, 32 } )[amount], waves = 2, ms = ms * 1.3 }
	elseif kind == "square" then
		local s = ( { 40, 70, 110 } )[amount]
		return { type = "square", w = s, h = s, ms = ms * 2 }
	elseif kind == "figure8" then
		local s = ( { 50, 80, 130 } )[amount]
		return { type = "figure8", w = s, h = s * 0.6, ms = ms * 1.5, dir = extra.dir or 1 }
	elseif kind == "pulse" then
		return { type = "pulse", scale = ( { 1.3, 1.6, 2.0 } )[amount], ms = ms }
	end
	return nil
end

M.SPIN_SPEEDS = { 0, 45, 90, 180, 300 }
M.SPIN_LABEL = { "no spin", "slow", "medium", "fast", "very fast" }

return M
