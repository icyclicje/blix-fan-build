------------------------------------------------------------------------------
-- scene_achievements.lua
-- Local achievements and high scores (opened by the Game Center button).
------------------------------------------------------------------------------

local composer = require "composer"
local ui = mods.ui
local ach = mods.achievements

local scene = composer.newScene()

local W, H = 330, 272
local PER_PAGE = 5
local tab, page = "achievements", 1
local panel, tabA, tabS

local function pages()
	if tab == "achievements" then return math.ceil( #ach.defs / PER_PAGE ) end
	return #ach.boards
end

local render

local function setTab( t )
	tab, page = t, 1
	render()
end

function render()
	display.remove( panel )
	panel = display.newGroup()
	scene.view:insert( panel )
	ui.relabel( tabA, nil, tab == "achievements" and blue or lightgray )
	ui.relabel( tabS, nil, tab == "scores" and blue or lightgray )

	local top = _H2 - H / 2
	local left = _W2 - W / 2 + 24
	if tab == "achievements" then
		local got, total = ach.count()
		ui.text( panel, got .. " of " .. total .. " unlocked", _W2, top + 50, 12, gray )
		local first = ( page - 1 ) * PER_PAGE + 1
		for i = first, math.min( first + PER_PAGE - 1, #ach.defs ) do
			local d = ach.defs[i]
			local y = top + 82 + ( i - first ) * 34
			local on = ach.isUnlocked( d.id )
			ui.dot( panel, left + 6, y, on and 7 or 5, on and yellow or verylightgray )
			ui.text( panel, d.name, left + 22, y - 7, 16, on and black or lightgray, 0 )
			ui.text( panel, d.desc, left + 22, y + 9, 11, on and gray or lightgray, 0 )
		end
	else
		local b = ach.boards[page]
		ui.text( panel, b.title, _W2, top + 54, 20, b.color )
		local rows = ach.board( b.name )
		if #rows == 0 then
			ui.text( panel, "No scores yet.", _W2, _H2, 16, lightgray )
		end
		for i = 1, math.min( 6, #rows ) do
			local r = rows[i]
			local y = top + 86 + ( i - 1 ) * 26
			ui.text( panel, i .. ".", left + 4, y, 16, gray, 0 )
			ui.text( panel, r.profile.name, left + 26, y, 18, ui.palette[r.profile.color] or darkgray, 0 )
			ui.text( panel, ui.commas( r.score ), _W2 + W / 2 - 24, y, 18, black, 1 )
			if b.showLevel and r.level > 0 then
				ui.text( panel, "level " .. r.level, _W2 + W / 2 - 84, y + 1, 11, gray, 1 )
			end
		end
	end

	local fy = top + H - 24
	if pages() > 1 then
		ui.button( panel, "<", _W2 - W / 2 + 34, fy, function()
			page = ( page - 2 ) % pages() + 1
			render()
		end, { color = darkgray, size = 20 } )
		ui.text( panel, page .. "/" .. pages(), _W2 - W / 2 + 64, fy, 13, gray )
		ui.button( panel, ">", _W2 - W / 2 + 94, fy, function()
			page = page % pages() + 1
			render()
		end, { color = darkgray, size = 20 } )
	end
	ui.button( panel, "back", _W2 + W / 2 - 40, fy, function()
		composer.hideOverlay( false, "zoomOutIn", 100 )
	end, { color = black, alpha = 0.6, size = 16 } )
end

function scene:create( event )
	local g = self.view
	ui.dim( g, 0.1 )
	ui.card( g, _W2, _H2, W, H )
	local top = _H2 - H / 2
	tabA = ui.button( g, "Achievements", _W2 - 64, top + 24, function() setTab( "achievements" ) end, { size = 20 } )
	tabS = ui.button( g, "High Scores", _W2 + 72, top + 24, function() setTab( "scores" ) end, { size = 20 } )
end

function scene:show( event )
	if event.phase == "will" then
		tab = ( event.params and event.params.tab ) or "achievements"
		page = 1
		render()
	end
end

scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
return scene
